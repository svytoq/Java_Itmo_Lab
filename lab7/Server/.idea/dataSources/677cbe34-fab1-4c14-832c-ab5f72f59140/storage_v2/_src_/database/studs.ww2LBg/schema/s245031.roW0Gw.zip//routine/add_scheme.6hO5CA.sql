create function add_scheme(gun integer, grip integer, mag integer, barrel integer, stock integer, sight integer) returns integer
    language plpgsql
as
$$
DECLARE
    scheme_id integer;
BEGIN
    scheme_id := (SELECT max(id) from "Чертежи_оружия") + 1;
    INSERT INTO "Чертежи_оружия" (id, рукоять, приклад, прицел, ствол, магазин, затвор)
    VALUES (scheme_id, grip, stock, sight, barrel, mag, gun);

    RETURN scheme_id;
END;
$$;

alter function add_scheme(integer, integer, integer, integer, integer, integer) owner to s245031;

