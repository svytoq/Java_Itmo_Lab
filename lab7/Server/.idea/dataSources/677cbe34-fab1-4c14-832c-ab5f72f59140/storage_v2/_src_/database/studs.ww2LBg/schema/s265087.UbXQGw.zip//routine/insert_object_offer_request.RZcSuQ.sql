create function insert_object_offer_request(name character varying, content character varying, author integer, offer integer, object integer) returns void
    language plpgsql
as
$$
DECLARE
    REQUEST_ID INTEGER;
BEGIN
    INSERT INTO REQUEST (NAME, CONTENT, AUTHOR)
    VALUES (NAME, CONTENT, AUTHOR)
    RETURNING id INTO REQUEST_ID;
    INSERT INTO OBJECT_OFFER_REQUEST (REQUEST, OFFER, OBJECT)
    VALUES (REQUEST_ID, OFFER, OBJECT);
END;
$$;

alter function insert_object_offer_request(varchar, varchar, integer, integer, integer) owner to s265087;

