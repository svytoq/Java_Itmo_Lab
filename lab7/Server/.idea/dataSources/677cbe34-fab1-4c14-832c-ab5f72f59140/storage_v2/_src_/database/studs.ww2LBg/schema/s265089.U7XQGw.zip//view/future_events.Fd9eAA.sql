create view future_events(event_date, title, event_place, employee) as
SELECT ev.event_date,
       ev.title,
       ev.event_place,
       (em.first_name::text || ' '::text) || em.last_name::text AS employee
FROM s265089.events ev
         JOIN s265089.employees em USING (employee_id)
WHERE ev.event_date > 'now'::text::date
ORDER BY ev.event_date;

alter table future_events
    owner to s265089;

