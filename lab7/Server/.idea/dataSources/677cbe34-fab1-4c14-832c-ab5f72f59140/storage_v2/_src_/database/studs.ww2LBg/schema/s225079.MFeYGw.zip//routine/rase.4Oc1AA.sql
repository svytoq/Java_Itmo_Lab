create function rase() returns trigger
    language plpgsql
as
$$
BEGIN
    IF OLD.ТИП NOT IN ('НЕ ОПРЕДЕЛЕНО') THEN
	RAISE NOTICE 'ТИП РАСЫ НЕ МОЖЕТ ИЗМЕНИТЬСЯ!';
	RETURN OLD;
	ELSE RETURN NEW;
	END IF;
END;
$$;

alter function rase() owner to s225079;

