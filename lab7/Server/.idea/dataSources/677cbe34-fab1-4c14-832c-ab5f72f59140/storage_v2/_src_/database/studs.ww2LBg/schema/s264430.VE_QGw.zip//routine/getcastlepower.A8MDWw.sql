create function getcastlepower(id text) returns bigint
    language sql
as
$$
select SUM(ОБОРОННАЯ_МОЩЬ) from ЗЕМЛЯ
inner join ЗАМОК on ЗАМОК.НАЗВАНИЕ_ЗЕМЛИ = $1
where ЗЕМЛЯ.НАЗВАНИЕ = $1
$$;

alter function getcastlepower(text) owner to s264430;

