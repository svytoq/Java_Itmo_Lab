create function plus_smth() returns trigger
    language plpgsql
as
$$
declare
new_id integer;
begin
new_id=new.Group_ID;
if(tg_relname='members')
then
if(exists(select * from groups where ID=new_id))
then 
update groups set Number_of_characters=Number_of_characters+1 where ID=new_id; 
end if;
elsif(tg_relname='messenger')
then
if(exists(select * from groups where ID=new_id))
then 
update groups set Number_of_messengers=Number_of_messengers+1 where ID=new_id; 
end if;
end if;
return new;
end;
$$;

alter function plus_smth() owner to s225054;

