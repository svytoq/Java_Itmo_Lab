create function transferdatanew1() returns SETOF character varying
    language plpgsql
as
$$
declare
ta integer;
a integer;
b integer;
r integer;
c timestamp;
s text;
k varchar(100);
begin
for r in 1..100000
loop
ta = floor(random()*3);
a = floor(random ()*100000000);
b = floor(random ()*100000000);
c = fx_rndtime(1);
case when ta=1 then s='HEAVEN'; when ta=2 then s='HELL'; else s='PURGATORY';
end case;
INSERT INTO Transfer  ( idTransfer ,  idHuman ,  TransferDate ,  TransferDirection ) VALUES (a, b, c, s);
end loop;
end
$$;

alter function transferdatanew1() owner to s243135;

