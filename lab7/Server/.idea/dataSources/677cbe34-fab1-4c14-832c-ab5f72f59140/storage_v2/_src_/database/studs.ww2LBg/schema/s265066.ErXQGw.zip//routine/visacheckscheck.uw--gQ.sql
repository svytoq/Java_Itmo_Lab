create function visacheckscheck() returns trigger
    language plpgsql
as
$$
begin
    if NEW.is_finished then
        if not exists(
            select 1 from Visa_check_employees
            where visa_check_id=NEW.visa_check_id
        ) then
        return NULL; end if;
    end if;
    return NEW;
end;
$$;

alter function visacheckscheck() owner to s265066;

