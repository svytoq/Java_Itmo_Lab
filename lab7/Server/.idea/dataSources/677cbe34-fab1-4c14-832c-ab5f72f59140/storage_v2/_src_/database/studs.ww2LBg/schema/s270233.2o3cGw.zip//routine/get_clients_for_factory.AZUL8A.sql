create function get_clients_for_factory(factory_id integer)
    returns TABLE(name character varying, surname character varying)
    language sql
as
$$
SELECT humans.name, humans.surname
FROM humans
WHERE (humans.id IN (SELECT clients.human_id
                     FROM clients
                     WHERE (clients.delivery_place_id IN (SELECT providers.delivery_place_id
                                                          FROM providers
                                                          WHERE (providers.factory_id = $1)))));
$$;

alter function get_clients_for_factory(integer) owner to s270233;

