create function songs_by(id integer)
    returns TABLE(song_id integer, name character, instr character, meaning character)
    language sql
as
$$
select songs.song_id, songs.name, songs.meaning, instruments.name from songs, instruments
where songs.hero_id = id and songs.instrument_id = instruments.instrument_id;
$$;

alter function songs_by(integer) owner to s191928;

