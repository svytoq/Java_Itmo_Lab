create function abil_id_ins() returns trigger
    language plpgsql
as
$$
DECLARE
seq_id integer;
max_id integer;
BEGIN
SELECT currval('К_Способности_Id_seq') INTO seq_id;
SELECT max(Id) INTO max_id FROM "К_Способности";
IF (seq_id = max_id) THEN
NEW.Id := nextval('К_Способности_Id_seq');
ELSEIF (seq_id != NEW.Id) THEN
NEW.Id := nextval('К_Способности_Id_seq');
END IF;
RETURN NEW;
END;
$$;

alter function abil_id_ins() owner to s243870;

