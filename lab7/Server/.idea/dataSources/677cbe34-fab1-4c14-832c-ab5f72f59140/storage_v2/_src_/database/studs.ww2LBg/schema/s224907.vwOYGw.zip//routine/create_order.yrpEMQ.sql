create function create_order(shop_id_in integer, address_lat_in double precision, address_lng_in double precision, customer_id_in integer) returns integer
    language plpgsql
as
$$
declare
    order_id int;
begin
    insert into "order"(address_lat, address_lng, shop_id, customer_id, status)
    values (address_lat_in, address_lng_in, shop_id_in, customer_id_in, 'Поиск курьера')
    returning id into order_id;
    return order_id;
end;
$$;

alter function create_order(integer, double precision, double precision, integer) owner to s224907;

