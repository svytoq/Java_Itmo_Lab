create function проверка_билета() returns trigger
    language plpgsql
as
$$
DECLARE 
	места_ид_зала int;
	сеансы_ид_зала int;
BEGIN

SELECT Места.ид_зала INTO места_ид_зала FROM "Места" WHERE ид = NEW.ид_места;
SELECT Сеансы.ид_зала INTO сеансы_ид_зала FROM "Сеансы" WHERE ид = NEW.ид_сеанса;
IF места_ид_зала <> сеансы_ид_зала THEN
	RAISE EXCEPTION 'ИД зала, указанный в информации о месте билета (%) не соответствует ИД зала, указанному в сеансах (%)', места_ид_зала, сеансы_ид_зала;
END IF;

RETURN NEW;
END;
$$;

alter function проверка_билета() owner to s224932;

