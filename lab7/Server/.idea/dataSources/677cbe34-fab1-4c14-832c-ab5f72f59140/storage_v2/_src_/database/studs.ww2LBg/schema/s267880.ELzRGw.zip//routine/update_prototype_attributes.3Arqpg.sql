create function update_prototype_attributes(product_prototype_id integer, description text, modifier s267880.modifier_type) returns integer
    language sql
as
$$
update product_prototype set description = $2, modifier = $3 where product_prototype_id = $1 returning product_prototype_id;
$$;

alter function update_prototype_attributes(integer, text, s267880.modifier_type) owner to s267880;

