create function "ДУЭЛИ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('ДУЭЛИ_ИД_ДУЭЛЬ_seq')!=NEW.ИД_ДУЭЛЬ THEN NEW.ИД_ДУЭЛЬ=nextval('ДУЭЛИ_ИД_ДУЭЛЬ_seq');
  RETURN NEW;
ELSE
  RETURN NEW; 
END IF; 
END;
$$;

alter function "ДУЭЛИ_ИД"() owner to s225071;

