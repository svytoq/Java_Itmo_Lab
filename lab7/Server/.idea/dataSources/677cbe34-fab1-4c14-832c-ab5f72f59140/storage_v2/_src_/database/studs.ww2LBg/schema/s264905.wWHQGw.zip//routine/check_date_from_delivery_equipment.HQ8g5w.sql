create function check_date_from_delivery_equipment() returns trigger
    language plpgsql
as
$$
DECLARE
	count_of_miner integer;
BEGIN
	IF (NEW.date_work <> (SELECT DISTINCT delivery_date FROM Delivery_Equipment INNER JOIN Brigade_record ON Delivery_Equipment.miner_id = Brigade_record.miner_id
						  WHERE Brigade_record.brigade_id = NEW.brigade_id)) THEN
		RAISE 'Дата не может отличаться от даты выдачи оборудования';
	ELSE
		RETURN NEW;
	END IF;
END;
$$;

alter function check_date_from_delivery_equipment() owner to s264905;

