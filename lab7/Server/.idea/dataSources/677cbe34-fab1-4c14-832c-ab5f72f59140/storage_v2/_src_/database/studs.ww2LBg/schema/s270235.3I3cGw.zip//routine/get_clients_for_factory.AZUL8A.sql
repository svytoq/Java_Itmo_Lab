create function get_clients_for_factory(id_factory integer)
    returns TABLE(name character varying, surname character varying)
    language sql
as
$$
SELECT humans.name, humans.surname
FROM humans
WHERE (humans.id_human IN (SELECT clients.id_human
                           FROM clients
                           WHERE (clients.id_delivery_place IN (SELECT providers.id_delivery_place
                                                                FROM providers
                                                                WHERE (providers.id_factory = $1)))));
$$;

alter function get_clients_for_factory(integer) owner to s270235;

