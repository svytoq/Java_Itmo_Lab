create view sound_person
            (s_name, s_coor_x, s_coor_y, volume, start_time, duration, name, coor_x, coor_y, time_p, get_distance) as
SELECT s.name                                                         AS s_name,
       s.coor_x                                                       AS s_coor_x,
       s.coor_y                                                       AS s_coor_y,
       s.volume,
       s.start_time,
       s.duration,
       p.name,
       pp.coor_x,
       pp.coor_y,
       pp.time_p,
       s264449.get_distance(s.coor_x, s.coor_y, pp.coor_x, pp.coor_y) AS get_distance
FROM s264449.sound_fact s
         CROSS JOIN s264449.person_position pp
         JOIN s264449.person p ON p.id = pp.person_id;

alter table sound_person
    owner to s264449;

