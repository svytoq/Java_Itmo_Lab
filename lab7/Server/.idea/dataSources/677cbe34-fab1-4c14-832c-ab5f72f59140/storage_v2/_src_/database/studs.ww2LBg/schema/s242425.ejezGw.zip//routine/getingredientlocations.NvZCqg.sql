create function getingredientlocations(idingredient integer, minamount integer)
    returns TABLE("ИД_ЛОКАЦИИ" integer, "НАЗВАНИЕ" text, "ШИРОТА" real, "ДОЛГОТА" real, "КОЛИЧЕСТВО" integer)
    language sql
as
$$
select loc.ИД_ЛОКАЦИИ,
        aqu.НАЗВАНИЕ,
        loc.ШИРОТА,
        loc.ДОЛГОТА,
        loc.КОЛИЧЕСТВО
    from ЛОКАЦИЯ as loc
        join АКВАТОРИЯ as aqu using(ИД_АКВАТОРИИ)
    where loc.ИД_СУЩЕСТВА = (select ИД_СУЩЕСТВА from getCreatureInfo(idIngredient))
    group by loc.ИД_ЛОКАЦИИ, aqu.НАЗВАНИЕ, loc.ШИРОТА, loc.ДОЛГОТА, loc.КОЛИЧЕСТВО
    having loc.КОЛИЧЕСТВО > minAmount
$$;

alter function getingredientlocations(integer, integer) owner to s242425;

