create function createvillain(charactername text, venemies integer, vdamage integer) returns text
    language plpgsql
as
$$
declare
    id_ch int;
begin
    insert into character(name) values (characterName) returning id_character into id_ch;
    insert into villain(id_character, enemies, damage) values (id_ch, vEnemies, vDamage);
    return 'Волшебник создан! id - ' || id_ch;
end;
$$;

alter function createvillain(text, integer, integer) owner to s264912;

