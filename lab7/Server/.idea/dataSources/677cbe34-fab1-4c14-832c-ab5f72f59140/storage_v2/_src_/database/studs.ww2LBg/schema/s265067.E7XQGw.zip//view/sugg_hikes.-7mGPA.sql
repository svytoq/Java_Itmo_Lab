create view sugg_hikes
            (num, type_hike, category, com_ncom, number_days, month, name, country, cost_rub, number_people) as
SELECT row_number() OVER () AS num,
       type_hike.type_hike,
       hikes.category,
       hikes.com_ncom,
       hikes.number_days,
       hikes.month,
       places.name,
       places.country,
       hikes.cost_rub,
       hikes.number_people
FROM s265067.hiketype_places
         RIGHT JOIN s265067.hikes ON hiketype_places.type_id = hikes.type_id
         RIGHT JOIN s265067.type_hike ON hikes.type_id = type_hike.type_id
         JOIN s265067.places ON hiketype_places.place_id = places.place_id;

alter table sugg_hikes
    owner to s265067;

