create function "ВЫДАТЬ_СЕРТИФИКАТ"() returns trigger
    language plpgsql
as
$$
DECLARE
	stud_level integer;
	sale smallint;
BEGIN
	IF (NEW.ТИП='СЕРТИФИКАТ' AND NEW.РЕЗУЛЬТАТ=TRUE) THEN
		stud_level:=NEW.УРОВЕНЬ;
		stud_level:=stud_level+1;
		UPDATE УЧЕНИК SET (УРОВЕНЬ,ГРУППА_ИД,ОЖИДАНИЕ,СТОИМОСТЬ_ОБУЧЕНИЯ)=(stud_level,NULL,false,17500) WHERE УЧЕНИК_ИД=NEW.УЧЕНИК_ИД;
		INSERT INTO СЕРТИФИКАТ(УЧЕНИК_ИД,ЭКЗАМЕН_ИД) VALUES (NEW.УЧЕНИК_ИД,NEW.ЭКЗАМЕН_ИД);
	ELSIF (NEW.ТИП='ТЕСТИРОВАНИЕ' AND NEW.РЕЗУЛЬТАТ=TRUE) THEN
		stud_level:=NEW.УРОВЕНЬ;
		UPDATE УЧЕНИК SET (УРОВЕНЬ,ГРУППА_ИД,ОЖИДАНИЕ,СТОИМОСТЬ_ОБУЧЕНИЯ)=(stud_level,NULL,false,18500) WHERE УЧЕНИК_ИД=NEW.УЧЕНИК_ИД;
	END IF;
	RETURN NEW;
END;
$$;

alter function "ВЫДАТЬ_СЕРТИФИКАТ"() owner to s265057;

