create function seqtonull() returns void
    language plpgsql
as
$$
DECLARE
  sequences text[] = '{СТРАНА_УЧАСТНИЦА_ИД_СТРАНЫ_seq, СТАДИОН_ИД_СТАДИОНА_seq, СУДЬЯ_ИД_СУДЬИ_seq, ФОРМА_ИГРОКОВ_ИД_ФОРМЫ_ИГРОКОВ_seq,
  ИГРОК_ИД_ИГРОКА_seq, ОТЕЛЬ_ИД_ОТЕЛЯ_seq, ЗАСЕЛЕНИЕ_ИД_ЗАСЕЛЕНИЯ_seq, МАТЧ_ИД_МАТЧА_seq, КАРТОЧКА_ИД_КАРТОЧКИ_seq, ГОЛ_ИД_ГОЛА_seq}';
  i INTEGER DEFAULT 1;
BEGIN

  for i in 1..10 loop
      PERFORM pg_catalog.setval(sequences[i], 1, true);
  end loop;
END;
$$;

alter function seqtonull() owner to s224514;

