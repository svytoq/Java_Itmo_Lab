create function insert_service_suggestion(name_suggestion character varying, description_suggestion character varying, name_service character varying, description_service character varying, author integer) returns void
    language plpgsql
as
$$
DECLARE
    SERVICE_ID    INTEGER;
    SUGGESTION_ID INTEGER;
BEGIN
    INSERT INTO SERVICE (NAME, DESCRIPTION, USER_ID)
    VALUES (NAME_SERVICE, DESCRIPTION_SERVICE, AUTHOR)
    RETURNING id INTO SERVICE_ID;
    INSERT INTO SUGGESTION (NAME, DESCRIPTION, CREATION_DATE, AUTHOR)
    VALUES (NAME_SUGGESTION, DESCRIPTION_SUGGESTION, CURRENT_TIMESTAMP, AUTHOR)
    RETURNING id INTO SUGGESTION_ID;
    INSERT INTO SERVICE_SUGGESTION (SUGGESTION, SERVICE)
    VALUES (SUGGESTION_ID, SERVICE_ID);
END;
$$;

alter function insert_service_suggestion(varchar, varchar, varchar, varchar, integer) owner to s265087;

