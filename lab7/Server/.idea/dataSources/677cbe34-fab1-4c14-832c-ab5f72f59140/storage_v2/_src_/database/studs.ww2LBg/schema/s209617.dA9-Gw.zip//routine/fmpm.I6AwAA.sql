create function fmpm() returns trigger
    language plpgsql
as
$$
begin
    update prisoner SET faction = new.name
    where person_id = new.main_person;
    return new;
  end;
$$;

alter function fmpm() owner to s209617;

