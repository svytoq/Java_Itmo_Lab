create function insert_random_device_and_detectors() returns void
    language plpgsql
as
$$
declare
    min_val integer;
    max_val integer;
    ip inet;
    ret_id integer;

begin
    ret_id := insert_device_and_detectors(random_string(100), random_string(200));
    for i in 1..10 loop
            min_val := floor(random() * 1000 + 1)::int;
            max_val := floor(random() * 1000 + 1)::int + 1000;
            ip := CONCAT(
                    TRUNC(RANDOM() * 250 + 2), '.' ,
                    TRUNC(RANDOM() * 250 + 2), '.',
                    TRUNC(RANDOM() * 250 + 2), '.',
                    TRUNC(RANDOM() * 250 + 2)
                )::INET;
            insert into "Detectors"(id_device, min_value, max_value, type, description, ip_address)
            VALUES (ret_id, min_val, max_val,  'analog_input', random_string(100), ip);
        end loop;
end;
$$;

alter function insert_random_device_and_detectors() owner to s264434;

