create function "ЖАЛОБА_ВРЕМЯ"() returns trigger
    language plpgsql
as
$$
BEGIN

IF NEW.ВРЕМЯ IS NULL THEN
NEW.ВРЕМЯ = CURRENT_TIMESTAMP;
END IF;

RETURN NEW;
END;
$$;

alter function "ЖАЛОБА_ВРЕМЯ"() owner to s243879;

