create function fix_squad_size() returns trigger
    language plpgsql
as
$$
BEGIN
        if (select base_number
            from squad_type
            where new.squad_type = id) < new.unit_number
        then
            new.unit_number = (select base_number
                            from squad_type
                            where new.squad_type = id);
        end if;
        return new;
    end;
$$;

alter function fix_squad_size() owner to s265106;

