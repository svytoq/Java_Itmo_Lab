create function check_cover() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW."ИД" = NEW."Кавер_ИД" AND NEW."Кавер_ИД" != NULL THEN
      RAISE EXCEPTION 'Песня не может быть кавером на саму себя';
    end IF;
    If NEW."Длительность" <= '00:00:01' THEN
      RAISE EXCEPTION 'Некорректная длительность';
    END IF;
    RETURN NEW;
  END;
$$;

alter function check_cover() owner to s223569;

