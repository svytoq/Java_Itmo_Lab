create function insert_assignment() returns trigger
    language plpgsql
as
$$
BEGIN
--Check for valid
IF NEW.assignmentdate < (SELECT tormenteddateofdeath FROM tormented where idtormented = NEW.idtormented) THEN
RAISE EXCEPTION 'Дата распределения не может быть раньше даты смерти';
END IF;

RETURN NEW;
END;
$$;

alter function insert_assignment() owner to s243135;

