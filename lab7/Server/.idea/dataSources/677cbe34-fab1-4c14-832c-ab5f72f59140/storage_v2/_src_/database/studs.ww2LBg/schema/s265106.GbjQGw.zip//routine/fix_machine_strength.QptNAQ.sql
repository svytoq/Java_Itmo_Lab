create function fix_machine_strength() returns trigger
    language plpgsql
as
$$
BEGIN
if (select base_strength from machine_type where new.machine_type = id) < new.strength
then new.strength = (select base_strength from machine_type where new.machine_type = id);
end if;
return new;
end;
$$;

alter function fix_machine_strength() owner to s265106;

