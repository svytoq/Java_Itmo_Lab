create function check_up_on_end() returns trigger
    language plpgsql
as
$$
declare
       days_left integer;
   begin
       days_left = NEW.days_left;
       if days_left = -1 then
           insert into turned_to_animal (person_id, animal_type, date) values (new.person_id, (select lodger.chosen_animal from lodger where lodger.person_id = new.person_id), now());
           
        elseif exists(select * from couples where couples.man_id = new.person_id or couples.woman_id = new.person_id ) then
        return old;
       end if;
       return new;
   end;
$$;

alter function check_up_on_end() owner to s265492;

