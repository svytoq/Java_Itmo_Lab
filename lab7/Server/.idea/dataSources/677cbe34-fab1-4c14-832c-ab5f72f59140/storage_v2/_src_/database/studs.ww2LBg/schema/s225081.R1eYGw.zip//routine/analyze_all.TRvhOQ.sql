create function analyze_all() returns void
    language plpgsql
as
$$
DECLARE 
   J VARCHAR(35);
BEGIN 
  FOR J IN SELECT DISTINCT 
  table_name
FROM
  information_schema.columns
WHERE
  table_schema='s225081' LOOP
    VACUUM ANALYSE J;
  END LOOP;
END;
$$;

alter function analyze_all() owner to s225081;

