create function add_worker_building(count integer) returns void
    language plpgsql
as
$$
DECLARE
w_ids integer[];
w_ids_count integer := 0;
b_ids integer[];
b_ids_count integer := 0;
w_id integer := 0;
b_id integer := 0;
exists integer := 0;
BEGIN
FOR i IN 1..count LOOP
w_ids := array(SELECT ИД FROM РАБОЧИЙ);
SELECT COUNT(*) INTO w_ids_count FROM РАБОЧИЙ;
b_ids := array(SELECT НОМЕР FROM КОРПУС);
SELECT COUNT(*) INTO b_ids_count FROM КОРПУС;

w_id := random() * (w_ids_count - 1) + 1;
b_id := random() * (b_ids_count - 1) + 1;
SELECT COUNT(*) INTO exists FROM РАБОЧИЙ_КОРПУС WHERE РАБОЧИЙ_ИД = w_ids[w_id] AND КОРПУС_НОМЕР = b_ids[b_id];
WHILE exists > 0 LOOP
w_id := random() * (w_ids_count - 1) + 1;
b_id := random() * (b_ids_count - 1) + 1;
SELECT COUNT(*) INTO exists FROM РАБОЧИЙ_КОРПУС WHERE РАБОЧИЙ_ИД = w_ids[w_id] AND КОРПУС_НОМЕР = b_ids[b_id];
END LOOP;

INSERT INTO РАБОЧИЙ_КОРПУС VALUES(w_ids[w_id], b_ids[b_id]);
END LOOP;
END;
$$;

alter function add_worker_building(integer) owner to s225141;

