create function "ВСЕ_ОТСЫЛКИ_НА_КНИГУ"(name character varying)
    returns TABLE("НАЗВАНИЕ" character varying, "СУТЬ_ОТНОШЕНИЯ" text)
    language plpgsql
as
$$
BEGIN 
RETURN QUERY SELECT B.НАЗВАНИЕ, B.СУТЬ
FROM (SELECT КНИГИ.НАЗВАНИЕ, ОТСЫЛКА_МЕЖДУ_КНИГ.СУТЬ FROM КНИГИ JOIN ОТСЫЛКА_МЕЖДУ_КНИГ ON КНИГИ.ИД=ОТСЫЛКА_МЕЖДУ_КНИГ.ИД_КНИГ1) AS A 
JOIN (SELECT КНИГИ.НАЗВАНИЕ, ОТСЫЛКА_МЕЖДУ_КНИГ.СУТЬ FROM КНИГИ JOIN ОТСЫЛКА_МЕЖДУ_КНИГ ON КНИГИ.ИД=ОТСЫЛКА_МЕЖДУ_КНИГ.ИД_КНИГ2) AS B 
ON (B.СУТЬ=A.СУТЬ) WHERE (A.НАЗВАНИЕ=name)
union
SELECT A.НАЗВАНИЕ, A.СУТЬ
FROM (SELECT КНИГИ.НАЗВАНИЕ, ОТСЫЛКА_МЕЖДУ_КНИГ.СУТЬ FROM КНИГИ JOIN ОТСЫЛКА_МЕЖДУ_КНИГ ON КНИГИ.ИД=ОТСЫЛКА_МЕЖДУ_КНИГ.ИД_КНИГ1) AS A 
JOIN (SELECT КНИГИ.НАЗВАНИЕ, ОТСЫЛКА_МЕЖДУ_КНИГ.СУТЬ FROM КНИГИ JOIN ОТСЫЛКА_МЕЖДУ_КНИГ ON КНИГИ.ИД=ОТСЫЛКА_МЕЖДУ_КНИГ.ИД_КНИГ2) AS B 
ON (B.СУТЬ=A.СУТЬ) WHERE (B.НАЗВАНИЕ=name);
END;
$$;

alter function "ВСЕ_ОТСЫЛКИ_НА_КНИГУ"(varchar) owner to s225058;

