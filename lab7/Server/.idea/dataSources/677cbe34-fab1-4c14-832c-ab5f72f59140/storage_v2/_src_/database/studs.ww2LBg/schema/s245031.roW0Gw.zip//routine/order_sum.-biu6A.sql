create function order_sum() returns trigger
    language plpgsql
as
$$
declare weap_sum int;
    declare shield_sum int;
begin
    if NEW.Оружие is null then
        weap_sum := 0;
    else weap_sum := (select цена from "Пушки" where id = NEW."Оружие");
    end if;


    if NEW.Щит is null then
        shield_sum := 0;
        else shield_sum := (select цена from "Щиты" where id = NEW."Щит");
    end if;

    NEW.стоимость := weap_sum + shield_sum;

    assert (select баланс from "Клиенты" where id = NEW.заказчик) > NEW.стоимость, 'У заказчика недостаточно средств для заказа';
    Update "Клиенты" set баланс = баланс - NEW.стоимость where id = NEW.заказчик;

    NEW."Срок" := make_interval(days => NEW.стоимость / 1000 * 10);
    NEW."Время" := now() + NEW."Срок";

    return new;
    end;
$$;

alter function order_sum() owner to s245031;

