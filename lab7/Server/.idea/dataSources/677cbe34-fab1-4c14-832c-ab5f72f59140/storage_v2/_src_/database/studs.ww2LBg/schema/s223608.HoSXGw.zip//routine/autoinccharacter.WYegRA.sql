create function autoinccharacter() returns trigger
    language plpgsql
as
$$
BEGIN
     NEW.ID := nextval('IdCharactSequence');
   Return NEW;
 END;
$$;

alter function autoinccharacter() owner to s223608;

