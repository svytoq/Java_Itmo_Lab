create function validation_date_of_abon() returns trigger
    language plpgsql
as
$$
begin

  IF (Select ОКОНЧАНИЕ from АБОНЕМЕНТЫ where АБОНЕМЕНТЫ.ИД IN(Select ИД_АБОНЕМЕНТА from ПОСЕТИТЕЛИ where ИД = NEW.ИД_ПОСЕТИТЕЛЯ)) >= NEW.ДАТА
  then
    return NEW;
  else
    RAISE EXCEPTION 'Действие абонемента закончилось';
  end if;
end;

$$;

alter function validation_date_of_abon() owner to s223457;

