create function addperson(text, character, date, money) returns void
    language plpgsql
as
$$
DECLARE
ФИО alias for $1; 
ПОЛ alias for $2; 
ГОД_РОЖДЕНИЯ alias for $3;
БЮДЖЕТ alias for $4;
BEGIN
INSERT INTO ВЛАДЕЛЕЦ (БЮДЖЕТ, ГОД_РОЖДЕНИЯ, mail, ПОЛ, ФИО, КОЛИЧЕСТВО_ОЧКОВ, СПОРТИВНЫЙ_РАЗРЯД) VALUES (
БЮДЖЕТ, ГОД_РОЖДЕНИЯ, 0, ПОЛ, ФИО,  0, 0);
END;
$$;

alter function addperson(text, char, date, money) owner to s243880;

