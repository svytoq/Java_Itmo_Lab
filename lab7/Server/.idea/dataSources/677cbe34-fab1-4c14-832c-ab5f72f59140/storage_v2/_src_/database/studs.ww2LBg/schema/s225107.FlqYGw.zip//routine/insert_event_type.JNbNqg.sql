create function insert_event_type() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
    name text = insert_random();
  BEGIN
    LOOP
      IF NOT exists(Select * from event_type where type = name)
        THEN
          INSERT INTO event_type VALUES (DEFAULT, name);
          count = count + 1;
        ELSE name = insert_random();
      END IF;
      EXIT WHEN count = 20;
    END LOOP;
  END;
$$;

alter function insert_event_type() owner to s225107;

