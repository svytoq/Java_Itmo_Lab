create function check_objects_not_claimed_by_many_entities() returns trigger
    language plpgsql
as
$$
DECLARE
	amount int;
	sum int = 0;
BEGIN
	IF (is_object_claimed(NEW.object)) THEN
		RAISE EXCEPTION 
			'Object % claimed by many entities
			%', NEW.object, NEW;
	END IF;

	RETURN NEW;
END;
$$;

alter function check_objects_not_claimed_by_many_entities() owner to s244711;

