create function "Штип"(id integer, "id_базы" integer, "название" character varying) returns void
    language plpgsql
as
$$
BEGIN
insert into корабль values(ID, 900, название, '[10, 20]' , 1500, 'создается',500, ID_базы, now(), null);
insert into оружие_корабль values(10, ID);
END;
$$;

alter function "Штип"(integer, integer, varchar) owner to s242552;

