create function "ХРАНИЛИЩЕ_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "ХРАН_ИД" FROM "ХРАНИЛИЩЕ");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."ХРАН_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''ХРАНИЛИЩЕ_ХРАН_ИД_seq'', max("ХРАН_ИД") + 1) FROM "ХРАНИЛИЩЕ"';
                        NEW."ХРАН_ИД" := max_id + 1;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "ХРАНИЛИЩЕ_PK_seq_func"() owner to s245094;

