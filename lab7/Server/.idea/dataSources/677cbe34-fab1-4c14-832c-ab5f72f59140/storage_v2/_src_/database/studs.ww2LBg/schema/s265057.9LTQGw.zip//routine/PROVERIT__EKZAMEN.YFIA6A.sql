create function "ПРОВЕРИТЬ_ЭКЗАМЕН"() returns trigger
    language plpgsql
as
$$
DECLARE
	duration interval;
	start_date date;
	finish_date date;
	lesson_ex_row record;
	stud_level smallint;
BEGIN
	--проверить длительность экзамена--
	duration:=age(NEW.ВРЕМЯ_КОНЦА,NEW.ВРЕМЯ_НАЧАЛА);
	IF (duration<'1 hour' or duration>'4 hours') THEN
		RAISE NOTICE 'Экзамен должен длиться от 1 до 4 часов, %',duration;
		RETURN NULL;
	END IF;
	--отдельная проверка для тестирования и экзамена
	SELECT INTO stud_level УРОВЕНЬ from УЧЕНИК WHERE УЧЕНИК_ИД=NEW.УЧЕНИК_ИД;
	IF (NEW.ТИП='ТЕСТИРОВАНИЕ') THEN
		IF (stud_level IS NOT NULL) THEN
			RAISE NOTICE 'Ученик уже прошёл тестирование';
			RETURN NULL;
		END IF;
	ELSE
		IF (stud_level>NEW.УРОВЕНЬ) THEN
			RAISE NOTICE 'Ученику не нужно сдавать экзамен, т.к. он уже подтвердил свой уровень';
			RETURN NULL;
		ELSIF (stud_level IS NULL) THEN
			RAISE NOTICE 'Ученик еще не прошел тестирование';
			RETURN NULL;
		END IF;
		SELECT INTO start_date,finish_date ДАТА_НАЧАЛА,ДАТА_КОНЦА FROM СЕМЕСТР WHERE СЕМЕСТР_ИД=NEW.СЕМЕСТР_ИД;
		IF ((NEW.ВРЕМЯ_НАЧАЛА<start_date or NEW.ВРЕМЯ_КОНЦА>finish_date) AND (NEW.ТИП='СЕРТИФИКАТ')) THEN
			RAISE NOTICE 'Экзамен не проходит в рамках семестра';
			RETURN NULL;
		END IF;
	END IF;
	--далее проверка, что препод/аудитория в это время не заняты--
	FOR lesson_ex_row IN SELECT * FROM ЗАНЯТИЕ WHERE (NOT(NEW.ВРЕМЯ_НАЧАЛА>=ВРЕМЯ_КОНЦА) AND NOT(NEW.ВРЕМЯ_КОНЦА<=ВРЕМЯ_НАЧАЛА)) LOOP
		IF (lesson_ex_row.ЭКЗАМЕН_ИД=NEW.ЭКЗАМЕН_ИД) THEN CONTINUE;
		END IF;
		IF (NEW.ПРЕП_ИД IS NOT NULL) THEN
			IF (lesson_ex_row.ПРЕП_ИД IS NOT NULL AND lesson_ex_row.ПРЕП_ИД=NEW.ПРЕП_ИД) THEN
				RAISE NOTICE 'Преподаватель ID=% уже занят в это время на занятии',NEW.ПРЕП_ИД;
				RETURN NULL;
			END IF;
		END IF;
		IF (NEW.АУД_ИД IS NOT NULL) THEN
			IF (lesson_ex_row.АУД_ИД IS NOT NULL AND lesson_ex_row.АУД_ИД=NEW.АУД_ИД) THEN
				RAISE NOTICE 'Аудитория номер=% уже занята в это время на занятие',NEW.АУД_ИД;
				RETURN NULL;
			END IF;
		END IF;
	END LOOP;
	FOR lesson_ex_row IN SELECT * FROM ЭКЗАМЕН WHERE (NOT(NEW.ВРЕМЯ_НАЧАЛА>=ВРЕМЯ_КОНЦА) AND NOT(NEW.ВРЕМЯ_КОНЦА<=ВРЕМЯ_НАЧАЛА)) LOOP
		IF (NEW.ПРЕП_ИД IS NOT NULL) THEN
			IF (lesson_ex_row.ПРЕП_ИД IS NOT NULL AND lesson_ex_row.ПРЕП_ИД=NEW.ПРЕП_ИД) THEN
				RAISE NOTICE 'Преподаватель ID=% уже занят в это время на экзамене',NEW.ПРЕП_ИД;
				RETURN NULL;
			END IF;
		END IF;
		IF (NEW.АУД_ИД IS NOT NULL) THEN
			IF (lesson_ex_row.АУД_ИД IS NOT NULL AND lesson_ex_row.АУД_ИД=NEW.АУД_ИД) THEN
				RAISE NOTICE 'Аудитория номер=% уже занята в это время на экзамен',NEW.АУД_ИД;
				RETURN NULL;
			END IF;
		END IF;
	END LOOP;
	RETURN NEW;
END;
$$;

alter function "ПРОВЕРИТЬ_ЭКЗАМЕН"() owner to s265057;

