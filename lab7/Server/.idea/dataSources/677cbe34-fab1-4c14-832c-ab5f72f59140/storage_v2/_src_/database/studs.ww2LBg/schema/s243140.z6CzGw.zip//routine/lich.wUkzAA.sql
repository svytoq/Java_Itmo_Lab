create function lich() returns trigger
    language plpgsql
as
$$
DECLARE
lich TEXT;
BEGIN
SELECT INTO lich ИМЯ_ЛИЧНОСТИ FROM ЛИЧНОСТИ WHERE ЛИЧНОСТЬ_ИД=NEW.ЛИЧНОСТЬ_ИД;
NEW.ИМЯ_ЛИЧНОСТИ:=lich;
RETURN NEW;
END
$$;

alter function lich() owner to s243140;

