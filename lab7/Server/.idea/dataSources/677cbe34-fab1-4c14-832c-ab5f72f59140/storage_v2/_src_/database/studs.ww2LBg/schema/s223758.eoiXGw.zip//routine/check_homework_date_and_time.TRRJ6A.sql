create function check_homework_date_and_time() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.дата_выдачи >= CURRENT_TIMESTAMP AND NEW.дата_проверки < CURRENT_TIMESTAMP) THEN
		RAISE EXCEPTION 'Домашнее задание: дата и время выдачи превышает текущую дату и время, и дата и время проверки меньше текущей даты и времени!';
	END IF;
	IF (NEW.дата_выдачи >= CURRENT_TIMESTAMP) THEN
		RAISE EXCEPTION 'Домашнее задание: дата и время выдачи превышает текущую дату и время!';
	END IF;
	IF (NEW.дата_проверки < CURRENT_TIMESTAMP) THEN
		RAISE EXCEPTION 'Домашнее задание: дата и время проверки меньше текущей даты и времени!';
	END IF;
	RETURN NEW;
END;
$$;

alter function check_homework_date_and_time() owner to s223758;

