create function "НАРУШЕНИЯ_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW."ИД_НАРУШЕНИЕ" IS NULL THEN
   NEW."ИД_НАРУШЕНИЕ" = generate_UUID();
END IF;
IF (exists(SELECT FROM "НАРУШЕНИЯ" WHERE "НАРУШЕНИЯ"."ИД_НАРУШЕНИЕ" = NEW."ИД_НАРУШЕНИЕ")) THEN
RAISE 'Нарушение с указанным ид уже существует';
END IF;
IF NEW."ОПИСАНИЕ" IS NULL THEN
RAISE 'Графа "Описание" не может быть пустой.';
END IF;
IF NEW."ШТРАФ" < CAST(0 AS MONEY) THEN
RAISE 'Не может быть меньше 0';
END IF;
IF NEW."ВЫПЛАЧЕННАЯ_ЧАСТЬ_ШТРАФА" < CAST(0 AS MONEY) THEN
RAISE 'Не может быть меньше 0';
END IF;
return NEW;
END;
$$;

alter function "НАРУШЕНИЯ_ТФ"() owner to s223443;

