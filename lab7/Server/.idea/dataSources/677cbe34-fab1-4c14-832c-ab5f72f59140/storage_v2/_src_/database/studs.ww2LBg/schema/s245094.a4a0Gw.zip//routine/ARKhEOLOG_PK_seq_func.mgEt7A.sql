create function "АРХЕОЛОГ_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "АРХ_ИД" FROM "АРХЕОЛОГ");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."АРХ_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''АРХЕОЛОГ_АРХ_ИД_seq'', max("АРХ_ИД") + 1) FROM "АРХЕОЛОГ"';
                        NEW."АРХ_ИД" := max_id + 1;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "АРХЕОЛОГ_PK_seq_func"() owner to s245094;

