create function employment_check(person bigint, pos integer) returns integer
    language plpgsql
as
$$
declare
    cp_id bigint;
    cp_dep departments;
    cp_departments departments[];
begin
    select counterpart into cp_id from People where person_id = person;
   
    if (select department from Positions where position_id=pos) = 'interface' then
        if cp_id is NULL then raise exception 'no counterpart'; end if;

        cp_departments = array(select department  from Positions 
            join Employee_Positions using(position_id)
            join Employees using(employee_id)
            where person_id = cp_id);


        if array_length(cp_departments, 1) > 0 then
            foreach cp_dep in array cp_departments loop
                if cp_dep = 'interface' then raise exception 'counterpart in interface'; end if;
            end loop;
        end if;
    else
        if (select knows from People where person_id = person) = false then
            raise exception 'non-interface must know';
        end if;
    end if; 
    return 1;
end;
$$;

alter function employment_check(bigint, integer) owner to s265066;

