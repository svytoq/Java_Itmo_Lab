create function create_settlement(planet_name character varying) returns void
    language plpgsql
as
$$
DECLARE
 planet_id_ INTEGER;
    settlement_id_ INTEGER;
    rand_fraction_id_ INTEGER;
 BEGIN
 SELECT planet.id into planet_id_ from planet where planet.name = planet_name;
 INSERT INTO settlement (planet_id) VALUES (planet_id_);
    SELECT max (settlement.id) into settlement_id_ from settlement where settlement.planet_id = planet_id_;
    SELECT id into rand_fraction_id_ from fraction order by random() limit 1;
    INSERT INTO citizens_in_settlement (citizen_class_id, settlement_id, fraction_id, amount)
    VALUES (3, settlement_id_, rand_fraction_id_, 100); 
RAISE NOTICE 'Created settlement №% on planet %', settlement_id_, planet_name;
END
$$;

alter function create_settlement(varchar) owner to s264483;

