create function close_order(car integer) returns void
    language plpgsql
as
$$
declare
    request integer;
begin
    request = (select request_id from booked_car where car_id = car order by request_id desc limit 1);
    UPDATE client_requests
    set lights       = false,
        lock         = true,
        start_a_ride = false
    where request_id = request;
    delete from booked_car where car_id = car;
end;
$$;

alter function close_order(integer) owner to s263138;

