create function dec_max_number_groups() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE type_group
  SET number_group = number_group - 1
  WHERE id = new.type_group;
  RETURN new;
END;
$$;

alter function dec_max_number_groups() owner to s243872;

