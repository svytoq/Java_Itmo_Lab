create function pk_func_eating() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_eating');
  RETURN new;
END;
$$;

alter function pk_func_eating() owner to s223457;

