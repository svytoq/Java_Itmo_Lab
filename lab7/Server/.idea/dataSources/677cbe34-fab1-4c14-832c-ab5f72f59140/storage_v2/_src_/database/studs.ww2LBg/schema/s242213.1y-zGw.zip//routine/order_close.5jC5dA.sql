create function order_close() returns trigger
    language plpgsql
as
$$
BEGIN
            IF NEW."ДОСТАВЛЕНО_К" IS NOT NULL AND OLD."ДОСТАВЛЕНО_К"
IS NULL THEN
            NEW."СТАТУС" := 'ЗАВЕРШЕН';
	            END IF;
		            RETURN NEW;
			        END;

$$;

alter function order_close() owner to s242213;

