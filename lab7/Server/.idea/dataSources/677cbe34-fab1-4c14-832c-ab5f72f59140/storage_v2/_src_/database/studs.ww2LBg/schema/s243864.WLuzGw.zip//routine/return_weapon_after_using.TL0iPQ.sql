create function return_weapon_after_using() returns trigger
    language plpgsql
as
$$
BEGIN
    IF tg_op = 'UPDATE' THEN
      IF (NEW.weapon_id IS NULL AND OLD.weapon_id IS NOT NULL) OR (NEW.weapon_id <> OLD.weapon_id) THEN
        UPDATE weaponry SET quantity = quantity+1 WHERE id = OLD.weapon_id;
      END IF;
      RETURN NEW;
    ELSIF tg_op = 'DELETE' THEN
      IF (OLD.weapon_id IS NOT NULL) THEN
        UPDATE weaponry SET quantity = quantity+1 WHERE id = OLD.weapon_id;
      END IF;
      RETURN old;
    END IF;
  END;
$$;

alter function return_weapon_after_using() owner to s243864;

