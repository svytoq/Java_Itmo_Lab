create function create_project(team_id integer, order_id integer, project_id integer, description text, cost numeric, wallet character varying) returns void
    language plpgsql
as
$$
BEGIN

  IF EXISTS(SELECT * FROM team WHERE id = create_project.team_id AND close_date NOTNULL) THEN
    RAISE EXCEPTION 'Cannot create project for closed/non-existing team';
  END IF;

  PERFORM insert_project(project_id, description, NULL, cost, wallet);
  PERFORM insert_team_project(team_id, project_id);

  IF EXISTS(SELECT * FROM orders WHERE id = create_project.order_id AND project_id NOTNULL) THEN
    RAISE EXCEPTION 'Order already has a project';
  END IF;

  UPDATE orders SET project_id = create_project.project_id WHERE id = create_project.order_id;

  RAISE NOTICE 'Заказ назначен команде';

END;

$$;

alter function create_project(integer, integer, integer, text, numeric, varchar) owner to s264458;

