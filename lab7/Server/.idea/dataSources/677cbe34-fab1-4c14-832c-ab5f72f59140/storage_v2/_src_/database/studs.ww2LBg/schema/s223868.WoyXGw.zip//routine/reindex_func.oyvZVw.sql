create function reindex_func() returns trigger
    language plpgsql
as
$$
BEGIN
		IF(TG_TABLE_NAME='Человек')THEN
			REINDEX TABLE Человек;
		END IF;
		IF(TG_TABLE_NAME='Резюме')THEN
			REINDEX TABLE Резюме;
		END IF;
		IF(TG_TABLE_NAME='Занятие')THEN
			REINDEX TABLE Занятие;
		END IF;
		IF(TG_TABLE_NAME='Результат')THEN
			REINDEX TABLE Результат;
		END IF;
	RETURN NEW;
	END;
$$;

alter function reindex_func() owner to s223868;

