create function hashparolmd5new3() returns trigger
    language plpgsql
as
$$
begin 
UPDATE ЧЕЛОВЕК 
set ПАРОЛЬ=md5(ПАРОЛЬ)
WHERE ИД LIKE (SELECT ИД
FROM ЧЕЛОВЕК
ORDER BY ИД
LIMIT 1); 
RETURN NEW; 
END;
$$;

alter function hashparolmd5new3() owner to s243886;

