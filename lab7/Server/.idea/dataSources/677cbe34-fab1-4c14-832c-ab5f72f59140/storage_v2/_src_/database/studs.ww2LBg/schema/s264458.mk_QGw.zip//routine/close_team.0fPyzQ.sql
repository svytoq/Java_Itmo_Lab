create function close_team(team_id integer) returns void
    language plpgsql
as
$$
BEGIN

  IF EXISTS(SELECT * FROM team WHERE id = close_team.team_id AND close_date NOTNULL) THEN
    RAISE EXCEPTION 'Team is already closed';
  END IF;

  UPDATE team SET close_date = current_date WHERE id = close_team.team_id;

  RAISE NOTICE 'Команда закрыта';

END;

$$;

alter function close_team(integer) owner to s264458;

