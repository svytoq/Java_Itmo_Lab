create function check_fail() returns trigger
    language plpgsql
as
$$
BEGIN
  IF(NEW.ПОЛЕТЫ_СТАНЦИИ >= 900) THEN
      NEW.ПОЛЕТЫ_СТАНЦИИ = NULL;
  END IF;
  IF(NEW.ПОЛЕТЫ_ПЛАНЕТЫ >= 900) THEN
    NEW.ПОЛЕТЫ_ПЛАНЕТЫ = NULL;
  END IF;
  IF(NEW.ПОЛЕТЫ_СПУТНИКИ >= 900) THEN
    NEW.ПОЛЕТЫ_СПУТНИКИ = NULL;
  END IF;
  RETURN NEW;
END;
$$;

alter function check_fail() owner to s225110;

