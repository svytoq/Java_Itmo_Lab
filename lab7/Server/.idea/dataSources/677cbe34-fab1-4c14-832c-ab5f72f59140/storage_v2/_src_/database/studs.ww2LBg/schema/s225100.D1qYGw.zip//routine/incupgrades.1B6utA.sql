create function incupgrades() returns void
    language plpgsql
as
$$
DECLARE i INTEGER :=0;
BEGIN
  FOR i IN 0..1000000 LOOP
    IF i%4=0 THEN
      INSERT INTO UPGRADES VALUES (i, 'подствольн. креп.', 'convenience',0,'podstvol',i%100000);
    ELSEIF i%4=1 THEN
      INSERT INTO UPGRADES VALUES (i, 'передняя рукоятка', 'convenience',0,'podstvol',i%100000);
    ELSEIF i%4=2 THEN
      INSERT INTO UPGRADES VALUES (i, 'ПСО-1', 'accuracy',4,'crosshair',i%100000);
    ELSE
      INSERT INTO UPGRADES VALUES (i, 'глушитель', 'stealth',0,'barrel',i%100000);
    end if;
    i:=i+1;
  END LOOP;
end;
$$;

alter function incupgrades() owner to s225100;

