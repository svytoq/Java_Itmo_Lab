create function recalculate_price() returns trigger
    language plpgsql
as
$$
BEGIN
        UPDATE location_resources SET price = price * exp((NEW.rarity - OLD.rarity) / 7) WHERE resource_id = NEW.id;
        RETURN NEW;
    END;
$$;

alter function recalculate_price() owner to s265098;

