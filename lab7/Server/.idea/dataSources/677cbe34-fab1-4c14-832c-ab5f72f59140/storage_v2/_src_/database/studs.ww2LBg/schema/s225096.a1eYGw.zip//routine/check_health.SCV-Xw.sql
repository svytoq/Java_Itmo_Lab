create function check_health(life_of integer, count_of_life_of integer, damage_to integer, id integer, kind_of integer) returns integer
    language plpgsql
as
$$
DECLARE
	situation INTEGER;
	count_of INTEGER;
BEGIN
	if life_of > 5*(count_of_life_of-damage_to) THEN
		situation := 1;
		RAISE NOTICE 'Animal is badly injured';
					IF count_of_life_of-damage_to <= 0 THEN
						situation :=2;
						UPDATE passenger SET is_alive = FALSE, level_of_life = 0 WHERE id = passport_document;
						UPDATE food SET count_of_food = count_of_food + count_of_life_of WHERE name_of_food='meat_type';
						IF ((SELECT gender FROM passenger WHERE id = passenger.passport_document) = 'M')
							THEN
							UPDATE number_of_species SET count_of_male = count_of_male - 1 WHERE id_of_kind =  kind_of;
							SELECT count_of_male into count_of FROM number_of_species WHERE id_of_kind =  kind_of;
							ELSE
							UPDATE number_of_species SET count_of_male = count_of_female - 1 WHERE id_of_kind =  kind_of;
							SELECT count_of_female into count_of FROM number_of_species WHERE id_of_kind =  kind_of;
						END IF;
							ELSE
								INSERT INTO clinic (id_of_diagnosis, id_of_passenger, damage_power) VALUES (1, id, damage_to);
					END IF;
				END IF;
	if count_of < 2
								THEN
								RAISE NOTICE 'ACHTUNG! GLOBAL PROBLEM!';
  							INSERT INTO global_problem (id_of_kind, id_of_passenger, type) VALUES (kind_of, id, 'kinds');

							END IF;
	RETURN situation;
END;
$$;

alter function check_health(integer, integer, integer, integer, integer) owner to s225096;

