create view sound_locations
            (s_name, s_coor_x, s_coor_y, volume, start_time, duration, l_name, l_center_coor_x, l_center_coor_y,
             l_radius, get_distance)
as
SELECT s.name                                                       AS s_name,
       s.coor_x                                                     AS s_coor_x,
       s.coor_y                                                     AS s_coor_y,
       s.volume,
       s.start_time,
       s.duration,
       l.name                                                       AS l_name,
       l.coor_x                                                     AS l_center_coor_x,
       l.coor_y                                                     AS l_center_coor_y,
       l.radius                                                     AS l_radius,
       s264449.get_distance(s.coor_x, s.coor_y, l.coor_x, l.coor_y) AS get_distance
FROM s264449.sound_fact s
         CROSS JOIN s264449.location l
WHERE s264449.get_distance(s.coor_x, s.coor_y, l.coor_x, l.coor_y)::numeric <= (l.radius::numeric + s.volume);

alter table sound_locations
    owner to s264449;

