create function checkplace(x numeric, y numeric, z numeric) returns text
    language sql
as
$$
select
case when exists(select * from Место_установки where "X"=x and "Y"=y and "Z"=z) then 'Небезопасно'
else 'Безопасно'
end;
$$;

alter function checkplace(numeric, numeric, numeric) owner to s265102;

