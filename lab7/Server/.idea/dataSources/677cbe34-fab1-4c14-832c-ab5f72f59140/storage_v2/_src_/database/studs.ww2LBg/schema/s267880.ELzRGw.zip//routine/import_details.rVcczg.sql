create function import_details(detail_type_id integer, detail_source_id integer, quantity integer, price_per_unit integer, import_date date DEFAULT ('now'::text)::date) returns integer
    language sql
as
$$
insert into storage(detail_type_id, detail_source_id, quantity, price_per_unit, import_date)
    values ($1, $2, $3, $4, $5)
    returning storage_id;
$$;

alter function import_details(integer, integer, integer, integer, date) owner to s267880;

