create function check_exp() returns trigger
    language plpgsql
as
$$
BEGIN

    IF ((SELECT captain.exp FROM captain WHERE NEW.captain_id = captain.id) <= (SELECT spaceship.req_exp FROM spaceship WHERE NEW.spaceship_id = spaceship.id))
    THEN
        RAISE EXCEPTION 'Sorry, captain does not have any experience. If you want to look at the list of available captains then enter "select show_available_captains()".';
    END IF;
    RETURN NEW;
END
$$;

alter function check_exp() owner to s243900;

