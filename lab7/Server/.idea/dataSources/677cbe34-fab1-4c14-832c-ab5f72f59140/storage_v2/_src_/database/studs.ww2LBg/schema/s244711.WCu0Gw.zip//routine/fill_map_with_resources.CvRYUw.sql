create function fill_map_with_resources(_map integer, amount integer) returns void
    language plpgsql
as
$$
DECLARE
	types_amount smallint;
BEGIN
	types_amount = 
		(SELECT MAX(id)
		FROM resource_types);

	FOR i IN 1 .. amount LOOP
		INSERT INTO map_resources
			(object, type, amount)
			VALUES
			(get_first_not_claimed_object(_map),
			(SELECT round(random() * (types_amount - 1)) + 1),
			(SELECT round(random() * 1000) + 1));
	END LOOP;
END;
$$;

alter function fill_map_with_resources(integer, integer) owner to s244711;

