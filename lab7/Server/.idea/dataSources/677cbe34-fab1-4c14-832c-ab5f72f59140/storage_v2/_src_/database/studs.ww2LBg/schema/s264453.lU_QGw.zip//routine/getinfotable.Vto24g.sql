create function getinfotable(_table_name text)
    returns TABLE(no bigint, column_name information_schema.sql_identifier, attributes text)
    language plpgsql
as
$$
DECLARE
  BEGIN
  
--START Check whether table exists or not
    IF
       (SELECT EXISTS(
       SELECT FROM pg_catalog.pg_class c
       JOIN   pg_catalog.pg_namespace n ON n.oid = c.relnamespace
       WHERE  n.nspname = 's264453' -- schema name
       AND    c.relname = _table_name -- table name
       AND    c.relkind = 'r'    -- only tables
       ))
      THEN
        RAISE INFO '   Table: %', _table_name;
      ELSE
        RAISE INFO 'Table % does not exist', _table_name;
        RETURN;
    END IF;
--END Check whether table exists or not

---Prolonged query START---
      RETURN QUERY SELECT DISTINCT on (Column_Name)
            DENSE_RANK() OVER (
            ORDER BY cls.column_name
            ) as No,
           cls.column_name AS Column_Name,

          concat_ws('','Type : ' || data_type,
            --CASE MOMENT (NOT NULL CHECK-constraint)--
            CASE
            WHEN is_nullable='NO' THEN concat(' NOT NULL')
            WHEN is_nullable='YES' THEN concat(' ')
            END,

             chr(10),
                 'Comment : ' || col_description((cls.table_schema||'.'||cls.table_name)::regclass::oid, cls.ordinal_position),
             chr(10),
             CASE
             WHEN pg_get_constraintdef(c.oid) LIKE '%CHECK%'
             THEN concat('Constr : ',pg_get_constraintdef(c.oid) ,' ', conname)
             END,

             chr(10)) as Attribute


       FROM information_schema.columns AS cls,
       pg_constraint c
       JOIN   pg_namespace n ON n.oid = c.connamespace
       WHERE cls.table_schema = 'public'
       AND cls.table_name   = _table_name;
---Prolonged query END---
  END

$$;

alter function getinfotable(text) owner to s264453;

