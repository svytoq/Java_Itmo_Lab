create function student_diary_entry_write_stage_note(in_student_id bigint, in_entry_date timestamp without time zone) returns void
    language plpgsql
as
$$
begin
insert into student_diary_entries as sde (student_id, note_id, date)
select s.id, s.stage_note_id, in_entry_date from students s
where s.id = in_student_id;
end;
$$;

alter function student_diary_entry_write_stage_note(bigint, timestamp) owner to s244706;

