create function select_experiences_between(t1 timestamp without time zone, t2 timestamp without time zone)
    returns TABLE(id uuid, start timestamp without time zone, role character varying, end_d timestamp without time zone, employee uuid)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT *
                 from experience
                 where end_date < t2
                   AND start_date > t1;
END;
$$;

alter function select_experiences_between(timestamp, timestamp) owner to s264452;

