create function add_client(name character varying) returns integer
    language plpgsql
as
$$
DECLARE
    client_id integer;

BEGIN
    client_id := (SELECT max(id) from "Клиенты") + 1;
    INSERT INTO "Клиенты" (id, имя, баланс) VALUES (client_id, name, 0);

    RETURN client_id;
END;
$$;

alter function add_client(varchar) owner to s245031;

