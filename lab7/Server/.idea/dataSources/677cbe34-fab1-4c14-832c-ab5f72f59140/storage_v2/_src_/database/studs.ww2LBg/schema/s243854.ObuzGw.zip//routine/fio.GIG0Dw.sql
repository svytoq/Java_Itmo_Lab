create function fio(texst text) returns text
    language plpgsql
as
$$
DECLARE
result text;
kol    integer;

BEGIN
result := LOWER(RTRIM(LTRIM(texst)));
kol := LENGTH(result);
IF kol > 0 THEN
result := REPLACE(result, '  ', ' '); 
result := REPLACE(result, '- ', '-'); 
result := REPLACE(result, ' -', '-'); 
kol := LENGTH(result);
FOR i IN 1..kol LOOP
IF STRPOS('- абвгдеёжзийклмнопрстуфхцчшщъыьэюя', SUBSTR(result, i, 1)) = 0
THEN
result := '0';
EXIT;
END IF;
END LOOP;
ELSE
result := '0';
END IF;
IF result <> '0' THEN
result := INITCAP(result);
END IF;
RETURN result;
END
$$;

alter function fio(text) owner to s243854;

