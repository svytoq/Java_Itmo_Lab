create function start_championship(championship_id integer) returns void
    language plpgsql
as
$$
BEGIN
    IF (check_judge_teams(championship_id) AND
        check_platforms(championship_id) AND
        check_teams(championship_id) AND
        check_cases(championship_id) AND
        check_projects(championship_id) AND
        check_performances(championship_id))
    THEN
        UPDATE championship
        SET begin_date = now()
        WHERE championship.championship_id = start_championship.championship_id;
    END IF;
END;
$$;

alter function start_championship(integer) owner to s264448;

