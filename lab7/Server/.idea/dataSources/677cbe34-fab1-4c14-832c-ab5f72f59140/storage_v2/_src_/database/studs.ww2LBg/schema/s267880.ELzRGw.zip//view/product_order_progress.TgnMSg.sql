create view product_order_progress(product_order_id, assigned_workers_count, finished_workers_count) as
SELECT product_order.product_order_id,
       count(product_order_with_worker_info.worker_id)                               AS assigned_workers_count,
       COALESCE(sum(product_order_with_worker_info.is_finished::integer), 0::bigint) AS finished_workers_count
FROM s267880.product_order_with_worker_info
         RIGHT JOIN s267880.product_order USING (product_order_id)
GROUP BY product_order.product_order_id;

alter table product_order_progress
    owner to s267880;

