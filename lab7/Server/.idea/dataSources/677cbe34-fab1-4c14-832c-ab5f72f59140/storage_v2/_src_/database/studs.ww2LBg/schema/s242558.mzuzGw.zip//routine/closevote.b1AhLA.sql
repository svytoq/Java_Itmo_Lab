create function closevote(id integer) returns void
    language plpgsql
as
$$
DECLARE
    temp integer;
BEGIN
    IF EXISTS(SELECT 1 FROM сезоны WHERE ид=id) THEN
        FOR i IN 1..9 LOOP
            temp = (SELECT игрок_ид FROM (SELECT игрок_ид, COUNT(игрок_ид) FROM голосование WHERE (сезон_ид=id) AND (нагр_ид=i) GROUP BY игрок_ид ORDER BY COUNT(игрок_ид) DESC LIMIT 1) AS sub);
            INSERT INTO награждения VALUES (id, i, temp);
        END LOOP;
    END IF;
END;
$$;

alter function closevote(integer) owner to s242558;

