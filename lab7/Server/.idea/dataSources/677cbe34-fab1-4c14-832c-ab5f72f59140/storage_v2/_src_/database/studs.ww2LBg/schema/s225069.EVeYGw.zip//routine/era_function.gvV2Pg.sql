create function era_function() returns trigger
    language plpgsql
as
$$
begin
new.Era_ID=nextval('Eras_Era_Id_seq');
return new;
end;
$$;

alter function era_function() owner to s225069;

