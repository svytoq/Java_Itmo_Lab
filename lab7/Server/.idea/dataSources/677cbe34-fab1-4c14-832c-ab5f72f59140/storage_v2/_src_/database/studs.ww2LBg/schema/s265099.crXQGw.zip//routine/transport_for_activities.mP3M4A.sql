create function transport_for_activities(id_activity_a integer, id_activity_b integer)
    returns TABLE("тип" character varying, "стоимость_проезда" integer, "время_в_пути" interval, "локация_А" text, "локация_Б" text)
    language plpgsql
as
$$
DECLARE id_location_A INTEGER;
DECLARE id_location_B INTEGER;	
	BEGIN
		id_location_A = (SELECT id_локации FROM активность where id_активности = id_activity_A);
		id_location_B = (SELECT id_локации FROM активность where id_активности = id_activity_B);

		IF id_location_A = id_location_B THEN
			RETURN;
		END IF;

		RETURN QUERY (
			SELECT транспорт.тип, транспорт.стоимость_проезда, транспорт.время_в_пути, locationA.название AS локация_А, locationB.название AS локация_Б
			FROM транспорт 
			JOIN локация AS locationA ON транспорт.id_локации_а = locationA.id_локации
			JOIN локация AS locationB ON транспорт.id_локации_б = locationB.id_локации
			WHERE транспорт.id_локации_а = id_location_A AND транспорт.id_локации_б = id_location_B);
	END
$$;

alter function transport_for_activities(integer, integer) owner to s265099;

