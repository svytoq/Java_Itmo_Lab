create function get_main_process_joined_artifacts_info()
    returns TABLE(main_process_id integer, duration integer, deadline_date date, description text, status s263229.process_status, estimation_time interval, start_date date, artifact_id integer, artifact_type s263229.artifact_types, size integer, upload_date timestamp without time zone, main_worker_id integer)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT 
    mp.MAIN_PROCESS_ID, mp.DURATION, mp.DEADLINE_DATE, mp.DESCRIPTION, mp.STATUS, mp.ESTIMATION_TIME,
    mp.START_DATE, a.ARTIFACT_ID, a.ARTIFACT_TYPE, a.SIZE, a.UPLOAD_DATE, a.MAIN_WORKER_ID
    FROM processes AS mp JOIN process_artifact USING(MAIN_PROCESS_ID) 
    JOIN artifacts AS a USING(ARTIFACT_ID);
END
$$;

alter function get_main_process_joined_artifacts_info() owner to s263229;

