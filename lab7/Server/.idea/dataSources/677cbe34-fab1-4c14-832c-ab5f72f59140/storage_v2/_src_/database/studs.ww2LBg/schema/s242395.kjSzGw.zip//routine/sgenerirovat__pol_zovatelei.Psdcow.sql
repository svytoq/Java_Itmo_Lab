create function сгенерировать_пользователей("число_пользователей" integer) returns void
    language plpgsql
as
$$
BEGIN
        FOR i IN 1 .. число_пользователей LOOP
                INSERT INTO Пользователи(логин, пароль, фио)
                 VALUES (random_string(10), random_string(10),random_string(20));
        END LOOP;
END;
$$;

alter function сгенерировать_пользователей(integer) owner to s242395;

