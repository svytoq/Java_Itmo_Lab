create function closevotes(arr integer[]) returns void
    language plpgsql
as
$$
BEGIN
FOR i IN 0..(array_length(arr, 1)) LOOP
PERFORM closeVote(arr[i]);
END LOOP;
END;
$$;

alter function closevotes(integer[]) owner to s242558;

