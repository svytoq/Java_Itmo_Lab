create function insert_city() returns void
    language plpgsql
as
$$
DECLARE count INTEGER = 0;
  BEGIN
    LOOP
      INSERT INTO city VALUES(DEFAULT,trunc(random()*10)+1, insert_random());
      count = count + 1;
      EXIT WHEN count = 1000;
    END LOOP;
  END;
$$;

alter function insert_city() owner to s225107;

