create function "ПОКАЗАТЬ_ЗАНЯТИЯ_ПРЕПОДАВАТЕЛЯ"(id integer) returns SETOF s265057."ЗАНЯТИЕ"
    language sql
as
$$
select * FROM ЗАНЯТИЕ WHERE ПРЕП_ИД=id
$$;

alter function "ПОКАЗАТЬ_ЗАНЯТИЯ_ПРЕПОДАВАТЕЛЯ"(integer) owner to s265057;

