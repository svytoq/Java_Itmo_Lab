create function create_student(email character varying, password character varying, name character varying, surname character varying) returns void
    language plpgsql
as
$$
DECLARE
    user_id integer DEFAULT 0;
BEGIN
    RAISE DEBUG 'Function create_student() fired';
    INSERT INTO users (email, password) VALUES (email, password) RETURNING id INTO user_id;
    INSERT INTO accounts (id, balance) VALUES (user_id, 0);
    INSERT INTO students (id, name, surname) VALUES (user_id, name, surname);
END;
$$;

alter function create_student(varchar, varchar, varchar, varchar) owner to s268925;

