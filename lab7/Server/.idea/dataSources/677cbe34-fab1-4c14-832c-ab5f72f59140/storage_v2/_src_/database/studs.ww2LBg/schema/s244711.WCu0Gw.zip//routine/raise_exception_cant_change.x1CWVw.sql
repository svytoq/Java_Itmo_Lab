create function raise_exception_cant_change() returns trigger
    language plpgsql
as
$$
BEGIN
	RAISE EXCEPTION 
		'You cannot change ID of this object.';
END;
$$;

alter function raise_exception_cant_change() owner to s244711;

