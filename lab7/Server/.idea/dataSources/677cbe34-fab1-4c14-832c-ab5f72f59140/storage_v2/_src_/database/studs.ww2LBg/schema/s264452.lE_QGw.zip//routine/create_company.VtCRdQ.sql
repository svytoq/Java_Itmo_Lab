create function create_company(new_company_uuid uuid, new_name character varying, new_business_type character varying, new_manager_name character varying, new_bik bigint, new_inn bigint, new_ogrn bigint) returns text
    language plpgsql
as
$$
declare
    id_company uuid;
begin
    insert into company(id, bik, business_type, inn, manager_legal_name, name, ogrn)
    values (new_company_uuid, new_bik, new_business_type, new_inn, new_manager_name, new_name, new_ogrn)
    returning company.id into id_company;

    return 'Company created. Id: ' || id_company;
end;
$$;

alter function create_company(uuid, varchar, varchar, varchar, bigint, bigint, bigint) owner to s264452;

