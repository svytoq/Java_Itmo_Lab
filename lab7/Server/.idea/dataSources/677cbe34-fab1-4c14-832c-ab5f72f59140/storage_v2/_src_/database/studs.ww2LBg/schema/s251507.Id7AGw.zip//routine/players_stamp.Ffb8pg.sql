create function players_stamp() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.player_name IS NULL THEN
         RAISE EXCEPTION 'player_name cannot be null';
END IF;

    IF NEW.player_role IS NULL THEN
    RAISE EXCEPTION '% cannot be null', NEW.player_name;
    END IF;

    IF NEW.player_number < 0 THEN
    RAISE EXCEPTION '% cannot have a negative number', NEW.player_name;
    END IF;
    end ;

$$;

alter function players_stamp() owner to s251507;

