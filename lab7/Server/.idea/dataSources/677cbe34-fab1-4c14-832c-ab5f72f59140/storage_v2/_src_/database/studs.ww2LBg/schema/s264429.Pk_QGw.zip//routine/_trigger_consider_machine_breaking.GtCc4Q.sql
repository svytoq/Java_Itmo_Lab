create function _trigger_consider_machine_breaking() returns trigger
    language plpgsql
as
$$
begin
    if random() < 0.0002*work_hrs then
        UPDATE circuit_board_machine SET state = 'broken' where id = new.id;
    end if;
    return new;
end;
$$;

alter function _trigger_consider_machine_breaking() owner to s264429;

