create function to_parts(count integer) returns void
    language plpgsql
as
$$
DECLARE
  NM   VARCHAR(30);
  TIP  PART;
  NUM  INT;
  LEG  INT;
  CENT INT;
  I    INT;
BEGIN
  LEG = 0;
  CENT = 0;
  FOR I IN 1..COUNT LOOP
    NM = 'ПОДРАЗДЕЛЕНИЕ_'||I;
    IF I % 7 = 0
    THEN NUM = RANDOM() * (700 - 101) + 101 :: INT;
      TIP = 'ЛЕГИОН';
      SELECT ID_ВОИНА
      FROM ВОИНЫ
      WHERE ДОЛЖНОСТЬ = 'ЛЕГИОНЕР' AND ID_ВОИНА > LEG
      INTO LEG;
      INSERT INTO ПОДРАЗДЕЛЕНИЕ VALUES (DEFAULT, NM, NUM, TIP, LEG);
    ELSE NUM = RANDOM() * (100 - 10) + 10 :: INT;
      TIP = 'ЦЕНТУРИЯ';
      SELECT ID_ВОИНА
      FROM ВОИНЫ
      WHERE ДОЛЖНОСТЬ = 'ЦЕНТУРИОН' AND ID_ВОИНА > CENT
      INTO CENT;
      INSERT INTO ПОДРАЗДЕЛЕНИЕ VALUES (DEFAULT, NM, NUM, TIP, CENT);
    END IF;
  END LOOP;
END;
$$;

alter function to_parts(integer) owner to s225081;

