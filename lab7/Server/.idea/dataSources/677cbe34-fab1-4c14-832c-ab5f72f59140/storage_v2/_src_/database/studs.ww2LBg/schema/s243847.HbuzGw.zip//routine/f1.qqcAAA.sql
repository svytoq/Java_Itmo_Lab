create function f1() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE Планетарные_системы SET Кол_планет = Кол_планет+1
WHERE ID_Системы = NEW.ID_Системы;
RETURN NEW;
END;
$$;

alter function f1() owner to s243847;

