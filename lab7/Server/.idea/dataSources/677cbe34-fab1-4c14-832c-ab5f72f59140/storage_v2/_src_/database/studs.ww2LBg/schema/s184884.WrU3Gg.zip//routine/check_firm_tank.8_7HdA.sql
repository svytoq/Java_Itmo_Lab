create function check_firm_tank() returns trigger
    language plpgsql
as
$$
DECLARE
  rec INTEGER;
BEGIN

  rec := (SELECT firm.id FROM firm WHERE NEW.id_firm = firm.id AND firm.specialization = 'Engine');
  IF rec is not NULL THEN
    RAISE EXCEPTION 'Firm % cannot create weapons', NEW.id_firm;
  END IF;

  RETURN NEW;

END;
$$;

alter function check_firm_tank() owner to s184884;

