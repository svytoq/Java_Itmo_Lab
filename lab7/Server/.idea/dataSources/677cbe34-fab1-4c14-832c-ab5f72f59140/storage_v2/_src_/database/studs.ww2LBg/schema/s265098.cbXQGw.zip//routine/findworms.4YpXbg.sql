create function findworms(c_id integer, occupation_name text)
    returns TABLE(id integer, name text, salary integer)
    language sql
as
$$
SELECT worms.id, worms.name, worms.salary FROM colony_worms 
JOIN worms ON colony_worms.worm_id=worms.id
JOIN colonies ON colony_worms.colony_id=colonies.id
JOIN worm_occupations ON worm_occupations.worm_id=worms.id
JOIN occupations ON worm_occupations.occupation=occupations.name
WHERE occupations.name=occupation_name AND colonies.id=c_id 
ORDER BY worms.salary;
$$;

alter function findworms(integer, text) owner to s265098;

