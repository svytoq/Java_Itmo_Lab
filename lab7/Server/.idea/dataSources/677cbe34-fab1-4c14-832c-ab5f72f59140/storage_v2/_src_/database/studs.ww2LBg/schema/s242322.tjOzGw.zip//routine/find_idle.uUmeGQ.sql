create function find_idle() returns SETOF s242322."ЧЛЕНЫ_ПОЛИЦИИ"
    language plpgsql
as
$$
begin
return query select * from ЧЛЕНЫ_ПОЛИЦИИ where ИД not in (select АГЕНТ from КОМАНДЫ as К join МИССИИ as М on К.МИССИЯ = М.ИД where М.СТАТУС != 'Выполнена') 
and ИД not in (select distinct ОТВЕТСТВЕННЫЙ from РЕМОНТ_ТРАНСПОРТА where now() between НАЧАЛО AND ГОТОВНОСТЬ_К)
and ИД not in (select distinct ОТВЕТСТВЕННЫЙ from РЕМОНТ_ОРУЖИЯ where now() between НАЧАЛО AND ГОТОВНОСТЬ_К);
return;
end;
$$;

alter function find_idle() owner to s242322;

