create function insert_relations() returns void
    language plpgsql
as
$$
DECLARE
    count INTEGER = 0;
    name text = insert_random();
  BEGIN
    LOOP
      IF NOT EXISTS(SELECT * FROM relations WHERE reltype = name)
        THEN
          INSERT INTO relations VALUES(DEFAULT, name);
          count = count + 1;
        ELSE name = insert_random();
      END IF;
      EXIT WHEN count = 50;
    END LOOP;
  END;
$$;

alter function insert_relations() owner to s225107;

