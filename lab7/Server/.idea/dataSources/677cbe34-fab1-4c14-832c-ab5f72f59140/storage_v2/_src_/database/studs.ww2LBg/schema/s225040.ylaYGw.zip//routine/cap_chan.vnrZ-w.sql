create function cap_chan() returns trigger
    language plpgsql
as
$$
DECLARE
old_cap integer;
new_cap integer;
cap_limit integer;
BEGIN
SELECT КОЛИЧЕСТВО_ЗАКЛЮЧЁННЫХ INTO old_cap FROM КАМЕРА WHERE НОМЕР_КАМЕРЫ = OLD.НОМЕР_КАМЕРЫ;
SELECT КОЛИЧЕСТВО_ЗАКЛЮЧЁННЫХ INTO new_cap FROM КАМЕРА WHERE НОМЕР_КАМЕРЫ = NEW.НОМЕР_КАМЕРЫ;
SELECT ТИП_КАМЕРЫ.ВМЕСТИМОСТЬ INTO cap_limit FROM ТИП_КАМЕРЫ INNER JOIN КАМЕРА ON (ТИП_КАМЕРЫ.ИД_ТИПА = КАМЕРА.ТИП_КАМЕРЫ) WHERE НОМЕР_КАМЕРЫ = NEW.НОМЕР_КАМЕРЫ;
IF (new_cap + 1 > cap_limit) THEN 
 RAISE EXCEPTION '% КАМЕРА ПЕРЕПОЛНЕНА', NEW.НОМЕР_КАМЕРЫ;
ELSE
UPDATE КАМЕРА SET КОЛИЧЕСТВО_ЗАКЛЮЧЁННЫХ = old_cap - 1 where НОМЕР_КАМЕРЫ = OLD.НОМЕР_КАМЕРЫ;
UPDATE КАМЕРА SET КОЛИЧЕСТВО_ЗАКЛЮЧЁННЫХ = new_cap + 1 where НОМЕР_КАМЕРЫ = NEW.НОМЕР_КАМЕРЫ;
RETURN NEW;
END IF; 
END;
$$;

alter function cap_chan() owner to s225040;

