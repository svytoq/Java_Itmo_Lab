create function to_grazhd(count integer, start integer) returns void
    language plpgsql
as
$$
DECLARE
  name VARCHAR(30);
  stat BOOLEAN;
  date DATE;
  J    INT;
  K    INT;
BEGIN
  date = '0541-01-01 BC';
  K = 0;
  FOR J IN SELECT ID_МЕСТО
           FROM МЕСТОПОЛОЖЕНИЕ
           WHERE ID_МЕСТО >= start LOOP
    IF K = COUNT
    THEN EXIT; END IF;
    IF J % 33 = 0
    THEN
      date = date + 7;

    END IF;

    IF J % 5 = 0
    THEN
      name = 'ПИР НА ВЕСЬ МИР'||J;
      STAT = FALSE;
    ELSEIF J% 7 =0 THEN 
      STAT = TRUE ;
      NAME ='СОБРАНИЕ'||J;
    ELSE STAT = TRUE;
            name = 'МЕРОПРИЯТИЕ'||J;

    END IF;
    INSERT INTO ГРАЖДАНСКИЕ_МЕРОПРИЯТИЯ VALUES (DEFAULT, name, date, J, stat);
    K = K + 1;
  END LOOP;
END;
$$;

alter function to_grazhd(integer, integer) owner to s225081;

