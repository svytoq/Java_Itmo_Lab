create function get_info_about_table_by_name(schema_name character varying, table_name character varying) returns void
    language plpgsql
as
$$
declare
    schema_oid oid;
    i record;
    k record;
    constr_printed boolean;
begin
    schema_oid = (select n.oid from pg_namespace n where nspname=schema_name limit 1);
    if schema_oid is NULL
    then
        raise notice 'Cхемы % не существует.', schema_name;
        return;
    end if;

    if not exists(select 1 from pg_class where relnamespace::regnamespace::text=schema_name and relname=table_name limit 1)
    then
        raise notice 'Таблицы % не существует.', table_name;
        return;
    end if;

    create temp table temp_table on commit drop as 
    select 
    attnum, 
    attname, 
    typname,
    tables.oid as table_oid
    FROM pg_attribute columns
    inner join pg_class tables
    ON columns.attrelid = tables.oid
    inner join pg_type pt
    on columns.atttypid = pt.oid
    left join pg_namespace n on n.oid = tables.relnamespace
    where tables.relname = table_name
    and tables.relnamespace=schema_oid
    and columns.attnum > 0;

    raise notice 'Таблица: %', table_name;
    raise notice ' ';

    raise notice '%', ' No. Имя столбца   Атрибуты';
    raise notice '%', ' --- -----------   ------------------------------------------------------';     

    for i in select * from temp_table order by attnum
    loop
        raise notice '%', format('%4s %-13s Type   : %-45s', i.attnum, i.attname, i.typname);
        constr_printed = false;

        for k in (SELECT c.oid
                    FROM   pg_constraint c
                    JOIN   pg_attribute  a ON a.attrelid = c.conrelid     -- !
                                        AND a.attnum   = ANY(c.conkey)  -- !
                    WHERE  c.conrelid = i.table_oid
                    AND    a.attname = i.attname)
        loop
                raise notice '%', format('%18s Constr : %s', '', pg_get_constraintdef(k.oid));
                constr_printed = true;
        end loop;
        if constr_printed then 
                raise notice ' ';
        end if;
    end loop;
end;
$$;

alter function get_info_about_table_by_name(varchar, varchar) owner to s265066;

