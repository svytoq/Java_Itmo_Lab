create function init_beldons_for_gas_planet() returns trigger
    language plpgsql
as
$$
DECLARE
    beldons_count integer;
    iterator integer;
    position_id_tmp integer;
BEGIN
    if NEW.planet_type = 'GAS' THEN
        beldons_count = floor((random()*100+1))::int;
        for iterator in 1..beldons_count
            loop
                insert into positions(x, y, z, origin_type)
                       values (floor((random()*1000+1))::int, floor((random()*1000+1))::int,floor((random()*1000+1))::int, 'PLANET') returning id into position_id_tmp;
                insert into beldons(planet_id, status, gas_count, position_id)
                        values (NEW.id,
                                'EXIST',
                                floor((random()*100+1))::int,
                                position_id_tmp);
            end loop;
    end if;

END
$$;

alter function init_beldons_for_gas_planet() owner to s250947;

