create function create_levels() returns void
    language plpgsql
as
$$
begin
    INSERT INTO "Level"("Name", "Start_capital", "Max_bottle_course")
    VALUES ('EASY', 500, 10);

    INSERT INTO "Level"("Name", "Start_capital", "Max_bottle_course")
    VALUES ('MEDIUM', 300, 7);

    INSERT INTO "Level"("Name", "Start_capital", "Max_bottle_course")
    VALUES ('HARD', 150, 5);

    INSERT INTO "Level"("Name", "Start_capital", "Max_bottle_course")
    VALUES ('EXPERT', 0, 3);
    RETURN;
end
$$;

alter function create_levels() owner to s264425;

