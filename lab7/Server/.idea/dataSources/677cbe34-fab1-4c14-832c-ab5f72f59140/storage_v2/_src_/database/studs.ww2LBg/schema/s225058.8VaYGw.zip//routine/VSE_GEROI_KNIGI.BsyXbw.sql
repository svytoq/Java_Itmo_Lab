create function "ВСЕ_ГЕРОИ_КНИГИ"(name character varying)
    returns TABLE("ИМЯ" character varying, "ФАМИЛИЯ" character varying, "ОТЧЕСТВО" character varying, "РАСА" character varying, "ПОЛ" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT ПЕРСОНАЖИ.ИМЯ,ПЕРСОНАЖИ.ФАМИЛИЯ,ПЕРСОНАЖИ.ОТЧЕСТВО,ПЕРСОНАЖИ.РАСА,ПЕРСОНАЖИ.ПОЛ FROM (КНИГИ JOIN КНИГА_И_ПЕРСОНАЖ ON КНИГИ.ИД=КНИГА_И_ПЕРСОНАЖ.ИД_КНИГИ) AS A JOIN ПЕРСОНАЖИ ON ПЕРСОНАЖИ.ИД=A.ИД_ПЕРСОНАЖ WHERE НАЗВАНИЕ = name;
END;
$$;

alter function "ВСЕ_ГЕРОИ_КНИГИ"(varchar) owner to s225058;

