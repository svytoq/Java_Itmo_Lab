create function "подтвердитьЗаказ"("заказ" integer, "центрЗабораМатериала" integer) returns void
    language plpgsql
as
$$
declare
сегодня int;
r ЛабораторныеИсследования%rowtype;
begin
    for r in (select * from ЛабораторныеИсследования where заказ_id=заказ)
    loop
        сегодня := (select id from Доставки
         where Доставки.дата_отправления=now()::DATE AND Доставки.центр_id=центрЗабораМатериала
         AND Доставки.лаборатория_id=(select лаборатория_id from Лаборатории_Исследования 
                                        where r.исследование_id=ЛабораторныеИсследования.исследование_id 
                                        order by random() limit 1));
        update ЛабораторныеИсследования
        set доставка_id=сегодня
        where id=r.id;
    end loop;
end;
$$;

alter function "подтвердитьЗаказ"(integer, integer) owner to s264447;

