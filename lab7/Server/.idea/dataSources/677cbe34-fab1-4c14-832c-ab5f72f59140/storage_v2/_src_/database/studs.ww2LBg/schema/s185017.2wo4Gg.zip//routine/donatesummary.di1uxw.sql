create function donatesummary()
    returns TABLE(sp_id integer, org_id integer, sum numeric)
    language plpgsql
as
$$
BEGIN
return query select sp.ИД_Спонсора, sp.ИД_НИЦ, sum(sp.Сумма_вклада) from Спонсор as sp group by sp.ИД_НИЦ, sp.ИД_Спонсора order by sp.ИД_Спонсора,sum;
END;
$$;

alter function donatesummary() owner to s185017;

