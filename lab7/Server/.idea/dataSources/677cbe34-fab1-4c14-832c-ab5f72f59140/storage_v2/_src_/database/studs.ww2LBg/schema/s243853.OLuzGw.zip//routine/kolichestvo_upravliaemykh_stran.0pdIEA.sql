create function количество_управляемых_стран("ид_правителя" integer) returns integer
    language plpgsql
as
$$
BEGIN
RETURN (SELECT COUNT(*) FROM ГОСУДАРСТВА WHERE ИД_ПРАВИТЕЛЯ = ид_правителя);
END
$$;

alter function количество_управляемых_стран(integer) owner to s243853;

