create function checkmoneyage() returns trigger
    language plpgsql
as
$$
DECLARE
    age int = 0;
BEGIN
    SELECT "Age"
    FROM "Homeless"
    where "Homeless".ID = NEW."Homeless_ID"
    INTO age;
    IF age < 60 * 240 and NEW."Action_ID" = 42 THEN
        RAISE EXCEPTION 'Нельзя выйти на пенсию до 60 лет';
    END IF;
    RETURN NEW;
END;
$$;

alter function checkmoneyage() owner to s264425;

