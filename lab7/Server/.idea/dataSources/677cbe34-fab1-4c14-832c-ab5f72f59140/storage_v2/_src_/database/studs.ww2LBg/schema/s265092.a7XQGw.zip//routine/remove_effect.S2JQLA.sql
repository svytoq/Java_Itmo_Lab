create function remove_effect(humanid integer, mageid integer) returns integer
    language plpgsql
as
$$
DECLARE
    ABIL VARCHAR(25);
BEGIN
IF(((SELECT EFFECT FROM HUMAN WHERE PERSON_ID = HUMANID) IS NULL)) THEN
RETURN 2;
END IF;
    ABIL = (SELECT ABILITY FROM SMOKE JOIN MAGE ON MAGE.SMOKE_ID = SMOKE.SMOKE_ID WHERE MAGE_ID = MAGEID);
    IF ((ABIL = 'Healing' OR ABIL = 'Dispelling') AND (SELECT ALIVE FROM MAGE WHERE MAGE_ID = MAGEID)) THEN
        UPDATE HUMAN
        SET EFFECT = NULL,
            EFFECT_FROM = NULL
        WHERE PERSON_ID = HUMANID;
UPDATE MAGE
        SET MONEY = MONEY + 250
        WHERE MAGE_ID = MAGEID;
RETURN 0;
ELSE
RETURN 1;
    END IF;
END;
$$;

alter function remove_effect(integer, integer) owner to s265092;

