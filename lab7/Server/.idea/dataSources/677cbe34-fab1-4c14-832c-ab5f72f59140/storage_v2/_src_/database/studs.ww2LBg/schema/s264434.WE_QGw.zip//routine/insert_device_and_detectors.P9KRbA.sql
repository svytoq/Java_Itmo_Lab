create function insert_device_and_detectors(_name character varying, _description character varying) returns integer
    language plpgsql
as
$$
declare
    min_val integer;
    max_val integer;
    ip inet;
    ret_id integer;
begin
    INSERT INTO "Devices"(model_name, model_description) VALUES (_name, _description) returning id into ret_id;
    min_val := floor(random() * 1000 + 1)::int;
    max_val := floor(random() * 1000 + 1)::int + 1000;
    ip := random_ip();
    insert into "Detectors"(id_device, min_value, max_value, type, description, ip_address)
    VALUES (ret_id, min_val, max_val,  'analog_input', 'Напряжение на устройстве', ip),
           (ret_id, min_val, max_val,  'analog_output', 'Частота работы', ip),
           (ret_id, min_val, max_val,  'digital_input', 'Время работы устройста', ip),
           (ret_id, min_val, max_val,  'digital_output', 'Кол-во опросов', ip);
    return ret_id;
end;
$$;

alter function insert_device_and_detectors(varchar, varchar) owner to s264434;

