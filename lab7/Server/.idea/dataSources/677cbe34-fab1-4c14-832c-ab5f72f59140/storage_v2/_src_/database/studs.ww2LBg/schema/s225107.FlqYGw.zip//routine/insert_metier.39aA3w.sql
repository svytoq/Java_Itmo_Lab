create function insert_metier() returns void
    language plpgsql
as
$$
DECLARE
    count INTEGER = 0;
    name text = insert_random();
  BEGIN
    LOOP
      IF NOT EXISTS(SELECT * FROM metier WHERE metier = name)
        THEN
          INSERT INTO metier VALUES(DEFAULT, name);
          count = count + 1;
        ELSE name = insert_random();
      END IF;
      EXIT WHEN count = 100;
    END LOOP;
  END;
$$;

alter function insert_metier() owner to s225107;

