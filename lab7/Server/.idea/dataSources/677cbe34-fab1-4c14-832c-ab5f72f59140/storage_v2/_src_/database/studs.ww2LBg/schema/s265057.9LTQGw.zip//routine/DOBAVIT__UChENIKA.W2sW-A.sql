create function "ДОБАВИТЬ_УЧЕНИКА"() returns trigger
    language plpgsql
as
$$
DECLARE
	age interval;
BEGIN
	age:=age(NEW.ДАТА_РОЖДЕНИЯ);
	if (age<'5 YEARS' or age>'130 YEARS') THEN
		RAISE NOTICE 'Ученик слишком молод или стар для этой школы';
		RETURN NULL;
	ELSIF (NEW.УРОВЕНЬ is not null) THEN
		RAISE NOTICE 'У нового ученика уровень должен быть неопределён';
		RETURN NULL;
	ELSIF (NEW.ГРУППА_ИД IS NOT NULL) THEN
		RAISE NOTICE 'У нового ученика группа должна быть неопределена';
		RETURN NULL;
	ELSIF (NEW.ОЖИДАНИЕ=false) THEN
		RAISE NOTICE 'У нового ученика ожидание должно быть равно 1, т.к. он ожидает тестирования';
		RETURN NULL;
	ELSIF (NEW.СТОИМОСТЬ_ОБУЧЕНИЯ=17500) THEN
		RAISE NOTICE 'У нового ученика стоимость=18500';
		RETURN NULL;
	ELSE RETURN NEW;
	END IF;
END;
$$;

alter function "ДОБАВИТЬ_УЧЕНИКА"() owner to s265057;

