create function updaterate() returns trigger
    language plpgsql
as
$$
DECLARE
s_serial int := 0;
s_season int := 0;
s_seria int := 0;
BEGIN

s_seria := new."SeriaId";

s_season := (SELECT "SeasonId" from "Seria" WHERE "Id" = s_seria);
s_serial := (SELECT "SerialId" from "Season" WHERE "Id" = s_season);
UPDATE "Seria" SET "Rate" = (SELECT AVG("Value") FROM "UserRate" WHERE "SeriaId" = s_seria) WHERE "Id" = s_seria;
UPDATE "Season" SET "Rate" = (SELECT AVG("Rate") FROM "Seria" WHERE "SeasonId" = s_season) WHERE "Id" = s_season;
UPDATE "Serial" SET "Rate" = (SELECT AVG("Rate") FROM "Season" WHERE "SerialId" = s_serial) WHERE "Id" = s_serial;
RETURN NEW;
END;
$$;

alter function updaterate() owner to s264469;

