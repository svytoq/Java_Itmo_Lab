create function customer_information(customer_nick character varying)
    returns TABLE(customer_id integer, age integer, customer_nick_name character varying, customer_name character varying, customer_last_name character varying, link_photo character varying, rating_num integer, credentials character varying, paymentmethod_type s263919.paymentmethod_types, customer_balance integer)
    language plpgsql
as
$$
begin
    return query select c.customer_id, c.age, c.customer_nick_name, c.customer_name, c.customer_last_name, a.link_photo, r.rating_num, p.credentials, p.paymentmethod_type, p.customer_balance from customer c join rating r using (rating_id) join avatar a using(avatar_id) join paymentmethod p using(customer_nick_name) where c.customer_nick_name = customer_nick;
end;
$$;

alter function customer_information(varchar) owner to s263919;

