create function return_transport_after_using() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW.transport_id IS NULL AND OLD.transport_id IS NOT NULL) OR (NEW.transport_id <> OLD.transport_id) THEN
      UPDATE transport SET availability = TRUE WHERE id = OLD.transport_id;
    END IF;
      RETURN NEW;
  END;
$$;

alter function return_transport_after_using() owner to s243867;

