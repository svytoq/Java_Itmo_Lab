create function "СОРЕВНОВАНИЯ_stamp"() returns trigger
    language plpgsql
as
$$
BEGIN 
    IF NEW.ИД IS NULL THEN
            RAISE EXCEPTION 'ИД cannot be null';
        END IF;
   
IF NEW.ИД_ТРАССЫ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF; 
IF (NEW.УРОВЕНЬ_СОРЕВНОВАНИЙ IN (SELECT НАЗВАНИЕ FROM УРОВЕНЬ_СОРЕВН)) = FALSE THEN 
RAISE EXCEPTION '% cannot have THIS TYPE', NEW.ИД;
        END IF;
IF (NEW.ТИП IN (SELECT НАЗВАНИЕ FROM ТИП_СОРЕВН)) = FALSE THEN 
RAISE EXCEPTION '% cannot have THIS TYPE', NEW.ИД;
        END IF;
RETURN NEW;
  END;
$$;

alter function "СОРЕВНОВАНИЯ_stamp"() owner to s243880;

