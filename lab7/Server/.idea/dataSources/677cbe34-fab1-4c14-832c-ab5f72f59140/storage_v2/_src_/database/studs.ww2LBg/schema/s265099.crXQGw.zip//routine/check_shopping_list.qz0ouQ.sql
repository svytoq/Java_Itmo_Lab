create function check_shopping_list(shopping_list_id integer) returns void
    language plpgsql
as
$$
DECLARE count_of_products INTEGER;	
	BEGIN
		count_of_products = (SELECT COUNT(*) FROM продукты WHERE id_списка_покупок = shopping_list_id);

		IF (count_of_products = 0) THEN
			DELETE FROM список_покупок WHERE id_списка_покупок = shopping_list_id;
		END IF;
	END
$$;

alter function check_shopping_list(integer) owner to s265099;

