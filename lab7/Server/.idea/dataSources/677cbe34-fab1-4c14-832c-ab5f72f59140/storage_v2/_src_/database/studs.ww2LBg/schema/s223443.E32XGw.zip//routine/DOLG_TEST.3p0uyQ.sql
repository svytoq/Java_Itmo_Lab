create function "ДОЛГ_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "ДОЛГ" ("ДАТА_ОТКРЫТИЯ", "ДАТА_ЗАКРЫТИЯ","ВЫПЛАЧЕННАЯ_ЧАСТЬ_ДОЛГА","СУММА_ДОЛГА")
VALUES (date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)),date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)),w,s);
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END LOOP;
END;
$$;

alter function "ДОЛГ_ТЕСТ"(integer) owner to s223443;

