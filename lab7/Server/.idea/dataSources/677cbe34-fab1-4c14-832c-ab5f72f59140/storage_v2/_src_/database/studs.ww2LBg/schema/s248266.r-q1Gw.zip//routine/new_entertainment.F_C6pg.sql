create function new_entertainment(userid integer, entertainmentname text, entertainmenttype text, description text, whenstarts timestamp without time zone, whenends timestamp without time zone) returns void
    language plpgsql
as
$$
DECLARE
eventId int;
typeId int;
BEGIN
    IF whenStarts > whenEnds THEN
        RAISE EXCEPTION 'Событие заканчивается раньше начала.';
    END IF;

    IF NOT EXISTS (
        SELECT 1 FROM К_Вид_развлечения WHERE Название = entertainmentType)
    THEN
        INSERT INTO К_Вид_развлечения (Название) VALUES (entertainmentType);
    END IF;
    typeId := (SELECT ИД FROM К_Вид_развлечения WHERE Название = entertainmentType);
    
    INSERT INTO К_Событие (ИД_Пользователя, Название, Описание, Тип,
        Время_начала, Время_окончания) VALUES (userId,
        'Развлечение (' || entertainmentName || ')',
        description, entertainmentType, whenStarts, whenEnds)
        RETURNING ИД INTO eventId;
    INSERT INTO К_Развлечение (ИД_События, ИД_Вида_развлечения)
        VALUES (eventId, typeId);
END;
$$;

alter function new_entertainment(integer, text, text, text, timestamp, timestamp) owner to s248266;

