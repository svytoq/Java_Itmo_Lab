create function new_attempt() returns trigger
    language plpgsql
as
$$
DECLARE
	last_attempt_date TIMESTAMP;
BEGIN 
	SELECT attempt_end 
	FROM attempts
	INTO last_attempt_date
	WHERE 
		user_id=NEW.user_id 
		AND 
		test_id=NEW.test_id
	ORDER BY attempt_end DESC
	LIMIT 1;
	IF (SELECT 'true' FROM attempts WHERE user_id=NEW.user_id AND test_id=NEW.test_id AND attempt_end IS NULL) THEN
		IF (SELECT attempt_start+'24 hours' FROM attempts WHERE user_id=NEW.user_id AND test_id=NEW.test_id AND attempt_end IS NULL) < NOW() THEN
			UPDATE attempts SET attempt_end=(attempt_start+'24 hours') WHERE user_id=NEW.user_id AND test_id=NEW.test_id AND attempt_end IS NULL;
			return NEW;
		ELSE
			RAISE EXCEPTION 'Прошлая попытка не завершена.';
		END IF;
	END IF;
	IF (last_attempt_date + '24 hours') > (SELECT NOW()) THEN
		RAISE EXCEPTION 'Лимит 1 попытка в день.';
	END IF;
	return NEW;
END;
$$;

alter function new_attempt() owner to s173525;

