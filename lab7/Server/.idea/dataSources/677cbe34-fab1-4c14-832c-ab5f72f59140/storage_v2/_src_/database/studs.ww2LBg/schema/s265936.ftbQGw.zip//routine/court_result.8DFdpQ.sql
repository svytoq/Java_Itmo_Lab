create function court_result(n_id integer, angel_id integer) returns integer
    language plpgsql
as
$$
declare
pray_points int;
sin_points int;
BEGIN
pray_points = (select sum(points) from pray join remorse r on pray.id = r.pray_id
    join soul s on r.soul_id = s.id where s.id = n_id);
sin_points = (select sum(level) from sin join sin_fall sf on sin.id = sf.sin_id
    join soul s2 on sf.soul_id = s2.id where s2.id = n_id);
if (sin_points - pray_points)>=0 then
        insert into last_judgment(soul_id, worker_id, result) VALUES
        (n_id, angel_id, 'Осужден');
        update soul set status = 'Отправлен в Ад' where id = n_id;
else
        insert into last_judgment(soul_id, worker_id, result) VALUES
        (n_id, angel_id, 'Помилован');
        update soul set status = 'Отправлен в Рай' where id = n_id;
end if;
RETURN 1;
END;
$$;

alter function court_result(integer, integer) owner to s265936;

