create function generate() returns text
    language plpgsql
as
$$
declare
begin

  insert into teams (id, organization_id, name, status) 
  select i, case when i%2=0 then 1 else 2 end, i::text, case when i%2=0 then 'active' else 'failed' end
  from generate_series(10, 5000) as i;
  
  insert into characters (id, organization_id, base_id, first_name, second_name, nickname, team_id) 
  select i, case when i%2=0 then 1 else 2 end, 
  case when i%2=0 then 1 else 2 end, 
  i::text, i::text, i::text, i%4990+10 from generate_series(5, 20000) as i;
  
  insert into weapons (id) select i from generate_series(21, 50000) as i;
  
  insert into equipments(id, name) select i, i::text from generate_series(21, 50000) as i;
  
  insert into character_has_weapon(character_id, weapon_id) 
  select i%1970+20, i from generate_series(21, 50000) as i;
  
  insert into organization_has_equipment(organization_id, equipment_id)
  select case when i%2=0 then 1 else 2 end, i from generate_series(21, 50000) as i;
  
  insert into operations (id, team_id, region_id, name, status)
  select i, i%4990+10, case when i%2=0 then 1 else 2 end, i::text, 
  case when i%2=0 then 'success' else 'failed' end
  from generate_series(10, 10000) as i;
  
  insert into goals (id, operation_id, goal_description)
  select i, i%9990+10,
  case when i%3=0 then 'attack' when i%3=1 then 'free' else 'catch' end
  from generate_series(10, 20000) as i;
  
  insert into equipment_in_operation (equipment_id, operation_id)
  select i, i%9990+10 from generate_series(10, 50000) as i;
  
  insert into transitions (character, from_org, to_org)
  select i%19990+10, case when i%2=0 then 1 else 2 end, case when i%2=0 then 2 else 1 end
  from generate_series(10, 30000) as i;
  
  return 'Данные сгенерированы';
end;
$$;

alter function generate() owner to s263148;

