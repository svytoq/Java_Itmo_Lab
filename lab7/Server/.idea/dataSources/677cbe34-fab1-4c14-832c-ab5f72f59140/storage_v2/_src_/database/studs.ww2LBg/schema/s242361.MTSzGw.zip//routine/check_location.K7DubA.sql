create function check_location() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((NEW.КООРДИНАТА_X > (SELECT ДЛИНА_АРЕНЫ FROM АРЕНЫ 
JOIN ИГРЫ ON ((ИД_АРЕНЫ = АРЕНА) AND (NEW.ИД_ИГРЫ = ИГРЫ.ИД_ИГРЫ))
))
OR
(NEW.КООРДИНАТА_Y > (SELECT ШИРИНА_АРЕНЫ FROM АРЕНЫ 
JOIN ИГРЫ ON ((ИД_АРЕНЫ = АРЕНА) AND (NEW.ИД_ИГРЫ = ИГРЫ.ИД_ИГРЫ))
)))
THEN
RAISE WARNING 'Введёны неверные координаты';
RETURN NULL;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function check_location() owner to s242361;

