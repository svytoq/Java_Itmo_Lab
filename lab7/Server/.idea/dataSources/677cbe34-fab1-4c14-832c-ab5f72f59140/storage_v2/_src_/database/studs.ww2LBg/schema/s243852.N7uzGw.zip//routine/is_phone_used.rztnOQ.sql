create function is_phone_used(f_phone character varying) returns boolean
    language plpgsql
as
$$
DECLARE
  phone_from_db varchar(20) = (SELECT phone
                               FROM app_user
                               where app_user.phone = f_phone);
BEGIN
  if phone_from_db IS NOT NULL THEN
    return true;
  end if;
  return false;
END;
$$;

alter function is_phone_used(varchar) owner to s243852;

