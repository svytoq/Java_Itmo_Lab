create function note_heart_toggle(heart_user_id bigint, heart_note_id bigint, OUT status text, OUT new_heart_count bigint) returns record
    language plpgsql
as
$$
declare
note_creator_id bigint;
heart_deleted boolean;
begin
note_creator_id := (select creator_id from notes where id = heart_note_id);

if note_creator_id = heart_user_id
then
status := 'error';
return;
end if;

with try_delete as (
delete from note_hearts_users
where user_id = heart_user_id and note_id = heart_note_id
returning 1
)
select exists(select from try_delete)
into heart_deleted;

if heart_deleted then
status := 'removed';
else
status := 'added';
insert into note_hearts_users values (heart_user_id, heart_note_id);
end if;

new_heart_count := (select heart_count from notes where id = heart_note_id);
end;
$$;

alter function note_heart_toggle(bigint, bigint, out text, out bigint) owner to s244706;

