create function count_currency_market_price(currencyid1 integer, currencyid2 integer) returns double precision
    language plpgsql
as
$$
declare currency1ToCurrency2Fraction float;
    begin
        currency1ToCurrency2Fraction = (select avg(currency_listing.buy_amount::float / sell_amount::float)
                                                                                        from currency_listing
        where currency_for_sell_id = currencyId1 and currency_for_buy_id = currencyId2);
        return currency1ToCurrency2Fraction;
    end;
$$;

alter function count_currency_market_price(integer, integer) owner to s263063;

