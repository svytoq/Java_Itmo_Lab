create function update_participant_info() returns trigger
    language plpgsql
as
$$
BEGIN
        update participant set country_id = new.id where new.main_person_id = id;
    return null;
    end;
$$;

alter function update_participant_info() owner to s264957;

