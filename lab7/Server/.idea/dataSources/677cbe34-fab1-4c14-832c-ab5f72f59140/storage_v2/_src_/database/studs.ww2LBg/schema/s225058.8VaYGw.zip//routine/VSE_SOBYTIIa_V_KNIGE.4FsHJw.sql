create function "ВСЕ_СОБЫТИЯ_В_КНИГЕ"(name character varying)
    returns TABLE("СУТЬ" text, "ДАТА" s225058.datepair, "СТРАНА" character varying, "ВЛИЯНИЕ" text)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT КУЛЬТ_И_ИСТ_СОБ.СУТЬ,КУЛЬТ_И_ИСТ_СОБ.ДАТА,КУЛЬТ_И_ИСТ_СОБ.СТРАНА,КУЛЬТ_И_ИСТ_СОБ.ВЛИЯНИЕ FROM (КНИГИ JOIN КНИГА_И_СОБ ON КНИГИ.ИД=КНИГА_И_СОБ.ИД_КНИГИ) as A JOIN КУЛЬТ_И_ИСТ_СОБ ON A.ИД_СОБ = КУЛЬТ_И_ИСТ_СОБ.ИД WHERE НАЗВАНИЕ = name;
END;
$$;

alter function "ВСЕ_СОБЫТИЯ_В_КНИГЕ"(varchar) owner to s225058;

