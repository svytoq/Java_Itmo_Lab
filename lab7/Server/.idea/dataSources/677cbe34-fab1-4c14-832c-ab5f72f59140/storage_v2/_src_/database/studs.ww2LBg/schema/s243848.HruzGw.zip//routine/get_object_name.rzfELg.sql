create function get_object_name(object_id integer) returns text
    language plpgsql
as
$$
BEGIN
IF EXISTS(SELECT ИД_ОБЪЕКТА
FROM КОРАБЛИ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id)
THEN

RETURN ( SELECT НАЗВАНИЕ
FROM КОРАБЛИ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id);
ELSEIF EXISTS(SELECT ИД_ОБЪЕКТА
FROM ЛЮДИ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id)
THEN

RETURN ( SELECT ИМЯ
FROM ЛЮДИ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id);
ELSEIF EXISTS(SELECT ИД_ОБЪЕКТА
FROM СТАНЦИИ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id)
THEN

RETURN ( SELECT НАЗВАНИЕ
FROM СТАНЦИИ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id);

ELSEIF EXISTS(SELECT ИД_ОБЪЕКТА
FROM ВИДЫ_ДВИГАТЕЛЕЙ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id)
THEN

RETURN ( SELECT НАЗВАНИЕ
FROM ВИДЫ_ДВИГАТЕЛЕЙ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id);

ELSEIF EXISTS(SELECT ИД_ОБЪЕКТА
FROM ДВИГАТЕЛИ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id)
THEN

RETURN ( SELECT CONCAT(ИД, МОДЕЛЬ)
FROM ДВИГАТЕЛИ NATURAL JOIN ОБЪЕКТЫ WHERE ИД_ОБЪЕКТА = object_id);
END IF;
END;
$$;

alter function get_object_name(integer) owner to s243848;

