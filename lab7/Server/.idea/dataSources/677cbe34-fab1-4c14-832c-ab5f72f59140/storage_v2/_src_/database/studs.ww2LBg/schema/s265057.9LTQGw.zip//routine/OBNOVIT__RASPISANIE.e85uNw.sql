create function "ОБНОВИТЬ_РАСПИСАНИЕ"() returns trigger
    language plpgsql
as
$$
DECLARE
	lesson record;
BEGIN
	IF (NEW.ПРЕП_ИД IS NULL) THEN 
		RETURN NULL;
	ELSIF (OLD.ПРЕП_ИД IS NOT NULL AND NEW.ПРЕП_ИД=OLD.ПРЕП_ИД) THEN 
		RETURN NULL;
	END IF;
	IF (OLD.ПРЕП_ИД IS NULL) THEN
		FOR lesson IN SELECT * FROM ЗАНЯТИЕ WHERE ГРУППА_ИД=NEW.ГРУППА_ИД AND ПРЕП_ИД IS NULL LOOP
			UPDATE ЗАНЯТИЕ SET ПРЕП_ИД=NEW.ПРЕП_ИД WHERE ЗАНЯТИЕ_ИД=lesson.ЗАНЯТИЕ_ИД;
		END LOOP;
	ELSE
		FOR lesson IN SELECT * FROM ЗАНЯТИЕ WHERE ГРУППА_ИД=NEW.ГРУППА_ИД AND ПРЕП_ИД=OLD.ПРЕП_ИД LOOP
			UPDATE ЗАНЯТИЕ SET ПРЕП_ИД=NEW.ПРЕП_ИД WHERE ЗАНЯТИЕ_ИД=lesson.ЗАНЯТИЕ_ИД;
		END LOOP;
	END IF;
	RETURN NULL;
END;
$$;

alter function "ОБНОВИТЬ_РАСПИСАНИЕ"() owner to s265057;

