create function add_to_log() returns trigger
    language plpgsql
as
$$
DECLARE
    msg varchar(40);
    id int;
    стая int;
    пол char(1);
    действие int;
    имя char(20);
    retstr varchar(256);
BEGIN
    IF  TG_OP = 'INSERT' THEN
        id = NEW.id;
        стая = NEW.стая;
        пол = NEW.пол;
        действие = NEW.действие;
        имя = NEW.имя;
        msg := 'Добавлен человек ';
        retstr := msg || ' '|| id || ' '|| стая || ' '|| пол || ' '|| действие|| ' ' || имя;
        INSERT INTO Logs(Текст, Добавлено) values (retstr,NOW());
        RETURN NEW;
    ELSIF  TG_OP = 'DELETE' THEN
        id = id;
        стая = OLD.стая;
        пол = OLD.пол;
        действие = OLD.действие;
        имя = OLD.имя;
        msg := 'Удален человек ';
        retstr := msg || ' '|| id || ' '|| стая || ' '|| пол || ' '|| действие|| ' ' || имя;
        INSERT INTO Logs(Текст, Добавлено) values (retstr,NOW());
        RETURN OLD;
    END IF;
END;
$$;

alter function add_to_log() owner to s245031;

