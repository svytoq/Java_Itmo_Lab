create function "ИГРОК_ИНДЕКС_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  q integer;
BEGIN
  q = (SELECT max("ИД_ИГРОКА") + 1 FROM "ИГРОК");
  FOR k IN 1..i LOOP
    INSERT INTO "ИГРОК" ("ИД_ИГРОКА", "ИМЯ_ИГРОКА", "ФАМИЛИЯ_ИГРОКА", "ДАТА_РОЖДЕНИЯ", "НИКНЕЙМ", "СТРАНА", "НАЧАЛО_КАРЬЕРЫ")
    VALUES (q::integer, random_string(random()::integer*10+4), random_string(random()::integer*10+4), date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)), random_string(random()::integer*10+4), random_string(random()::integer*10+4), date(NOW() + '1 year'::INTERVAL + '1 year'::INTERVAL * ROUND(RANDOM() * 100)));
    k = k + 1;
    q = q + 1;
  END LOOP;
END;
$$;

alter function "ИГРОК_ИНДЕКС_ТЕСТ"(integer) owner to s225126;

