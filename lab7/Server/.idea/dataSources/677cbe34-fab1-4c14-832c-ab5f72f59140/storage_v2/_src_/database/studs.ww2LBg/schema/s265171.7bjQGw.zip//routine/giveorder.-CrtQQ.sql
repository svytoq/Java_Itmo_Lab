create function giveorder(don_id integer, order_id integer, with_consiglieri boolean) returns boolean
    language plpgsql
as
$$
declare
      current_order "order";
      don_family family;
      lawyers_number int;
      soldiers_number int;
      current_lawyer record;
      current_soldier record;
      current_consiglieri consiglieri;
    begin
      select into current_order * from "order" where order_id=id;
      if don_id != current_order.don then
        raise exception 'Unable to give an order with id %',
          order_id
          using hint='The don is not responsible for this order';
      else
        select into don_family * from family
        where name=(select don.family from don where don_id=id);
        if don_family.budget>=current_order.cost then
          execute format('create or replace view soldiers as select id, family, is_busy from soldier
          where family=''%s'' and is_busy=false limit %s',
            don_family.name, current_order.soldiers_number);
          execute format('create or replace view lawyers as select id, family, is_busy from lawyer
          where family=''%s'' and is_busy=false limit %s',
            don_family.name, current_order.lawyers_number);
          execute 'select count(*) from lawyers'
            into lawyers_number using don_family.name;
          execute 'select count(*) from soldiers'
            into soldiers_number using don_family.name;
          if (lawyers_number)
               >=
             current_order.lawyers_number then
            if (soldiers_number)
              >=
              current_order.soldiers_number then
              for current_lawyer in select * from lawyers loop
                update lawyer set is_busy=true where id=current_lawyer.id;
              end loop;
              for current_soldier in select * from soldiers loop
                update soldier set is_busy=true where id=current_soldier.id;
              end loop;
              update family
              set budget=don_family.budget-current_order.cost
              where name=don_family.name;
              if with_consiglieri then
                select into current_consiglieri *
                from consiglieri where id=(select family.consiglieri
                from family where name=don_family.name);
                if current_consiglieri.current_order is null then
                  update "order" set income=income*2 where id=order_id;
                  update consiglieri set current_order=order_id
                  where id=current_consiglieri.id;
                else
                  raise exception 'Unable to give an order with id %',
                    order_id
                    using hint='The consiglieri is busy now';
                end if;
              end if;
              return true;
            else
                raise exception 'Unable to give an order with id % with % soldier(s)',
                  order_id, soldiers_number
                  using hint='The family has not got enough soldiers';
            end if;
          else
            raise exception 'Unable to give an order with id % with % lawyer(s)',
              order_id, lawyers_number
              using hint='The family has not got enough lawyers';
          end if;
          return true;
        else
          raise exception 'Unable to give an order with id %',
            order_id
            using hint='The family budget is too low';
        end if;
      end if;
      return null;
    end;
$$;

alter function giveorder(integer, integer, boolean) owner to s265171;

