create function _trigger_transfer_employee_from_decommissioned_machine() returns trigger
    language plpgsql
as
$$
declare
    new_machine_id integer := 0;
begin
    if new.state = 'decommissioned' then
         insert into circuit_board_machine(assembly_date, work_hrs, area, state) values (now(), 0, new.area, 'ok') returning id into new_machine_id;
         update circuit_board_machine_param_item set machine_id = new_machine_id where machine_id = new.id;
         update employee_machine_xref set machine_id = new_machine_id where machine_id = new.id;
    end if;
    return new;
end;
$$;

alter function _trigger_transfer_employee_from_decommissioned_machine() owner to s264429;

