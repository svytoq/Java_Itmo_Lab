create function do_smt() returns trigger
    language plpgsql
as
$$
begin
if TG_OP = 'INSERT' then
select 'i have done smt with ' as message;
return new;
end if;
end;
$$;

alter function do_smt() owner to s264479;

