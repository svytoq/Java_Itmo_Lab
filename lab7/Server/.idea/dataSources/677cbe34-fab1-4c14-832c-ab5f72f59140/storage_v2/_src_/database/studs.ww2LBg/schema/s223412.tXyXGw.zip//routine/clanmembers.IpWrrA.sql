create function clanmembers()
    returns TABLE(name text, count bigint)
    language sql
as
$$
SELECT
  "Название_клана",
  Count(*)
FROM "Самурай"
WHERE "Жив" AND "Название_клана" IS NOT NULL
GROUP BY "Название_клана";
$$;

alter function clanmembers() owner to s223412;

