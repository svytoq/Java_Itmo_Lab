create function remove_developer_from_team(developer_id integer, team_id integer) returns void
    language plpgsql
as
$$
BEGIN

  IF (SELECT count(*) FROM team_project WHERE team_id = remove_developer_from_team.team_id) < 2 THEN
    RAISE EXCEPTION 'Cannot remove last developer from team';
  END IF;

  DELETE
  FROM team_project
  WHERE team_id = remove_developer_from_team.team_id
    AND developer_id = remove_developer_from_team.developer_id;

  RAISE NOTICE 'Разработчик удален из команды "%"',team_name(team_id);

END;

$$;

alter function remove_developer_from_team(integer, integer) owner to s264458;

