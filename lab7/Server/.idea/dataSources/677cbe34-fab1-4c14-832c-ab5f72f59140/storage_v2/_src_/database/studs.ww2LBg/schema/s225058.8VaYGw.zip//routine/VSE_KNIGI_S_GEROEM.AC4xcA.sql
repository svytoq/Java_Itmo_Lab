create function "ВСЕ_КНИГИ_С_ГЕРОЕМ"(firstname character varying, secondname character varying)
    returns TABLE("НАЗВАНИЕ" character varying, "СТРАНА" character varying, "ДАТА_ПУБЛИКАЦИИ" date, "ЖАНР" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT КНИГИ.НАЗВАНИЕ,КНИГИ.СТРАНА,КНИГИ.ДАТА_ПУБЛИКАЦИИ,КНИГИ.ЖАНР FROM (ПЕРСОНАЖИ JOIN КНИГА_И_ПЕРСОНАЖ ON ПЕРСОНАЖИ.ИД=КНИГА_И_ПЕРСОНАЖ.ИД_ПЕРСОНАЖ) AS A JOIN КНИГИ ON КНИГИ.ИД=A.ИД_КНИГИ WHERE ИМЯ = firstname and ФАМИЛИЯ = secondname or ФАМИЛИЯ is NULL and secondname IS NULL;
END;
$$;

alter function "ВСЕ_КНИГИ_С_ГЕРОЕМ"(varchar, varchar) owner to s225058;

