create function trigger_stages_del() returns trigger
    language plpgsql
as
$$
DECLARE
ondelete INTEGER;
BEGIN
SELECT "ИД_ЭТАПА" INTO ondelete FROM "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА" WHERE "ИД_СЛЕД_ЭТАПА" = OLD."ИД_ЭТАПА";
UPDATE "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА" SET "ИД_СЛЕД_ЭТАПА" = OLD."ИД_СЛЕД_ЭТАПА" WHERE "ИД_ЭТАПА" = ondelete ;
  RETURN OLD;
END;
$$;

alter function trigger_stages_del() owner to s243839;

