create function sell_of_item() returns trigger
    language plpgsql
as
$$
declare
		prise real;
	BEGIN
		IF (OLD.Статус = 'в инвентаре' AND NEW.Статус = 'продан') THEN
			Select Цена into prise from К_Предметы where Id = OLD.Предмет_ИД;
			UPDATE "К_Персонажи" SET "Деньги" = "К_Персонажи".Деньги + prise WHERE "К_Персонажи".Id = OLD.Персонаж_ИД;
			NEW.Момент_Отдачи := current_timestamp;
		END IF;
		RETURN NEW;
	END;

$$;

alter function sell_of_item() owner to s242193;

