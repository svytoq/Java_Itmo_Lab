create function game_ins_succ() returns trigger
    language plpgsql
as
$$
DECLARE
    pid integer;
BEGIN
    pid := (SELECT ид FROM стадии WHERE (начало<=new.дата) AND (конец>=new.дата));
    IF EXISTS (SELECT 1 FROM статистика WHERE (стад_ид=pid) AND (кмнд_ид=new.поб_ид)) THEN
        UPDATE статистика SET побед=побед+1 WHERE (стад_ид=pid) AND (кмнд_ид=new.поб_ид);
    ELSE 
        INSERT INTO статистика VALUES (pid, new.поб_ид, 1, 0);
    END IF;
    IF EXISTS (SELECT 1 FROM статистика WHERE (стад_ид=pid) AND (кмнд_ид=new.про_ид)) THEN
        UPDATE статистика SET поражений=поражений+1 WHERE (стад_ид=pid) AND (кмнд_ид=new.про_ид);
    ELSE 
        INSERT INTO статистика VALUES (pid, new.про_ид, 0, 1);
    END IF;
    RETURN NEW;
END;
$$;

alter function game_ins_succ() owner to s242558;

