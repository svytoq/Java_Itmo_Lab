create function pk_func_kon() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_kon');
  RETURN new;
END;
$$;

alter function pk_func_kon() owner to s223457;

