create function get_results(champ_id integer)
    returns TABLE(team_id integer, team_name text, final_score integer, place integer, special_award text)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT team.team_id, team.name, final_score, place, special_award
                 FROM team INNER JOIN score ON team.team_id = score.team_id
                 WHERE team.championship_id = champ_id
                 ORDER BY place;
END;
$$;

alter function get_results(integer) owner to s264448;

