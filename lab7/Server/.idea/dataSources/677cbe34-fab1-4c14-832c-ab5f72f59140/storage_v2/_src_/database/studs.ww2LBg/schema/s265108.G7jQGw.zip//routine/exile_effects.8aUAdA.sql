create function exile_effects() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE Magicians SET mag_type = 'd', order_id = null WHERE person_id = NEW.magician_id;
  RETURN NEW;
END;
$$;

alter function exile_effects() owner to s265108;

