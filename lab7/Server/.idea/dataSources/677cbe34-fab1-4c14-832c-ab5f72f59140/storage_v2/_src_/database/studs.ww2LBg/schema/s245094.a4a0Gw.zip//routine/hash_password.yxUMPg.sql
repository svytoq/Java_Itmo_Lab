create function hash_password() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE client set password = md5(NEW.password) where id=NEW.id;

    RETURN NEW;
END;
$$;

alter function hash_password() owner to s245094;

