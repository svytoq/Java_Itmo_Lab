create function check_tip_popolneniya() returns trigger
    language plpgsql
as
$$
BEGIN
  IF ( (new."Способ_пополнения" = 'ОНЛАЙН') AND (new."Код_станции" IS NOT NULL ) )
    THEN RAISE EXCEPTION 'Добавлене невозможно. При пополнении онлайн код_станции должен отсутствовать';
  end if;
  return new;
end;


$$;

alter function check_tip_popolneniya() owner to s244710;

