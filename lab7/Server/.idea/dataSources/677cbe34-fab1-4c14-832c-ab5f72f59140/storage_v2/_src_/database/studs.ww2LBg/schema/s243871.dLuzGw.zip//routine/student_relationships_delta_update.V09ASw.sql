create function student_relationships_delta_update() returns trigger
    language plpgsql
as
$$
begin
if tg_op = 'INSERT'
then new.delta := new.relationship;
end if;
if tg_op = 'UPDATE' and new.relationship <> old.relationship
then new.delta := old.delta + (new.relationship - old.relationship);
end if;
return new;
end;
$$;

alter function student_relationships_delta_update() owner to s243871;

