create function sell_of_item_del() returns trigger
    language plpgsql
as
$$
BEGIN
		IF (OLD.Статус = 'в инвентаре') THEN
			UPDATE "К_Инвентарь" SET "Статус" = 'продан' WHERE
			"К_Инвентарь".Предмет_ИД = OLD.Предмет_ИД AND "К_Инвентарь".Персонаж_ИД = OLD.Персонаж_ИД;
		END IF;
		RETURN NULL;
		END;
$$;

alter function sell_of_item_del() owner to s243870;

