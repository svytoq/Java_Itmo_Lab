create function check_teacher_student_duplicate_function() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE DEBUG 'Trigger function check_teacher_student_duplicate_function() fired';
    IF EXISTS(
            SELECT 1
            FROM students
            WHERE students.id = new.id
        )
    THEN
        RAISE WARNING 'Teacher with id % already exists as student',
            new.id;
        RETURN NULL;
    ELSE
        RETURN new;
    END IF;
END;
$$;

alter function check_teacher_student_duplicate_function() owner to s268925;

