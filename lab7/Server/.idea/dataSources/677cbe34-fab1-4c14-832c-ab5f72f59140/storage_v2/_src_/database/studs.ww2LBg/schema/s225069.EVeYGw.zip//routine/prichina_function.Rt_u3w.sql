create function prichina_function() returns trigger
    language plpgsql
as
$$
begin
new.Код=nextval('Причины_и_следствия_Код_seq');
return new;
end;
$$;

alter function prichina_function() owner to s225069;

