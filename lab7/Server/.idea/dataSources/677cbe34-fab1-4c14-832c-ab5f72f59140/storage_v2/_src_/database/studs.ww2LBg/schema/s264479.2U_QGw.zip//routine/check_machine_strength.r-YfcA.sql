create function check_machine_strength() returns trigger
    language plpgsql
as
$$
begin
if new.strength is null then
raise exception 'strngth cannot be null';
end if;
if new.strength < 0 then
raise exception 'strngth cannot be less than zero';
end if;
if (select (machine_type.base_strength >= new.strength) 
	from machine_type
	where machine_type.id = new.machine_type
	limit 1) then
return new;
else
return null;
end if;
end;
$$;

alter function check_machine_strength() owner to s264479;

