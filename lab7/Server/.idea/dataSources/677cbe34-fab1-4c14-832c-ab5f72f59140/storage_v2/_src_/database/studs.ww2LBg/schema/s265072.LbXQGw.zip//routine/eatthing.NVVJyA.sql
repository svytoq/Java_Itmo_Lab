create function eatthing(shortyid integer, contid integer) returns boolean
    language plpgsql
as
$$
DECLARE
	eatId integer;
	obj integer;
BEGIN
	IF (SELECT NOT EXISTS(SELECT 1 FROM Container join Changeable using (changeable_id) WHERE contId = container_id AND is_state = true)) THEN RETURN false; END IF;
	SELECT min(thing_id) INTO eatId FROM Thing WHERE container_id = contId and eatable = true;
	IF (eatId is NULL) Then RETURN false; END IF;
	UPDATE Shorty SET action_until_feed = 10 WHERE shortyId = shorty_id;
	DELETE FROM THING WHERE eatId = thing_id;
	SELECT object_id INTO obj FROM Changeable JOIN Container using (changeable_id) WHERE contId = container_id;
	INSERT INTO Object_to_action (shorty_id, action_id, subject_id, time) VALUES (shortyId, 2, obj, now());
	RETURN true;
END;
$$;

alter function eatthing(integer, integer) owner to s265072;

