create function set_zombie() returns trigger
    language plpgsql
as
$$
BEGIN 
 UPDATE Район SET Зомби = FALSE;
 UPDATE Район SET Зомби = TRUE 
           FROM Группы_зомби
WHERE Район.ИД = Группы_зомби.ИД_район;
RETURN NULL;
END;
$$;

alter function set_zombie() owner to s225039;

