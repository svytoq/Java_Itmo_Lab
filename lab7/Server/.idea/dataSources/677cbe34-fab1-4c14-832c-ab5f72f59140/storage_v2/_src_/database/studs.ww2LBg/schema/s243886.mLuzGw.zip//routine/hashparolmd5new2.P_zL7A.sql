create function hashparolmd5new2() returns trigger
    language plpgsql
as
$$
begin 
UPDATE ЧЕЛОВЕК 
set ПАРОЛЬ=md5(ПАРОЛЬ)
WHERE ИД LIKE (SELECT MAX(ИД) FROM ЧЕЛОВЕК); 
RETURN NEW; 
END;
$$;

alter function hashparolmd5new2() owner to s243886;

