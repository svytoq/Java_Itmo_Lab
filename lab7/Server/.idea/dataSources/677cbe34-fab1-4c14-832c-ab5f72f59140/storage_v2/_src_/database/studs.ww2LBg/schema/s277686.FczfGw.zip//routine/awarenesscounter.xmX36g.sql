create function awarenesscounter() returns integer
    language plpgsql
as
$$
BEGIN
RETURN 10;
END;
$$;

alter function awarenesscounter() owner to s277686;

