create function checkjudge() returns trigger
    language plpgsql
as
$$
DECLARE
    Judge varchar(40);
	  JudgeOfTeam1 varchar(40);
    JudgeOfTeam2 varchar(40);
BEGIN
  SELECT СУДЬЯ.СТРАНА_СУДЬИ INTO Judge
    FROM СУДЬЯ
    WHERE СУДЬЯ.ИД_СУДЬИ = NEW.ИД_СУДЬИ;

    SELECT СТРАНА_УЧАСТНИЦА.НАИМЕНОВАНИЕ_СТРАНЫ INTO JudgeOfTeam1
    FROM СТРАНА_УЧАСТНИЦА
    WHERE СТРАНА_УЧАСТНИЦА.ИД_СТРАНЫ = NEW.ИД_1СТРАНЫ;

    SELECT СТРАНА_УЧАСТНИЦА.НАИМЕНОВАНИЕ_СТРАНЫ INTO JudgeOfTeam2
    FROM СТРАНА_УЧАСТНИЦА
    WHERE СТРАНА_УЧАСТНИЦА.ИД_СТРАНЫ = NEW.ИД_2СТРАНЫ;
  if (Judge <> JudgeOfTeam1 AND Judge <> JudgeOfTeam2) THEN
     return NEW;
     COMMIT;
    ELSE RAISE EXCEPTION 'Страна судьи совпадает со страной одной из команд!';
  END IF;
    return NULL;
END;
$$;

alter function checkjudge() owner to s224514;

