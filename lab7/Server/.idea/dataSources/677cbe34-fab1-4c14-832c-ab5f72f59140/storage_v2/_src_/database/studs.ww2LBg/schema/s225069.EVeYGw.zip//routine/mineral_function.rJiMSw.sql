create function mineral_function() returns trigger
    language plpgsql
as
$$
begin
new.Mineral_ID=nextval('Minerals_Mineral_ID_seq');
return new;
end;
$$;

alter function mineral_function() owner to s225069;

