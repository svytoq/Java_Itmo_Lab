create function to_warriors(count integer) returns void
    language plpgsql
as
$$
DECLARE
  I    INT;
  POS  POS;
  K    INT;
  SOSL VARCHAR(30);
  POL  VARCHAR(3);
BEGIN
  K = 0;
  FOR I IN SELECT ID_ЧЕЛ
           FROM ЛЮДИ
           WHERE ПОЛ = 'муж' AND СОСЛОВИЕ != 'ТОРГОВЕЦ' LOOP
    IF K = COUNT
    THEN EXIT; END IF;
    SELECT СОСЛОВИЕ
    FROM ЛЮДИ
    WHERE ID_ЧЕЛ = I
    INTO SOSL;
    SELECT ПОЛ
    FROM ЛЮДИ
    WHERE ID_ЧЕЛ = I
    INTO POL;


    IF SOSL = 'ПАТРИЦИЙ'
    THEN POS = 'ЛЕГИОНЕР';
    ELSEIF I % 100 = 0
      THEN POS = 'ЦЕНТУРИОН';
    ELSE POS = 'РЯДОВОЙ ВОИН';
    END IF;
    INSERT INTO ВОИНЫ VALUES (I, POS, NULL);
    K = K + 1;

  END LOOP;
END;
$$;

alter function to_warriors(integer) owner to s225081;

