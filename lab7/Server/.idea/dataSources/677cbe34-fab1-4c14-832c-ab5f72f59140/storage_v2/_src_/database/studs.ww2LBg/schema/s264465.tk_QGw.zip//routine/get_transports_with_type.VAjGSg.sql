create function get_transports_with_type(transport_type_id_arg integer)
    returns TABLE(id integer, additional_price numeric, additional_stress integer, name character varying, speed integer, transport_type_id integer)
    language plpgsql
as
$$
begin
    RETURN QUERY select * from transport where transport.transport_type_id = transport_type_id_arg;
end;
$$;

alter function get_transports_with_type(integer) owner to s264465;

