create function check_asoiaftblte(t1 text, t2 text) returns boolean
    language plpgsql
as
$$
DECLARE
  tstart bigint; tend bigint;
BEGIN
  tstart = ASOIAFtimeStringToInt(t1);
  tend = ASOIAFtimeStringToInt(t2);
  IF tstart = 0 OR tend = 0 OR t2 > t1 THEN
      RETURN FALSE;
  END IF;
  RETURN TRUE;
END
$$;

alter function check_asoiaftblte(text, text) owner to s225125;

