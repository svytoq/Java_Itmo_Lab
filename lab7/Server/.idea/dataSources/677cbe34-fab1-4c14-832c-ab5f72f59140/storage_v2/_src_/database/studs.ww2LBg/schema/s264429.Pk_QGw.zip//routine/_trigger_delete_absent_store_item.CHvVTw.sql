create function _trigger_delete_absent_store_item() returns trigger
    language plpgsql
as
$$
begin
    if new.amount = 0 then
        delete from store_item where store_id = new.store_id and product_id = new.product_id;
        return NULL; -- do not execute other triggers
    end if;
    return new;
end;
$$;

alter function _trigger_delete_absent_store_item() owner to s264429;

