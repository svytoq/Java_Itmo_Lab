create function check_dormitory_for_suggestion() returns trigger
    language plpgsql
as
$$
DECLARE
    REQUEST_AUTHOR       INTEGER := (SELECT AUTHOR
                                     FROM REQUEST
                                     WHERE ID = NEW.ID);
    SUGGESTION_AUTHOR    INTEGER := (SELECT AUTHOR
                                     FROM SUGGESTION
                                     WHERE ID = NEW.SUGGESTION);
    REQUEST_DORMITORY    INTEGER := (SELECT DORMITORY
                                     FROM USERS
                                     WHERE ID = REQUEST_AUTHOR);
    SUGGESTION_DORMITORY INTEGER := (SELECT DORMITORY
                                     FROM USERS
                                     WHERE ID = SUGGESTION_AUTHOR);
BEGIN
    IF REQUEST_DORMITORY != SUGGESTION_DORMITORY THEN
        RETURN NULL;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_dormitory_for_suggestion() owner to s265087;

