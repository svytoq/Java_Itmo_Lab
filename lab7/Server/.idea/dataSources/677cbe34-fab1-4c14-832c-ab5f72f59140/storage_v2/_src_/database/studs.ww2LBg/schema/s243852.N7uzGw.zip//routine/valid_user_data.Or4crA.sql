create function valid_user_data() returns trigger
    language plpgsql
as
$$
DECLARE
  code             int = 0;
  codeEmail        int = 1;
  codePhone        int = 2;
  codeSerialNumber int = 4;


BEGIN
  if is_email_used(new.email) THEN
    code = code + codeEmail;
  end if;
  if is_phone_used(new.phone) THEN
    code = code + codePhone;
  end if;
  if is_serial_number_used(new.serial_number) THEN
    code = code + codeSerialNumber;
  end if;
  case
    --     everything's fine
    when code = 0 then code = null ;
    --     email
    when code = 1 then code = 23030;
    --     phone
    when code = 2 then code = 23032;
    --     serial number
    when code = 4 then code = 23031;
    --     e + p
    when code = 3 then code = 23034;
    --     e + s_n
    when code = 5 then code = 23033;
    --     p + s_n
    when code = 6 then code = 23035;
    --     e + p + s_n
    when code = 7 then code = 23036;
    end case;
  if code is not null then
    raise using errcode = code;
  end if;
  return new;
end;
$$;

alter function valid_user_data() owner to s243852;

