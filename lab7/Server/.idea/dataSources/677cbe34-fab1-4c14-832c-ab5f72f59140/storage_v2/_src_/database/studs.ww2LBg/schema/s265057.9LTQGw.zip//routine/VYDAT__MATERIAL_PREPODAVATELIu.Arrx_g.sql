create function "ВЫДАТЬ_МАТЕРИАЛ_ПРЕПОДАВАТЕЛЮ"(id integer, name character varying, level_book smallint, OUT resultat text) returns text
    language plpgsql
as
$$
DECLARE
	material_id RECORD;
BEGIN
	IF (id is null) THEN
		resultat:=(SELECT ВЫДАТЬ_МАТЕРИАЛ_ПРЕПОДАВАТЕЛЮ(name,level_book));
	ELSE
		IF (name IS NULL) THEN
			IF (level_book is NULL) THEN
				FOR material_id IN SELECT МАТ_ПРЕП_ИД FROM МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ LOOP
					INSERT INTO ДОСТУП_МАТ_ПРЕПОД(ПРЕП_ИД,МАТ_ПРЕП_ИД) VALUES (id,material_id.МАТ_ПРЕП_ИД);
				END LOOP;
			ELSE 
				FOR material_id IN SELECT МАТ_ПРЕП_ИД FROM МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ WHERE (МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ.УРОВЕНЬ=level_book) LOOP
					INSERT INTO ДОСТУП_МАТ_ПРЕПОД(ПРЕП_ИД,МАТ_ПРЕП_ИД) VALUES (id,material_id.МАТ_ПРЕП_ИД);
				END LOOP;
			END IF;
		ELSE 
			IF (level_book is NULL) THEN
				FOR material_id IN SELECT МАТ_ПРЕП_ИД FROM МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ WHERE (МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ.НАЗВАНИЕ=name) LOOP
					INSERT INTO ДОСТУП_МАТ_ПРЕПОД(ПРЕП_ИД,МАТ_ПРЕП_ИД) VALUES (id,material_id.МАТ_ПРЕП_ИД);
				END LOOP;
			ELSE 
				FOR material_id IN SELECT МАТ_ПРЕП_ИД FROM МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ WHERE (МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ.УРОВЕНЬ=level_book and МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ.НАЗВАНИЕ=name) LOOP
					INSERT INTO ДОСТУП_МАТ_ПРЕПОД(ПРЕП_ИД,МАТ_ПРЕП_ИД) VALUES (id,material_id.МАТ_ПРЕП_ИД);
				END LOOP;
			END IF;
		END IF;
		resultat:='Материалы преподавателю успешно выданы';
	END IF;
EXCEPTION
	WHEN unique_violation THEN
		RAISE NOTICE 'Материал % уровня % не был выдан преподавателю с id %',name,level_book,id;
END;
$$;

alter function "ВЫДАТЬ_МАТЕРИАЛ_ПРЕПОДАВАТЕЛЮ"(integer, varchar, smallint, out text) owner to s265057;

