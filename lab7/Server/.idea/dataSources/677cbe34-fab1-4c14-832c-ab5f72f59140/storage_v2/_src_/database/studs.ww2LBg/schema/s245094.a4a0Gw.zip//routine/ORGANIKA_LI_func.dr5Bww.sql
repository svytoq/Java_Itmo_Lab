create function "ОРГАНИКА_ЛИ_func"() returns trigger
    language plpgsql
as
$$
    -- Каждый артефакт должен быть либо органического происхождения, либо неорганического
-- Третьего не дано, поэтому сразу в двух таблицах одного артефакта быть не может
        BEGIN
                IF TG_TABLE_NAME='ОРГ_АРТ' AND NEW."АРТ_ИД" IN (SELECT "АРТ_ИД" FROM "НЕОРГ_АРТ") THEN
                        RAISE EXCEPTION 'Artifact #% is already known as non-organics', NEW."АРТ_ИД";
                        RETURN NULL;
                ELSIF TG_TABLE_NAME='НЕОРГ_АРТ' AND NEW."АРТ_ИД" IN (SELECT "АРТ_ИД" FROM "ОРГ_АРТ") THEN
                        RAISE EXCEPTION 'Artifact #% is already known as organics', NEW."АРТ_ИД";
                        RETURN NULL;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "ОРГАНИКА_ЛИ_func"() owner to s245094;

