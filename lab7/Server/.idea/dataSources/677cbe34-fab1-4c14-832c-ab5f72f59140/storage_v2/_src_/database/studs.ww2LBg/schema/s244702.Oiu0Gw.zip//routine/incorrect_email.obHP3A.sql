create function incorrect_email() returns trigger
    language plpgsql
as
$$
declare i int;
        f int;
        CurrentSimbol text;
        simbols varchar;
        at_ int;
        dot int;
        --mail text;
BEGIN
  i:=1;
  f=0;
  at_=0;
  dot=0;
  simbols='abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_-0123456789';

  if new.email='' then f=-1000; end if; --работает
  while (i<=char_length(new.email)) loop
     CurrentSimbol:=SUBSTRING(new.email, i, 1);
  --raise exception 'Неверный email (%)',q;
   if ((strpos(simbols,CurrentSimbol)>0) or CurrentSimbol='.') and (f=i-1) and (at_=0) and (dot=0) then f:=f+1;
      elseif ((CurrentSimbol='@') and (f=i-1) and (i>1)) then f:=f+1;  at_=at_+1;
        elseif ((strpos(simbols,CurrentSimbol)>0) and (f=i-1) and (at_=1) and (dot=0)) then f:=f+1;
          elseif ((CurrentSimbol='.') and (f=i-1) and (at_=1) and (SUBSTRING(new.email, i-1, 1)!='@') and (i!=char_length(new.email))) then  f:=f+1; dot:=dot+1;
            elseif ((strpos(simbols, CurrentSimbol)>0) and (f=i-1) and (at_=1) and (dot=1)) then f:=f+1; else  f=-1000;
    end if;
    i:=i+1;
end loop;
  if ((f=char_length(new.email)) and (at_=0) and (dot=0)) or at_=0 or dot=0  then f=-1000;
    end if;
if f<0 then raise exception 'Неверный email'; else return new; end if ;
end;
$$;

alter function incorrect_email() owner to s244702;

