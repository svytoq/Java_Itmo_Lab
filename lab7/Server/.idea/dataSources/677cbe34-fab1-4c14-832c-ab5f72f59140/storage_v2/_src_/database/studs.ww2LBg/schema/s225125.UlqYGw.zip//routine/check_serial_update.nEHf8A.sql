create function check_serial_update() returns trigger
    language plpgsql
as
$$
DECLARE
  old_serial integer;
  new_serial integer;
BEGIN
  EXECUTE 'SELECT ($1).' || TG_ARGV[0] INTO new_serial USING NEW;
  EXECUTE 'SELECT ($1).' || TG_ARGV[0] INTO old_serial USING OLD;
  IF new_serial <> old_serial THEN
    RAISE EXCEPTION 'Нельзя изменять значение поля % таблицы %',
      TG_ARGV[0], TG_TABLE_NAME;
  END IF;
  RETURN NEW;
END
$$;

alter function check_serial_update() owner to s225125;

