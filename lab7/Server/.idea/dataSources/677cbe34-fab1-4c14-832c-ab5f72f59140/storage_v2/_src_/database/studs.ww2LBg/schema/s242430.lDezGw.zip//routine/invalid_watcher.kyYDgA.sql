create function invalid_watcher() returns trigger
    language plpgsql
as
$$
BEGIN
IF (NEW.idPunishment not in (select Punishment.idPunishment from Punishment where Punishment.idWatcherType=NEW.idWatcherType)) then
RAISE EXCEPTION 'Данный наблюдатель не может работать тут!';
END IF;
RETURN NEW;
END;
$$;

alter function invalid_watcher() owner to s242430;

