create function trigger_magic_before_del() returns trigger
    language plpgsql
as
$$
BEGIN

    if (select count(*) from "Битва"
    where "Битва"."Магия"=OLD."id")>0
        then delete from "Битва" where "Битва"."Магия"=OLD."id";
    end if;

    if (select count(*) from "ГЕРОЙ_К_МАГИИ" a
    where a."id_магии"=OLD."id")>0
        then delete from "ГЕРОЙ_К_МАГИИ" where "ГЕРОЙ_К_МАГИИ"."id_магии"=OLD."id";
    end if;

    return OLD;
END;
$$;

alter function trigger_magic_before_del() owner to s225133;

