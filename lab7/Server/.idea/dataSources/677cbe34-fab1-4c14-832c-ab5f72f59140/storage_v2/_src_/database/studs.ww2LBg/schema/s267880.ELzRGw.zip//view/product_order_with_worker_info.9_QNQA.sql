create view product_order_with_worker_info
            (product_order_id, user_profile_id, product_prototype_id, price, planned_delivery_date, delivery_address,
             additional_description, order_status, worker_id, deadline, is_finished)
as
SELECT product_making.product_order_id,
       product_order.user_profile_id,
       product_order.product_prototype_id,
       product_order.price,
       product_order.planned_delivery_date,
       product_order.delivery_address,
       product_order.additional_description,
       product_order.order_status,
       product_making.worker_id,
       product_making.deadline,
       product_making.is_finished
FROM s267880.product_order
         RIGHT JOIN s267880.product_making USING (product_order_id);

alter table product_order_with_worker_info
    owner to s267880;

