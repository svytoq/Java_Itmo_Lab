create function insert_planets_and_manufactures() returns void
    language plpgsql
as
$$
declare
    ret_id integer;
    begin
    insert into "Planets"(name, radius, weight, atmospheric_density) VALUES ('Земля', random() * 10000, random() * 10000, random()) returning id into ret_id;
    insert into "Manufactures"(id_planet) VALUES (ret_id);
    insert into "Planets"(name, radius, weight, atmospheric_density) VALUES ('Марс', random() * 10000, random() * 10000, random()) returning id into ret_id;
    insert into "Manufactures"(id_planet) VALUES (ret_id);
    insert into "Planets"(name, radius, weight, atmospheric_density) VALUES ('Меркурий', random() * 10000, random() * 10000, random()),
                                                                            ('Венера', random() * 10000, random() * 10000, random()),
                                                                            ('Юпитер', random() * 10000, random() * 10000, random()),
                                                                            ('Сатурн', random() * 10000, random() * 10000, random()),
                                                                            ('Уран', random() * 10000, random() * 10000, random()),
                                                                            ('Неептун', random() * 10000, random() * 10000, random()),
                                                                            ('Луна', random() * 10000, random() * 10000, random());
end;
$$;

alter function insert_planets_and_manufactures() owner to s264434;

