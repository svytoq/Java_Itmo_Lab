create function ran_album(integer) returns void
    language plpgsql
as
$$
DECLARE
N alias for $1;
rand INTEGER default 0;
lenght integer;
i INTEGER default 1;
count integer default 0;
Alb INTEGER[] := '{5, 6, 7, 8, 12, 13}';
Names text[] := '{Песня про любовь, Песня про разлуку, Песня про наркотики, Песня про алоголь, Песня про разгульный образ жизни}';
Название1 text = NULL;
Альбом integer = 0;
Begin
for i in 1..N loop
RAND:=floor(random()*5+1);
Название1 = Names[RAND];
RAND :=floor(random()*6+1);
Альбом = Alb[RAND];
insert into Композиция (Название, Альбом_ИД) values (Название1, Альбом);
 Название1 = NULL;
 Альбом = 0;
 end loop;
 end;
$$;

alter function ran_album(integer) owner to s223569;

