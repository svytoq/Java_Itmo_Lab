create function sete() returns trigger
    language plpgsql
as
$$
BEGIN
	CASE WHEN NEW.year_death <= 475 THEN NEW.epoch:='Античность';
	     	when NEW.year_death between 1476 and 1250 then NEW.epoch:='Средневековье';
		when NEW.year_death between 1251 and 1550 then NEW.epoch:='Возрождение';
		when NEW.year_death between 1551 and 1917 then NEW.epoch:='Новое время';
		when NEW.year_death between 1918 and 2018 then NEW.epoch:='Новейшее время';
	ELSE NEW.epoch = NULL;
	END CASE;
	RETURN NEW;
END;
$$;

alter function sete() owner to s243885;

