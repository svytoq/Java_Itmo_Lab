create function pprocess(tbl character varying) returns character varying
    language plpgsql
as
$$
BEGIN
RETURN ' * FROM ' || tbl;
END
$$;

alter function pprocess(varchar) owner to s243858;

