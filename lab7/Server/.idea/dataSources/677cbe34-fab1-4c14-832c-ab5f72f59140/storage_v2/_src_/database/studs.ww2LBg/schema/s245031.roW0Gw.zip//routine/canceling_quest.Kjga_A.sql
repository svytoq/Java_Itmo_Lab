create function canceling_quest() returns trigger
    language plpgsql
as
$$
begin
update Квесты
set возможность_получения=new.Жив 
from Люди
where Люди.Характеристики = new.id 
and квестодатель = Люди.id
and возможность_получения != new.Жив;
return new;
end;
$$;

alter function canceling_quest() owner to s245031;

