create function insert_service_offer_request(name character varying, content character varying, author integer, offer integer, service integer) returns void
    language plpgsql
as
$$
DECLARE
    REQUEST_ID INTEGER;
BEGIN
    INSERT INTO REQUEST (NAME, CONTENT, AUTHOR)
    VALUES (NAME, CONTENT, AUTHOR)
    RETURNING id INTO REQUEST_ID;
    INSERT INTO SERVICE_OFFER_REQUEST (REQUEST, OFFER, SERVICE)
    VALUES (REQUEST_ID, OFFER, SERVICE);
END;
$$;

alter function insert_service_offer_request(varchar, varchar, integer, integer, integer) owner to s265087;

