create function del_all_too_many_penalties_from_employees() returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM employee WHERE penalties > 10;
end;
$$;

alter function del_all_too_many_penalties_from_employees() owner to s265109;

