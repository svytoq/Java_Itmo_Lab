create function equipmentoccupiedcheck() returns trigger
    language plpgsql
as
$$
DECLARE
    startTS timestamp;
    endTS   timestamp;
    new_startTS timestamp;
    new_endTS   timestamp;
    ts_id int;
BEGIN
    select starttimestamp into new_startTS from timestampinterval where timestampinterval.id = NEW.timestampintervalid;
    select endtimestamp into new_endTS from timestampinterval where timestampinterval.id = NEW.timestampintervalid;

    FOR ts_id IN
        SELECT timestampintervalid FROM equipmentoccupiedintervals where equipmentid = NEW.equipmentid
        LOOP
            select starttimestamp into startTS from timestampinterval where timestampinterval.id = ts_id;
            select endtimestamp into endTS from timestampinterval where timestampinterval.id = ts_id;
            if (new_startTS > startTS and new_endTS < endTS)
                or (new_startTS < endTS and new_endTS > endTS)
                or (new_startTS < startTS and new_endTS > startTS) then
                raise exception 'Equipment occupied intervals can not overlap!';
            end if;
        END LOOP;

    RETURN NEW;
END;
$$;

alter function equipmentoccupiedcheck() owner to s265111;

