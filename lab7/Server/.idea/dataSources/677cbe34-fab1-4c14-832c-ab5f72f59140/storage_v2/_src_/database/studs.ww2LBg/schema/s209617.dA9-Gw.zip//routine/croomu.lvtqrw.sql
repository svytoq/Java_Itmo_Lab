create function croomu() returns trigger
    language plpgsql
as
$$
begin
    update rooms SET number_of_prisoners = number_of_prisoners-1
    where id = old.room;
  return old;
  end;
$$;

alter function croomu() owner to s209617;

