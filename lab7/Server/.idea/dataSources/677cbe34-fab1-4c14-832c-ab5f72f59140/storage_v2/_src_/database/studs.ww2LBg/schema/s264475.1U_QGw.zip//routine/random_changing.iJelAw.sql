create function random_changing() returns numeric
    language plpgsql
as
$$
BEGIN
    RETURN (SELECT 1 + random() * 0.2 - 0.05 AS random_changing);
END;
$$;

alter function random_changing() owner to s264475;

