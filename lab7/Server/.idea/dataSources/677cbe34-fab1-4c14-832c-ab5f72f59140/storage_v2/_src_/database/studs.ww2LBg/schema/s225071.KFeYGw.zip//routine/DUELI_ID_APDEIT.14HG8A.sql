create function "ДУЭЛИ_ИД_АПДЕЙТ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ИД_ДУЭЛЬ!=NEW.ИД_ДУЭЛЬ THEN
 NEW.ИД_ДУЭЛЬ=OLD.ИД_ДУЭЛЬ;
 RETURN NEW;
ELSE
RETURN NEW;
END IF;
 END;
$$;

alter function "ДУЭЛИ_ИД_АПДЕЙТ"() owner to s225071;

