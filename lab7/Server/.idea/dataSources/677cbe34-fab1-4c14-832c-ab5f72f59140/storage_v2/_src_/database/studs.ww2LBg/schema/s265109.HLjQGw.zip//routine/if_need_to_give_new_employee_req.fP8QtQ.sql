create function if_need_to_give_new_employee_req() returns trigger
    language plpgsql
as
$$
DECLARE
    BOSS INTEGER;
BEGIN
    IF OLD.MAIN_ID != NULL THEN
        UPDATE clientrequests
        SET who_id=OLD.main_id
        WHERE who_id = OLD.id;
        UPDATE clientrequests
        SET worker_id=OLD.main_id
        WHERE worker_id = OLD.ID;
    ELSE
        SELECT ID INTO BOSS FROM employee WHERE position = 'Director' limit 1;
        UPDATE clientrequests
        SET who_id=BOSS
        WHERE who_id = OLD.id;
        UPDATE clientrequests
        SET worker_id=BOSS
        WHERE worker_id = OLD.ID;
    end if;
    return old;
end;
$$;

alter function if_need_to_give_new_employee_req() owner to s265109;

