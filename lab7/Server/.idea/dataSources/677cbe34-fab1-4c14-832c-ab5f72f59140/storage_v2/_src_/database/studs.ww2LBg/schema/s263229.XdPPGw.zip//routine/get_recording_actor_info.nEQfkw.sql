create function get_recording_actor_info(recording_actor_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text, pos s263229.recording_actors_positions)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT ra.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH, ra.POSITION FROM recording_actors AS ra 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE ra.WORKER_ID = recording_actor_id;
END
$$;

alter function get_recording_actor_info(integer) owner to s263229;

