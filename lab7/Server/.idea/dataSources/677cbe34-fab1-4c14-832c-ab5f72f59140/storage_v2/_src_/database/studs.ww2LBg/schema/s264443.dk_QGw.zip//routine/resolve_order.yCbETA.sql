create function resolve_order(main_order_id integer) returns void
    language plpgsql
as
$$
BEGIN
        UPDATE customer_order
        SET resolve_time = current_timestamp
        WHERE id = main_order_id;
    END;
$$;

alter function resolve_order(integer) owner to s264443;

