create function insert_ai_company_review(id integer, previous_data integer, review_id integer, company_id integer, accuracy double precision, precision_value double precision, recall double precision, f1 double precision, prediction text) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO ai_company_review (id,
                   previous_data,
                   review_id,
                   company_id,
                   accuracy,
                   precision_value,
                   recall,
                   f1,
                   prediction)

  VALUES (insert_ai_company_review.id,
      insert_ai_company_review.previous_data,
      insert_ai_company_review.review_id,
      insert_ai_company_review.company_id,
      insert_ai_company_review.accuracy,
      insert_ai_company_review.precision_value,
      insert_ai_company_review.recall,
      insert_ai_company_review.f1,
      insert_ai_company_review.prediction);
END;

$$;

alter function insert_ai_company_review(integer, integer, integer, integer, double precision, double precision, double precision, double precision, text) owner to s264458;

