create function add_case_to_project(project_id integer, case_id integer) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO project_case (project_id, case_id)
    VALUES (add_case_to_project.project_id,
            add_case_to_project.case_id);
END;
$$;

alter function add_case_to_project(integer, integer) owner to s264448;

