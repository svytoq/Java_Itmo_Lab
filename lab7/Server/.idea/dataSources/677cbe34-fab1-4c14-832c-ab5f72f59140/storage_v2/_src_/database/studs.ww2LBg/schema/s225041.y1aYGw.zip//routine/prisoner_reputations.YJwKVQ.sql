create function prisoner_reputations(num integer)
    returns TABLE(reputation_name character varying, reputation_effect text)
    language plpgsql
as
$$
DECLARE
		found_reputation record;
		BEGIN
			FOR found_reputation IN (
				SELECT name, effect 
				FROM REPUTATION
				JOIN REPUTATION_PRISONER
				ON REPUTATION.id = REPUTATION_PRISONER.reputation_fk
				JOIN PRISONER
				ON PRISONER.id = REPUTATION_PRISONER.prisoner_fk
				WHERE PRISONER.id = NUMBER
			)
			LOOP
				reputation_name = found_reputation.name;
				reputation_effect = found_reputation.effect;
				RETURN NEXT;
			END LOOP;
		END;

$$;

alter function prisoner_reputations(integer) owner to s225041;

