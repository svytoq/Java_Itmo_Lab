create function get_clients_for_provider(id_provider integer)
    returns TABLE(name character varying, surname character varying)
    language sql
as
$$
SELECT humans.name, humans.surname
FROM humans
WHERE (humans.id_human IN (SELECT clients.id_human
                           FROM clients
                           WHERE (clients.id_delivery_place =
                                  (SELECT p.id_delivery_place FROM providers AS p WHERE (p.id_provider = $1)))));
$$;

alter function get_clients_for_provider(integer) owner to s270235;

