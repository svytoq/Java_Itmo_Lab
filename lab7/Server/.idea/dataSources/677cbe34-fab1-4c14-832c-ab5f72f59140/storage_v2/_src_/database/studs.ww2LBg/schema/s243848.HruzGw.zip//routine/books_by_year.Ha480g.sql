create function books_by_year(y integer) returns integer
    language plpgsql
as
$$
DECLARE 
COUNT integer;
BEGIN
COUNT = (SELECT COUNT(*) FROM ПРОИЗВЕДЕНИЯ WHERE EXTRACT(YEAR FROM ГОД_ИЗДАНИЯ) = y);
RETURN COUNT;
END;
$$;

alter function books_by_year(integer) owner to s243848;

