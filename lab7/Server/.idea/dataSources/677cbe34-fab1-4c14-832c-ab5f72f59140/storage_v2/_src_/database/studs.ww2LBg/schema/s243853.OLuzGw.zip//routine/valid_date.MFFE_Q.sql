create function valid_date() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.ДАТА_НАЧАЛА > NEW.ДАТА_КОНЦА THEN
RAISE EXCEPTION 'Дата начала должна быть раньше даты конца';
END IF;
RETURN NEW;
END
$$;

alter function valid_date() owner to s243853;

