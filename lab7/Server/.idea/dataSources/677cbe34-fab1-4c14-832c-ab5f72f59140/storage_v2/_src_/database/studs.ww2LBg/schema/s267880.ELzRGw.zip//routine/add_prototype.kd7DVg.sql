create function add_prototype(user_profile_id integer) returns integer
    language sql
as
$$
insert into product_prototype (owner_id, description, modifier) values (user_profile_id, '', 'private')
    returning product_prototype_id;
$$;

alter function add_prototype(integer) owner to s267880;

