create function check_team_before_work() returns trigger
    language plpgsql
as
$$
BEGIN
    RETURN (check_team_not_empty(new.team_id)) AND (check_team_not_busy(new.team_id));
END;
$$;

alter function check_team_before_work() owner to s264458;

