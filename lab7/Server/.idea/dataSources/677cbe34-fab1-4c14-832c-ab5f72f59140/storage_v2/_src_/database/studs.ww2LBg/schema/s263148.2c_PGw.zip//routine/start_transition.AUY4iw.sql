create function start_transition(character_id integer, from_org_name character varying, to_org_name character varying) returns text
    language plpgsql
as
$$
declare
    from_org_id int;
    to_org_id int;
  begin
    select id into from_org_id from organizations where name = from_org_name;
    select id into to_org_id from organizations where name = to_org_name;
    insert into transitions (character, from_org, to_org) values 
    (character_id, from_org_id, to_org_id);
    return 'Переход прошел успешно';
  end;
$$;

alter function start_transition(integer, varchar, varchar) owner to s263148;

