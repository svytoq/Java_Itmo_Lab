create function nvl(date, date) returns date
    language plpgsql
as
$$
begin
if $1 is null then return $2;
else return $1;
end if;
end;
$$;

alter function nvl(date, date) owner to s225087;

