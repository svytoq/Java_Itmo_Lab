create function count_rows(schema_name name)
    returns TABLE(col1 name, col2 name, amount bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT schemaname, relname, n_live_tup
                 FROM pg_stat_user_tables
                 where schemaname = schema_name;
END;
$$;

alter function count_rows(name) owner to s264452;

