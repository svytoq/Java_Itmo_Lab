create function "ЛЮДИ_ПО_РОДУ_ДЕЯТЕЛЬНОСТИ"(string character varying)
    returns TABLE("ИМЯ" character varying, "ФАМИЛИЯ" character varying, "ОТЧЕСТВО" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"ЛЮДИ"."ИМЯ", "ЛЮДИ"."ФАМИЛИЯ", "ЛЮДИ"."ОТЧЕСТВО"
FROM "ЛЮДИ" WHERE "ЛЮДИ"."РОД_ДЕЯТЕЛЬНОСТИ" = string;
END;
$$;

alter function "ЛЮДИ_ПО_РОДУ_ДЕЯТЕЛЬНОСТИ"(varchar) owner to s225071;

