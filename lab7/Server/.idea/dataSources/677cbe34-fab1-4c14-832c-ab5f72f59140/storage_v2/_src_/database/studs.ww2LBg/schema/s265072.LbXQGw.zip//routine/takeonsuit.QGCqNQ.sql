create function takeonsuit(shortyid integer) returns boolean
    language plpgsql
as
$$
DECLARE 
    scene integer;
BEGIN
    IF (SELECT is_space_suit FROM Shorty WHERE shorty_id = shortyId) 
        THEN RETURN false; END IF;
    UPDATE Shorty SET is_space_suit = true WHERE shorty_id = shortyId;
    UPDATE Shorty SET action_until_feed = (action_until_feed - 1) WHERE shorty_id = shortyId and action_until_feed != 0;
    INSERT INTO Object_to_action (shorty_id, action_id, time) VALUES (shortyId, 3, now());
    RETURN true;
END;
$$;

alter function takeonsuit(integer) owner to s265072;

