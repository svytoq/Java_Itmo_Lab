create function is_email_used(f_email character varying) returns boolean
    language plpgsql
as
$$
DECLARE
  email_from_db varchar(60) = (SELECT email
                               FROM app_user
                               where app_user.email = f_email);
BEGIN
  if email_from_db IS NOT NULL THEN
    return true;
  end if;
  return false;
END;
$$;

alter function is_email_used(varchar) owner to s243852;

