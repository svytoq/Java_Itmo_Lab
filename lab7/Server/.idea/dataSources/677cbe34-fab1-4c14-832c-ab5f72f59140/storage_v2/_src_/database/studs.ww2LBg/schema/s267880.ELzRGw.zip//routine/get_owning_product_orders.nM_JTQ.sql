create function get_owning_product_orders(client_user_profile_id integer) returns SETOF s267880.product_order_with_user_info
    language sql
as
$$
select * from product_order_with_user_info where user_profile_id = client_user_profile_id order by planned_delivery_date;
$$;

alter function get_owning_product_orders(integer) owner to s267880;

