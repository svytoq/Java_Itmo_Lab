create function visa_check_assign(check_id integer, empl_id integer) returns void
    language plpgsql
as
$$
begin
    if empl_id=-1 and exists(select 1 from Visa_check_employees where visa_check_id=check_id and employee_id=empl_id)
    then return; end if;

    insert into Visa_check_employees(visa_check_id, employee_id)
        values(check_id, empl_id);
end;
$$;

alter function visa_check_assign(integer, integer) owner to s265066;

