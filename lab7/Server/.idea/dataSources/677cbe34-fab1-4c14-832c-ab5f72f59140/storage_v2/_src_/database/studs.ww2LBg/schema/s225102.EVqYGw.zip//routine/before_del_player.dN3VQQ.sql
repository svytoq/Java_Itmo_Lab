create function before_del_player() returns trigger
    language plpgsql
as
$$
DECLARE
id_to_delete integer;
modNat integer;
unit integer;
building integer;
BEGIN
id_to_delete = OLD.id;
modNat = nation_id from mods where creator_id = id_to_delete;
unit = unique_unit from nations where id=modNat;
building = unique_building from nations where id=modNat;
DELETE FROM mods WHERE creator_id=id_to_delete;
DELETE FROM achievements WHERE player_id=id_to_delete;
DELETE FROM nations WHERE id=modNat;
DELETE FROM unit_perks WHERE unit_id=unit;
DELETE FROM units WHERE id=unit;
DELETE FROM building_tech WHERE building_id=building;
DELETE FROM buildings WHERE id=building;
RETURN OLD;
END;
$$;

alter function before_del_player() owner to s225102;

