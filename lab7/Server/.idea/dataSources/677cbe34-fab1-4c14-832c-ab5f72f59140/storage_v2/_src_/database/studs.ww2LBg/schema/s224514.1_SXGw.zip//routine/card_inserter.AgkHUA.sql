create function card_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	i INTEGER DEFAULT 1;
	id_match integer default 1;
	id_player integer default 1;
	date_of_Card date default '2018-07-06';
	Card text;
	typeCard text[] = '{Красная, Желтая}';
  maxNmatch integer;
	maxNplayer integer;
BEGIN
	Select count(ИД_МАТЧА) from МАТЧ into maxNmatch;
	Select count(ИД_ИГРОКА) from ИГРОК into maxNplayer;
  if (N / 4) > maxNmatch THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "МАТЧ"';
	END if;
	if (N / 4) > maxNplayer THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "ИГРОК"';
	END if;
	for i in 1..N loop

	if i % (N / 4) THEN
		id_match = id_match + 1;
		Card = typeCard[i % 2];
	END IF;

		insert into "КАРТОЧКА" values(DEFAULT, id_match, id_player, CAST(Card AS type_of_card), date_of_Card);
		date_of_Card = date_of_Card + interval '1 day';
		id_player = id_player + 1;
	end loop;
END;
$$;

alter function card_inserter(integer) owner to s224514;

