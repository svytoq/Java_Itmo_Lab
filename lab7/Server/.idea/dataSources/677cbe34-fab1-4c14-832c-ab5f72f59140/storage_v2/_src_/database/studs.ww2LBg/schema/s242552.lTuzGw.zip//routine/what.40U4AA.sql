create function what() returns event_trigger
    language plpgsql
as
$$
BEGIN
  RAISE NOTICE 'Всё хуйня';
END;
$$;

alter function what() owner to s242552;

