create function to_resp() returns void
    language plpgsql
as
$$
DECLARE
  J    INT;
  CHEL INT;
  RESP TEXT;
BEGIN
  CHEL = 0;
  FOR J IN SELECT ID_ПЛАНА
           FROM ПОЛИТИЧЕСКИЕ_ПЛАНЫ LOOP
    SELECT ID_ЧЛЕНА
    FROM ЧЛЕНЫ_СЕНАТА
    WHERE ID_ЧЛЕНА > CHEL
    INTO CHEL;
    IF CHEL ISNULL
    THEN
      SELECT ID_ЧЛЕНА
      FROM ЧЛЕНЫ_СЕНАТА
      INTO CHEL;
    END IF;
    RESP = 'ВЫПОЛНИТЬ ПЛАН__'||J;
    INSERT INTO ОТВЕТСТВЕННОСТЬ_ЗА_ПЛАН VALUES (DEFAULT, CHEL, J, RESP);
  END LOOP;
END;
$$;

alter function to_resp() owner to s225081;

