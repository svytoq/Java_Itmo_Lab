create function add_trademark(_company_id integer, _drug_id integer, _name character varying, _doze numeric, _release_price numeric, _distribution character varying) returns integer
    language plpgsql
as
$$
DECLARE
    _patent_id INTEGER := (SELECT MAX(id) + 1
                           FROM patents);
BEGIN
    INSERT INTO patents(id, distribution) VALUES (_patent_id, _distribution::patent_distribution);
--
    INSERT INTO trademarks(name, doze, release_price, drug_id, company_id, patent_id)
    VALUES (_name, _doze, _release_price, _drug_id, _company_id, _patent_id);
--
    RETURN _patent_id;
END;
$$;

alter function add_trademark(integer, integer, varchar, numeric, numeric, varchar) owner to s264475;

