create function get_test_max_score(integer) returns integer
    language plpgsql
as
$$
DECLARE
	count INTEGER;
BEGIN
	SELECT sum(question_cost) FROM questions INTO count WHERE test_id = $1;
	return count;
END;
$$;

alter function get_test_max_score(integer) owner to s173525;

