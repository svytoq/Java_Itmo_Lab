create function create_place(vcountry text, vname text) returns bigint
    language plpgsql
as
$$
DECLARE
  ret bigint;
BEGIN
  INSERT INTO places(country, name) VALUES (vcountry, vname) returning place_id into ret;
  RETURN ret;
END;
$$;

alter function create_place(text, text) owner to s265067;

