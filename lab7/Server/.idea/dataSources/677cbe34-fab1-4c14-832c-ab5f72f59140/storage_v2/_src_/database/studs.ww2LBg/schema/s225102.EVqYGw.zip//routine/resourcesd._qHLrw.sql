create function resourcesd() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('resources_id_seq')!=NEW.ID THEN
NEW.ID=nextval('resources_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function resourcesd() owner to s225102;

