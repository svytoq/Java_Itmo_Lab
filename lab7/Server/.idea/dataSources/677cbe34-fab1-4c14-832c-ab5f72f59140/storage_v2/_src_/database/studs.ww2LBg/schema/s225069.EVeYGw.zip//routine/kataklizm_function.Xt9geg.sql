create function kataklizm_function() returns trigger
    language plpgsql
as
$$
begin
new.Код_катаклизма=nextval('Катаклизмы_Код_катаклизма_seq');
return new;
end;
$$;

alter function kataklizm_function() owner to s225069;

