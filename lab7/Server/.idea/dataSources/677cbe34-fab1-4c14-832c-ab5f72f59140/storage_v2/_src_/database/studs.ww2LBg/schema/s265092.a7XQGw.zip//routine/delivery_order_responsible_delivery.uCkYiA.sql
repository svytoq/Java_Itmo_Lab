create function delivery_order_responsible_delivery() returns trigger
    language plpgsql
as
$$
DECLARE responsible_dpt department := (
        SELECT department FROM employee WHERE id = NEW.responsible_id
    );

    BEGIN
        IF responsible_dpt = 'delivery' THEN
            RETURN NEW;
        END IF;
        RETURN NULL;
    END;
$$;

alter function delivery_order_responsible_delivery() owner to s265092;

