create function valid_beg_date() returns trigger
    language plpgsql
as
$$
BEGIN
IF NOT is_valid_date(NEW.id_creature, NEW.beg_date) THEN
RAISE EXCEPTION 'Invalid beginning date %', NEW.beg_date
USING HINT = 'Beginning date must be higher then birth date';
END IF;
RETURN NEW;
END;
$$;

alter function valid_beg_date() owner to s243856;

