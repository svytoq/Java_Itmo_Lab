create function bind_tariffs() returns void
    language plpgsql
as
$$
DECLARE
tariffs integer[] := '{1, 1, 2, 2, NULL}';
BEGIN
UPDATE КОМНАТА SET ИНТЕРНЕТ_ТАРИФ_ИД = tariffs[random()*4+1] WHERE НОМЕР = ANY(SELECT НОМЕР FROM КОМНАТА);
END;
$$;

alter function bind_tariffs() owner to s225141;

