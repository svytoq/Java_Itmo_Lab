create function сгенерировать_награды() returns void
    language plpgsql
as
$$
DECLARE
        film record;
        people record;
BEGIN
        FOR film IN (SELECT ид,премьера from Фильмы) LOOP
            FOR people IN (SELECT ид from Люди) LOOP
                if ((random() > 0.8) AND Exists(SELECT 1 from Фильмы 
                    Join Фильмы_Группы 
                    On Фильмы.ид=Фильмы_Группы.ид_фильма 
                    Join Роли 
                    On Фильмы_Группы.ид_группы=Роли.ид_группы
                    WHERE Роли.ид_человека=people.ид AND Фильмы.ид=film.ид
                    ) 
                ) THEN
                    insert into Награды(ид_фильма,ид_человека,название,тип,дата)
                        values(film.ид,people.ид,random_string(10),
                            random_string(5),film.премьера + random_film_interval());
                END IF;
            END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_награды() owner to s242395;

