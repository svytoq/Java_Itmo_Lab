create function insert_transfer() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.transferdate < (SELECT tormenteddateofdeath FROM tormented where Tormented.idtormented = NEW.idhuman) THEN
RAISE EXCEPTION 'Дата трансфера не может быть раньше даты смерти';
END IF;

RETURN NEW;
END;
$$;

alter function insert_transfer() owner to s242430;

