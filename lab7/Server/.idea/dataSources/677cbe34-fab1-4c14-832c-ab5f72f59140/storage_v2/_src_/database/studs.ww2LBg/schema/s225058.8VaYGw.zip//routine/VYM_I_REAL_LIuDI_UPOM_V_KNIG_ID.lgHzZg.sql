create function "ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ_ИД_seq')!=NEW.ИД THEN
NEW.ИД=nextval('ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ_ИД_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;   
    END;
$$;

alter function "ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ_ИД"() owner to s225058;

