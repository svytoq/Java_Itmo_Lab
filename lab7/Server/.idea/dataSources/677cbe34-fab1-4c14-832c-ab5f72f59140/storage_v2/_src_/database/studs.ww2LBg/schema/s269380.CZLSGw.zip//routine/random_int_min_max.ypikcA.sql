create function random_int_min_max(val_min integer, val_max integer) returns integer
    language sql
as
$$
select (random() * (val_max-val_min) + val_min)::int
$$;

alter function random_int_min_max(integer, integer) owner to s269380;

