create function update_rank() returns trigger
    language plpgsql
as
$$
DECLARE
rank_new integer;
player_id_check integer;
param integer;
BEGIN
IF (TG_OP = 'INSERT') THEN
player_id_check=NEW.player_id;
rank_new = COUNT(player_id) FROM achievements where player_id = NEW.player_id;
UPDATE player SET rank=rank_new WHERE id=player_id_check;
RETURN NEW;
ELSEIF (TG_OP = 'DELETE') THEN
player_id_check=OLD.player_id;
rank_new = COUNT(player_id)-COUNT(OLD.player_id) FROM achievements where player_id = player_id_check;
UPDATE player SET rank=rank_new WHERE id=player_id_check;
RETURN OLD;
END IF;
END;
$$;

alter function update_rank() owner to s225102;

