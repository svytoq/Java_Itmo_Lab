create function check_delivery_owl_sender_house_match() returns trigger
    language plpgsql
as
$$
declare
  house_id     integer;
  owl_house_id integer;
begin
  house_id := (select study_plans.house_id from study_plans
    inner join student_profiles on study_plans.id = student_profiles.study_plan_id
    where student_profiles.person_id = new.sender_id);
  owl_house_id := (select delivery_owls.house_id from delivery_owls
    where delivery_owls.id = new.owl_id);

  if house_id is not null and owl_house_id != house_id
  then raise exception 'The required owl does not belong to the sender''s house';
  end if;

  return new;
end;
$$;

alter function check_delivery_owl_sender_house_match() owner to s244706;

