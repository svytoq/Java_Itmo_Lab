create function "ВРЕМЯ_РЕГИСТРАЦИИ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF (TG_OP = 'INSERT') THEN
            INSERT INTO ИНФО(ИД_ЛИЧНОСТЬ, ДАТА_РЕГИСТР) VALUES(NEW.ИД_ЛИЧНОСТЬ, CURRENT_DATE);
            RETURN NEW;
        END IF;
        RETURN NULL;
    END;
$$;

alter function "ВРЕМЯ_РЕГИСТРАЦИИ"() owner to s243879;

