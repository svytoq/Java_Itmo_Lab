create function check_unique() returns trigger
    language plpgsql
as
$$
DECLARE
  rec INTEGER;
BEGIN

  rec := (SELECT chassis.id FROM chassis WHERE NEW.serial_no= chassis.id);
  IF rec is not NULL THEN
    RAISE EXCEPTION 'number % was found', NEW.serial_no;
  END IF;

  rec = (SELECT firm_tower.serial_no FROM firm_tower WHERE NEW.serial_no = firm_tower.serial_no);
  IF rec is not NULL THEN
    RAISE EXCEPTION 'number % was found', NEW.serial_no;
  END IF;

  rec = (SELECT firm_weapon.serial_no FROM firm_weapon WHERE NEW.serial_no = firm_weapon.serial_no);
  IF rec is not NULL THEN
    RAISE EXCEPTION 'number % was found', NEW.serial_no;
  END IF;

  rec = (SELECT firm_engine.serial_no FROM firm_engine WHERE NEW.serial_no = firm_engine.serial_no);
  IF rec is not NULL THEN
    RAISE EXCEPTION 'number % was found', NEW.serial_no;
  END IF;

  RETURN NEW;

END;
$$;

alter function check_unique() owner to s243858;

