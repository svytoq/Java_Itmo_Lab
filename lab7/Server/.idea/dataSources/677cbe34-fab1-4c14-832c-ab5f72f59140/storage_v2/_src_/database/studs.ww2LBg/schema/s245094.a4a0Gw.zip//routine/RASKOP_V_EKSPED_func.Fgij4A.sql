create function "РАСКОП_В_ЭКСПЕД_func"() returns trigger
    language plpgsql
as
$$
-- Дата начала раскопок должна попадать во временные рамки экспедиции
        DECLARE 
                year               int;
                duration        int;
        BEGIN
                year := (SELECT "ГОД_НАЧАЛА" FROM "ЭКСПЕДИЦИЯ" 
                            WHERE "ЭКСПЕДИЦИЯ"."ЭКСПЕД_ИД" = NEW."ЭКСПЕД_ИД");
                duration := (SELECT extract(YEAR from "ДЛИТЕЛЬНОСТЬ") FROM "ЭКСПЕДИЦИЯ" 
                            WHERE "ЭКСПЕДИЦИЯ"."ЭКСПЕД_ИД" = NEW."ЭКСПЕД_ИД");
                IF extract(YEAR from NEW."ДАТА") <  year OR
                     extract(YEAR from NEW."ДАТА") > year + duration + 1 THEN
                        RAISE EXCEPTION 'Excavation must be within its expedition`s duration'; 
                        RETURN NULL;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "РАСКОП_В_ЭКСПЕД_func"() owner to s245094;

