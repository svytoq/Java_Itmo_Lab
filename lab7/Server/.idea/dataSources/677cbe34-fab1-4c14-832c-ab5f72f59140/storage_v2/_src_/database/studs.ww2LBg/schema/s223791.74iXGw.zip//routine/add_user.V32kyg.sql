create function add_user(uname character varying, upass character varying, urole character varying) returns void
    language plpgsql
as
$$
BEGIN
                INSERT INTO users (password, username) VALUES (upass, uname);
                INSERT INTO user_roles (user_id, role_id)
                VALUES ((SELECT id FROM users WHERE username = uname),
                        (SELECT id FROM roles WHERE name = urole));
            END;
$$;

alter function add_user(varchar, varchar, varchar) owner to s223791;

