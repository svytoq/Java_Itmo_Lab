create function flora_function() returns trigger
    language plpgsql
as
$$
begin
new.Animal_ID=nextval('Flora_Fauna_Animal_ID_seq');
return new;
end;
$$;

alter function flora_function() owner to s225069;

