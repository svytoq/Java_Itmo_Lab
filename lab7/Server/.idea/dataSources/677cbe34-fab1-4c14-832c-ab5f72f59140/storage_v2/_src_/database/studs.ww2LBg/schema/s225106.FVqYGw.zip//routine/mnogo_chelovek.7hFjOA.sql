create function много_человек() returns void
    language plpgsql
as
$$
DECLARE
  namechel text;
BEGIN
  FOR i in 1..1000
  LOOP
    execute 'select КОРОТКОЕ_ИМЯ from ЧЕЛОВЕК where ИД=' || i || ';' into namechel;
    INSERT INTO ЧЕЛОВЕК VALUES (1, i::text, namechel, DEFAULT, random()*100);
    INSERT INTO СВЯЗЬ_ОСОБ_ЧЕЛ VALUES (i+50, MOD(i,6)+1);
    INSERT INTO СУЩЕСТВО VALUES (1,(i+5)::text, DEFAULT, i);
    INSERT INTO СВЯЗЬ_ОСОБ_СУЩ VALUES (i+31, MOD(i,6)+1);
    INSERT INTO ИНФА_ЧЕЛ VALUES (i+50, mod(i,34)+1, mod(i,27)+1);
    INSERT INTO "ЭПИЗОД" VALUES (1,i+5, i::text, (i+1)::text, (i+2)::text, i+50, i);
    INSERT INTO "УЧАСТИЕ" VALUES (i+50, i+25, 'Role');
    INSERT into "СВЯЗЬ_МЕСТА" VALUES (i+25, mod(i, 27)+1);
  END LOOP;
END;
$$;

alter function много_человек() owner to s225106;

