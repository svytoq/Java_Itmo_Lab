create function create_client_with_cat(client_name text, client_discount double precision, cat_name text, cat_breed text, cat_birthday timestamp without time zone, cat_sex character, cat_color integer) returns s259844.cat
    language plpgsql
as
$$
DECLARE
    ret cat;
    owner client;
BEGIN
    owner := (SELECT create_client(client_name, client_discount));
    ret := (SELECT create_cat(cat_name, cat_breed, cat_birthday, cat_sex, cat_color));
    UPDATE cat SET owner_id = owner.id WHERE id = ret.id RETURNING * INTO ret;

    RETURN ret;
END;
$$;

alter function create_client_with_cat(text, double precision, text, text, timestamp, char, integer) owner to s259844;

