create function season_ins_valid() returns trigger
    language plpgsql
as
$$
BEGIN
    IF new.конец IS NOT NULL THEN
        IF ((DATE_PART('year',new.конец::timestamp))::integer-(DATE_PART('year',new.начало::timestamp))::integer )<>1 THEN
            RAISE EXCEPTION 'Сезон должен оканчиваться в следующем году после года его начала!';
        END IF;
    END IF;
    IF EXISTS (SELECT 1 FROM сезоны WHERE ((new.начало>=сезоны.начало) AND (new.начало<=сезоны.конец)) OR
                                          ((new.конец>=сезоны.начало) AND (new.конец<=сезоны.конец)) OR
                                          ((сезоны.начало>=new.начало) AND (сезоны.начало<=new.конец)) OR
                                          ((сезоны.конец>=new.начало) AND (сезоны.конец<=new.конец))) THEN
        RAISE EXCEPTION 'Уже существует сезон, который накладывается на новый!';
    END IF;
    IF EXISTS (SELECT 1 FROM стадии WHERE ((new.начало>=стадии.начало) AND (new.начало<=стадии.конец)) OR
                                          ((new.конец>=стадии.начало) AND (new.конец<=стадии.конец)) OR
                                          ((стадии.начало>=new.начало) AND (стадии.начало<=new.конец)) OR
                                          ((стадии.конец>=new.начало) AND (стадии.конец<=new.конец))) THEN
        RAISE EXCEPTION 'Уже существует стадия, которая накладывается на новый сезон!';
    END IF;
    RETURN NEW;
END;
$$;

alter function season_ins_valid() owner to s242558;

