create function create_room(building integer, floor integer) returns void
    language plpgsql
as
$$
DECLARE
id integer:=0;
rooms integer:=0;
BEGIN
SELECT COUNT(*) INTO rooms FROM КОМНАТА;
id:=building*10000+MOD(floor, 10)*1000+MOD(rooms, 250);
INSERT INTO КОМНАТА VALUES(id, floor, NULL, NULL);
END;
$$;

alter function create_room(integer, integer) owner to s225141;

