create function check_path_exists() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (SELECT EXISTS (SELECT * FROM paths WHERE (station_id = NEW.to_station) AND (to_station = NEW.station_id))) THEN
		RETURN NULL;
	END IF;
	RETURN NEW;
END
$$;

alter function check_path_exists() owner to s208059;

