create function add_to_gods() returns trigger
    language plpgsql
as
$$
BEGIN
		INSERT INTO БОЖЕСТВА(ИД)
			VALUES (NEW.ИД);
		RETURN NEW;
	END;
$$;

alter function add_to_gods() owner to s243848;

