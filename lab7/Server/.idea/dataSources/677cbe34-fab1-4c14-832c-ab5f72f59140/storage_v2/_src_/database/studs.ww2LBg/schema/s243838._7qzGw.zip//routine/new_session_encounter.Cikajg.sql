create function new_session_encounter() returns trigger
    language plpgsql
as
$$
DECLARE
  encounter_id integer;
  player_character RECORD;
  BEGIN

      encounter_id = NEW.id;

      for player_character in (
        select id from Character
        where character.session_id = NEW.session_id and
              character.player_id != (select gm_id from Session where Session.id = NEW.session_id)
      ) loop
        INSERT INTO EncounterToCharacter VALUES(DEFAULT, player_character.id, encounter_id);
      end loop;
  return new;
  END;
$$;

alter function new_session_encounter() owner to s243838;

