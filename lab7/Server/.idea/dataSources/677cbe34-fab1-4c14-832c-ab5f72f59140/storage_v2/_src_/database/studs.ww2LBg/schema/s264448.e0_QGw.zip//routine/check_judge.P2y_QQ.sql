create function check_judge() returns trigger
    language plpgsql
as
$$
BEGIN
    IF people_age(NEW.person_id) < 27 THEN
        RAISE EXCEPTION 'jude should be older then 27';
    END IF;

    IF NOT EXISTS(SELECT NEW.person_id
                  FROM people_publication
                  WHERE NEW.person_id = people_publication.person_id) THEN
        RAISE EXCEPTION 'Judge should have one or more publications';
    END IF;

    IF EXISTS(SELECT *
              FROM mentor
              WHERE NEW.person_id = mentor.person_id
                AND NEW.championship_id = mentor.championship_id) THEN
        RAISE EXCEPTION 'Judge can not be a mentor in the same championship';
    END IF;

    IF EXISTS(SELECT *
              FROM participant
              WHERE NEW.person_id = participant.person_id
                AND NEW.championship_id = participant.championship_id) THEN
        RAISE EXCEPTION 'Judge can not be a participant in the same championship';
    END IF;

    IF NEW.judge_team_id IS NOT NULL AND NEW.championship_id != ANY
                                         (SELECT judge.championship_id
                                          FROM judge
                                          WHERE judge_team_id = NEW.judge_team_id) THEN
        RAISE EXCEPTION 'Judges in one judge team should be from one championship';
    END IF;

    RETURN NEW;
END;
$$;

alter function check_judge() owner to s264448;

