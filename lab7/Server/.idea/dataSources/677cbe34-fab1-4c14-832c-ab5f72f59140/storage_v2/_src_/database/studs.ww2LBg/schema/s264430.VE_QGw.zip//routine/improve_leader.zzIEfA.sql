create function improve_leader() returns trigger
    language plpgsql
as
$$
DECLARE
	count integer;
	BEGIN
		IF NEW.name is null then
			raise exception 'not leader';
		END IF;
		IF NEW.char_id IS NULL THEN
			RAISE EXCEPTION 'leader dont have characteristics';
		END IF;
		if new.experience > 100 then
		count = new.experience / 100;
		new.experience = new.experience - count*100;
		update characteristics set intellect = intellect +2*count, agillity = agillity + 3*count, strength = strength + 4*count, armor = armor +1*count where characteristics.id = new.char_id;
		end if;
		return new;
	END;
$$;

alter function improve_leader() owner to s264430;

