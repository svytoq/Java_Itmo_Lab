create function prisoner_programs(searchfullname character varying)
    returns TABLE(program_name character varying, program_room integer, program_teacher character varying)
    language plpgsql
as
$$
DECLARE
		found_program record;
		BEGIN
			FOR found_program IN (
				SELECT PROGRAM.name AS name,
				PROGRAM.room_fk AS ROOM, STAFF.fullName AS TEACHER 
				FROM PROGRAM
				JOIN PRISONER_PROGRAM
				ON PROGRAM.id = PRISONER_PROGRAM.program_fk
				JOIN STAFF
				ON PROGRAM.teacher_fk = STAFF.id
				JOIN PRISONER
				ON PRISONER.id = PRISONER_PROGRAM.prisoner_fk
				WHERE PRISONER.fullName = searchFullName
			)
			LOOP
				program_name = found_program.name;
				program_room = found_program.room_fk;
				program_teacher = found_program.teacher_fk;
				RETURN NEXT;
			END LOOP;
		END;

$$;

alter function prisoner_programs(varchar) owner to s225041;

