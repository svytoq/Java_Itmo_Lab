create function check_firm_weap_tow() returns trigger
    language plpgsql
as
$$
DECLARE
  rec INTEGER;
  rec2 INTEGER;
BEGIN

  rec := (SELECT firm_tower.id_firm FROM firm_tower WHERE NEW.id_tower = firm_tower.id_tower);
  rec2 := (SELECT firm_weapon.id_firm FROM firm_weapon WHERE NEW.id_weapon = firm_weapon.id_weapon);
  IF rec != rec2 THEN
    RAISE EXCEPTION 'Different firms';
  END IF;

  RETURN NEW;

END;
$$;

alter function check_firm_weap_tow() owner to s243858;

