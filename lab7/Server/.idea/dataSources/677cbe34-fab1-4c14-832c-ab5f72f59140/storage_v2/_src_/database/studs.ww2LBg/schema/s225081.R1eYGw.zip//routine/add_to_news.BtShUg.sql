create function add_to_news(n integer) returns void
    language plpgsql
as
$$
DECLARE
  NM VARCHAR ;
  BODY TEXT;
 DATE TIMESTAMP;
  I INTEGER;
BEGIN
  NM = 'NEWS';
 BODY = 'ABRACADABRA';

 FOR I IN 1..N LOOP
   SELECT NOW() INTO DATE;
   INSERT INTO NEWS VALUES (DEFAULT , BODY, NM, DATE);
   NM=NM||I;
     BODY=BODY||I;

 END LOOP;
END;

$$;

alter function add_to_news(integer) owner to s225081;

