create function deletepzu() returns trigger
    language plpgsql
as
$$
begin
 delete from УСТРОЙСТВА where  УСТРОЙСТВА.ИД_ПЗУ = ПЗУ.ИД;
 end;
$$;

alter function deletepzu() owner to s243855;

