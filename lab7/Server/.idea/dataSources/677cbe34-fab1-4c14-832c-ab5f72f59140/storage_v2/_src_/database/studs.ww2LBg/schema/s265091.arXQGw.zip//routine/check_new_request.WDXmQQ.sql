create function check_new_request() returns trigger
    language plpgsql
as
$$
declare
            дата_проведения date;
            участие_в_другом_соревновании int;
        begin
            дата_проведения := (select дата from Соревнование where соревнование_ид = new.соревнование_ид limit 1);
            участие_в_другом_соревновании := (select count(*) from Зарег_Участники
                join Соревнование on (Соревнование.соревнование_ид = Зарег_Участники.соревнование_ид)
                where new.спортсмен_ид = Зарег_Участники.спортсмен_ид and Соревнование.дата = дата_проведения);
            if дата_проведения <= now()::date then
                execute отклонить_заявку(new.спортсмен_ид, new.соревнование_ид, 'соревнование завершилось');
                return null;
            end if ;
            if участие_в_другом_соревновании > 0 then
                execute отклонить_заявку(new.спортсмен_ид, new.соревнование_ид, 'спортсмен уже зарегистрирован на дату соревнования');
                return null;
            end if;
            return new;
        end;
$$;

alter function check_new_request() owner to s265091;

