create function exchange_fail(exc_id integer) returns void
    language plpgsql
as
$$
begin
    update Messages set msg_state='encrypted' where msg_id=(
        select out_msg from Msg_exchanges where msg_exc_id=exc_id);

    update Msg_exchanges set msg_ex_state='fail'
        where msg_exc_id=exc_id;
end;
$$;

alter function exchange_fail(integer) owner to s265066;

