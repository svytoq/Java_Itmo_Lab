create function colony_salary_statistics()
    returns TABLE(colony_name text, avg_salary double precision, max_salary double precision, min_salary double precision)
    language sql
as
$$
SELECT colonies.name AS colony_name, 
AVG(salary)::float AS avg_salary,
  MAX(salary)::float AS max_salary, 
MIN(salary)::float AS min_salary 
FROM colony_worms 
JOIN worms ON colony_worms.worm_id=worms.id 
JOIN colonies ON colony_worms.colony_id=colonies.id 
GROUP BY colonies.name ORDER BY avg_salary DESC;
$$;

alter function colony_salary_statistics() owner to s265098;

