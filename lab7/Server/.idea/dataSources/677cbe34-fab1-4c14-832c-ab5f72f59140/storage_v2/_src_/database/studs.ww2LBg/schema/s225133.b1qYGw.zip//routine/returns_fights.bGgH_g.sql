create function returns_fights(a integer)
    returns TABLE(fights integer)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY SELECT "Битва".id FROM "Битва" WHERE "Битва".id_победителя=a;
END;
$$;

alter function returns_fights(integer) owner to s225133;

