create function insert_suggestion_comment(content character varying, author integer, parent_comment integer, suggestion integer) returns void
    language plpgsql
as
$$
DECLARE
    COMMENT_ID INTEGER;
BEGIN
    INSERT INTO COMMENT (CONTENT, CREATION_DATE, AUTHOR, PARENT_COMMENT)
    VALUES (CONTENT, CURRENT_TIMESTAMP, AUTHOR, PARENT_COMMENT)
    RETURNING id INTO COMMENT_ID;
    INSERT INTO SUGGESTION_COMMENT (SUGGESTION, COMMENT)
    VALUES (SUGGESTION, COMMENT_ID);
END;
$$;

alter function insert_suggestion_comment(varchar, integer, integer, integer) owner to s265087;

