create function get_order(number integer)
    returns TABLE(name character varying, amount integer, unit_price real, price real)
    language plpgsql
as
$$
begin return query select information.name, p_o.amount, p_o.unit_price, (p_o.unit_price*p_o.amount)::real from products_order p_o
left join information on (p_o.part_number = information.id)
where p_o.id_order = number
union all select 'Итог:', sum(p_o.amount)::integer, null, sum(p_o.unit_price*p_o.amount)::real from products_order p_o
left join information on (p_o.part_number = information.id)
where p_o.id_order = number;
end;
$$;

alter function get_order(integer) owner to s244707;

