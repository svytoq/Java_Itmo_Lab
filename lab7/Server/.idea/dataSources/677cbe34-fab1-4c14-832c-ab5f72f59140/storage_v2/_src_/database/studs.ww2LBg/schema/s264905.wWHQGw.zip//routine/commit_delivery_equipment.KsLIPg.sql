create function commit_delivery_equipment() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (SELECT EXISTS(SELECT 1 FROM Delivery_Equipment WHERE Delivery_Equipment.miner_id = NEW.miner_id)) THEN
		RAISE 'Этот шахтер уже получил оборудование';
	ELSEIF ((SELECT count FROM Counter WHERE Counter.name = (SELECT name FROM Equipment WHERE Equipment.equipment_id = NEW.equipment_id)) = 0
		   OR (SELECT NOT EXISTS (SELECT 1 FROM Counter WHERE Counter.name = (SELECT name FROM Equipment WHERE Equipment.equipment_id = NEW.equipment_id)))) THEN
		RAISE 'Нет оборудования';
	ELSEIF (SELECT EXISTS(SELECT 1 FROM Delivery_Equipment WHERE Delivery_Equipment.equipment_id = NEW.equipment_id)) THEN
		RAISE 'Оборудование уже выдано';
	ELSEIF (NOT(SELECT EXISTS(SELECT 1 FROM Miner WHERE NEW.miner_id IN (SELECT miner_id FROM Brigade_record)))) THEN
		RAISE 'Шахтер не относится ни к какой бригаде';
	ELSEIF ((SELECT part FROM Brigade_record INNER JOIN Miner ON Brigade_record.miner_id = Miner.miner_id WHERE Miner.miner_id = NEW.miner_id) = 'ВОДИТЕЛЬ') THEN
		RAISE 'Водитель не может брать оборудование';
	ELSEIF (NEW.delivery_date != current_date) THEN
		RAISE 'Выдача может быть только в сегодняшний день';
	ELSE
		IF ((SELECT part FROM Brigade_record INNER JOIN Miner ON Brigade_record.miner_id = Miner.miner_id WHERE Miner.miner_id = NEW.miner_id) = 'КОПАТЕЛЬ') THEN
			IF ((SELECT name FROM Equipment WHERE Equipment.equipment_id = NEW.equipment_id) <> 'ЛОПАТА') THEN
				RAISE 'Копатель может брать только лопату';
			END IF;
		ELSEIF ((SELECT part FROM Brigade_record INNER JOIN Miner ON Brigade_record.miner_id = Miner.miner_id WHERE Miner.miner_id = NEW.miner_id) = 'БУРИЛЬЩИК') THEN
			IF ((SELECT name FROM Equipment WHERE Equipment.equipment_id = NEW.equipment_id) <> 'БУР') THEN
				RAISE 'Бурильщик может брать только бур';
			END IF;
		END IF;
		UPDATE Counter SET count = count - 1 WHERE Counter.name = (SELECT name FROM Equipment WHERE Equipment.equipment_id = NEW.equipment_id);
	END IF;
    RETURN NEW;
END;
$$;

alter function commit_delivery_equipment() owner to s264905;

