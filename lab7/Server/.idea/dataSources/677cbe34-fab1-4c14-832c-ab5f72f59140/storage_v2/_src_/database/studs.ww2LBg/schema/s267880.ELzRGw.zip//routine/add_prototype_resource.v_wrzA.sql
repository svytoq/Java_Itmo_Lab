create function add_prototype_resource(product_prototype_id integer, resource_type s267880.prototype_resource_type, location text) returns integer
    language sql
as
$$
insert into product_prototype_resource (product_prototype_id, resource_type, location)
    values ($1, $2, $3) returning product_prototype_resource_id;
$$;

alter function add_prototype_resource(integer, s267880.prototype_resource_type, text) owner to s267880;

