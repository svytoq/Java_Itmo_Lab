create function is_object_claimed(_object bigint) returns boolean
    language plpgsql
as
$$
DECLARE
	amount int;
	sum int = 0;
BEGIN
	SELECT count(*) INTO amount 
		FROM map_buildings
		WHERE object = _object;

	sum = sum + amount;

	SELECT count(*) INTO amount 
		FROM map_resources
		WHERE object = _object;

	sum = sum + amount;

	SELECT count(*) INTO amount
		FROM map_units
		WHERE object = _object;

	sum = sum + amount;

	SELECT count(*) INTO amount 
		FROM towns
		WHERE object = _object;

	sum = sum + amount;

	RETURN sum > 0;
END;
$$;

alter function is_object_claimed(bigint) owner to s244711;

