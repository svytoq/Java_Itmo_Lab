create function check_build_storage_in_alien_planet() returns trigger
    language plpgsql
as
$$
DECLARE
    planet_company_id varchar;
BEGIN
    select c.id into planet_company_id from planets p
        left join spaceports s on s.id = p.id
        left join companies c on c.id = s.company_id
    where p.id = NEW.planet_id;

    if(planet_company_id != NEW.company_id) THEN
        raise exception 'Cannot create gas storage in alien planet';
    end if;
END
$$;

alter function check_build_storage_in_alien_planet() owner to s250947;

