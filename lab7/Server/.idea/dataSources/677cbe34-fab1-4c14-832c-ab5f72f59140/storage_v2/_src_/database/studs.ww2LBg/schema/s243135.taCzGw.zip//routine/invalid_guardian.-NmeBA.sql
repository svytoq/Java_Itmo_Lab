create function invalid_guardian() returns trigger
    language plpgsql
as
$$
BEGIN

IF (select idcircle from tormented natural join subcircle natural join circle where tormented.idtormented=NEW.idtormented) <> 
(SELECT idcircle FROM guardian join circle on (guardian.idcircle = circle.idcircle) where guardian.idguadian=NEW.idguadian) then
RAISE EXCEPTION 'Страж не с того района!';
END IF;

RETURN NEW;
END;
$$;

alter function invalid_guardian() owner to s243135;

