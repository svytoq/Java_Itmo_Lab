create function "ПЕРСОНАЛ_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
 IF NEW."ИД_ПЕРСОНАЛА" IS NULL THEN
    NEW."ИД_ПЕРСОНАЛА" = generate_UUID();
 END IF;
 IF (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."ИД_ПЕРСОНАЛА" = NEW."ИД_ПЕРСОНАЛА")) THEN
 RAISE 'Персонал с указанным ИД уже есть в базе.';
 END IF;
 IF NOT (exists(SELECT FROM "ЧЕЛОВЕК" WHERE "ЧЕЛОВЕК"."ИД_ЧЕЛОВЕКА" = NEW."ИД_ЧЕЛОВЕКА")) THEN
RAISE 'Человека с указаным ИД нет в базе.';
END IF;
IF (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."ИД_ЧЕЛОВЕКА" = NEW."ИД_ЧЕЛОВЕКА")) THEN
RAISE 'Человек с данным ИД уже записан как персонал.';
END IF;
IF (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."НОМЕР_ПАСПОРТА" = NEW."НОМЕР_ПАСПОРТА")) THEN
RAISE 'Человек с данным паспортом уже записан как персонал.';
END IF;
IF NEW."ЗАРПЛАТА" < CAST(0 AS MONEY) THEN
RAISE 'Зарплата не может быть отрицательной';
END IF;
IF NEW."ДАТА_ПРИЁМА" IS NULL THEN
RAISE 'Графа "ДАТА_ПРИЁМА" не может быть пустой.';
END IF;
IF NEW."ЗАРПЛАТА" IS NULL THEN
RAISE 'Графа "ЗАРПЛАТА" не может быть пустой.';
END IF;
return NEW;
END;
$$;

alter function "ПЕРСОНАЛ_ТФ"() owner to s223443;

