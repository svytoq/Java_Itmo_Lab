create function "Ургант"(id integer, "id_базы" integer, "название" character varying) returns void
    language plpgsql
as
$$
BEGIN
insert into корабль values(ID, 450, название, '[35, 40]' , 3700, 'создается',2500, ID_базы, now(), null);
insert into оружие_корабль values(3, ID);
insert into оружие_корабль values(7, ID);
END;
$$;

alter function "Ургант"(integer, integer, varchar) owner to s243840;

