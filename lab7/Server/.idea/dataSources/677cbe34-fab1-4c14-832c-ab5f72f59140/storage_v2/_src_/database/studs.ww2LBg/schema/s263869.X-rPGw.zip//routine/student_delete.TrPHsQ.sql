create function student_delete() returns trigger
    language plpgsql
as
$$
DECLARE
        kaseId integer := (SELECT CASE_ID FROM POLICE WHERE POLICE.STUDENT_INITIALS = OLD.INITIALS);
    BEGIN
        DELETE FROM CASES WHERE CASE_ID = kaseId;
        DELETE FROM POLICE WHERE  STUDENT_INITIALS = OLD.INITIALS;
        ALTER SEQUENCE studidseq RESTART WITH 1;
        UPDATE STUDENTS SET student_id=nextval('studidseq');
        RETURN  NULL;
    END;
$$;

alter function student_delete() owner to s263869;

