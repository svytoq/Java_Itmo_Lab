create function f2() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE Сектора SET Кол_пс = Кол_пс+1
WHERE ID_Сектора = NEW.ID_Сектора;
RETURN NEW;
END;
$$;

alter function f2() owner to s243845;

