create function active_cameraman()
    returns TABLE(id uuid, created_date timestamp without time zone, description text, doc_url character varying, end_date timestamp without time zone, interrupted boolean, interrupted_date timestamp without time zone, name character varying, printed boolean, company_id uuid, employee_id uuid, contact_film_id uuid, cameraman_id uuid, contract_id uuid, cameraman_employee_id uuid, film_id uuid)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY select *
                 from contract
                          join cameraman c2 on contract.id = c2.contract_id
                     AND contract.end_date > NOW()
                     AND contract.interrupted = false;
END;
$$;

alter function active_cameraman() owner to s264452;

