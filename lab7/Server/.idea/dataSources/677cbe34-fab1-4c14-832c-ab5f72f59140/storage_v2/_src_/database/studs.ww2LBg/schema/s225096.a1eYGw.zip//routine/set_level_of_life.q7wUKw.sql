create function set_level_of_life() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
	new.level_of_life := (SELECT life FROM skills WHERE skills.id = new.id_of_kind);
  RETURN NEW;
END;
$$;

alter function set_level_of_life() owner to s225096;

