create function show_fleet(civilization_name character varying)
    returns TABLE(name character varying, amount integer, military_force integer, wisdom_force integer)
    language sql
as
$$
select spaceship.name, spaceships_in_civilization.amount, spaceship.military_force, spaceship.wisdom_force 
from spaceship, spaceships_in_civilization where spaceship.id = spaceships_in_civilization.spaceship_id and spaceships_in_civilization.civilization_id =
(select spaceship_id from spaceships_in_civilization WHERE civilization_id = 
(select id from civilization where name = civilization_name));
$$;

alter function show_fleet(varchar) owner to s264483;

