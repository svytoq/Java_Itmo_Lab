create function check_max_number_groups() returns trigger
    language plpgsql
as
$$
BEGIN
  IF (SELECT count(*)
      FROM type_group
      WHERE id = new.type_group AND number_group < max_number_group) > 0
  THEN
    UPDATE type_group
    SET number_group = number_group + 1
    WHERE id = new.type_group;
  ELSE RAISE EXCEPTION 'Превышенно количество групп для данного типа группы';
  END IF;
  RETURN new;
END;
$$;

alter function check_max_number_groups() owner to s243872;

