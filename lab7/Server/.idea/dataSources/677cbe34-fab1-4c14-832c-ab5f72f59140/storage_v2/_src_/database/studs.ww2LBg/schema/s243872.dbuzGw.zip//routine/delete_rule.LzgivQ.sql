create function delete_rule() returns trigger
    language plpgsql
as
$$
BEGIN
  drop rule deny_update
  on refill;
  return new;
end;
$$;

alter function delete_rule() owner to s243872;

