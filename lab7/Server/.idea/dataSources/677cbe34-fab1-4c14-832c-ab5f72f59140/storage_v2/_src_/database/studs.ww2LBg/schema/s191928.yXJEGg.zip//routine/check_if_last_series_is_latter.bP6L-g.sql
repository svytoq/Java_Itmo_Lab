create function check_if_last_series_is_latter() returns trigger
    language plpgsql
as
$$
declare 
err character(50);
begin
err := 'Last series must be older than first series!';
if substr(new.first_series_to_appear, 2, 2) > substr(new.last_series_to_appear, 2, 2) then raise notice '%', err;
return null;
end if;
if substr(new.first_series_to_appear, 5, 3) > substr(new.last_series_to_appear, 5, 3) then raise notice '%', err;
return null;
end if;
return new;
end
$$;

alter function check_if_last_series_is_latter() owner to s191928;

