create function lift() returns trigger
    language plpgsql
as
$$
BEGIN
        if NEW.Макс_людей not between 0 and 500000 then
            Raise exception 'Макс_людей not between 0 .. 500000';
        end if;
        if NEW.Кол_людей not between 0 and NEW.Макс_людей then
            Raise exception 'Кол_людей not between 0 .. Макс_людей';
        end if;
        RETURN NEW;
    END;
$$;

alter function lift() owner to s269380;

