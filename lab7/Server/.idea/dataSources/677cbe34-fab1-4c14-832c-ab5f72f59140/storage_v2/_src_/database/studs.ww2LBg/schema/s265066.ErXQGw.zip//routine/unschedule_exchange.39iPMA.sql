create function unschedule_exchange(exc_id integer) returns integer
    language plpgsql
as
$$
begin
    update Messages set msg_state = 'encrypted' where msg_id=(
        select out_msg from Msg_exchanges where msg_exc_id=exc_id);

    delete from Msg_exchanges where msg_exc_id=exc_id;
    return 1;
end;
$$;

alter function unschedule_exchange(integer) owner to s265066;

