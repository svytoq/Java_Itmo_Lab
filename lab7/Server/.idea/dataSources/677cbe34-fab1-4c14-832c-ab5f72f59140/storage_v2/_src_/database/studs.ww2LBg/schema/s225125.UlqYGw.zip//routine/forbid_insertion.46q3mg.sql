create function forbid_insertion() returns trigger
    language plpgsql
as
$$
BEGIN
  RAISE EXCEPTION 'Нельзя добавлять новые строки в таблицу %', TG_TABLE_NAME;
END
$$;

alter function forbid_insertion() owner to s225125;

