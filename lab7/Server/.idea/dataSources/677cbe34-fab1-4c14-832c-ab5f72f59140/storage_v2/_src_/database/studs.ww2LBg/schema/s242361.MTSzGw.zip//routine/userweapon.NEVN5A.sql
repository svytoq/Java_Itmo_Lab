create function userweapon(number integer, OUT "ОРУЖИЕ" character varying) returns character varying
    language sql
as
$$
SELECT НАЗВАНИЕ FROM (SELECT НАЗВАНИЕ, COUNT(НАЗВАНИЕ) KEK FROM (
SELECT ИД_ПОЛЬЗОВАТЕЛЯ, ОРУЖИЕ.НАЗВАНИЕ НАЗВАНИЕ FROM ТРИБУТЫ
JOIN ОРУЖИЕ USING(ИД_ОРУЖИЯ)
WHERE ИД_УБИЙЦЫ = number) AS WEAPONS
GROUP BY (НАЗВАНИЕ)) AS RESULT
WHERE KEK = (SELECT max(KEK) FROM (SELECT НАЗВАНИЕ, COUNT(НАЗВАНИЕ) KEK FROM (
SELECT ИД_ПОЛЬЗОВАТЕЛЯ, ОРУЖИЕ.НАЗВАНИЕ FROM ТРИБУТЫ
JOIN ОРУЖИЕ USING(ИД_ОРУЖИЯ)
WHERE ИД_УБИЙЦЫ = number) AS WEAPONS
GROUP BY (НАЗВАНИЕ)) AS RESULT);

$$;

alter function userweapon(integer, out varchar) owner to s242361;

