create function цена_книги(name character varying, price numeric)
    returns TABLE(book character varying, new_price numeric)
    language plpgsql
as
$$
begin
update Учебная_литература set Средняя_цена = price 
where Автор = name;
return query select Название_экземпляра, Средняя_цена
from Учебная_литература where Автор = name;
end;
$$;

alter function цена_книги(varchar, numeric) owner to s225069;

