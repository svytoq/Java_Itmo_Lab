create function check_booking() returns void
    language plpgsql
as
$$
begin
        with delete_id as (
            select booking.id as id from booking where time_limit < now()
        ), delete_0 as (
            delete from ticket where exists(select 1 from delete_id where ticket.book_id = delete_id.id)
        )
            delete from booking where exists(select 1 from delete_id where booking.id = delete_id.id);
    end;
$$;

alter function check_booking() owner to s265061;

