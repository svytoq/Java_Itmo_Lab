create function check_present() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((SELECT ИД_ПОЛЬЗОВАТЕЛЯ FROM ТРИБУТЫ WHERE ИД_ТРИБУТА = NEW.ИД_ТРИБУТА) = NEW.ИД_ОТПРАВИТЕЛЯ) THEN
RAISE WARNING 'Трибут и отправитель не могут быть одним человеком';
RETURN NULL;
ELSEIF ((SELECT ИД_ИГРЫ FROM ТРИБУТЫ WHERE ((ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ОТПРАВИТЕЛЯ) 
AND (ИД_ИГРЫ = (SELECT ИД_ИГРЫ FROM ТРИБУТЫ WHERE ИД_ТРИБУТА = NEW.ИД_ТРИБУТА)))) IS NOT NULL)
THEN
RAISE WARNING 'Отправитель не может быть трибутом';
RETURN NULL;
ELSEIF (((SELECT ДЕНЬГИ FROM ПОЛЬЗОВАТЕЛИ WHERE ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ОТПРАВИТЕЛЯ) - (SELECT ЦЕНА FROM ПОДАРКИ WHERE ИД_ПОДАРКА = NEW.ИД_ПОДАРКА)*NEW.КОЛИЧЕСТВО ) < 0) THEN
RAISE WARNING 'У отправителя не хватает денег на подарок';
RETURN NULL;
ELSE
UPDATE ПОЛЬЗОВАТЕЛИ SET ДЕНЬГИ = ДЕНЬГИ - (SELECT ЦЕНА FROM ПОДАРКИ WHERE ИД_ПОДАРКА = NEW.ИД_ПОДАРКА)*NEW.КОЛИЧЕСТВО WHERE ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ОТПРАВИТЕЛЯ;
RETURN NEW;
END IF;
END;
$$;

alter function check_present() owner to s242361;

