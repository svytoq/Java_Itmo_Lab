create function get_illed() returns trigger
    language plpgsql
as
$$
DECLARE
	name_food_of type_of_food;
	available_food_of INTEGER;
	need_help integer;
	kind_of INTEGER;
BEGIN
	if new.id_of_diagnosis = 2
		THEN
			SELECT s.life - p.level_of_life, p.id_of_kind into need_help, kind_of FROM passenger p JOIN skills s on (s.id = p.passport_document) where p.passport_document = new.id_of_passenger;
			SELECT type_of_food INTO name_food_of FROM kind WHERE id_of_kind = (SELECT id_of_kind FROM passenger WHERE passport_document = new.id_of_passenger);
			available_food_of := get_reserved_food(need_help + new.damage_power, name_food_of, kind_of, new.id_of_passenger);
			UPDATE passenger SET level_of_life = level_of_life+available_food_of-new.damage_power WHERE new.id_of_passenger = passenger.passport_document;
	END IF;
  RETURN NEW;
END;
$$;

alter function get_illed() owner to s225096;

