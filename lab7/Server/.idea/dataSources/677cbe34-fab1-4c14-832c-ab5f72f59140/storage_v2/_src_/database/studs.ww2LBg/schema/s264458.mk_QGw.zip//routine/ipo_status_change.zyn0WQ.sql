create function ipo_status_change(id_company integer, ipo_status boolean) returns void
    language plpgsql
as
$$
BEGIN

  IF ipo_status_change.ipo_status = TRUE THEN

    UPDATE company
    SET ipo = TRUE
    WHERE id = ipo_status_change.id_company;

  ELSE

    UPDATE company
    SET ipo = FALSE
    WHERE id = ipo_status_change.id_company;

  END IF;


END;

$$;

alter function ipo_status_change(integer, boolean) owner to s264458;

