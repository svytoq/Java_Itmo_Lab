create function get_pol(idd integer) returns s241870."Пол"
    language plpgsql
as
$$
BEGIN
  RETURN (SELECT Птицы.Пол FROM Птицы WHERE ID_Птицы = idd);
END;
$$;

alter function get_pol(integer) owner to s241870;

