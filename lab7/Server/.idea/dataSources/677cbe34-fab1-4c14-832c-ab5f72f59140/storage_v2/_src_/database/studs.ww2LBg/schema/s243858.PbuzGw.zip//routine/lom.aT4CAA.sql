create function lom(OUT result integer) returns integer
    language plpgsql
as
$$
BEGIN
EXECUTE format('SELECT count(ID) FROM tank')
INTO result;
END
$$;

alter function lom(out integer) owner to s243858;

