create function create_passenger() returns trigger
    language plpgsql
as
$$
DECLARE
  male_compartment_of INTEGER;
  female_compartment_of INTEGER;
	kind_of INTEGER;
	gender_of VARCHAR(1);
	GP BOOLEAN;
	id_of INTEGER;
	gender_of_father VARCHAR(1);
BEGIN
	GP := FALSE;
	kind_of := check_kind(new.id_of_male, new.id_of_female);
	IF kind_of = -1
		THEN
		RAISE NOTICE 'THE ANIMALS HAVE THE SAME GENDER';
		RETURN NULL;
			END IF;
	IF kind_of = -2
		THEN
		RAISE NOTICE 'THE ANIMALS HAVE DIFFERENT DETACHMENTS';
		RETURN NULL;
			END IF;
	IF kind_of = -3
		THEN
		RAISE NOTICE 'ONE OR BOTH OF THE ANIMALS ALREADY DEAD';
		RETURN NULL;
		END IF;
	SELECT id_of_compartment,gender INTO male_compartment_of,gender_of_father FROM passenger WHERE new.id_of_male = passport_document;
	SELECT id_of_compartment INTO female_compartment_of FROM passenger WHERE new.id_of_female = passport_document;
	IF male_compartment_of != female_compartment_of THEN
		RAISE NOTICE 'ANIMALS DETECTED IN DIFFERENT COMPARTMENTS';
		RETURN NULL;
	END IF;
	IF ((SELECT capacity FROM compartment WHERE male_compartment_of = id_comparatment) > 0)
		THEN
			UPDATE compartment SET capacity=(capacity-1) WHERE male_compartment_of = id_comparatment;
		ELSE
			male_compartment_of := (SELECT id_comparatment FROM compartment WHERE capacity > 0 AND id_habitat = (SELECT id_habitat FROM compartment WHERE male_compartment_of = id_comparatment) LIMIT 1);
			UPDATE compartment SET capacity=(capacity-1) WHERE male_compartment_of = id_comparatment;
			IF male_compartment_of IS NULL
				THEN
				RAISE NOTICE 'ACHTUNG! GLOBAL PROBLEM! All compartments are busy.';
					GP := TRUE;
			END IF;
	END IF;
	IF((SELECT floor(random()*(2-1+1))+1) = 1)
		THEN gender_of := 'M';
		ELSE gender_of := 'F';
	END IF;
	INSERT INTO passenger (id_of_kind, id_of_compartment, id_of_father, id_of_mother, gender)
	VALUES (kind_of, male_compartment_of, new.id_of_male, new.id_of_female, gender_of);
	IF GP
		THEN
		SELECT passport_document INTO id_of FROM passenger ORDER BY passport_document DESC LIMIT 1;
 		INSERT INTO global_problem (id_of_kind, id_of_passenger, type) VALUES (kind_of, id_of, 'compartments');
	END IF;

	IF (gender_of = 'M')
							THEN
							UPDATE number_of_species SET count_of_male = count_of_male + 1 WHERE id_of_kind =  kind_of;
							ELSE
							UPDATE number_of_species SET count_of_female = count_of_female + 1 WHERE id_of_kind =  kind_of;
						END IF;
  RETURN NEW;
END;
$$;

alter function create_passenger() owner to s225096;

