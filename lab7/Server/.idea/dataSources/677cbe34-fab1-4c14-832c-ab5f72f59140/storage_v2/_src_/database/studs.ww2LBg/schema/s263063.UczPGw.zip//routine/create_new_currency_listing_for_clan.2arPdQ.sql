create function create_new_currency_listing_for_clan(clanid integer, currencyforsellid integer, currencytobuyid integer, currencyforsellamount integer, currencytobuyamount integer, listingdescription character varying) returns void
    language plpgsql
as
$$
declare currencyAmount int;
begin
    currencyAmount = (select amount from clan_currency where clan_id = clanId and currency_id = currencyForSellId);
    if (currencyAmount is null or currencyAmount < currencyForSellAmount) then
        return;
    end if;
    with insertListing as (
        insert into listing (seller, clan_id, description) values ('Clan', clanId, listingDescription)
            returning listing_id as listingId
    )
    insert
    into currency_listing (listing_id, currency_for_sell_id, currency_for_buy_id, sell_amount, buy_amount)
    values ((select listingId from insertListing), currencyForSellId, currencyToBuyId, currencyForSellAmount,
                                                                                            currencyToBuyAmount);
    update clan_currency set amount = currencyAmount - currencyForSellAmount where clan_id = clanId
                                                                                and currency_id = currencyForSellId;
end;
$$;

alter function create_new_currency_listing_for_clan(integer, integer, integer, integer, integer, varchar) owner to s263063;

