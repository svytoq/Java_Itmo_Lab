create view after_30_min_spot("Билет_ИД", "Тип_двери", "Занято_с") as
SELECT "о"."Билет_ИД",
       "д"."Тип_двери",
       "о"."Занято_с"
FROM s267650."Очередь_дверь" "о"
         JOIN s267650."Дверь_времени" "д" ON "о"."Дверь_ИД" = "д"."ИД"
WHERE ((date_part('day'::text, "о"."Занято_с"::timestamp with time zone - now()) * 24::double precision +
        date_part('hour'::text, "о"."Занято_с"::timestamp with time zone - now())) * 60::double precision +
       date_part('minute'::text, "о"."Занято_с"::timestamp with time zone - now())) >= 30::double precision
  AND ((date_part('day'::text, "о"."Занято_с"::timestamp with time zone - now()) * 24::double precision +
        date_part('hour'::text, "о"."Занято_с"::timestamp with time zone - now())) * 60::double precision +
       date_part('minute'::text, "о"."Занято_с"::timestamp with time zone - now())) <= 31::double precision;

alter table after_30_min_spot
    owner to s267650;

