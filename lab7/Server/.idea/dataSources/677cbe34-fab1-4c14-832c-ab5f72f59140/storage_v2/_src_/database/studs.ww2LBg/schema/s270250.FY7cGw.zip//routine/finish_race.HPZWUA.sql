create function finish_race() returns trigger
    language plpgsql
as
$$
DECLARE
        district_id integer;
        hippodrome_id integer;
        correct_mafia_id integer;
        time_start_race timestamp;
        race_fake_winner integer;
        winner_by_params integer;
        final_winner integer;
        coef_on_winner real;
        winner_bets_in_percent real;
    BEGIN
        SELECT time_start INTO time_start_race FROM Races r WHERE r.id = NEW.race_id;
        SELECT hippodrome INTO hippodrome_id FROM Races r WHERE r.id = NEW.race_id;
        SELECT district INTO district_id FROM Hippodromes h WHERE h.id = hippodrome_id;
        SELECT owner INTO correct_mafia_id FROM Districts d WHERE d.id = district_id;
        IF (time_start_race <= current_timestamp AND NEW.mafia_id = correct_mafia_id) THEN
            UPDATE Races r SET is_finished = TRUE WHERE r.id = NEW.race_id;
            -- тут происходит все самое интересное
            -- 1 определяем победителя гонки
            winner_by_params := get_winner_for_race(NEW.race_id);
            UPDATE Races SET predicted_winner = winner_by_params WHERE id = NEW.race_id;  --справлено
            SELECT fake_winner INTO race_fake_winner FROM Races WHERE id = NEW.race_id;
            final_winner := COALESCE(race_fake_winner, winner_by_params); --исправлено
            -- 2 рассчитываем коэф для выплаты выигрышных ставок
            coef_on_winner := get_coef_by_race_and_winner(NEW.race_id, final_winner);
            -- 3 рассчитываем все ставки, чистые выигрыша списываем со счета мафии, проигрышы переводим мафии
            UPDATE Mafies m SET wealth = wealth - COALESCE((
                SELECT ceil(sum(b.amount)*coef_on_winner) FROM Bets b JOIN Horse_in_race hir ON (b.horse_in_race = hir.id)
                WHERE hir.race_id = NEW.race_id AND hir.horse_id = final_winner
            ),0) WHERE m.id = NEW.mafia_id;

            UPDATE Mafies m SET wealth = wealth + COALESCE((
                SELECT floor(sum(b.amount*bkmk.coefficient)) FROM Bets b
                JOIN Bookmakers bkmk ON (b.bookmaker=bkmk.id)
                JOIN Horse_in_race hir ON (b.horse_in_race = hir.id)
                WHERE hir.race_id = NEW.race_id AND hir.horse_id != final_winner
            ), 0) WHERE m.id = NEW.mafia_id;

            -- 4 расчет прибыли от продажи билетов
            UPDATE Mafies m SET wealth = wealth + COALESCE((
                SELECT floor(number_of_seats*20*((
                   SELECT authority FROM Mafies WHERE id = NEW.mafia_id
                )/10.0)*((
                   SELECT h.popularity FROM Horse_in_race hir
                   JOIN Horses h ON (hir.horse_id = h.id)
                   WHERE hir.race_id=NEW.race_id ORDER BY h.popularity DESC LIMIT 1
                )/10.0)) FROM Hippodromes
                WHERE id = hippodrome_id
            ), 0) WHERE m.id = NEW.mafia_id;

            -- 5 увеличиваем характеристики выигравшей лошади
            UPDATE horses SET
            luck = round((luck + (1 - luck) * 0.1)::numeric, 3),
            popularity = ceil(popularity + (10 - popularity) * 0.1)
            WHERE id = final_winner;


            -- 6 расчет процента выигрышных ставок (<40%, понижение авторитета мафии)
--             SELECT round((
--                 SELECT count(*) FROM Bets b JOIN Horse_in_race hir ON (b.horse_in_race = hir.id) WHERE hir.race_id = NEW.race_id AND hir.horse_id = final_winner
--             )/GREATEST(((
--                 SELECT count(*) FROM Bets b JOIN Horse_in_race hir ON (b.horse_in_race = hir.id) WHERE hir.race_id = NEW.race_id
--             )::numeric, 3), 1))*100 INTO winner_bets_in_percent;

            SELECT round((
                SELECT count(*) FROM Bets b JOIN Horse_in_race hir ON (b.horse_in_race = hir.id) WHERE hir.race_id = NEW.race_id AND hir.horse_id = final_winner
                )/GREATEST((
                SELECT count(*) FROM Bets b JOIN Horse_in_race hir ON (b.horse_in_race = hir.id) WHERE hir.race_id = NEW.race_id
                    )::numeric, 1), 3)*100 INTO winner_bets_in_percent;


            IF (winner_bets_in_percent < 40) THEN
                UPDATE Mafies m SET authority = authority-(authority * 0.1) WHERE m.id = NEW.mafia_id;
            END IF;

            RETURN NEW;
        ELSE
            RAISE EXCEPTION 'Вы не можете завершить гонку';
        END IF;
    END;
$$;

alter function finish_race() owner to s270250;

