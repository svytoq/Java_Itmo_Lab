create function mine_object_trigger() returns trigger
    language plpgsql
as
$$
declare
    current_planet_x bigint;
    current_planet_y bigint;
    current_planet_z bigint;
    current_planet_r bigint;
    army_current_object_id int;
    is_star boolean;
    available_moskoviy bigint;
    needed_moskoviy bigint;
    mining_army_quantity bigint;
    mining_difficulty smallint;
    moskoviy bigint;
    kantoniy bigint;
    can_mine boolean;
  begin
    select r_a.quantity into available_moskoviy from army as a 
    inner join resource_army as r_a on (a.id = r_a.army_id)
    inner join resource as r on (r_a.resource_id = r.id)
    where r.name = 'moskoviy';
    
    select s_o.x_coordinate, s_o.y_coordinate, s_o.z_coordinate, s_o.radius, s_o.id
    into current_planet_x, current_planet_y, current_planet_z, current_planet_r, army_current_object_id
    from space_object as s_o
    inner join planet as p on (p.object_id = s_o.id)
    where p.army_id = new.army_id;
    
    select 't' into is_star from star where object_id = new.object_id;
    
    -- mining for star
    if is_star = 't' then
      select quantity into mining_army_quantity from army where id = new.army_id;
      
      select difficulty into mining_difficulty from star where object_id = new.object_id;
      
      select (sqrt(
      power(current_planet_x - s_o.x_coordinate, 2) + 
      power(current_planet_y - s_o.y_coordinate, 2) + 
      power(current_planet_z - s_o.z_coordinate, 2)
    )-current_planet_r-s_o.radius) * 2 into needed_moskoviy from space_object as s_o
    where s_o.id = new.object_id;
      
      if available_moskoviy >= needed_moskoviy 
      and mining_army_quantity >= mining_difficulty*10000 then
        update resource_army set quantity = quantity - needed_moskoviy 
        where resource_id = (select id from resource where name = 'moskoviy') and army_id = new.army_id;
        
        select quantity into moskoviy from resource_space_object as r_s_o 
        inner join resource as r on (r.id = r_s_o.resource_id) where r.name='moskoviy' and r_s_o.object_id = new.object_id;
        select quantity into kantoniy from resource_space_object as r_s_o 
        inner join resource as r on (r.id = r_s_o.resource_id) where r.name='kantoniy' and r_s_o.object_id = new.object_id;
        
        update resource_space_object set quantity = 0 where object_id = new.object_id;
        update resource_army set quantity = quantity + moskoviy 
        where resource_id = (select id from resource where name = 'moskoviy') and army_id = new.army_id;
        update resource_army set quantity = quantity + kantoniy 
        where resource_id = (select id from resource where name = 'kantoniy') and army_id = new.army_id;
        return new;
      end if;
      raise exception 'Not enough resources or people in army';
    end if;
    
    -- mining for planet
    
    select quantity into moskoviy from resource_space_object as r_s_o 
    inner join resource as r on (r.id = r_s_o.resource_id) where r.name='moskoviy' and r_s_o.object_id = new.object_id;
    select quantity into kantoniy from resource_space_object as r_s_o 
    inner join resource as r on (r.id = r_s_o.resource_id) where r.name='kantoniy' and r_s_o.object_id = new.object_id;
        
    update resource_space_object set quantity = 0 where object_id = new.object_id;
    update resource_army set quantity = quantity + moskoviy 
    where resource_id = (select id from resource where name = 'moskoviy') and army_id = new.army_id;
    update resource_army set quantity = quantity + kantoniy 
    where resource_id = (select id from resource where name = 'kantoniy') and army_id = new.army_id;
    
    return new;
  end;
$$;

alter function mine_object_trigger() owner to s264482;

