create function judge() returns trigger
    language plpgsql
as
$$
DECLARE
judge_id int;
j_post varchar;
j_duties text;
BEGIN
judge_id = (select worker_id from last_judgment where worker_id = new.worker_id);
j_post = (select post from worker join last_judgment lj on worker.id = lj.worker_id where lj.worker_id = new.worker_id);
j_duties = (select duties from worker join last_judgment lj on worker.id = lj.worker_id where lj.worker_id = new.worker_id);
if (j_post != 'Архангел') or (j_duties != 'Проводит суд') then
    raise exception 'Суд должен проводить только архангел или ангел с должностью проводить суд';
    else return new;
end if;
END;
$$;

alter function judge() owner to s265936;

