create function deleteproc() returns trigger
    language plpgsql
as
$$
begin
 delete from УСТРОЙСТВА where  УСТРОЙСТВА.ИД_ПРОЦЕССОРА = ПРОЦЕССОР.ИД;
 end;
$$;

alter function deleteproc() owner to s243855;

