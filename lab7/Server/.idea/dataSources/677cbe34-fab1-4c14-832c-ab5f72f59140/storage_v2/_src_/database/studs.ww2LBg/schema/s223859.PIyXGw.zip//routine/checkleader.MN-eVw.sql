create function checkleader() returns trigger
    language plpgsql
as
$$
BEGIN
IF((select ИМЯ from ПЕРСОНАЖИ where ПЕРСОНАЖИ.ОРГАНИЗАЦИЯ=new.НАЗВАНИЕ_ОРГ))!=new.ГЛАВНОКОМАНДУЮЩИЙ THEN
RAISE EXCEPTION 'Этот персонаж не может быть главнокомандующим этой организации, так как не состоит в ней';
ELSE RETURN NEW;
END IF;
END;
$$;

alter function checkleader() owner to s223859;

