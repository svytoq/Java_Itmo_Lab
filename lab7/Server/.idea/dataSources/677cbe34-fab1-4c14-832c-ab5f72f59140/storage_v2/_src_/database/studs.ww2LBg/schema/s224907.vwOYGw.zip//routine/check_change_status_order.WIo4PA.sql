create function check_change_status_order() returns trigger
    language plpgsql
as
$$
begin
    if (NEW.status != 'Поиск курьера' and NEW.courier_id is NULL) then
        raise exception 'you cannot change the status to another, because this status has a courier';
    end if;
    if (OLD.status = 'Поиск курьера' and NEW.status != 'Покупка товаров') then
        raise exception 'you cannot change the status to another like this';
    end if;
    if (OLD.status = 'Покупка товаров' and NEW.status != 'Доставка товаров') then
        raise exception 'you cannot change the status to another like this';
    end if;
    if (OLD.status = 'Доставка товаров' and NEW.status != 'Оплачен') then
        raise exception 'you cannot change the status to another like this';
    end if;
    if (OLD.status = 'Оплачен') then
        raise exception 'you cannot change this status to another like this';
    end if;
    return NEW;
end;
$$;

alter function check_change_status_order() owner to s224907;

