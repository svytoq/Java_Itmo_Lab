create function select_product_shop(shop_id_in integer)
    returns TABLE(product_name character varying, product_description text, product_category character varying, price real)
    language plpgsql
as
$$
begin
    if not exists(select * from product_shop where shop_id = shop_id_in) then
        raise exception 'Shop products with this id is not exist';
    end if;
    return query
        select p.name, p.description, p.category, ps.price
        from product_shop ps
                 join product p on p.id = ps.product_id
        where ps.shop_id = shop_id_in;
end;
$$;

alter function select_product_shop(integer) owner to s264451;

