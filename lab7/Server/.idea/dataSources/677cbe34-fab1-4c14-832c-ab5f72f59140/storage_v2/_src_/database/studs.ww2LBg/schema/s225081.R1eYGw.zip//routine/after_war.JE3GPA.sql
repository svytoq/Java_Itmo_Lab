create function after_war() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP = 'INSERT'
  THEN
    INSERT INTO УЧАСТНИК_МЕРОПРИЯТИЯ VALUES (DEFAULT, NEW.ИНИЦИАТОР, NEW.ID_МЕРОПРИЯТИЯ);
    INSERT INTO УЧАСТНИК_МЕРОПРИЯТИЯ VALUES (DEFAULT, NEW.ПРОТИВНИК, NEW.ID_МЕРОПРИЯТИЯ);

  ELSEIF TG_OP = 'UPDATE'
    THEN
      UPDATE УЧАСТНИК_МЕРОПРИЯТИЯ
      SET ЧЕЛОВЕК = NEW.ИНИЦИАТОР, МЕРОПРИЯТИЕ = NEW.ID_МЕРОПРИЯТИЯ
      WHERE ЧЕЛОВЕК = OLD.ИНИЦИАТОР AND МЕРОПРИЯТИЕ = OLD.ID_МЕРОПРИЯТИЯ;

      UPDATE УЧАСТНИК_МЕРОПРИЯТИЯ
      SET ЧЕЛОВЕК = NEW.ПРОТИВНИК, МЕРОПРИЯТИЕ = NEW.ID_МЕРОПРИЯТИЯ
      WHERE ЧЕЛОВЕК = OLD.ПРОТИВНИК AND МЕРОПРИЯТИЕ = OLD.ID_МЕРОПРИЯТИЯ;
  END IF;
  RETURN NULL;
END;
$$;

alter function after_war() owner to s225081;

