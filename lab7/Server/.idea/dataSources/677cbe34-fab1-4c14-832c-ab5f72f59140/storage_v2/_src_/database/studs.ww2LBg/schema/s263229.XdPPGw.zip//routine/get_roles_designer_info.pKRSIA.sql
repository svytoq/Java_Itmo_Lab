create function get_roles_designer_info(roles_designer_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT rd.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH FROM roles_designers AS rd 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE rd.WORKER_ID = roles_designer_id;
END
$$;

alter function get_roles_designer_info(integer) owner to s263229;

