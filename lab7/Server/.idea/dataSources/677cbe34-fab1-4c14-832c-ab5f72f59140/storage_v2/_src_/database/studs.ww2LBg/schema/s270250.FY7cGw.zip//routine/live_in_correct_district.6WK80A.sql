create function live_in_correct_district() returns trigger
    language plpgsql
as
$$
DECLARE
--         Проверка на то, что букмекер/мафия живет в своем раойне. Если оказывается что нет,
--         то меняем просто его принадлежность к той мафии, где он живет.
        mafia_id integer;
    BEGIN
        SELECT owner INTO mafia_id FROM Districts m WHERE m.id = NEW.live_in;
        IF (NEW.mafia_family IS NOT NULL AND NEW.mafia_family != mafia_id) THEN
            UPDATE Persons SET mafia_family = mafia_id WHERE id = NEW.id;
        END IF;
        RETURN NEW;
    END;
$$;

alter function live_in_correct_district() owner to s270250;

