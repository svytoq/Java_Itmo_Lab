create function upd_warriors() returns void
    language plpgsql
as
$$
DECLARE
  I      INT;
  DEPART INT;
  COUNT  INT;
BEGIN
  FOR I IN SELECT ID_ВОИНА
           FROM ВОИНЫ LOOP
    SELECT COUNT(*)
    FROM ПОДРАЗДЕЛЕНИЕ
    INTO COUNT;
    DEPART = RANDOM() * (COUNT - 1) + 1 :: INT;
    UPDATE ВОИНЫ
    SET ПОДРАЗДЕЛЕНИЕ = DEPART
    WHERE ID_ВОИНА = I AND ДОЛЖНОСТЬ = 'РЯДОВОЙ ВОИН';
  END LOOP;
END;
$$;

alter function upd_warriors() owner to s225081;

