create function log_comrade_union_action() returns trigger
    language plpgsql
as
$$
begin
    raise notice 'Actor rating:';
    if old.union_id is null and new.union_id is not null then
        insert into comradeunionlog(comrade_id, union_id, action_type)
        values (new.id, new.union_id, 'Join');
        return new;
    end if;

    if old.union_id != new.union_id then
        insert into comradeunionlog(comrade_id, union_id, action_type)
        values (new.id, new.union_id, 'Join');
        insert into comradeunionlog(comrade_id, union_id, action_type)
        values (new.id, old.union_id, 'Leave');
        return new;
    end if;

    if old.union_id is not null and new.union_id is null then
        insert into comradeunionlog(comrade_id, union_id, action_type)
        values (new.id, old.union_id, 'Leave');
    end if;
    return new;
end;
$$;

alter function log_comrade_union_action() owner to s267883;

