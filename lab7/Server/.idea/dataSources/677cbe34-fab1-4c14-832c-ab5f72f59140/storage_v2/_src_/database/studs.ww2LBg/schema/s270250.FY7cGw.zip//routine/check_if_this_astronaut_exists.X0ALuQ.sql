create function check_if_this_astronaut_exists() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
   IF (EXISTS(SELECT person_id FROM astronaut WHERE person_id = NEW.person_id)) THEN
     RAISE EXCEPTION 'no, this person is already a astronaut';
   END IF;
   RETURN NEW;
END;
$$;

alter function check_if_this_astronaut_exists() owner to s270250;

