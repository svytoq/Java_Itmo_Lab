create function visaapplinsertcheck() returns trigger
    language plpgsql
as
$$
declare
    restriction date;
    opened_violation bool;
    active_visa bool;
    -- cp bigint;
    close_relations relation_types[];
begin
    if exists(select 1 from Visa_applications where person_id=NEW.person_id and visa_app_state!='done') = true then
        raise exception 'active application exists';
    end if;

    -- if (select birth_dim from People where person_id=-1) != (select birth_dim from People where person_id=NEW.person_id)
    -- and not exists(select 1 from Employees where person_id=NEW.person_id)
    -- then
    --     raise exception 'person from another dim';
    -- end if;
    return NEW;
end;
$$;

alter function visaapplinsertcheck() owner to s265066;

