create function getobservatoryequipment(observatory_name text)
    returns TABLE(name_ text, type_ s265111.equipment_type, canbeusedfor_ s265111.can_be_used_for)
    language plpgsql
as
$$
DECLARE
    observatory_id_local int;
BEGIN
    select id into observatory_id_local from observatory where name = observatory_name;
    return query
        select equipment.name, type, canbeusedfor
        from equipment
                 inner join observatory on equipment.observatoryid = observatory.id
        where observatoryid = observatory_id_local;
END;
$$;

alter function getobservatoryequipment(text) owner to s265111;

