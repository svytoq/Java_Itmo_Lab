create function thing_border_prevent_proc() returns trigger
    language plpgsql
as
$$
declare 
        thingsNum INT;
        thingsBorder INT;
    begin
        select count(*) into thingsNum from thing;
        select things_border into thingsBorder from trading_platform where platform_id = new.platform_id;
        if thingsNum <= thingsBorder then
          return new;
        else 
          return null;
        end if;
    end;
$$;

alter function thing_border_prevent_proc() owner to s263919;

