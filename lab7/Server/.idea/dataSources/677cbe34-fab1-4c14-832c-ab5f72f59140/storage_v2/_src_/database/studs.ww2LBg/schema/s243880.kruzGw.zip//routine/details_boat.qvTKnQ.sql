create function details_boat("id_ЛОДКИ" integer)
    returns TABLE("ИД_ЛОДКИ" integer, "ИД_ДЕТАЛИ" integer, "ВЕС" integer, "ВЛИЯНИЕ_НА_СКОРОСТЬ" integer, "ВЛИЯНИЕ_НА_УПРАВЛЯЕМОСТЬ" integer, "ВЛИЯНИЕ_НА_УСКОРЕНИЕ" integer)
    language sql
as
$$
SELECT boat_ИД, details_ИД, ВЕС, ВЛИЯНИЕ_НА_СКОРОСТЬ,
ВЛИЯНИЕ_НА_УПРАВЛЯЕМОСТЬ, ВЛИЯНИЕ_НА_УСКОРЕНИЕ FROM ДЕТАЛИ 
INNER JOIN  ЛОДКА_ДЕТАЛИ ON  ЛОДКА_ДЕТАЛИ.details_ИД =
ДЕТАЛИ.ИД WHERE ЛОДКА_ДЕТАЛИ.boat_ИД = $1;
$$;

alter function details_boat(integer) owner to s243880;

