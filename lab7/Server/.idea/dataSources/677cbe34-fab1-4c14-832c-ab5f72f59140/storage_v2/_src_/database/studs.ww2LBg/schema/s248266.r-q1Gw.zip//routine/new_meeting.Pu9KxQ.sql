create function new_meeting(userid integer, whereid integer, startdate date, hasdresscode boolean, meetingtype text) returns void
    language plpgsql
as
$$
DECLARE
addressName text;
eventId int;
typeId int;
BEGIN
    addressName := (SELECT Адрес FROM К_Место WHERE ИД = whereId);
    IF NOT EXISTS (
        SELECT 1 FROM К_Вид_встречи WHERE Название = meetingType)
    THEN
        INSERT INTO К_Вид_встречи (Название) VALUES (meetingType);
    END IF;
    typeId := (SELECT ИД FROM К_Вид_встречи WHERE Название = meetingType);
    INSERT INTO К_Событие (ИД_Пользователя, Название, Описание, Тип,
        Время_начала, Время_окончания) VALUES (userId,
        'Встреча (' || meetingType || ')',
        'Встреча по адресу: ' || addressName, 'Встреча', startDate::timestamp,
        NULL) RETURNING ИД INTO eventId;
    INSERT INTO К_Встреча (ИД_События, ИД_Места, ИД_Вида, Наличие_дресс_кода)
        VALUES (eventId, whereId, typeId, hasDressCode);
END;
$$;

alter function new_meeting(integer, integer, date, boolean, text) owner to s248266;

