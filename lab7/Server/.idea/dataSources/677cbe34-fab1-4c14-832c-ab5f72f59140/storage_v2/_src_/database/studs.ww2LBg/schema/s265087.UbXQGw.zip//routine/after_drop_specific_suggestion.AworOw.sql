create function after_drop_specific_suggestion() returns trigger
    language plpgsql
as
$$
DECLARE
    SUGGESTION_ID INTEGER := (SELECT ID
                              FROM SUGGESTION
                              WHERE ID = OLD.SUGGESTION);
BEGIN
    DELETE FROM SUGGESTION WHERE ID = SUGGESTION_ID;
    RETURN OLD;
END;
$$;

alter function after_drop_specific_suggestion() owner to s265087;

