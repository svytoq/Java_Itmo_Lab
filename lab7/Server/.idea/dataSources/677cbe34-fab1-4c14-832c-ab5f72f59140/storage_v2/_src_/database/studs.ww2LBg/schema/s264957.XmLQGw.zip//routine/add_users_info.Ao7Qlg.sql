create function add_users_info() returns trigger
    language plpgsql
as
$$
BEGIN
        insert into participant values(NEW.participant_id, null, null, null, NEW.location_id, null, null, null, null, null);
        insert into location values(NEW.location_id, null, null, null);
        insert into weather values(NEW.weather_id, null, null, null);
        return NEW;
        end;
$$;

alter function add_users_info() owner to s264957;

