create function mask_planet_trigger() returns trigger
    language plpgsql
as
$$
declare
    population_planet_type char;
    masking_planet_type char; 
    masking_planet_is_masked boolean;
  begin
    update planet set is_masked = 't' where id = new.planet_id;
    return new;
  end;
$$;

alter function mask_planet_trigger() owner to s264482;

