create function getingredientspermedicalgroup(idingredient integer, minamount integer)
    returns TABLE("ИД_ЛОКАЦИИ" integer, "НАЗВАНИЕ" text, "ШИРОТА" real, "ДОЛГОТА" real, "КОЛИЧЕСТВО" integer)
    language sql
as
$$
select loc.ИД_ЛОКАЦИИ,
        aqu.НАЗВАНИЕ,
        loc.ШИРОТА,
        loc.ДОЛГОТА,
        loc.КОЛИЧЕСТВО
    from ЛОКАЦИЯ as loc
        join АКВАТОРИЯ as aqu using(ИД_АКВАТОРИИ)
    where loc.ИД_СУЩЕСТВА = (select ИД_СУЩЕСТВА from getCreatureInfo(22))
    group by loc.ИД_ЛОКАЦИИ, aqu.НАЗВАНИЕ, loc.ШИРОТА, loc.ДОЛГОТА, loc.КОЛИЧЕСТВО
    having loc.КОЛИЧЕСТВО > 100000
$$;

alter function getingredientspermedicalgroup(integer, integer) owner to s242425;

