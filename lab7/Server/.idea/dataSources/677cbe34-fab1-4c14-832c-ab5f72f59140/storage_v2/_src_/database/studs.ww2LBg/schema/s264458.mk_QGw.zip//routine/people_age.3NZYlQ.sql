create function people_age(user_id integer) returns integer
    language plpgsql
as
$$
DECLARE
  age INTEGER;

BEGIN
  SELECT date_part('year', age(dob)) INTO age FROM users WHERE id = user_id;

  RETURN age;
END;
$$;

alter function people_age(integer) owner to s264458;

