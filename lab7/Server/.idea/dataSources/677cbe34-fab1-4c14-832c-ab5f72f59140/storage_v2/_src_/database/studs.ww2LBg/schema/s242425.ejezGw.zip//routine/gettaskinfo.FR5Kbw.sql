create function gettaskinfo(name text)
    returns TABLE(id_medicine integer, name_medicine text, medicine_amount integer, number_in_queue integer, progress double precision, finish_date date)
    language sql
as
$$
select ЛЕКАРСТВО.ИД_ЛЕКАРСТВА, 
        ЛЕКАРСТВО.НАЗВАНИЕ,
        ЗАКАЗ.КОЛИЧЕСТВО,
        СТАТУС_ЗАКАЗА.НОМЕР_В_ОЧЕРЕДИ,
        СТАТУС_ЗАКАЗА.ВЫПОЛНЕНИЕ,
        СТАТУС_ЗАКАЗА.ДАТА_ЗАВЕРШЕНИЯ
    from ЗАКАЗ 
        join ЛЕКАРСТВО using(ИД_ЛЕКАРСТВА)
        join СТАТУС_ЗАКАЗА using(ИД_ЗАКАЗА)
    where ЗАКАЗ.НАЗВАНИЕ_АПТЕЧНОЙ_СЕТИ=name
    order by СТАТУС_ЗАКАЗА.НОМЕР_В_ОЧЕРЕДИ;
$$;

alter function gettaskinfo(text) owner to s242425;

