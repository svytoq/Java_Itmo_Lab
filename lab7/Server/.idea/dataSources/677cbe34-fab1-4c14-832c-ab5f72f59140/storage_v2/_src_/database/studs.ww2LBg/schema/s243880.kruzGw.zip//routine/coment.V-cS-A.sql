create function coment("ИД" integer)
    returns TABLE("КОМЕНТАРИЙ" text)
    language sql
as
$$
SELECT КОМЕНТАРИЙ FROM  КОМЕНТАРИИ inner JOIN ЗАПИСЬ_НА_ФОРУМЕ on КОМЕНТАРИИ.ЗАПИСЬ_НА_ФОРУМЕ_ИД = ЗАПИСЬ_НА_ФОРУМЕ.ИД WHERE ЗАПИСЬ_НА_ФОРУМЕ.ИД = $1 ;
$$;

alter function coment(integer) owner to s243880;

