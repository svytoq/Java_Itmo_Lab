create function check_machine_application(army_id integer, machine_type integer) returns boolean
    language sql
as
$$
SELECT (t1.army_type=t2.application_area) FROM army as t1, machine_type as t2 WHERE t1.ID = army_id and t2.ID = machine_type;
$$;

alter function check_machine_application(integer, integer) owner to s265106;

