create function process(tbl character varying) returns character varying
    language plpgsql
as
$$
BEGIN
RETURN EXECUTE 'SELECT * FROM ' || tbl;
END
$$;

alter function process(varchar) owner to s243858;

