create function check_recipe() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        IF (calculate_recipe_total_volume(NEW.id_кофе) +
            NEW.количество * (SELECT количество_мл FROM ингредиент WHERE id = NEW.id_ингредиента)) > 400 THEN
            RETURN NULL;
        ELSE
            RETURN NEW;
        END IF;
    ELSIF TG_OP = 'UPDATE' THEN
        IF (calculate_recipe_total_volume(NEW.id_кофе) +
            NEW.количество * (SELECT количество_мл FROM ингредиент WHERE id = NEW.id_ингредиента) -
            OLD.количество * (SELECT количество_мл FROM ингредиент WHERE id = OLD.id_ингредиента)) > 400 THEN
            RETURN NULL;
        ELSE
            RETURN NEW;
        END IF;
    END IF;
END;
$$;

alter function check_recipe() owner to s265082;

