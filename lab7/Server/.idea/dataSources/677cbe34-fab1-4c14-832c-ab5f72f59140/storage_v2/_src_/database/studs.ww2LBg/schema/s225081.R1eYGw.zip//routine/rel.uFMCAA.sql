create function rel() returns trigger
    language plpgsql
as
$$
DECLARE
  sONE  SEX;
  sSEC SEX;
  SOSLH SOSL;
  SOSLW SOSL;
BEGIN
  SELECT ПОЛ
  FROM ЛЮДИ
  WHERE ID_ЧЕЛ = NEW.МУЖ
  INTO STRICT sONE;
  SELECT СОСЛОВИЕ
  FROM ЛЮДИ
  WHERE ID_ЧЕЛ = NEW."МУЖ"
  INTO SOSLH;
  SELECT СОСЛОВИЕ
  FROM ЛЮДИ
  WHERE ID_ЧЕЛ = NEW."ЖЕНА"
  INTO SOSLW;
  SELECT ПОЛ
  FROM ЛЮДИ
  WHERE ID_ЧЕЛ = NEW.ЖЕНА
  INTO STRICT sSEC;
  IF sSEC = sONE
  THEN
    RAISE NOTICE 'СУПРУГИ ДОЛЖНЫ БЫТЬ РАЗНОГО ПОЛА МУЖ (%) ЖЕНА (%)', sONE, sSEC;
    RETURN NULL;
  ELSEIF SOSLH != SOSLW
    THEN
      RAISE NOTICE 'СУПРУГИ ДОЛЖНЫ ПРИНАДЛЕЖАТЬ ОДНОМУ СОСЛОВИЮ МУЖ (%)  ЖЕНА(%)', SOSLH, SOSLW;
      RETURN NULL;
  ELSE RETURN NEW;
  END IF;
END;
$$;

alter function rel() owner to s225081;

