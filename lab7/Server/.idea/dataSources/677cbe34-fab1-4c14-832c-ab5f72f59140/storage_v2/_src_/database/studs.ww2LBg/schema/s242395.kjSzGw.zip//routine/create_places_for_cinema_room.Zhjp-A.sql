create function create_places_for_cinema_room(room_id integer, rows_count integer, column_count integer, base_prise integer) returns void
    language plpgsql
as
$$
BEGIN
        FOR i IN 1 .. rows_count LOOP
                FOR j IN 1 .. column_count LOOP
                        INSERT INTO Места(ид_зала, ряд, место, стоимость)
                         values(room_id, i, j, base_prise);
                END LOOP;
        END LOOP;
END;
$$;

alter function create_places_for_cinema_room(integer, integer, integer, integer) owner to s242395;

