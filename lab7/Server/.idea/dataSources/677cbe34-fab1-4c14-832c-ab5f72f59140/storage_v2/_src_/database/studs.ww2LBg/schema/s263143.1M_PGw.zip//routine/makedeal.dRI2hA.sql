create function makedeal(witchernamein text, questgivername text) returns void
    language plpgsql
as
$$
DECLARE
    witcherCharisma int;
    questgiverCharisma int;
    price int;
    maxprice int;
    finalprice int;
    monster text;
begin
    select charisma into witcherCharisma from witcher where witcher.witchername = witcherNameIn;
    select charisma into questgiverCharisma from questgiver where questgiver.questgiver = questgiverName;
    select startprice into price from questgiver where questgiver.questgiver = questgiverName;
    select money into maxprice from questgiver where questgiver.questgiver = questgiverName;
    select monstername into monster from questgiver where questgiver.questgiver = questgiverName;
    
    if witcherCharisma < questgiverCharisma then finalprice = price;
    end if;
    if witcherCharisma = questgiverCharisma then
        finalprice = price;
        update witcher set charisma = charisma + 1 where witchername = witcherNameIn;
    end if;
    if witcherCharisma > questgiverCharisma then
        finalprice = price * (witcherCharisma/questgiverCharisma);
        if finalprice > maxprice then finalprice = maxprice; end if;
        update witcher set charisma = charisma + 1 where witchername = witcherNameIn;
    end if;

    insert into board values (default, witcherNameIn, monster, finalprice, questgiverName);
end;
$$;

alter function makedeal(text, text) owner to s263143;

