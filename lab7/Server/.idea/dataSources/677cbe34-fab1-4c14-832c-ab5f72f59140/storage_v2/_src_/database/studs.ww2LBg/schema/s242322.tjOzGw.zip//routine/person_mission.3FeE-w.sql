create function person_mission(pass integer, description text) returns void
    language plpgsql
as
$$
declare
        t_id integer;
        r_id integer;
    begin
        if exists(select 1 from ЦЕЛИ where ПЕРСОНА = pass) then
            select ИД into t_id from ЦЕЛИ where ПЕРСОНА = pass;
        else
            insert into ЦЕЛИ values(DEFAULT, pass, NULL) returning ИД into t_id;
        end if;
        if exists(select 1 from find_idle() as Л join ОТДЕЛЫ as О on Л.ОТДЕЛ = О.ИД AND (О.ИД = 2 or О.ПОДЧИНЯЕТСЯ = 2)) then
            select Л.ИД into r_id from 
                find_idle() as Л 
                join ОТДЕЛЫ as О 
                    on Л.ОТДЕЛ = О.ИД AND (О.ИД = 2 or О.ПОДЧИНЯЕТСЯ = 2) 
            order by random() limit 1;
        else select Л.ИД into r_id from 
                ЧЛЕНЫ_ПОЛИЦИИ as Л 
                join ОТДЕЛЫ as О 
                    on Л.ОТДЕЛ = О.ИД AND (О.ИД = 2 or О.ПОДЧИНЯЕТСЯ = 2) 
            order by random() limit 1;
        end if;
        insert into МИССИИ values (DEFAULT, 1, description, 2, 'Создана', t_id, r_id);
    end;
$$;

alter function person_mission(integer, text) owner to s242322;

