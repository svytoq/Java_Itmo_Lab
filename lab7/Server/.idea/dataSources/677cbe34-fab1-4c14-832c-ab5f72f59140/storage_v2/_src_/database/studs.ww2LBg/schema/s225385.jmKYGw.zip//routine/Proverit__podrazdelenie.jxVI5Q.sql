create function "Проверить_подразделение"() returns trigger
    language plpgsql
as
$$
declare
Тип_нового Тип_подразделения;
Тип_родителя Тип_подразделения;
begin
Тип_нового = new.Тип;
select Тип into Тип_родителя from Подразделение where ИД = new.Родительское_подразделение;

if (Тип_нового >= Тип_родителя) then raise notice 'Ошибка в подразделении %. Неверный тип. % не может находиться внутри %.', 
new.ИД, Тип_родителя, Тип_нового;
return null;
end if;
return new;
end
$$;

alter function "Проверить_подразделение"() owner to s225385;

