create function buildbuildingbyfamily(integer, integer) returns void
    language plpgsql
as
$$
DECLARE
    family_id integer;
    family_money integer;
    building_cost integer;
BEGIN
RAISE NOTICE 'Nachal';

select Peasant.family_id into family_id from Peasant where id = $1;
SELECT FamilyInventoryList.amount INTO family_money FROM FamilyInventoryList WHERE F_ID = family_id  AND I_ID = 1;
SELECT building.cost INTO building_cost FROM building WHERE id = $2;

IF family_money > building_cost THEN
family_money := family_money - building_cost;
UPDATE FamilyInventoryList SET amount = family_money WHERE F_ID = family_id  AND I_ID = 1;
    INSERT INTO Villagebuildinglist(V_id, b_id) VALUES( (SELECT Village FROM FAMILY WHERE ID= $1),$2);
    RAISE NOTICE 'Postroil';
ELSE 
RAISE NOTICE 'No money, lox';
END IF;
END
$$;

alter function buildbuildingbyfamily(integer, integer) owner to s265104;

