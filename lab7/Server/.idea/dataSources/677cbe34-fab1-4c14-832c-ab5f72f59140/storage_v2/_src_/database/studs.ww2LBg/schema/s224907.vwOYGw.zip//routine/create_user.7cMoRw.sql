create function create_user(name_in character varying, phone_in character varying, email_in character varying, password_in character varying) returns text
    language plpgsql
as
$$
begin
    insert into account(name, phone, email, password) values (name_in, phone_in, email_in, password_in);
    return 'account created';
end
$$;

alter function create_user(varchar, varchar, varchar, varchar) owner to s224907;

