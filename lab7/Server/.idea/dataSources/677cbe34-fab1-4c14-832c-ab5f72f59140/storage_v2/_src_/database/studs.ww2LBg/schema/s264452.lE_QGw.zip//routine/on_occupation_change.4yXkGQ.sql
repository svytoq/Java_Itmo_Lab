create function on_occupation_change() returns trigger
    language plpgsql
as
$$
begin
    raise notice 'occupation start % , occupation end %', NEW.occupation_start, NEW.occupation_end;
    if NEW.occupation_start < NEW.occupation_end then
        return NEW;
    else
        RAISE EXCEPTION 'occupation start date cant be after the occupation end date';
    end if;

end;
$$;

alter function on_occupation_change() owner to s264452;

