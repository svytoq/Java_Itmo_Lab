create function get_service_suggestions_in_dormitory(dormitory_id integer)
    returns TABLE(suggestion_id integer, suggestion_name character varying, suggestion_description character varying, status s265090."STATUS", creation_date timestamp with time zone, author integer, service_id integer, service_name character varying, service_description character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT 
    SUGGESTION.ID as SUGGESTION_ID, SUGGESTION.NAME as SUGGESTION_NAME, SUGGESTION.DESCRIPTION as SUGGESTION_DESCRIPTION, SUGGESTION.STATUS, SUGGESTION.CREATION_DATE, 
SUGGESTION.AUTHOR, SERVICE.ID as SERVICE_ID, SERVICE.NAME as SERVICE_NAME, SERVICE.DESCRIPTION as SERVICE_DESCRIPTION
    FROM "USER"
JOIN DORMITORY ON "USER".DORMITORY = DORMITORY.ID
JOIN SUGGESTION ON SUGGESTION.AUTHOR = "USER".ID
JOIN SERVICE_SUGGESTION ON SERVICE_SUGGESTION.SUGGESTION = SUGGESTION.ID
JOIN SERVICE ON SERVICE_SUGGESTION.SERVICE = SERVICE.ID WHERE DORMITORY.ID = DORMITORY_ID;
END;
$$;

alter function get_service_suggestions_in_dormitory(integer) owner to s265090;

