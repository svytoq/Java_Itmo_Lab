create function check_day_d() returns trigger
    language plpgsql
as
$$
BEGIN 
IF (select ДАТА_РОЖДЕНИЯ FROM РЕЖИССЕР JOIN (СЦЕНАРИЙ JOIN ФИЛЬМ ON (СЦЕНАРИЙ.ИД_Ф= ФИЛЬМ.ИД)) ON (РЕЖИССЕР.ИД=СЦЕНАРИЙ.ИД_Р) WHERE РЕЖИССЕР.ИД = NEW.ИД ) != (select ФИЛЬМ.ГОД FROM РЕЖИССЕР JOIN (СЦЕНАРИЙ JOIN ФИЛЬМ ON (СЦЕНАРИЙ.ИД_Ф= ФИЛЬМ.ИД)) ON (РЕЖИССЕР.ИД=СЦЕНАРИЙ.ИД_Р) WHERE РЕЖИССЕР.ИД = NEW.ИД ) THEN 
RETURN NEW; 
ELSE 
RETURN NULL; 
END IF; 
END;
$$;

alter function check_day_d() owner to s243886;

