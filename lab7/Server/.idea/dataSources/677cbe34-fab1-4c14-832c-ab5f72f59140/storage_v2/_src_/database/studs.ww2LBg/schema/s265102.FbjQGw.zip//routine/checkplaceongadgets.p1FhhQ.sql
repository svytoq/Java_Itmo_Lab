create function checkplaceongadgets(x numeric, y numeric, z numeric, OUT "Модель" character varying, OUT "Тип" character varying, OUT "Частота" numeric) returns record
    language sql
as
$$
select Модель, Тип, Частота from Устройства_передатчики where Место_установки in (select "Место_установки"."ID_места" from Место_установки where "X"=x and "Y"=y and "Z"=z);
$$;

alter function checkplaceongadgets(numeric, numeric, numeric, out varchar, out varchar, out numeric) owner to s265102;

