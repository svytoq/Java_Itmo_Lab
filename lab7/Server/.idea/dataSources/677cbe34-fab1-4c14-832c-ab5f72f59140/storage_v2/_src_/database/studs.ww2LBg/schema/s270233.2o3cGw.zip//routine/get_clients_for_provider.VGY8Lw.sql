create function get_clients_for_provider(provider_id integer)
    returns TABLE(name character varying, surname character varying)
    language sql
as
$$
SELECT humans.name, humans.surname
FROM humans
WHERE (humans.id IN (SELECT clients.human_id
                     FROM clients
                     WHERE (clients.delivery_place_id =
                            (SELECT p.delivery_place_id FROM providers AS p WHERE (p.id = $1)))));
$$;

alter function get_clients_for_provider(integer) owner to s270233;

