create function get_result_student(stdid bigint)
    returns TABLE(name character varying, surname character varying, event_name character varying, subject_name character varying, result double precision)
    language plpgsql
as
$$
begin
    return query select s.name, s.surname, e.name, s2.name, r.points
                 from result r
                          join student s on (s.id = r.stud_id and s.id = stdId)
                          join event e on e.id = r.ev_id
                          join event_subjects es on r.ev_id = es.ev_id
                          join subject s2 on s2.id = es.subj_id;

end;
$$;

alter function get_result_student(bigint) owner to s263975;

