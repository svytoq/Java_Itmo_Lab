create function hero_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE 
N alias for $1; 
rand INTEGER; 
length integer; 
i INTEGER DEFAULT 1; 
count integer default 0; 
chars text[] := '{a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z}'; 
name text := ''; 
sex text := ''; 

BEGIN 
for i in 1..N loop 

rand := random(); 
length:=random() * 1 + 13; 

while count<length or name=null loop 
name := name || chars[1+random()*(array_length(chars, 1)-1)]; 
if(length > 13)THEN 
sex := 'мужчина'; 
else sex:='женщина'; 
end if; 
count:=count+1; 
end loop; 

insert into "Герой" values(initcap(name), initcap(sex), (SELECT Название FROM "Фракция" ORDER BY random() LIMIT 1)); 
name := ''; 
sex:= ''; 
count:=0; 

end loop; 

END;
$$;

alter function hero_inserter(integer) owner to s225133;

