create function show_table_info(table_name text, schema_name text) returns void
    language plpgsql
as
$$
declare
    column_inf record;
    not_null_text text;
begin
    if table_name is null or schema_name is null then
        raise info 'Имя таблицы или название схемы не задано';
    else
        raise info 'Таблица: %', table_name;
        raise info 'No. Имя столбца         Атрибуты';
        raise info ' --- ----------------- ------------------------------------------------------';
        for column_inf in
            select pa.attnum, pa.attname, pt.typname, pa.atttypmod, pa.attnotnull, pd.description, p.conname
            from pg_attribute pa
                     join pg_class pc on pc.oid = pa.attrelid
                     left join pg_type pt on pa.atttypid = pt.oid
                     left join pg_description pd on pa.attnum = pd.objsubid and pd.objoid = pc.oid
                     left join pg_constraint p on p.conrelid = pc.oid and p.contype = 'p' and pa.attnum = any (p.conkey)
            where attrelid = (
                select oid from pg_class where relname = table_name and relnamespace = (
                    select oid from pg_namespace where nspname = schema_name
                )
            ) and attnum > 0
            order by attnum loop
                if (column_inf.attnotnull) then
                    not_null_text = 'NOT NULL';
                else not_null_text = '';
                end if;
--
                if column_inf.atttypmod < 0 then
                    raise info '% % Type: % %', rpad(column_inf.attnum::text, 3, ' '), rpad(column_inf.attname, 17, ' '),
                        column_inf.typname, not_null_text;
                else
                    raise info '% % Type: % (%) %', rpad(column_inf.attnum::text, 3, ' '), rpad(column_inf.attname, 17, ' '),
                        column_inf.typname, column_inf.atttypmod - 4, not_null_text;
                end if;
                if (column_inf.description is not null) then
                    raise info '%', lpad('Comment: ', 31, E'\u00A0') || column_inf.description;
                end if;
                if (column_inf.conname is not null) then
                    raise info '%', lpad('Constraint: ', 34, E'\u00A0') || column_inf.conname || ' Primary key';
                end if;
            end loop;
    end if;
end
$$;

alter function show_table_info(text, text) owner to s274007;

