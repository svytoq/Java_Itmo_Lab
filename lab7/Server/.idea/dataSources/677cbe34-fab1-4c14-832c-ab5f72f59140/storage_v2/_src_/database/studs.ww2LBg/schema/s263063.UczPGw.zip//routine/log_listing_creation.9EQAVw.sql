create function log_listing_creation() returns trigger
    language plpgsql
as
$$
begin
    if new.author_id is null then
        insert into listing_history (seller, action, clan_id, listing_id)
        values (new.seller, 'Created', new.clan_id, new.listing_id);
    end if;
    if new.clan_id is null then
        insert into listing_history (seller, action, author_id, listing_id)
        values (new.seller, 'Created', new.author_id, new.listing_id);
    end if;
    return new;
end;
$$;

alter function log_listing_creation() owner to s263063;

