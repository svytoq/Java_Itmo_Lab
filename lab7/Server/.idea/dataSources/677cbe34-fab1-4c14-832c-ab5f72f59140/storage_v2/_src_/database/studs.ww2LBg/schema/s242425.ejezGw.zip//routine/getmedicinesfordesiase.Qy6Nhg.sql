create function getmedicinesfordesiase(id integer)
    returns TABLE(id_medicine integer, name text, efficiency double precision)
    language sql
as
$$
select ЛЕКАРСТВО.ИД_ЛЕКАРСТВА,
        ЛЕКАРСТВО.НАЗВАНИЕ,
        ЭФФЕКТИВНОСТЬ_ЛЕКАРСТВА.ЭФФЕКТИВНОСТЬ
    from ЭФФЕКТИВНОСТЬ_ЛЕКАРСТВА
        join БОЛЕЗНЬ using(ИД_БОЛЕЗНИ)
        join ЛЕКАРСТВО using(ИД_ЛЕКАРСТВА)
    where ЭФФЕКТИВНОСТЬ_ЛЕКАРСТВА.ЭФФЕКТИВНОСТЬ > 0.4
        and БОЛЕЗНЬ.ИД_БОЛЕЗНИ=id;
$$;

alter function getmedicinesfordesiase(integer) owner to s242425;

