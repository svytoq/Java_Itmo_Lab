create function _show_hero_fights_(integer) returns void
    language plpgsql
as
$$
DECLARE
  hero alias for $1;
  count INTEGER;
BEGIN
SELECT id FROM "Битва" WHERE id_победителя=hero;
END;
$$;

alter function _show_hero_fights_(integer) owner to s225133;

