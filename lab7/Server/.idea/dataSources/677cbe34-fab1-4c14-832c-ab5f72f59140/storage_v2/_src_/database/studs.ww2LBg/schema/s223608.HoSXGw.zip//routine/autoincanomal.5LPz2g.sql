create function autoincanomal() returns trigger
    language plpgsql
as
$$
BEGIN
     NEW.Код := nextval('IdAnomalSequence');
   Return NEW;
 END;
$$;

alter function autoincanomal() owner to s223608;

