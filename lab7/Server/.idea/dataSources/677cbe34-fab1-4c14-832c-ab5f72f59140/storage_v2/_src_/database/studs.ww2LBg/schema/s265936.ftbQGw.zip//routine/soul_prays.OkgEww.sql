create function soul_prays(n_id integer) returns integer
    language plpgsql
as
$$
declare
    pray_sum int;
begin
    pray_sum = (select count(*) from pray join remorse r on pray.id = r.pray_id
    join soul s on r.soul_id = s.id where s.id = n_id);
    return pray_sum;
end;
$$;

alter function soul_prays(integer) owner to s265936;

