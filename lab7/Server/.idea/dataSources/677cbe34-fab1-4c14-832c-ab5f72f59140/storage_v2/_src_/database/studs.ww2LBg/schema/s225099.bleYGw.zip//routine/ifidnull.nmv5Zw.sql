create function ifidnull() returns trigger
    language plpgsql
as
$$
DECLARE
  max INTEGER;
  i INTEGER;
  temp INTEGER;
  counter INTEGER;
  newid INTEGER;
BEGIN
  max:=0;
  EXECUTE 'SELECT MAX(id) FROM "'||tg_table_name||'";' INTO temp;
  if (NEW.id is NOT NULL) THEN
    EXECUTE 'SELECT id FROM "'||tg_table_name||'" WHERE id='||NEW.id||';' INTO counter;
  END IF;
  If (temp is NOT NULL) THEN
    max:=temp;
  END IF;
  if (NEW.id is NULL OR (counter) IS NOT NULL ) THEN
    FOR i IN 1..max+1 LOOP
      EXECUTE 'SELECT id from "'|| tg_table_name||'" where id=' ||i||';'INTO newid;
      if (newid) IS NULL THEN
        if(counter) IS NOT NULL THEN
          RAISE NOTICE 'Этот id занят, но мы подобрали тебе пустой newid = %',i;
        END IF;
        NEW.id=i;
        RETURN new;
      END IF;
    END LOOP;
    RETURN new;
  end if;

  RETURN new;
END;
$$;

alter function ifidnull() owner to s225099;

