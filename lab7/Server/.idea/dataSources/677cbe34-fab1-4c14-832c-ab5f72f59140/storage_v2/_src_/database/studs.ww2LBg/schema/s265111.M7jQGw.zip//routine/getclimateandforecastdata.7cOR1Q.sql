create function getclimateandforecastdata(observatory_name character varying, startts timestamp without time zone, endts timestamp without time zone)
    returns TABLE(film_title s265111.astroclimate, film_release_year s265111.forecast)
    language plpgsql
as
$$
BEGIN
    return query
    select * from astroclimate;
END;
$$;

alter function getclimateandforecastdata(varchar, timestamp, timestamp) owner to s265111;

