create function registration(tic_id integer, reg boolean) returns void
    language plpgsql
as
$$
begin
update  ticket set registered=reg where id=tic_id;
end;
$$;

alter function registration(integer, boolean) owner to s265061;

