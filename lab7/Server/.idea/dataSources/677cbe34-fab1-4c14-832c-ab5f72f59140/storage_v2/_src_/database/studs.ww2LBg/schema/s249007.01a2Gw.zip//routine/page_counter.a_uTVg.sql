create function page_counter() returns trigger
    language plpgsql
as
$$
declare counter integer;
begin
  if (tg_op = 'INSERT') then
    new.count_of_entries = 0;
    select into counter count(*) from page where note_id = new.note_id;
    update note set count_of_pages = counter where id = new.note_id;
    return new;
  end if ;
  if (tg_op = 'DELETE') then
    select into counter count(*) from page where note_id = old.note_id;
    update note set count_of_pages = counter where id = old.note_id;
    return old;
  end if;
  if (tg_op = 'UPDATE') then
    if((old.note_id != new.note_id) or (old.number_of_page != new.number_of_page)) then
    raise exception 'You can not change page specifications';
    return old;
    end if;
    return new;
  end if;
  return null;
end;
$$;

alter function page_counter() owner to s249007;

