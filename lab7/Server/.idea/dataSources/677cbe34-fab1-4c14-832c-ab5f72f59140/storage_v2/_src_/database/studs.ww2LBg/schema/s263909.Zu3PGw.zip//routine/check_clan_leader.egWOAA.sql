create function check_clan_leader() returns trigger
    language plpgsql
as
$$
declare
    new_guy integer;
begin
    if (check_clan(new.ninja_id, old.clan_id)) then
        new_guy = (select status from ninja where ninja.ninja_id = new.ninja_id);
        if (new_guy = 'dead') then
            raise exception 'He is DEAD!!!';
        end if;
    else
        raise exception 'new leader of clan not a clan member';
    end if;
    return new;
end;
$$;

alter function check_clan_leader() owner to s263909;

