create function "ИД_ПО_ИМЕНИ"(name character varying, surname character varying, patr character varying) returns smallint
    language sql
as
$$
SELECT "ЛЮДИ"."ИД_ЧЕЛОВЕК" FROM "ЛЮДИ" WHERE ("ЛЮДИ"."ИМЯ" = name AND "ЛЮДИ"."ФАМИЛИЯ" = surname AND "ЛЮДИ"."ОТЧЕСТВО" = patr);
$$;

alter function "ИД_ПО_ИМЕНИ"(varchar, varchar, varchar) owner to s225071;

