create function rev() returns void
    language sql
as
$$
    CREATE TABLE типы_стадий
(
    ид integer CONSTRAINT pos_id CHECK (ид>0) PRIMARY KEY,
    название varchar(100) NOT NULL UNIQUE
);
COMMENT ON TABLE типы_стадий IS 'Перечень различных типов стадий, происходящий в рамках одного игрового сезона';

CREATE TABLE награды
(
    ид serial PRIMARY KEY,
    название varchar(100) NOT NULL UNIQUE
);
COMMENT ON TABLE награды IS 'Перечень существующих индивидуальных наград';

CREATE TABLE сезоны
(
    ид serial PRIMARY KEY,
    начало date NOT NULL UNIQUE,
    конец date UNIQUE
);
COMMENT ON TABLE сезоны IS 'Список игровых сезонов с их названиями, а также датами начала и конца';
COMMENT ON COLUMN сезоны.начало IS 'Дата начала сезона должна быть уникальной, т.к. несколько сезонов не могут начаться в один день, а также быть меньше даты окончания сезона. Обязательное поле';
COMMENT ON COLUMN сезоны.конец IS 'Дата конца сезона должна быть уникальной, т.к. несколько сезонов не могут закончиться в один день, а также быть больше даты окончания сезона. Может быть неизвестна';


CREATE TABLE стадии
(
    ид serial PRIMARY KEY,
    сезон_ид integer NOT NULL REFERENCES сезоны(ид) ON UPDATE CASCADE,
    типс_ид integer NOT NULL REFERENCES типы_стадий(ид) ON UPDATE CASCADE,
    начало date UNIQUE,
    конец date UNIQUE
);
COMMENT ON TABLE стадии IS 'Список стадий игровых сезонов, обладающих уникальным номером, с указанием их типа (регулярная, плей-офф), а также датами начала и конца';
COMMENT ON COLUMN стадии.сезон_ид IS 'Сезон, в рамках которого проходит стадия. Обязательное поле';
COMMENT ON COLUMN стадии.типс_ид IS 'Тип стадии (регулярная, плей-офф). Обязательное поле';
COMMENT ON COLUMN стадии.начало IS 'Дата начала стадии должна быть уникальной, т.к. несколько стадий не могут начаться в один день, а также быть меньше даты окончания стадии. Может быть неизвестна';
COMMENT ON COLUMN стадии.конец IS 'Дата конца стадии должна быть уникальной, т.к. несколько стадий не могут закончиться в один день, а также быть больше даты окончания стадии. Может быть неизвестна';

CREATE TABLE страны
(
    ид serial PRIMARY KEY,
    название varchar(100) NOT NULL UNIQUE 
);
COMMENT ON TABLE страны IS 'Список известных стран с их уникальными номерами';

CREATE TABLE люди
(
    ид serial PRIMARY KEY,
    имя varchar(100) NOT NULL,
    стрн_ид integer REFERENCES страны(ид) ON DELETE SET NULL ON UPDATE CASCADE,
    дата_рожд date,
    рост integer CONSTRAINT heigth_value CHECK (рост BETWEEN 40 AND 272),
    вес integer CONSTRAINT weigth_value CHECK (вес BETWEEN 3 AND 635)
);
COMMENT ON TABLE люди IS 'Список людей, в котором хранятся сведения о их уникальном номере, имени, гражданстве, дате рождения, росте и весе';
COMMENT ON COLUMN люди.имя IS 'Информация об имени обязательна при добавлении нового человека в систему';
COMMENT ON COLUMN люди.стрн_ид IS 'Уникальный номер страны, гражданство которой имеет человек. Необязательное поле';
COMMENT ON COLUMN люди.дата_рожд IS 'Дата рождения человека. Необязательное поле';
COMMENT ON COLUMN люди.рост IS 'Рост человека. Должен быть в пределах от 40 до 272. Измеряется в сантиметрах. Необязательное поле';
COMMENT ON COLUMN люди.вес IS 'Вес человека. Должен быть в пределах от 3 до 635. Измеряется в килограммах. Необязательное поле';

CREATE TABLE награждения
(
    сезон_ид integer NOT NULL REFERENCES сезоны(ид) ON UPDATE CASCADE,
    нагр_ид integer NOT NULL REFERENCES награды(ид) ON UPDATE CASCADE,
    члвк_ид integer REFERENCES люди(ид) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT награждения_PK PRIMARY KEY (сезон_ид, нагр_ид)
);
COMMENT ON TABLE награждения IS 'Список людей, получивших какую-либо награду в определенном сезоне. Победитель определяется путем голосования (см. табл. "голосование")';
COMMENT ON COLUMN награждения.сезон_ид IS 'Сезон, в котором проходило голосование, по результату которого была вручена награда. Обязательное поле';
COMMENT ON COLUMN награждения.нагр_ид IS 'Награда, врученная победителю голосования. Обязательное поле';
COMMENT ON COLUMN награждения.члвк_ид IS 'Человек, выигравший данную награду в данном сезоне. Обязательное поле';

CREATE TABLE типы_матчей(
ид integer CONSTRAINT pos_id CHECK (ид>0) PRIMARY KEY,
название varchar(100) NOT NULL UNIQUE
);
COMMENT ON TABLE типы_матчей IS 'Перечень различных типов матчей. Например "финал" или "четверть-финал"';

CREATE TABLE конференции
(
    ид integer CONSTRAINT pos_id CHECK (ид>0) PRIMARY KEY,
    название varchar(100) NOT NULL UNIQUE
);
COMMENT ON TABLE конференции IS 'Перечень существующих конференций';

CREATE TABLE города
(
    ид serial PRIMARY KEY,
    название varchar(100) NOT NULL,
    стрн_ид integer NOT NULL REFERENCES страны(ид) ON UPDATE CASCADE
);
COMMENT ON TABLE города IS 'Список известных городов, с указанием их уникального номеров и стран, к которым они принадлежат. В пределах одной страны не может быть несколько городов с одинаковыми названиями';
COMMENT ON COLUMN города.название IS 'Название города. Обязательное поле';
COMMENT ON COLUMN города.стрн_ид IS 'Уникальный номер страны, которой принадлежит город. Обязательное поле';

CREATE TABLE позиции
(
    ид integer CONSTRAINT pos_id CHECK (ид>0) PRIMARY KEY,
    короткое_название varchar(10) UNIQUE,
    название varchar(100) NOT NULL UNIQUE
);
COMMENT ON TABLE позиции IS 'Список позиций в баскетболе, содержащий короткие и полные названия соответствующих позиций';
COMMENT ON COLUMN позиции.короткое_название IS 'Короткое название баскетбольной позиции. Может отсутствовать, но обязано быть уникальным';
COMMENT ON COLUMN позиции.название IS 'Полное название баскетбольной позиции. Обязательное поле, должно быть уникальным';

CREATE TABLE дивизионы 
(
    ид integer CONSTRAINT pos_id CHECK (ид>0) PRIMARY KEY,
    название varchar(100) NOT NULL UNIQUE, 
    конф_ид integer NOT NULL REFERENCES конференции(ид) ON UPDATE CASCADE
);
COMMENT ON TABLE дивизионы IS 'Список существующих дивизионов, принадлежащих к какой-либо конференции';
COMMENT ON COLUMN дивизионы.название IS 'Название дивизиона. Должно быть уникальным. Обязательное поле';
COMMENT ON COLUMN дивизионы.конф_ид IS 'Уникальный номер конференции к которой принадлежит дивизион. Обязательное поле';

CREATE TABLE арены
(
    ид serial PRIMARY KEY,
    название varchar(100) NOT NULL UNIQUE,
    гор_ид integer NOT NULL REFERENCES города(ид),
    постройка date,
    вместимость integer CONSTRAINT pos_cap CHECK (вместимость>0)
);
COMMENT ON TABLE арены IS 'Список баскетбольных арен. Каждая арена обладает уникальным номером. Также список содержит информацию о местрорасположении, дате постройки и вместимости';
COMMENT ON COLUMN арены.название IS 'Название баскетбольной арены. Должно быть уникальным. Обязательное поле';
COMMENT ON COLUMN арены.гор_ид IS 'Уникальный номер города, в котором расположена арена. Обязательное поле';
COMMENT ON COLUMN арены.постройка IS 'Дата постройки арены. Может быть неизвестна';
COMMENT ON COLUMN арены.вместимость IS 'Вместимость арены. Должна быть положительной. Может быть неизвестна';

CREATE TABLE команды
(
    ид serial PRIMARY KEY,
    название varchar(100) NOT NULL UNIQUE,
    див_ид integer NOT NULL REFERENCES дивизионы(ид) ON UPDATE CASCADE,
    гор_ид integer NOT NULL REFERENCES города(ид) ON UPDATE CASCADE,
    арена_ид integer NOT NULL REFERENCES арены(ид) ON UPDATE CASCADE,
    основание date,
    вступление_в_нба date
);
COMMENT ON TABLE команды IS 'Список команд-участниц лиги. Каждая команда обладает своим уникальным номером, названием, представляет какой-либо дивизион, базируется в каком-либо городе и имеет собственную арену(либо делит ее с другой командой). Также в списке хранится информация о дате основания команды и ее вступления в НБА';
COMMENT ON COLUMN команды.название IS 'Уникальное название команды. Обязательное поле';
COMMENT ON COLUMN команды.див_ид IS 'Номер дивизиона, представляющегося командой. Обязательное поле';
COMMENT ON COLUMN команды.гор_ид IS 'Номер города, в котором базируется команда. Обязательное поле';
COMMENT ON COLUMN команды.арена_ид IS 'Номер арены команды. Обязательное поле';
COMMENT ON COLUMN команды.основание IS 'Дата основания команды. Необязательное поле';
COMMENT ON COLUMN команды.вступление_в_нба IS 'Дата вступления команды в НБА. Необязательное поле';

CREATE TABLE роли
(
    ид integer CONSTRAINT pos_id CHECK (ид>0) PRIMARY KEY,
    название varchar(100) NOT NULL UNIQUE
);
COMMENT ON TABLE роли IS 'Перечень ролей в команде, например "главный тренер" или "игрок"';

CREATE TABLE участники
(
    члвк_ид integer NOT NULL REFERENCES люди(ид) ON UPDATE CASCADE,
    кмнд_ид integer NOT NULL REFERENCES команды(ид) ON UPDATE CASCADE,
    роль_ид integer NOT NULL REFERENCES роли(ид) ON UPDATE CASCADE,
    поз_ид integer REFERENCES позиции(ид) ON UPDATE CASCADE,
    номер integer CONSTRAINT player_number CHECK (номер BETWEEN 0 AND 99),
    начало date NOT NULL,
    конец date NOT NULL DEFAULT '9999-09-09',
    CONSTRAINT участники_PK PRIMARY KEY (члвк_ид, кмнд_ид, роль_ид)
);
COMMENT ON TABLE участники IS 'Список членов команд (как игроков, так и представителей администрации)';
COMMENT ON COLUMN участники.члвк_ид IS 'Уникальный номер человека. Обязательное поле';
COMMENT ON COLUMN участники.кмнд_ид IS 'Уникальный номер команды. Обязательное поле';
COMMENT ON COLUMN участники.роль_ид IS 'Уникальный номер роли, которую человек исполняет в команде. Обязательное поле';
COMMENT ON COLUMN участники.поз_ид IS 'Уникальный номер баскетбольной позиции игрока. Обязательное поле для игроков в составе команды';
COMMENT ON COLUMN участники.члвк_ид IS 'Игровой номер игрока команды. Обязательное поле для игроков в составе команды';
COMMENT ON COLUMN участники.начало IS 'Официальная дата начала исполнения обязанностей члена команды. Обязательное поле';
COMMENT ON COLUMN участники.конец IS 'Официальная дата прекращения исполнения обязанностей члена команды. Обязательное поле. По умолчанию выставляется значение равное "9999-09-09", что означает, что человек в данный момент занимает конкретную должность';

CREATE TABLE статистика
(
    стад_ид integer NOT NULL REFERENCES стадии(ид) ON UPDATE CASCADE,
    кмнд_ид integer NOT NULL REFERENCES команды(ид) ON UPDATE CASCADE,
    побед integer NOT NULL DEFAULT 0 CONSTRAINT nneg_win CHECK (побед>=0),
    поражений integer NOT NULL DEFAULT 0 CONSTRAINT nneg_los CHECK (поражений>=0),
    CONSTRAINT статистика_PK PRIMARY KEY (стад_ид, кмнд_ид)
);
COMMENT ON TABLE статистика IS 'Статистика команд в различных стадиях';
COMMENT ON COLUMN статистика.стад_ид IS 'Номер стадии, в рамках которой происходит сбор статистики команды. Обязательное поле';
COMMENT ON COLUMN статистика.кмнд_ид IS 'Номер команды. Обязательное поле';
COMMENT ON COLUMN статистика.побед IS 'Количество побед команды в указанной стадии. По умолчанию равно 0, не может принимать отрицательных значений. Обязательное поле';
COMMENT ON COLUMN статистика.поражений IS 'Количество побед команды в указанной стадии. По умолчанию равно 0, не может принимать отрицательных значений. Обязательное поле';

CREATE TABLE матчи
(
    ид serial PRIMARY KEY,
    типм_ид integer NOT NULL REFERENCES типы_матчей(ид) ON UPDATE CASCADE,
    арена_ид integer NOT NULL REFERENCES арены(ид) ON UPDATE CASCADE,
    поб_ид integer NOT NULL REFERENCES команды(ид) ON UPDATE CASCADE,
    про_ид integer NOT NULL REFERENCES команды(ид) ON UPDATE CASCADE,
    дата date NOT NULL 
);
COMMENT ON TABLE матчи IS 'Список всех завершенных матчей с указанием типа, места проведения а также даты'; 
COMMENT ON COLUMN матчи.типм_ид IS 'Номер типа матча. Обязательное поле';
COMMENT ON COLUMN матчи.арена_ид IS 'Номер арены, на которой происходил матч. Обязательное поле';
COMMENT ON COLUMN матчи.поб_ид IS 'Команда-победитель. Обязательное поле';
COMMENT ON COLUMN матчи.про_ид IS 'Команда-проигравший. Обязательное поле';
COMMENT ON COLUMN матчи.дата IS 'Дата проведения матча. Обязательное поле';

CREATE TABLE голосование
(
    сезон_ид integer NOT NULL REFERENCES сезоны(ид) ON UPDATE CASCADE,
    члвк_ид integer NOT NULL REFERENCES люди(ид) ON UPDATE CASCADE,
    нагр_ид integer NOT NULL REFERENCES награды(ид) ON UPDATE CASCADE,
    игрок_ид integer NOT NULL REFERENCES люди(ид) ON UPDATE CASCADE,
    CONSTRAINT голосование_PK PRIMARY KEY (сезон_ид, члвк_ид, нагр_ид)
);
COMMENT ON TABLE голосование IS 'Список голосов людей в рамках голосования за игрока, который должен выиграть какую-либо индивидуальную награду в рамках конкретного сезона';
COMMENT ON COLUMN голосование.сезон_ид IS 'Сезон, в рамках которого происходит голосование. Голосовать можно только в рамках еще не завершившегося сезона. Обязательное поле';
COMMENT ON COLUMN голосование.члвк_ид IS 'Номер человека, отдающего свой голос за победу того или иного игрока в рамках какой-либо номинации. Обязательное поле';
COMMENT ON COLUMN голосование.нагр_ид IS 'Номер награды, за присуждение которой какому-либо игрок отдается голос. Обязательное поле';
COMMENT ON COLUMN голосование.игрок_ид IS 'Номер игрока, который заслуживает данной награды в текущем сезоне по мнению голосовавшего. Обязательное поле';
    $$;

alter function rev() owner to s242558;

