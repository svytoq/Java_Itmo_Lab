create function slay_monster(id integer, s_id integer) returns integer
    language plpgsql
as
$$
DECLARE
quality INTEGER = 2;
strength INTEGER;
str_b INTEGER;
experience INTEGER;
stamina INTEGER;
sta_b INTEGER;
agility INTEGER;
agi_b INTEGER;
name CHAR(100);
lvl INTEGER;
amount INTEGER;
h_h INTEGER;
begin
SELECT INTO h_h h_h_id from stream where stream_id = s_id ;
SELECT INTO name type FROM monster where monster_id = id;
SELECT INTO lvl lev FROM monster where monster_id = id;
SELECT INTO amount COUNT(witcher_id) from witcher where stream_id = s_id and role = 'witcher';
if (name = 'forktail')
THEN
SELECT INTO strength sum(sw.lev) from skill_witcher as sw join witcher as w on sw.witcher_id = w.witcher_id where ( skill_id = 1 and w.stream_id = s_id and w.role = 'witcher') ;
SELECT INTO stamina sum(sw.lev) from skill_witcher as sw join witcher as w on sw.witcher_id = w.witcher_id where ( skill_id = 3 and w.stream_id = s_id and w.role = 'witcher') ;
SELECT INTO str_b sum(s.strength_b) from witcher as w join role as r on w.role_id = r.role_id join sword as s on r.sil_sword = s.sword_id WHERE (w.stream_id = s_id and w.role = 'witcher');
SELECT INTO sta_b sum(s.stamina_b) from witcher as w join role as r on w.role_id = r.role_id join sword as s on r.sil_sword = s.sword_id WHERE (w.stream_id = s_id and w.role = 'witcher');
 
 quality = ((strength + stamina + (str_b  + sta_b)/ 29 * 14)*10/ 4 / amount / 14- lvl/3) * 10;
 
end if;

if (name = 'manticore')
THEN
SELECT INTO strength sum(sw.lev) from skill_witcher as sw join witcher as w on sw.witcher_id = w.witcher_id where ( skill_id = 1 and w.stream_id = s_id and w.role = 'witcher') ;
SELECT INTO experience sum(sw.lev) from skill_witcher as sw join witcher as w on sw.witcher_id = w.witcher_id where ( skill_id = 6 and w.stream_id = s_id and w.role = 'witcher') ;
SELECT INTO str_b sum(s.strength_b) from witcher as w join role as r on w.role_id = r.role_id join sword as s on r.sil_sword = s.sword_id WHERE (w.stream_id = s_id and w.role = 'witcher');

 quality = ((strength + experience + str_b / 29 * 14)*10 / 3 / amount / 14 - lvl/3)* 10;
end if;

if (name = 'bruxa')
THEN
SELECT INTO agility sum(sw.lev) from skill_witcher as sw join witcher as w on sw.witcher_id = w.witcher_id where ( skill_id = 2 and w.stream_id = s_id and w.role = 'witcher') ;
SELECT INTO experience sum(sw.lev) from skill_witcher as sw join witcher as w on sw.witcher_id = w.witcher_id where ( skill_id = 6 and w.stream_id = s_id and w.role = 'witcher') ;
SELECT INTO agi_b sum(s.agility_b) from witcher as w join role as r on w.role_id = r.role_id join sword as s on r.sil_sword = s.sword_id WHERE (w.stream_id = s_id and w.role = 'witcher');

 quality = ((agility + experience + (agi_b / 29 * 14))*10/ 3 / amount / 14- lvl/3) * 10;

end if;

if (quality > 100)
THEN
quality = 100;
end IF;
 INSERT INTO ingridient VALUES
 (DEFAULT, h_h, name, quality);
 
 RETURN 0;
 end
$$;

alter function slay_monster(integer, integer) owner to s268428;

