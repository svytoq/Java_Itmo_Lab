create function add_simulation_settings(new_settings_key text, new_settings_value text) returns integer
    language plpgsql
as
$$
DECLARE
new_id int = null;
BEGIN
insert into simulation_settings(settings_key, settings_value) values (new_settings_key, new_settings_value) returning id into new_id;
return new_id;
exception when unique_violation then
return (select id from simulation_settings where settings_key like new_settings_key limit 1);
END;
$$;

alter function add_simulation_settings(text, text) owner to s264450;

