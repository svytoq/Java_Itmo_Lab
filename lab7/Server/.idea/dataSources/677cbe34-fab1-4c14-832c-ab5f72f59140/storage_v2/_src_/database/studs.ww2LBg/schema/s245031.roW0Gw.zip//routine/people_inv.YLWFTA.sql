create function people_inv() returns trigger
    language plpgsql
as
$$
begin
update Характеристики
set СИЛ=СИЛ-coalesce(Эффекты.СИЛ_бнс, 0), 
ВСП=ВСП-coalesce(Эффекты.ВСП_бнс, 0), 
ВНС=ВНС-coalesce(Эффекты.ВНС_бнс, 0), 
ИНТ=ИНТ-coalesce(Эффекты.ИНТ_бнс, 0), 
ХАР=ХАР-coalesce(Эффекты.ХАР_бнс, 0), 
ЛВК=ЛВК-coalesce(Эффекты.ЛВК_бнс, 0), 
УДЧ=УДЧ-coalesce(Эффекты.УДЧ_бнс, 0),
Базовая_защита=Базовая_защита-Броня.защита
from  Люди
left join Инвентарь
on Инвентарь.id=old.Инвентарь
left join Броня
on Броня.id=Инвентарь.носимая_броня
left join Эффекты
on Броня.эффект=Эффекты.id 
where Характеристики.id in (
select Люди.Характеристики from Люди
where old.id=Люди.Инвентарь);

update Характеристики
set СИЛ=СИЛ+coalesce(Эффекты.СИЛ_бнс, 0), 
ВСП=ВСП+coalesce(Эффекты.ВСП_бнс, 0), 
ВНС=ВНС+coalesce(Эффекты.ВНС_бнс, 0), 
ИНТ=ИНТ+coalesce(Эффекты.ИНТ_бнс, 0), 
ХАР=ХАР+coalesce(Эффекты.ХАР_бнс, 0), 
ЛВК=ЛВК+coalesce(Эффекты.ЛВК_бнс, 0), 
УДЧ=УДЧ+coalesce(Эффекты.УДЧ_бнс, 0),
Базовая_защита=Базовая_защита-Броня.защита
from  Люди
left join Инвентарь
on Инвентарь.id=old.Инвентарь
left join Броня
on Броня.id=Инвентарь.носимая_броня
left join Эффекты
on Броня.эффект=Эффекты.id
where Характеристики.id in (
select Люди.Характеристики from Люди
where new.id=Люди.Инвентарь);
return new;
end;
$$;

alter function people_inv() owner to s245031;

