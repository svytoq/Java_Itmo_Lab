create function check_team_accepted() returns trigger
    language plpgsql
as
$$
DECLARE
  accept accept_status;
  team_key INT;
  BEGIN
    team_key:=(SELECT team_id FROM team_members WHERE (team_members.user_id = NEW.user_id));
    accept:=(SELECT status FROM teams WHERE (teams.id = team_key));
    IF (NOT(accept = 'ACCEPTED'))
      THEN RAISE EXCEPTION 'Team is not accepted yet';
      RETURN NULL;
      END IF;
  RETURN NEW;
  END;
$$;

alter function check_team_accepted() owner to s244077;

