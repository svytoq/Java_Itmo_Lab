create function ratrack() returns trigger
    language plpgsql
as
$$
BEGIN
        if NEW.Ширина_Прохода not between 1.5 and 15 then
            Raise exception 'Ширина_Прохода not between 1.5 .. 15';
        end if;
        if NEW.Запас_топлива not between 0 and 500 then
            Raise exception 'Запас_топлива not between 0 .. 500';
        end if;
        RETURN NEW;
    END;
$$;

alter function ratrack() owner to s269380;

