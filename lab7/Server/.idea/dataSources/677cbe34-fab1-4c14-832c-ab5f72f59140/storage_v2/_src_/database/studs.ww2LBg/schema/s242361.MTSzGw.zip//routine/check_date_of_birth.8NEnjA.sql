create function check_date_of_birth() returns trigger
    language plpgsql
as
$$
BEGIN
IF (((SELECT ДАТА_НАЧАЛА FROM ИГРЫ WHERE ИД_ИГРЫ = NEW.ИД_ИГРЫ) - (SELECT ДАТА_РОЖДЕНИЯ FROM ПОЛЬЗОВАТЕЛИ WHERE ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛЬЗОВАТЕЛЯ)) < 12*365) THEN
RAISE WARNING 'Трибут должен достичь 12 лет для участия в играх';
RETURN NULL;
ELSEIF (((SELECT ДАТА_НАЧАЛА FROM ИГРЫ WHERE ИД_ИГРЫ = NEW.ИД_ИГРЫ) - (SELECT ДАТА_РОЖДЕНИЯ FROM ПОЛЬЗОВАТЕЛИ WHERE ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛЬЗОВАТЕЛЯ)) > 18*365) THEN
RAISE WARNING 'Трибут не может быть старше 18 лет';
RETURN NULL;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function check_date_of_birth() owner to s242361;

