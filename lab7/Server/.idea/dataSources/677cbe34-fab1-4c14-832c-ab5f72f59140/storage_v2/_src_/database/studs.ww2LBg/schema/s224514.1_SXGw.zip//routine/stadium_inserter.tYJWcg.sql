create function stadium_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	rand INTEGER;
	length integer;
	i INTEGER DEFAULT 1;
	count integer default 0;
	chars text[] = '{a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z}';
	name text;
	adress text;
	vmestimost integer;

BEGIN
	for i in 1..N loop

		rand = random();
		length = random() * 10;
		vmestimost = 10001 + random()*100;

		while count<length or name IS null or adress IS null loop
			name = concat(chars[1+random()*(array_length(chars, 1)-1)], name);
			adress = concat(chars[1+random()*(array_length(chars, 1)-1)], adress);
			count = count+1;
		end loop;

		insert into "СТАДИОН" values(DEFAULT, initcap(LOWER(name)), adress, vmestimost);
		name = NULL;
		adress = NULL;
		count = 0;

	end loop;
END;
$$;

alter function stadium_inserter(integer) owner to s224514;

