create function building(x_cord integer, y_cord integer) returns void
    language plpgsql
as
$$
DECLARE basis integer;
BEGIN
    IF ((SELECT count(*) FROM basis_isbs WHERE x = X_cord AND y = Y_cord) < 1) THEN
        IF (((SELECT money FROM total_money) >= 50000)) THEN
            INSERT INTO basis_isbs(x, y) VALUES (X_cord, Y_cord);
            UPDATE total_money SET money = money - 50000;
            basis = (Select id from basis_isbs WHERE X = X_cord and Y = Y_cord);
            INSERT INTO isbs(basis_id, x, y) VALUES (basis, X_cord, Y_cord);
            INSERT INTO transport(isbs_id, name, quantity, distance) VALUES (basis,'Еда', 0,0);
            INSERT INTO transport(isbs_id, name, quantity, distance) VALUES (basis,'Воздух',0,0);
            INSERT INTO transport(isbs_id, name, quantity, distance) VALUES (basis,'Ресурс',0, 0);
            RAISE NOTICE 'Купол % начал стройку по координатам (%; %)', basis, X_cord, Y_cord;
        ELSE
            RAISE NOTICE 'Недостаточно денег';
        END IF;
    ELSE
        RAISE NOTICE 'В этом месте ISBS уже существует';
    END IF;
End
$$;

alter function building(integer, integer) owner to s263977;

