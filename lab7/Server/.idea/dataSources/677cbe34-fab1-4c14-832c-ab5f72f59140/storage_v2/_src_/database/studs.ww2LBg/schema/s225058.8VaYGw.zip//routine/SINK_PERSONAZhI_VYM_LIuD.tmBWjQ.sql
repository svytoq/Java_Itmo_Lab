create function "СИНК_ПЕРСОНАЖИ_ВЫМ_ЛЮД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.ПРОТОТИП!=0 THEN
IF (select not exists(select ИД from ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ where ИД=new.ПРОТОТИП))=true then 
IF currval('ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ_ИД_seq')!=NEW.ИД THEN
NEW.ИД=nextval('ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ_ИД_seq');
END IF; 
Insert into ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ (ИД, ИМЯ) values (new.ПРОТОТИП, 'tochange');
END IF;   
RETURN NEW;
END IF;
RETURN NEW;
    END;
$$;

alter function "СИНК_ПЕРСОНАЖИ_ВЫМ_ЛЮД"() owner to s225058;

