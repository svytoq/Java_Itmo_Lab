create function insertsponsor() returns trigger
    language plpgsql
as
$$
DECLARE
name text;
sum_ text;
BEGIN
select Название into name from НИЦ where NEW.ИД_НИЦ=НИЦ.ИД;
select sum into sum_ from donateSummary() where org_id=NEW.ИД_НИЦ;
raise notice 'Current %s account is: %s', name, sum_;
return NEW;
END;
$$;

alter function insertsponsor() owner to s185017;

