create function createanimal(charactername text, animalwisdom integer, animaltype text) returns text
    language plpgsql
as
$$
declare
    id_ch int;
begin
    insert into character(name) values (characterName) returning id_character into id_ch;
    insert into animal(id_character, wisdom, type) values (id_ch, animalWisdom, animalType);
    return 'Зверек создан! id - ' || id_ch;
end;
$$;

alter function createanimal(text, integer, text) owner to s264912;

