create function users_id() returns trigger
    language plpgsql
as
$$
BEGIN
NEW.Id := nextval('К_Пользователи_id_seq');

RETURN NEW;
END;
$$;

alter function users_id() owner to s242193;

