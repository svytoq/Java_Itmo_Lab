create function log_bought_item() returns trigger
    language plpgsql
as
$$
begin
        if new.status = 'Closed'::listing_status and new.buyer_actor_id is not null then
            with listingReq as (
                select seller as sel from listing where listing_id = new.listing_id
            )
            insert into listing_history(seller, action, author_id, listing_id) values ((select * from listingReq), 'Bought', new.buyer_actor_id, new.listing_id);
            return new;
        end if;

        if new.status = 'Closed'::listing_status and new.buyer_clan_id is not null then
            with listingReq as (
                select seller from listing where listing_id = new.listing_id
            )
            insert into listing_history(seller, action, clan_id, listing_id) values ((select * from listingReq), 'Bought', new.buyer_clan_id, new.listing_id);
            return new;
        end if;

        if new.status = 'Closed'::listing_status then
            with listingReq as (
                select seller from listing where listing_id = new.listing_id
            )
            insert into listing_history(seller, action, listing_id) values ((select * from listingReq), 'Bought', new.listing_id);
            return new;
        end if;

        return new;
    end;
$$;

alter function log_bought_item() owner to s263063;

