create function customer_contacts(customer_nick character varying)
    returns TABLE(people_nick character varying)
    language plpgsql
as
$$
begin
    return query select distinct sender_nick from message m where customer_nick = recipient_nick 
            union select distinct recipient_nick from message m where customer_nick = sender_nick;
end;
$$;

alter function customer_contacts(varchar) owner to s263919;

