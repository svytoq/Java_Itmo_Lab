create function delete_product() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM товар WHERE товар.id = OLD.id_товара;
    RETURN NULL;
END;
$$;

alter function delete_product() owner to s265082;

