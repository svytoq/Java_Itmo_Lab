create function death() returns trigger
    language plpgsql
as
$$
DECLARE
		clan integer;
		clan_kil integer;
		rec RECORD;
	BEGIN
	IF NOT EXISTS (SELECT * FROM people
		WHERE id = NEW.victim AND NOT DeathD = null)
	THEN
		IF NEW.result = true
		THEN
			SELECT INTO clan_kil clan_id FROM clan_members
				WHERE hum_id = NEW.killer;

			UPDATE people SET DeathD = NEW.date, Alive = false
				WHERE id = NEW.victim;

			DELETE FROM people_rel
				WHERE (hum1 = NEW.victim) OR (hum2 = NEW.victim);

			DELETE FROM bribed
				WHERE bribe = NEW.victim;

			IF EXISTS
				(SELECT hum_id FROM clan_members
					WHERE hum_id = NEW.victim)
			THEN
				SELECT INTO clan clan_id FROM clan_members
					WHERE hum_id = NEW.victim;
				FOR rec IN SELECT * FROM property LOOP
					UPDATE property SET hum_id = null, clan_id = clan
						WHERE hum_id = NEW.victim;
				END LOOP;
				IF (EXISTS (SELECT * FROM business
					WHERE clan_id = clan AND loc_id = NEW.loc_id))
				THEN
					UPDATE clans_rel SET loyal = loyal - 100
						WHERE (clan_1 = clan AND clan_2 = clan_kil) OR (clan_1 = clan_kil AND clan_2 = clan);
				ELSE
					UPDATE clans_rel SET loyal = loyal - 20
						WHERE (clan_1 = clan AND clan_2 = clan_kil) OR (clan_1 = clan_kil AND clan_2 = clan);
				END IF;
				DELETE FROM clan_members
					WHERE (hum_id = NEW.victim);
			ELSE
				DELETE FROM property
					WHERE hum_id = NEW.victim;
			END IF;
		ELSE
			SELECT INTO clan clan_id FROM clan_members
				WHERE hum_id = NEW.victim;
			IF EXISTS(SELECT * FROM business
				WHERE clan_id = clan AND loc_id = NEW.loc_id)
			THEN
				UPDATE clans_rel SET loyal = loyal - 50
					WHERE (clan_1 = clan AND clan_2 = clan_kil) OR (clan_1 = clan_kil AND clan_2 = clan);
			END IF;
		END IF;
		RETURN NEW;
	ELSE
	RETURN NULL;
	END IF;
	END;
$$;

alter function death() owner to s225107;

