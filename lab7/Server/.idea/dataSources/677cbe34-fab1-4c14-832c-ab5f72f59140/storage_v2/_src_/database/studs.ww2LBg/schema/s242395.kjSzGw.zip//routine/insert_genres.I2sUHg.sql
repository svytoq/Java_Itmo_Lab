create function insert_genres(count integer) returns void
    language plpgsql
as
$$
BEGIN
        FOR i in 1 .. count LOOP
                insert into Жанры(название)
                 values (random_string(20));
        END LOOP;
END;
$$;

alter function insert_genres(integer) owner to s242395;

