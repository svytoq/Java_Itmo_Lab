create function add_jmeter_seeds() returns void
    language plpgsql
as
$$
DECLARE
                upass varchar;
                uname varchar;
            BEGIN
                -- Add test users
                upass = '$2a$10$vOGvoOOaTtUZYoZTTl..IOF01JxNJJQ19DdtM6T41kV3gfkTn3rvi';
                FOR i IN 1..1000
                    LOOP
                        uname = 'admin' || i; perform add_user(uname, upass, 'ADMIN');
                        uname = 'nanny' || i; perform add_user(uname, upass, 'NANNY');
                        uname = 'lead' || i; perform add_user(uname, upass, 'LEAD_NANNY');
                        uname = 'caretaker' || i; perform add_user(uname, upass, 'CARETAKER');
                        uname = 'user' || i; perform add_user(uname, upass, 'USER');
                    END LOOP;

                -- Add test children 240k
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
                perform add_children(20000, make_date(1980, 1, 1));
            END;
$$;

alter function add_jmeter_seeds() owner to s223791;

