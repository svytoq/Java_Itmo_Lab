create function cascade_group() returns trigger
    language plpgsql
as
$$
BEGIN
DELETE FROM Альбом WHERE Группа_ИД = old.ИД;
    RETURN OLD;
  END;
$$;

alter function cascade_group() owner to s223569;

