create function register_user(id integer, first_name character varying, surname character varying, gender character varying, dob date, email character varying, mobile_phone character varying) returns void
    language plpgsql
as
$$
BEGIN

  PERFORM insert_user(id,first_name, surname, gender, dob, email, mobile_phone);
  RAISE NOTICE 'Пользователь зарегистрирован';

END;

$$;

alter function register_user(integer, varchar, varchar, varchar, date, varchar, varchar) owner to s264458;

