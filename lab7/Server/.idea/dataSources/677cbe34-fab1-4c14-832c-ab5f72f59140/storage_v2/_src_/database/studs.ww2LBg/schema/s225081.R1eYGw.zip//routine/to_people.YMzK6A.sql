create function to_people(count integer) returns void
    language plpgsql
as
$$
DECLARE
name VARCHAR(25);
  sirname VARCHAR(25);
  pol VARCHAR(3);
  pos VARCHAR(25);
  J int;
  k int;
BEGIN
  k=0;
  FOR J IN SELECT ID_МЕСТО FROM МЕСТОПОЛОЖЕНИЕ LOOP
    if k=COUNT THEN exit; END IF ;
  IF J%2=0 THEN
  pol ='МУЖ';
    ELSE POL='ЖЕН';
      END IF;
    IF J % 3 = 0 THEN
      POS ='РЕМЕСЛЕННИК';
    ELSEIF J % 5 = 0 THEN
      POS ='ТОРГОВЕЦ';
     ELSEIF J % 33 = 0 THEN
      POS ='ПАТРИЦИЙ';
    ELSE POS = 'КРЕСТЬЯНИН';
    END IF;
    name = substr(md5(random()::text),1,25);
    sirname = substr(md5(random()::text),1,25);
 INSERT INTO ЛЮДИ VALUES (DEFAULT , sirname, name,pos  ,J , pol);
    k=k+1;
 END LOOP;
END;
$$;

alter function to_people(integer) owner to s225081;

