create view future_delivery(purchase_id, purchase_date, delivery_date, last_name, first_name) as
SELECT p.purchase_id,
       p.purchase_date,
       p.delivery_date,
       em.first_name AS last_name,
       em.last_name  AS first_name
FROM s265089.purchases p
         JOIN s265089.employees em USING (employee_id)
WHERE p.delivery_date > 'now'::text::date
ORDER BY p.delivery_date;

alter table future_delivery
    owner to s265089;

