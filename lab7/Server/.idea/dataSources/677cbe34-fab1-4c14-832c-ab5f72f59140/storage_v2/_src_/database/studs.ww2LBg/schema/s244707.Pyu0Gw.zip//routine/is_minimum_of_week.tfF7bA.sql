create function is_minimum_of_week(id_st integer, d integer) returns boolean
    language plpgsql
as
$$
begin
if (get_count_order(id_st, 0) <= get_count_order(id_st, 1)
					 and get_count_order(id_st, 0) <= get_count_order(id_st, 2)
					 and get_count_order(id_st, 0) <= get_count_order(id_st, 3)
					 and get_count_order(id_st, 0) <= get_count_order(id_st, 4)
					 and get_count_order(id_st, 0) <= get_count_order(id_st, 5)
					 and get_count_order(id_st, 0) <= get_count_order(id_st, 6)) 
then return true;
else return false;
end if;
end;
$$;

alter function is_minimum_of_week(integer, integer) owner to s244707;

