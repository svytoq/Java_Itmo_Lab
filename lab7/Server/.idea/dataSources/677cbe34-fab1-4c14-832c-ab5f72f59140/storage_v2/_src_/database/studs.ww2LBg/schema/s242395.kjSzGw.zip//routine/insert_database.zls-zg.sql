create function insert_database(count integer) returns void
    language plpgsql
as
$$
BEGIN
        PERFORM create_cinema_circuit(count / 100);
        PERFORM create_cinemas(count / 50);
        PERFORM create_rooms(count / 100);
        PERFORM create_places();
END;
$$;

alter function insert_database(integer) owner to s242395;

