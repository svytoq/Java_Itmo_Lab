create function give_prime_to_employee(fio text, prime integer) returns boolean
    strict
    language plpgsql
as
$$
begin
UPDATE "СИСТЕМА_КОНТРОЛЯ_СОТРУДНИКОВ" set "ПРЕМИЯ" = prime where "ИД_СОТРУДНИКА" = (select "СОТРУДНИКИ"."ИД" from "СОТРУДНИКИ" where "ФИО" = fio);
return true;
end;
$$;

alter function give_prime_to_employee(text, integer) owner to s265080;

