create function actually_travel() returns trigger
    language plpgsql
as
$$
DECLARE
  hunter_id int;
  hunter_current_planet int;
  hunter_money_amount bigint;
  ship_fuel bigint;
  fuel_for_travel bigint;
  price_for_travel bigint;
  gate_from_planet int;
  gate_to_planet int;
BEGIN
  SELECT h.id, h.money_amount, ss.planet_id, ss.fuel 
  INTO hunter_id, hunter_money_amount, hunter_current_planet, ship_fuel
  FROM Space_ship as ss
  INNER JOIN Hunter as h ON (h.ship_id=ss.id)
  WHERE ss.id = NEW.ship_id;
  
  SELECT sg.come_from, sg.go_to, sg.price, sg.fuel
  INTO gate_from_planet, gate_to_planet, price_for_travel, fuel_for_travel
  FROM Space_gate as sg WHERE sg.id = NEW.gate_id;
  
  IF hunter_current_planet != gate_from_planet THEN
    RAISE EXCEPTION 'Wrong gate';
  END IF;
  
  IF hunter_money_amount < price_for_travel OR ship_fuel < fuel_for_travel THEN
    RAISE EXCEPTION 'Not enough money or fuel';
  END IF;
  
  UPDATE Hunter SET money_amount = money_amount - price_for_travel WHERE id = hunter_id;
  UPDATE Space_ship SET fuel = fuel - fuel_for_travel, planet_id = gate_to_planet WHERE id = NEW.ship_id;
  
  RETURN NEW;
END;
$$;

alter function actually_travel() owner to s263081;

