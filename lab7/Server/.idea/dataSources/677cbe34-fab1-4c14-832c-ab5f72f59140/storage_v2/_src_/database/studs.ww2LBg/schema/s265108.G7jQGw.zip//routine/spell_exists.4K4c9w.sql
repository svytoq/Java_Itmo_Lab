create function spell_exists(spell integer) returns boolean
    language plpgsql
as
$$
DECLARE
          spell_exists boolean;
        BEGIN
          SELECT 1 INTO spell_exists FROM Spells s WHERE s.id = spell;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Такого заклинания нет, проверьте введенные данные';
    END IF;
        RETURN 'TRUE';
        END;
$$;

alter function spell_exists(integer) owner to s265108;

