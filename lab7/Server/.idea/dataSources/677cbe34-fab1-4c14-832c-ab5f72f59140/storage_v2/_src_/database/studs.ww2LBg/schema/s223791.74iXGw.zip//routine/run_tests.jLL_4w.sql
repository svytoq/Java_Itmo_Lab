create function run_tests() returns text
    language plpgsql
as
$$
DECLARE
                passed text := 'Passed tests:' ||E'\n';
                failed text := 'Failed tests:' ||E'\n';
            BEGIN
                IF integrity_check_children_sex() then
                    passed := passed || 'integrity_check_children_sex' ||E'\n';
                else
                    failed := failed || 'integrity_check_children_sex' ||E'\n';
                end if;
                IF integrity_check_children_birthday() then
                    passed := passed || 'integrity_check_children_birthday' ||E'\n';
                else
                    failed := failed || 'integrity_check_children_birthday' ||E'\n';
                end if;
                IF integrity_check_children_status() then
                    passed := passed || 'integrity_check_children_status' ||E'\n';
                else
                    failed := failed || 'integrity_check_children_status' ||E'\n';
                end if;
                IF integrity_check_children_weight() then
                    passed := passed || 'integrity_check_children_weight' ||E'\n';
                else
                    failed := failed || 'integrity_check_children_weight' ||E'\n';
                end if;
                IF integrity_check_children_unique_pk() then
                    passed := passed || 'integrity_check_children_unique_pk' ||E'\n';
                else
                    failed := failed || 'integrity_check_children_unique_pk' ||E'\n';
                end if;
                IF integrity_check_orders_foreign_key() then
                    passed := passed || 'integrity_check_orders_foreign_key' ||E'\n';
                else
                    failed := failed || 'integrity_check_orders_foreign_key' ||E'\n';
                end if;
                RETURN (passed ||E'\n') || failed;
            END;
$$;

alter function run_tests() owner to s223791;

