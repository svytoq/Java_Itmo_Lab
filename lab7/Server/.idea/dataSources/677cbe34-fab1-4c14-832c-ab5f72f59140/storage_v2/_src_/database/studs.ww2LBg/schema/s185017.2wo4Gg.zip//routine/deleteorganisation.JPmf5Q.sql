create function deleteorganisation() returns trigger
    language plpgsql
as
$$
BEGIN
delete from Операция where ИД in(select ИД_Операции from Список_операций where ИД_Организации=OLD.ИД);
return OLD;
END;
$$;

alter function deleteorganisation() owner to s185017;

