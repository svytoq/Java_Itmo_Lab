create function printschemainfo(schema_name text) returns void
    language plpgsql
as
$$
declare
    tables int;
    columns int;
    indexes int;
    i record;
begin

    if not exists(select 1 from pg_class where relnamespace::regnamespace::text=schema_name limit 1)
    then
        raise notice 'Cхемы % не существует.', schema_name;
        return;
    end if;

    create temp table temp_table on commit drop as 
    select 
    relname, 
    reltuples, 
    relnatts, 
    relkind
    from pg_class where relnamespace::regnamespace::text=schema_name;
    tables = (select count(*) from temp_table where relkind='r');
    columns = (select sum(relnatts) from (select relnatts from temp_table) as a);
    indexes = (select count(*) from temp_table where relkind='i');

    raise notice 'Количество таблиц в схеме % - %', schema_name, tables;
    raise notice 'Количество столбцов в схеме % - %', schema_name, columns;
    raise notice 'Количество индексов в схеме % - %', schema_name, indexes;

    raise notice ' ';
    raise notice '   Таблицы схемы %',  schema_name;
    raise notice ' ';

    raise notice '%', format('   %-21s%-13s%-10s','Имя','Столбцов','Строк');
    raise notice '%', '-----------------------------------------------';     

    for i in select * from (select * from temp_table  where relkind='r') t
    loop
        raise notice '%', format('%-27s %-8s %-s', i.relname, i.relnatts, i.reltuples);
    end loop;
    raise notice '%', '----------------------------------------------------------';
end;
$$;

alter function printschemainfo(text) owner to s265066;

