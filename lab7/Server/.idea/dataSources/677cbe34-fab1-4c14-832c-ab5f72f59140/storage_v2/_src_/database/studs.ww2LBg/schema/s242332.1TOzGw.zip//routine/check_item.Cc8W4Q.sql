create function check_item() returns trigger
    language plpgsql
as
$$
declare cnt int;
	begin
		if NEW.Тип_вещи = 'броня' then
			select count(*) from Броня where ИД = NEW.ИД_Вещи into cnt;
		elsif NEW.Тип_вещи = 'оружие' then
			select count(*) from Оружия where ИД = NEW.ИД_Вещи into cnt;
		elsif NEW.Тип_вещи = 'медикамент' then
			select count(*) from Медикаменты where ИД = NEW.ИД_Вещи into cnt;
		else
			cnt := 0;
		end if;

		if cnt = 0 then
			raise exception 'no item found for ИД';
		end if;
		
		return NEW;
	end;
$$;

alter function check_item() owner to s242332;

