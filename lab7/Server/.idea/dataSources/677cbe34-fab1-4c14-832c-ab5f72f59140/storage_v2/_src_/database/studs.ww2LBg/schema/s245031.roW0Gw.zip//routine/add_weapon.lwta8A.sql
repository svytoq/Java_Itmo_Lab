create function add_weapon(gun integer, grip integer, mag integer, barrel integer, stock integer, sight integer, element integer, rarity integer, type integer) returns integer
    language plpgsql
as
$$
DECLARE
    scheme_id integer;
    weapon_id integer;
BEGIN
    scheme_id := (SELECT id from "Чертежи_оружия" where рукоять = grip and магазин = mag and ствол = barrel
    and приклад = stock and прицел = sight and затвор = gun);

    if scheme_id is null then scheme_id
        := add_scheme(gun, grip, mag, barrel, stock, sight);
    end if;

    weapon_id := (SELECT max(id) from "Пушки") + 1;

    INSERT INTO "Пушки" (id, стихия, редкость, тип, схема)
    VALUES (weapon_id, element, rarity, type, scheme_id);

    RETURN weapon_id;
END;
$$;

alter function add_weapon(integer, integer, integer, integer, integer, integer, integer, integer, integer) owner to s245031;

