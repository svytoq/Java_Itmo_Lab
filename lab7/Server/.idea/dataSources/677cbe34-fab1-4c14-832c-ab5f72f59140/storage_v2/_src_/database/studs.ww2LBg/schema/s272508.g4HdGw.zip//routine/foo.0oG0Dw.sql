create function foo(schema text) returns void
    language plpgsql
as
$$
DECLARE
    name_schema text := lower(schema);
    all_count_table int := 0;
    all_count_index int := 0;
    all_count_attr int := 0;
    table_name text;
    count_attr int;
    count_rows int;
    BEGIN
        IF (name_schema ~ '^([a-z]|_)\w*') THEN
            IF exists(SELECT 1 FROM information_schema.schemata WHERE schema_name = name_schema) THEN
            CREATE TEMP TABLE table_statistics ON COMMIT DROP AS
                SELECT tablename, relnatts, reltuples FROM pg_tables t
                    JOIN pg_namespace n ON t.schemaname=n.nspname
                    JOIN pg_class c ON t.tablename=c.relname and n.oid = c.relnamespace
                    WHERE schemaname=name_schema;
                SELECT count(*) INTO all_count_table FROM table_statistics;
                SELECT sum(table_statistics.relnatts) INTO all_count_attr FROM table_statistics;
                SELECT count(*) INTO all_count_index FROM pg_indexes WHERE schemaname = name_schema;

                RAISE NOTICE 'Количество таблиц в схеме % - %', name_schema, all_count_table;
                RAISE NOTICE 'Количество столбцов в схеме % - %', name_schema, all_count_attr;
                RAISE NOTICE 'Количество индексов в схеме % - %', name_schema, all_count_index;
                RAISE NOTICE ' ';
                RAISE NOTICE '   Таблицы схемы %', name_schema;
                RAISE NOTICE ' ';
                RAISE NOTICE '% % %', RPAD('Имя', 27, ' '), RPAD('Стобцов', 10, ' '),
		                    RPAD('Строк', 8, ' ');
                RAISE NOTICE '-------------------------------------------------';
                FOR table_name, count_attr, count_rows IN (SELECT * FROM table_statistics)
		            LOOP
		                RAISE NOTICE '% % %', RPAD(table_name::text, 30, ' '), RPAD(count_attr::text, 8, ' '),
		                    RPAD(count_rows::text, 8, ' ');
		            END LOOP;
                RAISE NOTICE '-------------------------------------------------';
            ELSE
                RAISE EXCEPTION 'Не удалось получить информацию о схеме %', name_schema;
            END IF;
        ELSE
            RAISE EXCEPTION 'Неверное имя схемы %', name_schema;
        END IF;
    END
$$;

alter function foo(text) owner to s272508;

