create function check_insert_wallet() returns trigger
    language plpgsql
as
$$
BEGIN
  UPDATE wallet
  SET account = (SELECT account
                 FROM wallet
                 WHERE wallet.id = new.wallet) + new.amount;
  RETURN new;
END;
$$;

alter function check_insert_wallet() owner to s243872;

