create function create_floor(building integer) returns void
    language plpgsql
as
$$
DECLARE
id integer:=0;
floors integer:=0;
BEGIN
SELECT COUNT(*) INTO floors FROM ЭТАЖ;
id:=building*10+MOD(floors, 10);
INSERT INTO ЭТАЖ VALUES(id, building, NULL);
FOR i IN 1..25 LOOP
PERFORM create_room(building, id);
END LOOP;
END;
$$;

alter function create_floor(integer) owner to s225141;

