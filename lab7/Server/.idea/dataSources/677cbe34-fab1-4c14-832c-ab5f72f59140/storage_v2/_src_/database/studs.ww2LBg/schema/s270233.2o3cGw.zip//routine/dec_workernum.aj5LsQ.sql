create function dec_workernum() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE factories
    SET worker_num = worker_num - 1
    WHERE factories.id = OLD.factory_id;
    RETURN NEW;
END;
$$;

alter function dec_workernum() owner to s270233;

