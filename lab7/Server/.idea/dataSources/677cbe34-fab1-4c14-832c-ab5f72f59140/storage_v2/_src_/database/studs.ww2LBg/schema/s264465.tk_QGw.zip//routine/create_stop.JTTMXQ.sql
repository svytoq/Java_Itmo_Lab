create function create_stop(time_to_stop_arg integer, food_price_arg numeric, route_id_arg integer) returns text
    language plpgsql
as
$$
begin
    insert into stop(food_price, time_to_stop, route_id) values (food_price_arg, time_to_stop_arg, route_id_arg);
    return 'Stop created';
end;
$$;

alter function create_stop(integer, numeric, integer) owner to s264465;

