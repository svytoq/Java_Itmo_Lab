create function "ВИД_ИГРЫ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW."ИД_ВИДА_ИГРЫ" IS NULL THEN
   NEW."ИД_ВИДА_ИГРЫ" = generate_UUID();
END IF;
IF (exists(SELECT FROM "ВИД_ИГРЫ" WHERE "ВИД_ИГРЫ"."ИД_ВИДА_ИГРЫ" = NEW."ИД_ВИДА_ИГРЫ")) THEN
RAISE 'Вид игры указанным ид уже существует';
END IF;
IF NEW."НАЗВАНИЕ" IS NULL THEN
RAISE 'Графа "Название" не может быть пустой.';
END IF;
return NEW;
END;
$$;

alter function "ВИД_ИГРЫ"() owner to s223443;

