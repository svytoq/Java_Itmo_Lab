create function insert_skill() returns trigger
    language plpgsql
as
$$
BEGIN
INSERT INTO НАВЫКИ_ПОЛЬЗОВАТЕЛЯ VALUES (NEW.ИД_ПОЛЬЗОВАТЕЛЯ, 
(SELECT ИД_НАВЫКА FROM ДИСТРИКТЫ WHERE ИД_ДИСТРИКТА = NEW.ДИСТРИКТ),
100);
RETURN NEW;
END;
$$;

alter function insert_skill() owner to s242361;

