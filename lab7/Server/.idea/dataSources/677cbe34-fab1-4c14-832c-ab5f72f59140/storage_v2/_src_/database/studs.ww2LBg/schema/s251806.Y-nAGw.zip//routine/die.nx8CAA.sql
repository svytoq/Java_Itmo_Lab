create function die() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE character_or_entity
    SET health_points = 0,
        race_id=(SELECT race_id FROM race WHERE race.race = 'dead');
    RETURN NULL;
END;
$$;

alter function die() owner to s251806;

