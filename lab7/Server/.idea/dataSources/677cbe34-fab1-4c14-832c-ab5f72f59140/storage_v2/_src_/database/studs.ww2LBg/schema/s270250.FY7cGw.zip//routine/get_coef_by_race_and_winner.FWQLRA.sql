create function get_coef_by_race_and_winner(race integer, winner integer, OUT coef_on_winner integer) returns integer
    language plpgsql
as
$$
DECLARE
        horse_winner_order integer;
    BEGIN
        SELECT row_number INTO horse_winner_order FROM (SELECT horse_id,
        ROW_NUMBER() OVER (
           ORDER BY h.power*0.6+h.luck*4 DESC
        ) FROM Horse_in_race
        JOIN Horses h ON (Horse_in_race.horse_id = h.id) WHERE race_id = race) as winners where horse_id = winner;
    coef_on_winner := horse_winner_order / 10;
    END;
$$;

alter function get_coef_by_race_and_winner(integer, integer, out integer) owner to s270250;

