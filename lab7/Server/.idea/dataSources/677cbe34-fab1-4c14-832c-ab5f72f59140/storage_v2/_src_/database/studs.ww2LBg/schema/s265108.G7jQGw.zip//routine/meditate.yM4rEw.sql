create function meditate(magician integer) returns text
    language plpgsql
as
$$
BEGIN
  IF magician_exists(magician) THEN
    INSERT INTO Meditations (magician_id) VALUES (magician);
    RETURN 'Колдун отдохнул, можно в бой';
  END IF;
END;
$$;

alter function meditate(integer) owner to s265108;

