create function correct_bookmaker() returns trigger
    language plpgsql
as
$$
DECLARE
        person_job varchar(20);
    BEGIN
        SELECT job INTO person_job FROM Persons p WHERE p.id = NEW.person;
        IF (person_job != 'bookmaker') THEN
            RAISE EXCEPTION 'Этот человек не букмекер';
        END IF;
        RETURN NEW;
    END;
$$;

alter function correct_bookmaker() owner to s264489;

