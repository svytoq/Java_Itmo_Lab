create function jinchuuriki_counter() returns trigger
    language plpgsql
as
$$
BEGIN
        IF ((SELECT SUM(percent_of_chakra) FROM jinchuuriki j WHERE (j.date_of_beginnig, j.date_of_ending) OVERLAPS (NEW.date_of_beginnig, NEW.date_of_ending)) > 100) THEN RAISE EXCEPTION 'The summary percent of chakra cannot be more than 100'
      USING HINT = 'Please  check the value';
        END IF;
RETURN NEW;
    END;
$$;

alter function jinchuuriki_counter() owner to s243860;

