create function increase_salary(id_empl integer, new_salary integer) returns void
    language plpgsql
as
$$
Begin
    Update employee  set  salary =new_salary where id=id_empl;
end;
$$;

alter function increase_salary(integer, integer) owner to s264431;

