create function add_collection(name text, publisher text, publication_date date, VARIADIC writings text[]) returns void
    language plpgsql
as
$$
DECLARE
COL_ID INTEGER;
W_NAME TEXT;
W_ID INTEGER;
BEGIN
INSERT INTO СБОРНИКИ(НАЗВАНИЕ, ИЗДАТЕЛЬСТВО, ГОД_ИЗДАНИЯ) VALUES (NAME, PUBLISHER, PUBLICATION_DATE);
COL_ID = (SELECT MAX(ИД) FROM СБОРНИКИ);
FOREACH W_NAME IN ARRAY WRITINGS
LOOP
W_ID = (SELECT ИД FROM ПРОИЗВЕДЕНИЯ WHERE НАЗВАНИЕ ILIKE(W_NAME));
IF W_ID IS NOT NULL THEN 
INSERT INTO СБОРНИКИ_ПРОИЗВЕДЕНИЯ(ИД_СБОРНИКА, ИД_ПРОИЗВЕДЕНИЯ) VALUES (COL_ID, W_ID);
END IF;
END LOOP;
END;
$$;

alter function add_collection(text, text, date, text[]) owner to s243848;

