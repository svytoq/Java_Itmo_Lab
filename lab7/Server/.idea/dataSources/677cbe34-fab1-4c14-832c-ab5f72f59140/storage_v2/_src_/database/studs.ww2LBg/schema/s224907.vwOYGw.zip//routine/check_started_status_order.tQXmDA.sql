create function check_started_status_order() returns trigger
    language plpgsql
as
$$
begin
    if (New.status != 'Поиск курьера' or New.courier_id is not null) then
        raise exception 'you cannot create an order with this status or with a specified courier';
    end if;
    return NEW;
end
$$;

alter function check_started_status_order() owner to s224907;

