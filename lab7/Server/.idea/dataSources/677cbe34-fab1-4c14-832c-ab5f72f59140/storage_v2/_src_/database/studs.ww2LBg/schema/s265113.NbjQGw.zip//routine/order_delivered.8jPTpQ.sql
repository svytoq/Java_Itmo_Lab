create function order_delivered() returns trigger
    language plpgsql
as
$$
DECLARE
    row order_position%rowtype;
BEGIN
    FOR row IN SELECT * FROM order_position WHERE order_position.order_id = NEW.order_id
        LOOP
            IF row.type = order_type('medicines')
            THEN
                UPDATE medicines
                SET amount = amount + row.amount
                WHERE station = NEW.station
                  AND type = row.medicines_type;
            ELSIF row.type = order_type('equipment')
            THEN
                INSERT INTO equipment(type, station) VALUES (row.equipment_type, NEW.station);
            ELSIF row.type = order_type('person')
            THEN
                UPDATE person
                SET arrival_date = current_date,
                    station      = NEW.station,
                    on_station   = true
                WHERE person_id = row.person_id;
            ELSIF row.type = order_type('snowmobile')
            THEN
                UPDATE snowmobile SET station = NEW.station, on_station = true WHERE snowmobile_id = row.snowmobile_id;
            ELSIF row.type = order_type('fuel')
            THEN
                UPDATE station SET fuel = fuel + row.amount WHERE station_id = NEW.station;
            ELSIF row.type = order_type('food')
            THEN
                UPDATE station SET food = food + row.amount WHERE station_id = NEW.station;
            END IF;
        END LOOP;
    RETURN NEW;
END;
$$;

alter function order_delivered() owner to s265113;

