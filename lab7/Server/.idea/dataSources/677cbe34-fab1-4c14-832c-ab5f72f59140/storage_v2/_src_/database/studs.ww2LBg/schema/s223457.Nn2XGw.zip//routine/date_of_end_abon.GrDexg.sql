create function date_of_end_abon() returns trigger
    language plpgsql
as
$$
begin

  IF (Select НАЗВАНИЕ from ТИПЫ_АБОНЕМЕНТОВ where ИД = new.ИД_ТИПА) = 'Полугодовой'
  then
    NEW.ОКОНЧАНИЕ = NEW.НАЧАЛО + 6 * interval '1 month';
    return NEW;
  elseif (Select НАЗВАНИЕ from ТИПЫ_АБОНЕМЕНТОВ where ИД = new.ИД_ТИПА) = 'Годовой'
    then
      NEW.ОКОНЧАНИЕ = NEW.НАЧАЛО + interval '1 year';
      return NEW;
  end if;
end;

$$;

alter function date_of_end_abon() owner to s223457;

