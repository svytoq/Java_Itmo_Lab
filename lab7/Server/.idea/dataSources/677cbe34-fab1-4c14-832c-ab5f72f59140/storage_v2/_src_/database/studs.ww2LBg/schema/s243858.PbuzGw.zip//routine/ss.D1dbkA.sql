create function ss(_tbl anyelement) returns SETOF anyelement
    language plpgsql
as
$$
BEGIN
RETURN QUERY EXECUTE 'SELECT * FROM ' || pg_typeof(_tbl);
END
$$;

alter function ss(anyelement) owner to s243858;

