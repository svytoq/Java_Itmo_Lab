create function not_more_than_one() returns trigger
    language plpgsql
as
$$
DECLARE
    rows_num int;
BEGIN
      CREATE TEMPORARY TABLE IF NOT EXISTS rows_cnt(
      cnt text);
      INSERT INTO rows_cnt values(TG_TABLE_NAME);
      SELECT COUNT(*) INTO rows_num FROM rows_cnt WHERE cnt=TG_TABLE_NAME;
      IF (rows_num > 1) THEN 
      LOOP
      RAISE EXCEPTION 'За один раз можно удалить только одну строку';
      END LOOP;  
    END IF;
    RETURN OLD;
END;
$$;

alter function not_more_than_one() owner to s245031;

