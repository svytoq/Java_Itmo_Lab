create function unique_cheker() returns trigger
    language plpgsql
as
$$
DECLARE
    temprow weapon_owners%ROWTYPE;
BEGIN
    FOR temprow IN 
        SELECT * FROM weapon_owners WHERE weapon_id = NEW.weapon_id
    LOOP
        IF ((NEW.date_of_beginning, NEW.date_of_ending)
         OVERLAPS 
         (temprow.date_of_beginning, temprow.date_of_ending))
        THEN 
            RAISE EXCEPTION 'An unique weapon cannot be used by more than one person simultaneously';
        END IF;
    END LOOP;
    RETURN NEW;
END;
$$;

alter function unique_cheker() owner to s243860;

