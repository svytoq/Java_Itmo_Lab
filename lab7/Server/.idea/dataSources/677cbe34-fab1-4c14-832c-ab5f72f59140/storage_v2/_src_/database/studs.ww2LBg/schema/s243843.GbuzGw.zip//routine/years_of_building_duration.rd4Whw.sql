create function years_of_building_duration("КОД_ДОСТ" integer) returns integer
    language plpgsql
as
$$
DECLARE duration INTEGER;
BEGIN
  SELECT (ROUND((ДАТА_ПОСТРОЙКИ - ДАТА_ОСНОВАНИЯ)::REAL/ 365)::INTEGER) FROM ДОСТОПРИМЕЧАТЕЛЬНОСТЬ
    WHERE ДОСТОПРИМЕЧАТЕЛЬНОСТЬ.КОД_ДОСТОПРИМЕЧАТЕЛЬНОСТИ = КОД_ДОСТ INTO duration;
  RETURN duration;
END
$$;

alter function years_of_building_duration(integer) owner to s243843;

