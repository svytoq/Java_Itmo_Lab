create function test_user() returns void
    language plpgsql
as
$$
declare
    res text ;
    res1 int;
    flag bool := true;
begin
    raise notice 'Creating test user';
    insert into user_table values (111, '', 'TEST', 'TEST', '', 'TEST');

    raise notice 'Check that created';
    select username from user_table where id=111 into res;
    if res='TEST' then
        raise notice 'CREATED OK';
    else
        raise notice 'NOT CREATED';
        flag := false;
    end if;
    begin     -- try
        raise notice 'Inserting with same ID';
        insert into user_table values (111, '', 'TEST1', 'TEST1', '', 'TEST1');
        flag := false;
    exception -- catch
        when sqlstate '23505' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Id should be unique';
    end ;
    begin     -- try
        raise notice 'Inserting with same Username';
        insert into user_table values (1111, '', 'TEST', 'TEST', '', 'TEST');
        flag := false;
    exception -- catch
        when sqlstate '23505' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Username should be unique';
    end ;

    raise notice 'Deleting row';
    delete from user_table where id=111;
    select count(*) from wiki where id=111 into res1;

    if res1=0 then
        raise notice 'DELETED OK';
    else
        raise notice 'NOT DELETED';
        flag := false;
    end if;
    raise notice 'Test accomplished: %', flag;
end;
$$;

alter function test_user() owner to s225102;

