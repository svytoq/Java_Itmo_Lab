create function man_am(man_id integer)
    returns TABLE(id integer, name text, col integer)
    language sql
as
$$
SELECT Оружие.ИД, Оружие.Модель_ор, Амуниция.Количество FROM Оружие, Амуниция 
WHERE Амуниция.ИД_чел = man_id AND Оружие.ИД = Амуниция.ИД_ор;
$$;

alter function man_am(integer) owner to s225039;

