create function add_points(n text, p integer) returns void
    language plpgsql
as
$$
BEGIN
    UPDATE students
    SET points = points + p
    WHERE id = (SELECT id FROM characters WHERE name = n);
END
$$;

alter function add_points(text, integer) owner to s278172;

