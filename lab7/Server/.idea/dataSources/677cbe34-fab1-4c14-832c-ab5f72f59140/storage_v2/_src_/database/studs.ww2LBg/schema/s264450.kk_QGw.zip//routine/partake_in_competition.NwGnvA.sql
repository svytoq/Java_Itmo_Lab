create function partake_in_competition(user_login text, competition_name text) returns void
    language plpgsql
as
$$
BEGIN
insert into competition_participant(competition_id, base_user_login) values ((select id from competition where name like competition_name limit 1), user_login);
END;
$$;

alter function partake_in_competition(text, text) owner to s264450;

