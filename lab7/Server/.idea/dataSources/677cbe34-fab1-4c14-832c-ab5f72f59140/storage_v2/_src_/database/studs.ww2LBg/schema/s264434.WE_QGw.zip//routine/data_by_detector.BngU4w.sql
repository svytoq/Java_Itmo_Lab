create function data_by_detector(_detector integer, _date_start timestamp with time zone, _date_end timestamp with time zone)
    returns TABLE(detector_id integer, id_date timestamp with time zone, value integer)
    language plpgsql
as
$$
begin
    return query SELECT * from "Data"
            where date between _date_start and _date_end
              and id_detector = _detector;
end;
$$;

alter function data_by_detector(integer, timestamp with time zone, timestamp with time zone) owner to s264434;

