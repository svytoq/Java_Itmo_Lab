create function insert_roles() returns void
    language plpgsql
as
$$
DECLARE
        people record;
        groupr record;
BEGIN
        FOR people IN (SELECT ид from Люди)
        LOOP
                FOR groupr IN (SELECT ид from Группы)
                LOOP
                        insert into Роли(название,ид_человека,ид_группы) 
                                values(random_string(10),people.ид, groupr.ид);
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_roles() owner to s224932;

