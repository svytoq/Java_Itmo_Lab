create function insert_championship(name text, description text, cases integer[], platforms integer[]) returns integer
    language plpgsql
as
$$
DECLARE
    championship_number integer;
    cur_case integer;
    cur_platform integer;
BEGIN
    INSERT INTO championship (name, description) VALUES (insert_championship.name, insert_championship.description);
    SELECT CURRVAL('championship_championship_id_seq') INTO championship_number;

    FOREACH cur_case IN ARRAY cases
        LOOP
            PERFORM add_case_to_championship(championship_number, cur_case);
        END LOOP;

    FOREACH cur_platform IN ARRAY platforms
        LOOP
            PERFORM add_platform(championship_number, cur_platform);
        END LOOP;

    RETURN championship_number;
END;
$$;

alter function insert_championship(text, text, integer[], integer[]) owner to s264448;

