create function add_employee(main integer, name character varying, surname character varying, patronymic character varying, birth date, sex s265109.pol, pos s265109.job, duties text, salary integer, phone character varying, schedule text, experience text, penalties integer) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO employee(MAIN_ID, NAME, SURNAME, PATRONYMIC, BIRTH, SEX, POSITION, DUTIES, SALARY, PHONE, SCHEDULE, EXPERIENCE, PENALTIES)
    VALUES (MAIN, NAME, SURNAME, PATRONYMIC, BIRTH, SEX, POS, DUTIES, SALARY, PHONE, SCHEDULE, EXPERIENCE, PENALTIES);
end;
$$;

alter function add_employee(integer, varchar, varchar, varchar, date, s265109.pol, s265109.job, text, integer, varchar, text, text, integer) owner to s265109;

