create function location_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.location_id:= NEXTVAL('location_seq');
RETURN new;
END;
$$;

alter function location_func() owner to s225074;

