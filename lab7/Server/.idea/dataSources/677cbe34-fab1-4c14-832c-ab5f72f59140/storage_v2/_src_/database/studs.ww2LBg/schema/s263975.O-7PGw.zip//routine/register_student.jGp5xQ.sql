create function register_student(sname character varying, ssurname character varying, sbirthday date, schid bigint, favsubj bigint[]) returns bigint
    language plpgsql
as
$$
declare
    stdId bigint = 0;
    s     bigint;
begin
    insert into student(name, surname, birthday, school_id)
    values (sName, sSurname, sBirthday, schId)
    returning id into stdId;

    foreach s in array favSubj
        loop
            insert into student_favorite_subjects(stud_id, subj_id) values (stdId, s);
        end loop;

    return stdId;
end;
$$;

alter function register_student(varchar, varchar, date, bigint, bigint[]) owner to s263975;

