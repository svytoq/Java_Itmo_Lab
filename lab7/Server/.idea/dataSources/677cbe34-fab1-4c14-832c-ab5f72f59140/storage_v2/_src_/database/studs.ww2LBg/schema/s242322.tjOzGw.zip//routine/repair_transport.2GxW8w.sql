create function repair_transport(transport integer, start_time timestamp without time zone, end_time timestamp without time zone) returns void
    language plpgsql
as
$$
declare
repair_man integer;
st timestamp;
et timestamp = end_time;
begin
if start_time is null then
            st = now();
else 
            st = start_time;
end if;
        update ТРАНСПОРТ set ГОТОВО_ЕДИНИЦ = ГОТОВО_ЕДИНИЦ - 1 where ИД = transport;
select ИД into repair_man from ЧЛЕНЫ_ПОЛИЦИИ where ОТДЕЛ = 5 or ОТДЕЛ in (select ИД from ОТДЕЛЫ where ПОДЧИНЯЕТСЯ = 5);
insert into РЕМОНТ_ТРАНСПОРТА values (default, transport, et, repair_man, st);
end;
$$;

alter function repair_transport(integer, timestamp, timestamp) owner to s242322;

