create function kod_klienta_god() returns SETOF integer
    language sql
as
$$
SELECT Код_клиента from Заказ where (Дата_оформления between '01/01/2017'::date and '31/12/2017'::date);
$$;

alter function kod_klienta_god() owner to s242096;

