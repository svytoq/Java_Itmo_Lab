create function hashparolmd() returns trigger
    language plpgsql
as
$$
begin 
UPDATE ЧЕЛОВЕК set ПАРОЛЬ=md5(ПАРОЛЬ);
RETURN NEW; 
END;
$$;

alter function hashparolmd() owner to s243886;

