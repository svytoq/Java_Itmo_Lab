create function asoiaftime_cmp(t1 s225125.asoiaftime, t2 s225125.asoiaftime) returns integer
    language plpgsql
as
$$
DECLARE
    t1_arr int[6]; t2_arr int[6];
    i int = 1;
    NULLFound bool = false;
    asoiafTmstmp1 bigint = 0; asoiafTmstmp2 bigint = 0;
    minCPart int;
BEGIN
    t1_arr = ASOIAFtimeToIntArray(t1);
    t2_arr = ASOIAFtimeToIntArray(t2);

    IF t1.year IS NULL OR t1.month IS NULL OR t1.day OR t1.hours IS NULL OR t1.minutes IS NULL OR t1.seconds IS NULL OR
       t2.year IS NULL OR t2.month IS NULL OR t2.day OR t2.hours IS NULL OR t2.minutes IS NULL OR t2.seconds IS NULL THEN
        NULLFound = true;
    END IF;


    IF NULLFound THEN -- if at least one of the time string is not specified
        IF t1.modifier > t2.modifier THEN -- means time1 is AC and time2 is BC
          RETURN 1;
        ELSEIF t1.modifier < t2.modifier THEN -- means time1 is BC and time is AC
          RETURN 2;
        END IF;

        t1_arr = array[t1.year, t1.month, t1.day, t1.hours, t1.minutes, t1.seconds];
        t2_arr = array[t2.year, t2.month, t2.day, t2.hours, t2.minutes, t2.seconds];

        minCPart = ASOIAFfindMaxComparablePartIndex(t1_arr, t2_arr);
        RAISE INFO 'minCPart: %', minCPart;
        IF minCPart = 0 THEN
          RETURN -1; -- -1 means ambigues
        END IF;

        FOR i IN 1..minCPart LOOP
          asoiafTmstmp1 = asoiafTmstmp1 * 10^2 + t1_arr[i];
          asoiafTmstmp2 = asoiafTmstmp2 * 10^2 + t2_arr[i];
        END LOOP;

        asoiafTmstmp1 = asoiafTmstmp1 * t1_arr[7];
        asoiafTmstmp2 = asoiafTmstmp2 * t2_arr[7];

        IF asoiafTmstmp1 > asoiafTmstmp2 THEN
          RETURN 1;
        ELSE IF asoiafTmstmp1 = asoiafTmstmp2 THEN
          RETURN -1; -- ambigues
        ELSE
          RETURN 2;
        END IF; END IF;
    END IF;

    asoiafTmstmp1 = (t1.year*10^10 + t1.month*10^8 + t1.day*10^6 + t1.hours*10^4 + t1.minutes*10^2 + t1.seconds)*t1.modifier;
    asoiafTmstmp2 = (t2.year*10^10 + t2.month*10^8 + t2.day*10^6 + t2.hours*10^4 + t2.minutes*10^2 + t2.seconds)*t2.modifier;

    IF asoiafTmstmp1 > asoiafTmstmp2 THEN
        RETURN 1;
    ELSEIF asoiafTmstmp1 = asoiafTmstmp2 THEN
        RETURN 0; -- means equal
    ELSE
        RETURN 2;
    END IF;
END
$$;

alter function asoiaftime_cmp(s225125.asoiaftime, s225125.asoiaftime) owner to s225125;

