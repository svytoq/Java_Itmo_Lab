create function to_participant() returns void
    language plpgsql
as
$$
DECLARE
  J INT;
  I INT;
BEGIN
  FOR I IN SELECT ID_МЕРОПРИЯТИЯ
           FROM ВОЕННЫЕ_МЕРОПРИЯТИЯ LOOP
    FOR J IN SELECT ID_ВОИНА
             FROM ВОИНЫ
             WHERE ДОЛЖНОСТЬ = 'РЯДОВОЙ ВОИН' LOOP
      IF J % 2000 = 0
      THEN
        INSERT INTO УЧАСТНИК_МЕРОПРИЯТИЯ VALUES (DEFAULT, J, I);

      END IF;
    END LOOP;
  END LOOP;
END;
$$;

alter function to_participant() owner to s225081;

