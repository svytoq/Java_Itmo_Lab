create function add_teacher_in_group(integer, integer, integer, integer) returns void
    language sql
as
$$
START TRANSACTION;
	INSERT INTO преподаватель
	VALUES ($1, $2)
	;
	INSERT INTO учебная_группа
	VALUES ($3, $1, $4)
	;
COMMIT;
$$;

alter function add_teacher_in_group(integer, integer, integer, integer) owner to s223758;

