create view sound_person_heared
            (s_name, s_coor_x, s_coor_y, volume, start_time, duration, name, coor_x, coor_y, time_p, get_distance) as
SELECT sound_person.s_name,
       sound_person.s_coor_x,
       sound_person.s_coor_y,
       sound_person.volume,
       sound_person.start_time,
       sound_person.duration,
       sound_person.name,
       sound_person.coor_x,
       sound_person.coor_y,
       sound_person.time_p,
       sound_person.get_distance
FROM s264449.sound_person
WHERE sound_person.get_distance::numeric < sound_person.volume
  AND sound_person.time_p > sound_person.start_time
  AND sound_person.time_p < (sound_person.start_time + sound_person.duration);

alter table sound_person_heared
    owner to s264449;

