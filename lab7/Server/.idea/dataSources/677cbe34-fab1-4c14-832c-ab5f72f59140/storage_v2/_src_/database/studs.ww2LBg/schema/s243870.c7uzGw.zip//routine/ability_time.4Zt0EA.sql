create function ability_time() returns trigger
    language plpgsql
as
$$
DECLARE
	item_time interval;
	BEGIN
		SELECT "Время_Освоения" INTO item_time FROM "К_Способности" where Id = NEW.Способность_ИД;
 		NEW.Момент_Освоения := (current_timestamp + item_time);
 		RETURN NEW;
		END;
$$;

alter function ability_time() owner to s243870;

