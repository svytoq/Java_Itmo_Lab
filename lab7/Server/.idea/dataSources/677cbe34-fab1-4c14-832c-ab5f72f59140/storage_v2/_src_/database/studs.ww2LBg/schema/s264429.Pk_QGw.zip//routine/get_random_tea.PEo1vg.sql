create function get_random_tea() returns integer
    language plpgsql
as
$$
declare
        result integer := 0;
    begin
        select super_id from tea order by random() limit 1 into result;
        return result;
    end;
$$;

alter function get_random_tea() owner to s264429;

