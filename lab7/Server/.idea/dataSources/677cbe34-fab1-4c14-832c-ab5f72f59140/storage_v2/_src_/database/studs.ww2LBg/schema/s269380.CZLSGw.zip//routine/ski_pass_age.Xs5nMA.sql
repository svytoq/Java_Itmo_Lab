create function ski_pass_age() returns trigger
    language plpgsql
as
$$
DECLARE 
        new_p_id int;
        new_tourist boolean;
        new_type_id int;
        day_of_week int;
        date_cycle date;
        last_date date;
        people_age int; 
        last_day_of_week int;
        date_end date;
        date_tmp date;
    BEGIN
        if NEW.Дата_начало < now()::date then
           raise exception 'data_start can`t be earlier than now' ;
        end if;
        people_age := (select Возраст from Человек where ИД = NEW.Человек_ИД);
        if people_age <= 14 then
            new_type_id := 3;
        else
            new_type_id := 1;
        end if;
        date_cycle := NEW.Дата_начало;
        last_date := NEW.Дата_начало;
        date_end := NEW.Дата_конец; 
        new_p_id := NEW.Человек_ИД;
        new_tourist := NEW.Это_турист;
        -- начальное значение
        last_day_of_week := (select extract (dow from date_cycle));
        WHILE date_cycle <= date_end LOOP 
            day_of_week := (select extract (dow from date_cycle));
            if (day_of_week = 6 or day_of_week = 0) and (last_day_of_week = 1 or last_day_of_week = 2 or last_day_of_week = 3 or last_day_of_week = 4 or last_day_of_week = 5) then
                    date_tmp := date_cycle - interval '24 hour';
                    
                    insert into ski_pass (Человек_ИД, Это_турист, Дата_начало, Дата_конец, Тип_ИД) values (new_p_id, new_tourist, last_date, (date_tmp), new_type_id);
                    last_date := date_cycle;
            elsif (day_of_week = 1 or day_of_week = 2 or day_of_week = 3 or  day_of_week = 4 or  day_of_week = 5) and (last_day_of_week = 6 or last_day_of_week = 0) then
                    date_tmp := date_cycle - interval '24 hour';

                    insert into ski_pass (Человек_ИД, Это_турист, Дата_начало, Дата_конец, Тип_ИД) values (new_p_id, new_tourist, last_date, (date_tmp), new_type_id + 1);
                    last_date := date_cycle;
            else 
                date_cycle := (date_cycle + interval '24 hour');
            end if;
            last_day_of_week := day_of_week;
            
            NEW.Человек_ИД := new_p_id;
            NEW.Это_турист := new_tourist;
            NEW.Дата_начало := last_date;
            NEW.Дата_конец := date_end;
        END LOOP;
        if (day_of_week = 1 or day_of_week = 2 or  day_of_week = 3 or day_of_week = 4 or day_of_week = 5) then
            NEW.Тип_ИД := new_type_id;
        else
            NEW.Тип_ИД := new_type_id + 1;
        end if; 
        RETURN NEW;
    END;
$$;

alter function ski_pass_age() owner to s269380;

