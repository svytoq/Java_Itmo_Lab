create function delete_review(review_id integer) returns void
    language plpgsql
as
$$
BEGIN

  DELETE FROM review WHERE id = review_id;

  RAISE NOTICE 'Отзыв закрыта';

END;

$$;

alter function delete_review(integer) owner to s264458;

