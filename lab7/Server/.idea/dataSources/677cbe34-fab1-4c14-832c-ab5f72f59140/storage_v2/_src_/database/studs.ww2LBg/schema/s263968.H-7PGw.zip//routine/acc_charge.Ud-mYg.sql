create function acc_charge() returns trigger
    language plpgsql
as
$$
declare
        reactorId integer := 0;
    begin
        if((cast(NEW.CurrentValue as decimal) / NEW.MaxValue * 100) < 80) then
            reactorId = (select m.Id from accumulator as a
                                              INNER JOIN ucw as u on a.id = u.moduleaccumid
                                              inner join modul m on u.moduleid = m.id and m.name = 'Реактор');

            Update Modul Set e_buffer = 1000 where Id = @reactorId;
        end if;
        return new;
    end
$$;

alter function acc_charge() owner to s263968;

