create function dec_delclientnum() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE delivery_places
    SET client_num = client_num - 1
    WHERE delivery_places.id = OLD.delivery_place_id;
    RETURN NEW;
END;
$$;

alter function dec_delclientnum() owner to s270233;

