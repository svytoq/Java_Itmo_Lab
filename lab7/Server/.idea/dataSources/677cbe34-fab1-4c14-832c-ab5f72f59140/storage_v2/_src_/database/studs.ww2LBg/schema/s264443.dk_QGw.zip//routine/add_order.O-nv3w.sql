create function add_order(requester_id integer, VARIADIC item_list s264443.order_item[]) returns integer
    language plpgsql
as
$$
DECLARE record order_item;
    DECLARE ord_id integer := nextval('customer_order_id_seq');

    BEGIN
        INSERT INTO customer_order(id, customer_id, responsible_id) VALUES
            (ord_id, requester_id, find_order_responsible());
        FOREACH record IN ARRAY item_list LOOP
            INSERT INTO order_content(order_id, item_id, item_count) VALUES
                (ord_id, record.item_id, record.item_count);
        END LOOP;
        RETURN ord_id;
    END;
$$;

alter function add_order(integer, s264443.order_item[]) owner to s264443;

