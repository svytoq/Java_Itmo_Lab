create function actions_with_village() returns trigger
    language plpgsql
as
$$
declare
    destroy_quantity integer ;
begin
    if (tg_op = 'update') then
        destroy_quantity = (select quantity_of_destruction from hidden_village where village_id = new.village_id);
        insert into hidden_village(village_id, name, quantity_of_destruction) values (old.village_id, old.name ,destroy_quantity + 1);
    end if;
    return new;
end;
$$;

alter function actions_with_village() owner to s263909;

