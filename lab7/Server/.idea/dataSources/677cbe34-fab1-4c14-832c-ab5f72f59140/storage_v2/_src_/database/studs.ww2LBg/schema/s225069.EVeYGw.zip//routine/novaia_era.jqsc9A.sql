create function новая_эра(era character varying, klimat character varying, kontinent character varying, square integer)
    returns TABLE("Название_эры" character varying, "Климат" character varying, "Название_континента" character varying, "Площадь" double precision)
    language plpgsql
as
$$
begin
insert into Эры  values (null,era,klimat);
insert into Континенты(Код_континента, Название_континента, Площадь) values (null,kontinent, square); 
insert into Эры_и_континенты values ((select Код_эры from Эры where Эры.Название_эры=era),(select Код_континента from Континенты where Континенты.Название_континента=kontinent));
return query select Эры.Название_эры,Эры.Климат, Континенты.Название_континента, Континенты.Площадь 
from Эры join Эры_и_континенты using (Код_эры) join Континенты using (Код_континента) where Эры.Название_эры=era;
end;
$$;

alter function новая_эра(varchar, varchar, varchar, integer) owner to s225069;

