create function on_transport_stress_change() returns trigger
    language plpgsql
as
$$
begin
    raise notice 'Stress level %', NEW.additional_price;
    if NEW.additional_price >= 0 then
        return NEW;
    else
        RAISE EXCEPTION 'Stress level cant be less than minimal value from transport type';
    end if;

end;
$$;

alter function on_transport_stress_change() owner to s264465;

