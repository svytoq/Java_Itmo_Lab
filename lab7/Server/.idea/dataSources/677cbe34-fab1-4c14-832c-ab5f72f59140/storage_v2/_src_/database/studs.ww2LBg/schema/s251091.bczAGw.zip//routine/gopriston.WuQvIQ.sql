create function gopriston(name text, house text) returns void
    language sql
as
$$
update АРМИЯ set ЗЕМЛЯ = null where ЛИДЕР = $1;
insert into ПЛЕННИК(ИМЯ_ЛИДЕРА, НАЗВАНИЕ_ДОМА_ПЛЕНИВШЕГО) values ($1, $2)
$$;

alter function gopriston(text, text) owner to s251091;

