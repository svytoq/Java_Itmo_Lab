create function get_first_not_claimed_object(_map integer) returns bigint
    language plpgsql
as
$$
DECLARE
	obj BIGINT;
BEGIN
	SELECT id INTO STRICT obj
		FROM objects
		WHERE (NOT is_object_claimed(id))
			AND map = _map
		LIMIT 1;

	RETURN obj;
END;
$$;

alter function get_first_not_claimed_object(integer) owner to s244711;

