create function team_name(team_id integer) returns character varying
    language plpgsql
as
$$
DECLARE
  teamName VARCHAR(64);

BEGIN
  SELECT title INTO teamName FROM team WHERE id = team_id;

  RETURN teamName;
END;

$$;

alter function team_name(integer) owner to s264458;

