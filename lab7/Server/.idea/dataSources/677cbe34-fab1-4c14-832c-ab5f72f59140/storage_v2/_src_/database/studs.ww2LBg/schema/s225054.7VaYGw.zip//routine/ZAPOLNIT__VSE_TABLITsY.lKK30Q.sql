create function "ЗАПОЛНИТЬ_ВСЕ_ТАБЛИЦЫ"(count integer, fr integer) returns void
    language plpgsql
as
$$
DECLARE now_indx INT := nextval('ПЕРСОНАЖИ_ID_seq'::regclass) + 1;
BEGIN
FOR i IN fr..count + fr LOOP
INSERT INTO ВОЛШЕБНЫЕ_ИГРЫ VALUES ('Игра' || i, i, i, 'В эту игру очень классно играть вдвоем!!!' );
INSERT INTO ЛОКАЦИИ VALUES ('Домик на дереве №' || i, i%10);
INSERT INTO ШКОЛЫ_МАГИИ VALUES ('МБОУ СОШ №' || i, 'Домик на дереве №' || i, i%10);
INSERT INTO ФАКУЛЬТЕТЫ VALUES ('ПииКТ' || i, 'Отчислен', 'МБОУ СОШ №' || i);
INSERT INTO ПРОФЕССИИ VALUES ('Карл Гюстав ' || i, 'В должностные обязанности всех Карлов Гюставов входит сдача лабараторных по Программированию и Базам Данных');
INSERT INTO ПЕРСОНАЖИ VALUES(DEFAULT, 'Мормонт', 'Виталий', NULL, NULL, 'Цвета базилика', 'Как океанская волна', NULL, 'Игра' || i, 'ПииКТ' || i, 'Карл Гюстав ' || i);
INSERT INTO ГОДЫ_ОБУЧЕНИЯ VALUES(i, CAST ('09-01-200' || i AS DATE), CAST ('06-30-200' || i+1 AS DATE));
INSERT INTO КРЕСТРАЖИ VALUES('Слеза студента ВТ ' || i, i);
INSERT INTO ВОЛШЕБНЫЕ_ЖИВОТНЫЕ VALUES('Барсик №' || i, 'Человекоядный паук', 'Цвета спелой сливы', now_indx, 'Пушистый хвост', 'Домик на дереве №' || i);
INSERT INTO ЗАКЛИНАНИЯ VALUES('Курсачус Сдавамус ' || i, 'Защищает курсач на максимальное количество баллов', 10);
INSERT INTO ВАЖНЫЕ_СОБЫТИЯ VALUES('Сдача курсача по БД ' || i, 'Домик на дереве №' || i, i);
INSERT INTO ЗАКЛИНАНИЯ_ПЕРСОНАЖЕЙ VALUES(now_indx, 'Курсачус Сдавамус ' || i);
INSERT INTO УЧЕБНЫЕ_ПРЕДМЕТЫ VALUES('Базы Данных' || i, 'ПииКТ' || i, now_indx, 'Введение в реляционные БД');
INSERT INTO ОРГАНИЗАЦИИ VALUES('ИТМО ' || i, now_indx, now_indx, 'Захватить мир', i+2);
END LOOP;
RETURN;
END;
$$;

alter function "ЗАПОЛНИТЬ_ВСЕ_ТАБЛИЦЫ"(integer, integer) owner to s225054;

