create function som(_tbl regclass, OUT result character varying) returns character varying
    language plpgsql
as
$$
BEGIN
EXECUTE format('SELECT * FROM %s ', _tbl)
INTO result;
END
$$;

alter function som(regclass, out varchar) owner to s243858;

