create function "СЕАНС_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "СЕАНС" ("СУММА","СТОЛ_АВТОМАТ","ИД_ПОСЕТИТЕЛЬ", "ВРЕМЯ_НАЧАЛА_СЕАНСА","ВРЕМЯ_ОКОНЧАНИЯ_СЕАНСА","ИД_ВИДА_ИГРЫ")
VALUES (s,(select trunc(random() * 9 + 1)),(SELECT "ИД_ПОСЕТИТЕЛЬ" FROM "ПОСЕТИТЕЛЬ" OFFSET floor(random()* 100) LIMIT 1),date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)),date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)),(SELECT "ИД_ВИДА_ИГРЫ" FROM "ВИД_ИГРЫ" OFFSET floor(random()*7) LIMIT 1));
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END LOOP;
END;
$$;

alter function "СЕАНС_ТЕСТ"(integer) owner to s223443;

