create function mask_planet(planet_population integer, planet_to_mask integer) returns text
    language plpgsql
as
$$
declare
    population_planet_type char;
    masking_planet_type char; 
    masking_planet_is_masked boolean;
  begin
    select planet_type into population_planet_type from planet where population_id = planet_population;
    
    if not found or population_planet_type != '3' then
      raise exception 'You can`t mask any planet';
    end if;
    
    select planet_type, is_masked into 
    masking_planet_type, masking_planet_is_masked from planet where id = planet_to_mask;
    
    if not found or masking_planet_type != '3' or masking_planet_is_masked = 't' then
      raise exception 'You can`t mask this planet';
    end if;
    
    insert into masking (planet_id, population_id) values (planet_to_mask, planet_population);
    
    return 'Planet is masked now';
  end;
$$;

alter function mask_planet(integer, integer) owner to s264482;

