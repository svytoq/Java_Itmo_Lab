create function is_prisoner_alive(id integer) returns boolean
    language plpgsql
as
$$
DECLARE
id_prisoner int = (SELECT id_creature FROM dead_creature d
WHERE d.id_creature = id);
BEGIN
IF id_prisoner != null THEN 
RETURN false;
END IF;
RETURN true;
END;
$$;

alter function is_prisoner_alive(integer) owner to s243856;

