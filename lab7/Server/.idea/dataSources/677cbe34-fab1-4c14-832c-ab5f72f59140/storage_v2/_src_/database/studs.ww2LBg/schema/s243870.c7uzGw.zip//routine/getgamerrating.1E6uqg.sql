create function getgamerrating(integer) returns real
    language plpgsql
as
$$
DECLARE
val real;
BEGIN
select SUM((select sum(К_Участники.Оценка_Персонажа) from К_Участники where К_Участники.Персонаж_ИД = К_Персонажи.id))
from К_Игроки
join К_Персонажи on К_Игроки.id = К_Персонажи.Игрок_ИД and К_Игроки.id = $1;

if(val is null) then
val:= 0;
end IF;
RETURN val;
END;
$$;

alter function getgamerrating(integer) owner to s243870;

