create function get_workers(id_factory integer)
    returns TABLE(name character varying, surname character varying, birth_date date, contacts character varying, address text, salary numeric)
    language sql
as
$$
SELECT humans.name, humans.surname, humans.birth_date, humans.contacts, humans.address, providers.salary
FROM humans
         JOIN providers ON providers.id_human = humans.id_human
WHERE providers.id_factory = $1;
$$;

alter function get_workers(integer) owner to s270235;

