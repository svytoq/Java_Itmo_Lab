create function create_worker_on_new_token() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO
        worker(profile_id, token_id)
    VALUES(new.profile_id, new.id);

    RETURN new;
END;
$$;

alter function create_worker_on_new_token() owner to s251437;

