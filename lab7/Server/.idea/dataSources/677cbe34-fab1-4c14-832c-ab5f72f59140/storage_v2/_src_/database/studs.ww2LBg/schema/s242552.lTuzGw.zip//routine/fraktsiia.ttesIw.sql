create function фракция() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.ID IN (select ID from фракция) THEN
UPDATE фракция SET название = NEW.название, ресурсы_фракции = NEW.ресурсы_фракции WHERE ID = NEW.ID;
RETURN null;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function фракция() owner to s242552;

