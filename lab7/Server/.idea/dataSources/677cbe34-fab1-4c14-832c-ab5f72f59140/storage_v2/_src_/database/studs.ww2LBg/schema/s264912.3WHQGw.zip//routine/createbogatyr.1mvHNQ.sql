create function createbogatyr(charactername text) returns text
    language plpgsql
as
$$
declare
    id_ch int;
begin
    insert into character(name) values (characterName) returning id_character into id_ch;
    insert into bogatyr(id_commander, name) values (id_ch, characterName);
    return 'Богатырь создан! id - ' || id_ch;
end;
$$;

alter function createbogatyr(text) owner to s264912;

