create function updaterating() returns trigger
    language plpgsql
as
$$
DECLARE oldRating smallint;
BEGIN
	oldRating = (SELECT РЕЙТИНГ FROM ГЕРОИ WHERE ИД_ГЕРОЯ = NEW.ИД_ГЕРОЯ);
	IF (SELECT count(*) FROM СТОРОНЫ WHERE NEW.ИД_ГЕРОЯ = ИД_ГЕРОЯ AND NEW.ИД_СРАЖЕНИЯ = ИД_СРАЖЕНИЯ) = 0 THEN
		UPDATE ГЕРОИ SET РЕЙТИНГ = oldRating + NEW.ИТОГ WHERE ИД_ГЕРОЯ = NEW.ИД_ГЕРОЯ;	
	ELSE
		UPDATE ГЕРОИ SET РЕЙТИНГ = oldRating - OLD.ИТОГ + NEW.ИТОГ WHERE ИД_ГЕРОЯ = NEW.ИД_ГЕРОЯ;
	END IF;
	RETURN NEW;
END;
$$;

alter function updaterating() owner to s225123;

