create function change_exp() returns trigger
    language plpgsql
as
$$
DECLARE
log1 varchar;
log2 varchar;
BEGIN
    IF TG_OP = 'INSERT' THEN
        log1 = NEW.Логин1;
log2 = NEW.Логин2;
    UPDATE Пользователь SET Опыт = Опыт + 10
    WHERE (Пользователь.Логин = log1) or (Пользователь.Логин = log2);
    ELSIF TG_OP = 'DELETE' THEN
    log1 = OLD.Логин1;
log2 = OLD.Логин2;
        UPDATE Пользователь SET Опыт = Опыт - 10
    WHERE (Пользователь.Логин = log1) or (Пользователь.Логин = log2);
    END IF;
    RETURN NEW;
END;
$$;

alter function change_exp() owner to s225037;

