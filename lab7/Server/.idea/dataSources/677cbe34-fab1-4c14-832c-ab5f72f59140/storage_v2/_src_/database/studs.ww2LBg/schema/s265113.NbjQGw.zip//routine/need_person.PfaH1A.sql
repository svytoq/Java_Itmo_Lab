create function need_person() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO request_position(type) VALUES (order_type('person'));
    RETURN NEW;
END;
$$;

alter function need_person() owner to s265113;

