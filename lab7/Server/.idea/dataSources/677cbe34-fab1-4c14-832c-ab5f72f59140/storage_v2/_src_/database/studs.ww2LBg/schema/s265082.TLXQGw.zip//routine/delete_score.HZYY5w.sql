create function delete_score() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM оценка WHERE оценка.id = OLD.id_оценки;
    RETURN NULL;
END;
$$;

alter function delete_score() owner to s265082;

