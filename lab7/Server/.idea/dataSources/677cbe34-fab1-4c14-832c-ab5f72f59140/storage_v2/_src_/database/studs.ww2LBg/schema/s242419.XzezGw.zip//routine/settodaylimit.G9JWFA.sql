create function settodaylimit() returns trigger
    language plpgsql
as
$$
BEGIN

NEW.лимит := 0;
IF ((select АКЦИЯ.надбавка from АКЦИЯ where (АКЦИЯ.день_акции=date_part('day', now()) and АКЦИЯ.месяц_акции=date_part('month', now()))) ISNULL) THEN
  NEW.лимит := NEW.лимит
  + (select ТРАНСПОРТ.нач_квота from ТРАНСПОРТ where ТРАНСПОРТ.ид=NEW.ид_транспорта)
  + (select КВОТА.надбавка from (ПОЛЬЗОВАТЕЛЬ inner join ЛЬГОТА on (ПОЛЬЗОВАТЕЛЬ.ид_льготы=ЛЬГОТА.ид)) inner join КВОТА on (ЛЬГОТА.ид_квоты=КВОТА.ид) where ПОЛЬЗОВАТЕЛЬ.ид=NEW.ид_пользователя);
ELSE
  NEW.лимит := NEW.лимит
  + (select ТРАНСПОРТ.нач_квота from ТРАНСПОРТ where ТРАНСПОРТ.ид=NEW.ид_транспорта)
  + (select КВОТА.надбавка from (ПОЛЬЗОВАТЕЛЬ inner join ЛЬГОТА on (ПОЛЬЗОВАТЕЛЬ.ид_льготы=ЛЬГОТА.ид)) inner join КВОТА on (ЛЬГОТА.ид_квоты=КВОТА.ид) where ПОЛЬЗОВАТЕЛЬ.ид=NEW.ид_пользователя)
  + (select АКЦИЯ.надбавка from АКЦИЯ where (АКЦИЯ.день_акции=date_part('day', now()) and АКЦИЯ.месяц_акции=date_part('month', now())));
END IF;



RETURN NEW;
END;
$$;

alter function settodaylimit() owner to s242419;

