create function phase_upd_valid() returns trigger
    language plpgsql
as
$$
BEGIN
    IF new.сезон_ид<>old.сезон_ид THEN 
        RAISE EXCEPTION 'Вы не можете изменить номер сезона, которому принадлежит стадия.
        Все стадии автоматически создаются при добавлении или изменении сезонов!';
    END IF;
    IF new.типс_ид<>old.типс_ид THEN 
        RAISE EXCEPTION 'Вы не можете изменить тип стадии.
        Все стадии автоматически создаются при добавлении или изменении сезонов!';
    END IF;
    IF new.типс_ид=(SELECT ид FROM типы_стадий WHERE название LIKE 'Регулярный сезон') THEN
        IF new.начало<>old.начало THEN 
            RAISE EXCEPTION 'Для изменения даты начала регулярного сезона измените дату начала соответствующего сезона!';
        END IF;
        IF (new.конец IS NOT NULL) THEN
            IF EXISTS (SELECT 1 FROM стадии WHERE (ид<>old.ид) AND (сезон_ид=old.сезон_ид)) THEN
                IF (SELECT начало FROM стадии WHERE (ид<>old.ид) AND (сезон_ид=old.сезон_ид)) IS NULL THEN
                    IF ((SELECT конец FROM стадии WHERE (ид<>old.ид) AND (сезон_ид=old.сезон_ид))-new.конец)<2 THEN
                        RAISE EXCEPTION 'Конец регулярного сезона должен быть раньше конца плей-оффа не менее чем на 2 дня!';
                    END IF;
                ELSE
                    IF ((SELECT начало FROM стадии WHERE (ид<>old.ид) AND (сезон_ид=old.сезон_ид))-new.конец)<>1 THEN
                        RAISE EXCEPTION 'Плей-офф должен начинаться ровно на следующий день после окончания регулярного сезона!';
                    END IF;
                END IF;
            ELSE
                IF ((DATE_PART('year',(new.конец+2)::timestamp))::integer - (DATE_PART('year',(old.начало)::timestamp))::integer)>=2 THEN
                    RAISE EXCEPTION 'Конец регулярного сезона не должен быть позже чем за два дня до года окончания следующего сезона!';
                END IF;
            END IF;
        END IF;     
    END IF;
    RETURN NEW;
END;
$$;

alter function phase_upd_valid() owner to s242558;

