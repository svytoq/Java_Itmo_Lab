create function count_persons(station_id_arg integer) returns integer
    language plpgsql
as
$$
DECLARE
    res integer;
BEGIN
    SELECT count(*) INTO res FROM person WHERE station = station_id_arg;
    RETURN res;
END;
$$;

alter function count_persons(integer) owner to s265113;

