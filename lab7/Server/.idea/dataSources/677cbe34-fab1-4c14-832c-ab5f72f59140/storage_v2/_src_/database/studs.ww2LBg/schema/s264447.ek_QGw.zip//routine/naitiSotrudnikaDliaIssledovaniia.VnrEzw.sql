create function "найтиСотрудникаДляИсследования"("исследование" integer) returns integer
    language plpgsql
as
$$
begin
    return (
        select сотрудник_id 
        from Сотрудники_Исследования 
        where Сотрудники_Исследования.исследование_id=исследование
        order by RANDOM() limit 1);
end;
$$;

alter function "найтиСотрудникаДляИсследования"(integer) owner to s264447;

