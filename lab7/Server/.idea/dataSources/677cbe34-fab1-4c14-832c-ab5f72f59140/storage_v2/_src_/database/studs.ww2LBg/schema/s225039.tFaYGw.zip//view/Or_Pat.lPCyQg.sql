create view "Ор_Пат"("ИД_ор", "ИД_пат") as
SELECT "Оружие"."ИД"  AS "ИД_ор",
       "Патроны"."ИД" AS "ИД_пат"
FROM s225039."Оружие"
         JOIN s225039."Патроны" USING ("Калибр");

alter table "Ор_Пат"
    owner to s225039;

