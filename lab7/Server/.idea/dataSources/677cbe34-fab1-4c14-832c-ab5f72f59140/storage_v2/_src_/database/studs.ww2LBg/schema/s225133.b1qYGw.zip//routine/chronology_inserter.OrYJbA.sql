create function chronology_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
    N alias for $1;
    length INTEGER;
    progress INTEGER;
    action integer;
    i INTEGER DEFAULT 1;
    count integer default 0;
    k integer;
    fight integer DEFAULT null;
    counterForFight INTEGER DEFAULT 1;
    numForFight INTEGER DEFAULT null;

BEGIN
    for i in 1..N loop

        progress:=trunc(random() * 500 + 1);
        action:=trunc(random() * 10 + 1);


        if ((SELECT COUNT(*) FROM "Хронология")=0) then
                fight =(SELECT "id" FROM "Битва" where id_победителя>0 and id_проигравшего>0 and "Артефакт">0 ORDER BY random() LIMIT 1);
        END IF;

        for counterForFight in 1..(SELECT COUNT(*) FROM "Хронология") loop
            numForFight:=(SELECT id FROM "Битва" WHERE id_победителя>0 and id_проигравшего>0 and "Артефакт">0 ORDER BY random() LIMIT 1);
            fight = (SELECT "id" FROM "Битва" WHERE "id"=numForFight);
            if (fight = (SELECT "id" FROM "Битва" WHERE "id"=numForFight)) then
            ELSE
                fight = (SELECT "id" FROM "Битва" WHERE "id"=numForFight);
                EXIT;
            END if;
        END loop;

        insert into "Хронология"("Ход", "Действие", id_игры, "Битва") values
          (
            progress,
            action,
            (SELECT id FROM "ИГРА" ORDER BY random() LIMIT 1),
            fight
          );
        count:=0;
        counterForFight:=1;

    end loop;

END;
$$;

alter function chronology_inserter(integer) owner to s225133;

