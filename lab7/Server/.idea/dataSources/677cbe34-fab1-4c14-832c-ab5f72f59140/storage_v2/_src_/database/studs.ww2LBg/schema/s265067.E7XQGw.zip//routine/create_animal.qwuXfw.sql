create function create_animal(vtype_pet text) returns bigint
    strict
    language plpgsql
as
$$
DECLARE
  ret bigint;
BEGIN
  INSERT INTO pets(type_pet) VALUES (vtype_pet) returning pet_id into ret;
  RETURN ret;
END;
$$;

alter function create_animal(text) owner to s265067;

