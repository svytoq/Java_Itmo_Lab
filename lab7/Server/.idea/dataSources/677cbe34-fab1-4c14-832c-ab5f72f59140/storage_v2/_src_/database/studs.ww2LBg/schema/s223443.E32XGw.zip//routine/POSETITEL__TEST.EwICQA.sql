create function "ПОСЕТИТЕЛЬ_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  telso uuid;
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
telso = (SELECT "ИД_ЧЕЛОВЕКА" FROM "ЧЕЛОВЕК" OFFSET floor(random()*500) LIMIT 1);
IF (NOT (exists(SELECT FROM "ПОСЕТИТЕЛЬ" WHERE "ПОСЕТИТЕЛЬ"."ИД_ЧЕЛОВЕКА" = telso))) THEN
IF (exists(SELECT FROM "ЧЕЛОВЕК" WHERE "ЧЕЛОВЕК"."ИД_ЧЕЛОВЕКА" = telso)) THEN
INSERT INTO "ПОСЕТИТЕЛЬ" ("ИД_ЧЕЛОВЕКА","ТЕЛЕФОН","ПОЧТА")
VALUES (telso,(select trunc(random() * 999999 + 10000)),random_string(random()::integer*10+4));
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END IF;
END IF;
END LOOP;
END;
$$;

alter function "ПОСЕТИТЕЛЬ_ТЕСТ"(integer) owner to s223443;

