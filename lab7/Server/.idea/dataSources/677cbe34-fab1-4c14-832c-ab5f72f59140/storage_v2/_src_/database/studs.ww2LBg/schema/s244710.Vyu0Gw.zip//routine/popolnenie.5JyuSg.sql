create function popolnenie() returns trigger
    language plpgsql
as
$$
DECLARE
      code_tarifa integer;
      metro integer;
      bus integer;
      tram integer;
      trolleybus integer;
      cost integer;
      inter interval;
		BEGIN

      code_tarifa = (SELECT "Код_Тарифа" FROM "Карты_пассажира" WHERE "Карты_пассажира"."Код_карты" = new."Код_карты");
      metro = (SELECT "Количество_поездок_в_метро" FROM "Тарифы" WHERE "Код_Тарифа" = code_tarifa);
      bus = (SELECT "Количество_поездок_в_автобусе" FROM "Тарифы" WHERE "Код_Тарифа" = code_tarifa);
      tram = (SELECT "Количество_поездок_в_трамвае" FROM "Тарифы" WHERE "Код_Тарифа" = code_tarifa);
      trolleybus = (SELECT "Количество_поездок_в_троллейбусе" FROM "Тарифы" WHERE "Код_Тарифа" = code_tarifa);
      cost = (SELECT "Стоимость_тарифа" FROM "Тарифы" WHERE "Код_Тарифа" = code_tarifa);
      inter = (SELECT "Время_действия_карты" FROM "Тарифы" WHERE  "Код_Тарифа"  = code_tarifa);


        if(code_tarifa = 19)
            THEN UPDATE "Карты_пассажира" SET "Остаток_денежных_средств" = "Остаток_денежных_средств" + new."Сумма" WHERE "Код_карты" = new."Код_карты";
            UPDATE "Карты_пассажира" SET "Дата_пополнения" = new."Дата" WHERE "Код_карты" = new."Код_карты";

        ELSEIF (new."Сумма" = cost )
                THEN
                  UPDATE "Карты_пассажира" SET "Дата_пополнения" = new."Дата" WHERE "Код_карты" = new."Код_карты";
                  UPDATE "Карты_пассажира" SET "Остаток_поездок_в_метро" = metro WHERE "Код_карты" = new."Код_карты";
                  UPDATE "Карты_пассажира" SET "Остаток_поездок_в_автобусах" = bus WHERE "Код_карты" = new."Код_карты";
                  UPDATE "Карты_пассажира" SET "Остаток_поездок_в_трамваях" = tram WHERE "Код_карты" = new."Код_карты";
                  UPDATE "Карты_пассажира" SET "Остаток_поездок_в_троллейбусах" = trolleybus WHERE "Код_карты" = new."Код_карты";
                  UPDATE "Карты_пассажира" SET "Дата_окончания_действия" = "Дата_пополнения" + inter WHERE "Код_карты" = new."Код_карты" ;
        ELSE  RAISE EXCEPTION 'Неверная сумма, для пополнения данной карты';

          END if;
			RETURN new;
		END;
$$;

alter function popolnenie() owner to s244710;

