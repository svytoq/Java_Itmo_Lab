create function add_platform(championship_id integer, platform_id integer) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO championship_platform (championship_id, platform_id)
    VALUES (add_platform.championship_id,
            add_platform.platform_id);
END;
$$;

alter function add_platform(integer, integer) owner to s264448;

