create function validate_user() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Убедимся, что CatMail корректен
    IF NEW.Cat_mail LIKE '%@%'
    THEN
        RAISE EXCEPTION 'CatMail не может содержать собаку!';
    END IF;
    
    IF NEW.Cat_mail NOT LIKE '%^^%' OR
       (length(NEW.Cat_mail) - 2) <> length(replace(NEW.Cat_mail, '^^', ''))
    THEN
      RAISE EXCEPTION 'CatMail не соответствует формату: "имя^^домен"';
    END IF;
    RETURN NEW;
  END
$$;

alter function validate_user() owner to s248266;

