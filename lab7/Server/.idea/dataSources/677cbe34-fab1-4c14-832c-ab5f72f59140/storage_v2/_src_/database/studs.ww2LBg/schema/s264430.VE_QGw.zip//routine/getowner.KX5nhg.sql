create function getowner(name text) returns text
    language sql
as
$$
select fraction_name from Provinces inner join Race on provinces.race_name=race.name where provinces.name=$1
$$;

alter function getowner(text) owner to s264430;

