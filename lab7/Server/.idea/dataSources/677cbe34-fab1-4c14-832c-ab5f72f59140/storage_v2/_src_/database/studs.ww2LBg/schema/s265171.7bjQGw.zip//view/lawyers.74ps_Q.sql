create view lawyers(id, family, is_busy) as
SELECT lawyer.id,
       lawyer.family,
       lawyer.is_busy
FROM s265171.lawyer
WHERE lawyer.family = 'Corleone'::text
  AND lawyer.is_busy = false
LIMIT 1;

alter table lawyers
    owner to s265171;

