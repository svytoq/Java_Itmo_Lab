create function need_food() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO request_position(type, amount)
    VALUES (order_type('food'), (count_persons(NEW.station_id)) * 120);
    RETURN NEW;
END;
$$;

alter function need_food() owner to s265113;

