create function триггер_самурай_битва_перед_встав() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NOT EXISTS(SELECT 1
                FROM Самурай
                WHERE id = NEW.id_самурай AND Жив)
  THEN
    RAISE EXCEPTION 'Самурай должен быть жив';
  END IF;
  IF NOT EXISTS(SELECT 1
                FROM "Самурай"
                  JOIN "Клан" ON "Самурай"."Название_клана" = "Клан"."Название"
                  JOIN "Клан_Сторона" ON "Клан"."Название" = "Клан_Сторона"."Название_клана"
                  JOIN "Сторона_Битва" ON "Клан_Сторона".id_стороны = "Сторона_Битва".id_стороны
                WHERE "Сторона_Битва".id_битва = new.id_битва AND "Самурай".id = new.id_самурай)
  THEN
    RAISE EXCEPTION 'Клан самурая должен участвовать в данной битве';
  END IF;
  RETURN NEW;
END;
$$;

alter function триггер_самурай_битва_перед_встав() owner to s223412;

