create function match_display_size(base_id integer) returns void
    language sql
as
$$
update bases
    set display_id = null
    where bases.id = base_id and display_size != (select size_inches
                           from displays
                           where displays.id = bases.display_id)
$$;

alter function match_display_size(integer) owner to s265482;

