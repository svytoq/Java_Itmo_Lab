create function check_student_spells_all_kinds_present() returns trigger
    language plpgsql
as
$$
begin
if exists(
select unnest(enum_range(NULL::spell_kind))
except (
select s.kind from spells s
inner join spells_students spst on
s.id = spst.spell_id and spst.student_id = new.id
)
)
then raise exception 'new student entries must have spells of all existing kinds assigned to them (via spells_students)';
end if;
return null;
end;
$$;

alter function check_student_spells_all_kinds_present() owner to s243871;

