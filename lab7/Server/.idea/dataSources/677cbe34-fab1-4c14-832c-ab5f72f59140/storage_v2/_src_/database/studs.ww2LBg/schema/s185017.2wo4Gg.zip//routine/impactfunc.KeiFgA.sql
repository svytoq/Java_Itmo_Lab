create function impactfunc() returns trigger
    language plpgsql
as
$$
BEGIN
update Подопытный set (IQ,Здоровье)=(IQ+NEW.Изменение_IQ,Здоровье+NEW.Изменение_здоровья) where Личный_номер=NEW.Личный_номер;
return NEW;
END;
$$;

alter function impactfunc() owner to s185017;

