create function check_reference_on_insert() returns trigger
    language plpgsql
as
$$
DECLARE
 t record;
BEGIN
  FOR t IN EXECUTE format('SELECT * FROM %I WHERE ИД = %s', NEW.tblname, NEW.ИД) LOOP
    IF t.ИД = NEW.ИД THEN
      RETURN NEW;
    END IF;
  END LOOP;
  RAISE EXCEPTION 'Не существует записи с ИД % в таблице %', NEW.ИД, NEW.tblname;
END
$$;

alter function check_reference_on_insert() owner to s225125;

