create function do_delivery_auto(miner_id integer) returns void
    language plpgsql
as
$$
DECLARE
	a_id integer;
BEGIN
	SELECT auto_id INTO a_id FROM Auto WHERE NOT(auto_id IN (SELECT auto_id FROM Delivery_Auto)) LIMIT 1;
	INSERT INTO Delivery_auto (auto_id, miner_id, delivery_date) VALUES (a_id, miner_id, current_date);	
END;
$$;

alter function do_delivery_auto(integer) owner to s264905;

