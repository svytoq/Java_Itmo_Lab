create function "СОЗДАНИЕ_ИД"() returns trigger
    language plpgsql
as
$$
DECLARE
maximum int;
counter int;
BEGIN
EXECUTE 'SELECT COUNT(*) FROM ' || TG_TABLE_NAME || ' WHERE ИД=' || NEW.ИД  || ';' INTO counter;
IF counter=1 THEN
EXECUTE 'SELECT MAX(ИД) FROM ' || TG_TABLE_NAME || ';' INTO maximum;
NEW.ИД:=maximum+1;
END IF;
RETURN NEW;
END;
$$;

alter function "СОЗДАНИЕ_ИД"() owner to s225106;

