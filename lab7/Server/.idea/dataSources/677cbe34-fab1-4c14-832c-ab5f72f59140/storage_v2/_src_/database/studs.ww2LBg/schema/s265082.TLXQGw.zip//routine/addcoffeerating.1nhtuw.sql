create function addcoffeerating(rating integer, comments text, coffee integer) returns text
    strict
    language plpgsql
as
$$
DECLARE
ret int;
BEGIN
	INSERT INTO оценка(оценка, отзыв) VALUES(rating, comments) RETURNING id INTO ret;
	INSERT INTO оценка_кофе(id, id_оценки, id_кофе) VALUES(ret, ret, coffee);
	RETURN 'Оценка на кофе добавлена, id - ' || ret;
END;
$$;

alter function addcoffeerating(integer, text, integer) owner to s265082;

