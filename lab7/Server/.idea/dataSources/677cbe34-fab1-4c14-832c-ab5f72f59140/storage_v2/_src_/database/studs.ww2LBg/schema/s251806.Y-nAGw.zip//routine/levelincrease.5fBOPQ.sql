create function levelincrease() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE character_or_entity SET experience=experience - 2000, level=level + 1 WHERE id = 0;
    RETURN NULL;
END;
$$;

alter function levelincrease() owner to s251806;

