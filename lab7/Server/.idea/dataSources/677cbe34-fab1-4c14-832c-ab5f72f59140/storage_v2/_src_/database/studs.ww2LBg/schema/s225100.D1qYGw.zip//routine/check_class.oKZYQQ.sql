create function check_class() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NOT(NEW.WEAPON_ID IN (SELECT weapon_id FROM weapon WHERE type_of_weapon= 'class')) THEN
    RAISE EXCEPTION 'Классового оружия с таким id не существует';
  END IF;
  RETURN NEW;
END;
$$;

alter function check_class() owner to s225100;

