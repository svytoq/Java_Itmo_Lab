create function buy_item_as_actor(actorid integer, listingid integer) returns void
    language plpgsql
as
$$
declare listingInfo listing%rowtype;
    declare itemListingInfo item_listing%rowtype;
    declare actorCurrencyAmount int;
    begin
        select * into listingInfo from listing where author_id = actorId and listing_id = listingId limit 1;
        select * into itemListingInfo from item_listing where listing_id = listingId limit 1;
        if (itemListingInfo.status = 'Closed'::listing_status) then
            return;
        end if;

        actorCurrencyAmount = (select amount from actor_currency where actor_id = actorId
        and currency_id = itemListingInfo.currency);

        if (actorCurrencyAmount >= itemListingInfo.price) then
            if ((select count(*) from actor_inventory where actor_id = actorId
                and item_id = itemListingInfo.item_id) != 0) then
                update actor_inventory set amount = amount + itemListingInfo.amount
                    where actor_id = actorId and item_id = itemListingInfo.item_id;
            else
                insert into actor_inventory(actor_id, item_id, amount)
                    values (actorId, itemListingInfo.item_id, itemListingInfo.amount);
            end if;
            update actor_currency set amount = amount - itemListingInfo.price where actor_id = actorId
                                                                        and currency_id = itemListingInfo.currency;
            update item_listing set status = 'Closed' where listing_id = listingId;
        end if;
    end;
$$;

alter function buy_item_as_actor(integer, integer) owner to s263063;

