create function get_smoothing_specialist_info(smoothing_specialist_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT s.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH FROM smoothing_specialist AS s 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE s.WORKER_ID = smoothing_specialist_id;
END
$$;

alter function get_smoothing_specialist_info(integer) owner to s263229;

