create function check_actor_rating_for_contract() returns trigger
    language plpgsql
as
$$
declare actorId int;
    declare actorRating int;
    begin
        actorId = (select author_id from listing where listing_id = new.listing_id and seller = 'Actor');
        raise notice 'Actor id: %', actorId;
        if actorId is not null then
            actorRating = (select rating from actor where id = actorId);
            raise notice 'Actor rating: %', actorRating;
            if actorRating < new.rating_amount then
                raise notice 'Rating amount: %', new.rating_amount;
                update contract_listing set rating_amount = actorRating where contract_id = new.contract_id;
                raise notice 'Rating amount: %', new.rating_amount;
            end if;
        end if;
        return old;
    end;
$$;

alter function check_actor_rating_for_contract() owner to s263063;

