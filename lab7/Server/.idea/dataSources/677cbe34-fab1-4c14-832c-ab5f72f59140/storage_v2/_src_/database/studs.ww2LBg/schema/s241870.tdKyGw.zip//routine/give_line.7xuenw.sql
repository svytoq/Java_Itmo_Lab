create function give_line(mafid integer) returns void
    language plpgsql
as
$$
declare
begin
SELECT * FROM Матчи m
INNER JOIN БК_Матчи bm ON m.ID_Матча = bm.ID_Команды
INNER JOIN БК b ON b.ID_БК = bm.ID_БК
INNER JOIN Мафия М on b.ID_Мафии = М.ID_Мафии
INNER JOIN Члены_Мафии ЧМ on М.ID_Мафии = ЧМ.ID_Мафии
WHERE ЧМ.ID_Мафии = mafid;
end
$$;

alter function give_line(integer) owner to s241870;

