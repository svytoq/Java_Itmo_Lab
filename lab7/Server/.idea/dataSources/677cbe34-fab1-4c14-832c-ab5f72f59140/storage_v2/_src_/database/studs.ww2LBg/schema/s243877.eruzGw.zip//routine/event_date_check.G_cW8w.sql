create function event_date_check() returns trigger
    language plpgsql
as
$$
begin
if exists (select place_id, date from event where place_id = NEW.place_id and date = NEW.date)
then
raise notice 'Date is unavailable'; 
return null;
else
if exists (select place_id, date from meeting where place_id = NEW.place_id and date = NEW.date)
then
raise notice 'Date is unavailable'; 
return null;
else
return NEW;
end if;
end if;
end
$$;

alter function event_date_check() owner to s243877;

