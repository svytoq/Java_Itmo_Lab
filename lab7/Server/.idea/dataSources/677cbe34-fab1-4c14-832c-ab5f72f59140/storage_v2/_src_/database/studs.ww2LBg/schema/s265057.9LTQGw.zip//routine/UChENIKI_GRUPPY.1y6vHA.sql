create function "УЧЕНИКИ_ГРУППЫ"(id integer)
    returns TABLE("УЧЕНИК_ИД" integer, "ФАМИЛИЯ" character varying, "ИМЯ" character varying, "ДАТА_РОЖДЕНИЯ" date, "УРОВЕНЬ" smallint)
    language sql
as
$$
SELECT УЧЕНИК_ИД,ФАМИЛИЯ,ИМЯ,ДАТА_РОЖДЕНИЯ,УРОВЕНЬ FROM УЧЕНИК WHERE УЧЕНИК.ГРУППА_ИД=$1
$$;

alter function "УЧЕНИКИ_ГРУППЫ"(integer) owner to s265057;

