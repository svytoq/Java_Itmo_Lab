create function "ЖУРНАЛ_ПО_НАЗВАНИЮ"(name character varying)
    returns TABLE("ИД_ЖУРНАЛА" smallint, "НАЗВАНИЕ_ЖУРНАЛА" character varying, "ОСНОВАТЕЛЬ" smallint, "ГОД_ОТКРЫТИЯ" date, "ГОД_ЗАКРЫТИЯ" date, "ЖУРНАЛ_ПРЕДШЕСТВЕННИК" smallint)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"ЛИТ_ЖУРНАЛ"."ИД_ЖУРНАЛА", "ЛИТ_ЖУРНАЛ"."НАЗВАНИЕ_ЖУРНАЛА", "ЛИТ_ЖУРНАЛ"."ОСНОВАТЕЛЬ", "ЛИТ_ЖУРНАЛ"."ГОД_ОТКРЫТИЯ", "ЛИТ_ЖУРНАЛ"."ГОД_ЗАКРЫТИЯ", "ЛИТ_ЖУРНАЛ"."ЖУРНАЛ_ПРЕДШЕСТВЕННИК"
FROM "ЛИТ_ЖУРНАЛ" WHERE "ЛИТ_ЖУРНАЛ"."НАЗВАНИЕ_ЖУРНАЛА" = name;
END;
$$;

alter function "ЖУРНАЛ_ПО_НАЗВАНИЮ"(varchar) owner to s225071;

