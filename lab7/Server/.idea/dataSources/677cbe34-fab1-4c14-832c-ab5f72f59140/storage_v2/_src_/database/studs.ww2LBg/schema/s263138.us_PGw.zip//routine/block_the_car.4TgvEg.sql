create function block_the_car(car integer) returns void
    language plpgsql
as
$$
declare
    request integer;
begin
    request = (select request_id from booked_car where car_id = car);

    update client_requests
    set lock         = true,
        lights       = false,
        start_a_ride = false
    where request_id = request;
end;
$$;

alter function block_the_car(integer) owner to s263138;

