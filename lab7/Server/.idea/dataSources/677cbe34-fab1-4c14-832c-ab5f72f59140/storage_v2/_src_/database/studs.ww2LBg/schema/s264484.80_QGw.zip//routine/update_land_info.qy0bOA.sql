create function update_land_info() returns trigger
    language plpgsql
as
$$
declare
    land_id_now integer;
    land_money         integer;
    land_materials     integer;
    land_idea          integer;
    land_sum_idea      integer;
    land_count_city    integer;
    land_arms          integer;
    land_soldier_count integer;
    land_index         integer;
begin
    if (tg_op = 'DELETE') then
        land_id_now = old.land_id;
    else land_id_now = new.land_id;
    end if;
    ---список изменившихся стран
    for land_index in
        select id from land where land.id = land_id_now
        loop
            select sum(money) into land_money from city where land_id = land_index;
            select sum(materials) into land_materials from city where land_id = land_index;
            select sum(idea) into land_sum_idea from city where land_id = land_index;
            select count(idea) into land_count_city from city where land_id = land_index;
            land_idea = land_sum_idea / land_count_city;
            select sum(arms) into land_arms from city where land_id = land_index;
            select sum(soldier_count) into land_soldier_count from city where land_id = land_index;
            update land
            set money         = land_money,
                materials     = land_materials,
                idea          = land_idea,
                arms          = land_arms,
                soldier_count = land_soldier_count
            where land.id = land_index;
        end loop;
    if (tg_op = 'DELETE') then
        return old;
    end if;
    return new;
end;

$$;

alter function update_land_info() owner to s264484;

