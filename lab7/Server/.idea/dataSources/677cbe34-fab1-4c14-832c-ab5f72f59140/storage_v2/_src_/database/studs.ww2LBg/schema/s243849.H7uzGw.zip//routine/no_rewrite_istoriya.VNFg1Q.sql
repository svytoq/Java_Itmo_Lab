create function no_rewrite_istoriya() returns event_trigger
    language plpgsql
as
$$
DECLARE
  table_oid oid := pg_event_trigger_table_rewrite_oid();

BEGIN 
	IF pg_event_trigger_table_rewrite_oid() = 'История_службы'::regclass
		THEN 
		RAISE EXCEPTION 'Таблицу нельзя изменить %', table_oid::regclass;
	END IF;
END;
$$;

alter function no_rewrite_istoriya() owner to s243849;

