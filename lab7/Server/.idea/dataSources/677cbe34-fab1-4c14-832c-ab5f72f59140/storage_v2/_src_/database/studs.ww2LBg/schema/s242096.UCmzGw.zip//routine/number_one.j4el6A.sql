create function number_one() returns trigger
    language plpgsql
as
$$
DECLARE
	telephone int;

BEGIN
	IF(TG_OP = 'UPDATE') THEN
		-- telephone = OLD.Телефон;
		IF(OLD.Телефон <> NEW.Телефон or OLD.E_mail<>NEW.E_mail) THEN
			OLD.Код_клиента=NEW.Код_клиента;
			OLD.ФИО=NEW.ФИО;
			OLD.Дата_рождения=NEW.Дата_рождения;
			-- REPLACE EXCEPTION 'Do you wanna Update phone number?',Клиент.Телефон;
		END IF;
	END IF;
	RETURN NEW;

END
$$;

alter function number_one() owner to s242096;

