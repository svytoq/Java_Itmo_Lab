create function random_intmax(val_max integer) returns integer
    language sql
as
$$
select (random() * val_max)::int
$$;

alter function random_intmax(integer) owner to s269380;

