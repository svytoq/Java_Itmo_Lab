create function get_character_abilities(char_id integer)
    returns TABLE(name text, description text, effects text, lost integer)
    language plpgsql
as
$$
BEGIN
    return query select Ability.name, Ability.description, Ability.effects, Ability.e_action_id from Ability where Ability.character_id = char_id order by Ability.e_action_id;
  END;
$$;

alter function get_character_abilities(integer) owner to s243838;

