create function somefunc()
    returns TABLE(income bigint, allbudget bigint, profit integer)
    language plpgsql
as
$$
BEGIN
    SELECT INTO income sum(profit) from game ;
    SELECT INTO allbudget sum(budget) from game;
    profit = income-allbudget;
    RETURN NEXT;

END;
$$;

alter function somefunc() owner to s264431;

