create function valid_prisoner() returns trigger
    language plpgsql
as
$$
BEGIN
IF NOT is_prisoner_alive(NEW.id_creature) THEN
RAISE EXCEPTION 'Invalid prisoner %', NEW.id_creature
USING HINT = 'Creature can not be accounted by prison as prisoner if it is dead';
END IF;
IF NOT is_prisoner_away(NEW.id_creature) THEN
RAISE EXCEPTION 'Invalid prisoner %', NEW.id_creature
USING HINT = 'Creature can not be a prisoner if it is wanted';
END IF;
RETURN NEW;
END;
$$;

alter function valid_prisoner() owner to s243856;

