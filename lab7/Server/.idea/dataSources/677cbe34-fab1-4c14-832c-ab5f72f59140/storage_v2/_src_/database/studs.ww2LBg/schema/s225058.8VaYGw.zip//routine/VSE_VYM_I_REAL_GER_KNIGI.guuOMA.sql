create function "ВСЕ_ВЫМ_И_РЕАЛ_ГЕР_КНИГИ"(name character varying)
    returns TABLE("ИМЯ" character varying, "ФАМИЛИЯ" character varying, "ОТЧЕСТВО" character varying, "ПОЛ" character varying)
    language plpgsql
as
$$
BEGIN 
RETURN QUERY SELECT ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ИМЯ, ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ФАМИЛИЯ, ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ОТЧЕСТВО, ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ПОЛ
FROM КНИГИ JOIN КНИГА_И_ВЫМ_И_РЕАЛЬНЫЕ_Л ON КНИГИ.ИД=ИД_КНИГИ
JOIN ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ ON ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ИД=ИД_Р_Ч WHERE КНИГИ.НАЗВАНИЕ = name; 
END;
$$;

alter function "ВСЕ_ВЫМ_И_РЕАЛ_ГЕР_КНИГИ"(varchar) owner to s225058;

