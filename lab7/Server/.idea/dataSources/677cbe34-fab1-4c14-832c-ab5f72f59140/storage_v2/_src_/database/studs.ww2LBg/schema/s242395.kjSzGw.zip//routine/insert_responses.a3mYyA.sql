create function insert_responses() returns void
    language plpgsql
as
$$
DECLARE
        film record;
        user record;
        film_time timestamp;
BEGIN
        FOR user IN (SELECT ид from Пользователи)
        LOOP
                FOR film IN (SELECT * from Фильмы)
                LOOP
                        insert into Отзывы(ид_фильма,ид_пользователя, значение, комментарий) 
        values(currval('Фильмы_ид_seq'), currval('Пользователи_ид_seq'), 5,'Хороший фильм');
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_responses() owner to s242395;

