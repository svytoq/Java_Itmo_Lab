create function cross_perform(person bigint, depart_dim s265066.dimensions) returns void
    language plpgsql
as
$$
declare
    dest_dim dimensions;
begin
    update Visas set cur_trans = cur_trans+1
    where person_id=person;

    if depart_dim = 'alpha' then
        dest_dim = 'prime';
    else
        dest_dim = 'alpha';
    end if;

    update People set current_dim=dest_dim
    where person_id=person;
end;
$$;

alter function cross_perform(bigint, s265066.dimensions) owner to s265066;

