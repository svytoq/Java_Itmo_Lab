create function trigger_fight_before_insert() returns trigger
    language plpgsql
as
$$
BEGIN

    if (NEW."id_победителя"=NEW."id_проигравшего" OR NEW.id_победителя IN (SELECT id_проигравшего FROM "Битва") OR NEW.id_проигравшего IN (SELECT id_проигравшего FROM "Битва")) then
    ROLLBACK;
    end if;

    return NEW;
END;
$$;

alter function trigger_fight_before_insert() owner to s225133;

