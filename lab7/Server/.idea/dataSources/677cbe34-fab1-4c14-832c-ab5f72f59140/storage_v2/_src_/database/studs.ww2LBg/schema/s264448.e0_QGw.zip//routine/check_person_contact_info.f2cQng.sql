create function check_person_contact_info() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS(SELECT NEW.person_id FROM email WHERE NEW.person_id = email.person_id) THEN
        RAISE EXCEPTION 'person should have an email';
    END IF;
    IF NOT EXISTS(SELECT NEW.person_id FROM phone WHERE NEW.person_id = phone.person_id) THEN
        RAISE EXCEPTION 'person should have an phone number';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_person_contact_info() owner to s264448;

