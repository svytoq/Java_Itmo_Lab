create function create_cat(cat_name text, breed_name text, cat_birthday timestamp without time zone, cat_sex character, cat_color integer) returns s259844.cat
    language plpgsql
as
$$
DECLARE
    ret cat;
BEGIN
    IF breed_name IS NOT NULL THEN
        INSERT INTO cat_breed(name) VALUES (breed_name) ON CONFLICT DO NOTHING;
    END IF;

    INSERT INTO cat(name, breed_id, birthday, sex, color)
        VALUES (cat_name, (SELECT id FROM cat_breed WHERE cat_breed.name = breed_name), cat_birthday, cat_sex, cat_color)
        RETURNING * INTO ret;

    RETURN ret;
    END;
$$;

alter function create_cat(text, text, timestamp, char, integer) owner to s259844;

