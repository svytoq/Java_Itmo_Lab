create function "ПОКАЗАТЬ_ЭКЗАМЕНЫ_ПРЕПОДАВАТЕЛЯ"(id integer) returns SETOF s265057."ЭКЗАМЕН"
    language sql
as
$$
select * FROM ЭКЗАМЕН WHERE ПРЕП_ИД=id
$$;

alter function "ПОКАЗАТЬ_ЭКЗАМЕНЫ_ПРЕПОДАВАТЕЛЯ"(integer) owner to s265057;

