create function get_all_criminals()
    returns TABLE(name character varying, planet_id integer, skills smallint, price bigint)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT c.name, c.planet_id, c.skills, c.price FROM Criminal as c
    WHERE jail_id IS null;
  END;
$$;

alter function get_all_criminals() owner to s263081;

