create function insert_object_suggestion(name_suggestion character varying, description_suggestion character varying, name_object character varying, description_object character varying, author integer) returns void
    language plpgsql
as
$$
DECLARE
    OBJECT_ID     INTEGER;
    SUGGESTION_ID INTEGER;
BEGIN
    INSERT INTO OBJECT (NAME, DESCRIPTION, USER_ID)
    VALUES (NAME_OBJECT, DESCRIPTION_OBJECT, AUTHOR)
    RETURNING id INTO OBJECT_ID;
    INSERT INTO SUGGESTION (NAME, DESCRIPTION, CREATION_DATE, AUTHOR)
    VALUES (NAME_SUGGESTION, DESCRIPTION_SUGGESTION, CURRENT_TIMESTAMP, AUTHOR)
    RETURNING id INTO SUGGESTION_ID;
    INSERT INTO OBJECT_SUGGESTION (SUGGESTION, OBJECT)
    VALUES (SUGGESTION_ID, OBJECT_ID);
END;
$$;

alter function insert_object_suggestion(varchar, varchar, varchar, varchar, integer) owner to s265087;

