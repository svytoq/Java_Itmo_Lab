create function upload_result(stdid bigint, evid bigint, point double precision) returns bigint
    language plpgsql
as
$$
declare
    rId bigint;
begin
    if (select 1
        from student_participation
        where student_participation.stud_id = stdId
          and student_participation.ev_id = evId) is null then
        --insert into student_participation(stud_id, ev_id) values (stdId, evId);
        insert into result(ev_id, stud_id, points) values (evId, stdId, point) returning id into rId;
    else
        update result set points = point where result.ev_id = evId and result.stud_id = stdId returning id into rId;
    end if;

return rId;
end;
$$;

alter function upload_result(bigint, bigint, double precision) owner to s263975;

