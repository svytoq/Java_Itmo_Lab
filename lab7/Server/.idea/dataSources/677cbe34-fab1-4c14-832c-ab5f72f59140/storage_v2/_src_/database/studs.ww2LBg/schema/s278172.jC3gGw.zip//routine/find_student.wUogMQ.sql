create function find_student(n text)
    returns TABLE(name text, year integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
        SELECT characters.name, students.year
        FROM characters
                 JOIN students ON characters.id = students.character_id
        WHERE characters.name = n;
END
$$;

alter function find_student(text) owner to s278172;

