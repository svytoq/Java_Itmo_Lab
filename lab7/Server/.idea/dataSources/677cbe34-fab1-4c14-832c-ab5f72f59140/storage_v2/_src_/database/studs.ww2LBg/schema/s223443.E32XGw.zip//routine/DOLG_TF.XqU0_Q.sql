create function "ДОЛГ_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW."ИД_ДОЛГА" IS NULL THEN
   NEW."ИД_ДОЛГА" = generate_UUID();
END IF;
IF (exists(SELECT FROM "ДОЛГ" WHERE "ДОЛГ"."ИД_ДОЛГА" = NEW."ИД_ДОЛГА")) THEN
RAISE 'Долга указанным ид уже существует';
END IF;
IF NEW."ДАТА_ОТКРЫТИЯ" > current_date THEN
RAISE 'Дата открытия долга не может быть позже чем текущяя дата';
END IF;
IF NEW."СУММА_ДОЛГА" < CAST(0 AS MONEY) THEN
RAISE 'СУММА_ДОЛГА не может быть меньше 0';
END IF;
IF NEW."ВЫПЛАЧЕННАЯ_ЧАСТЬ_ДОЛГА" < CAST(0 AS MONEY) THEN
RAISE ' ВЫПЛАЧЕННАЯ_ЧАСТЬ_ДОЛГА не может быть меньше 0';
END IF;
return NEW;
END;
$$;

alter function "ДОЛГ_ТФ"() owner to s223443;

