create function obj_am(obj_id integer)
    returns TABLE(id integer, name text, col integer)
    language sql
as
$$
SELECT Оружие.ИД, Оружие.Модель_ор, Нахождение_оруж.Количество FROM Оружие, Нахождение_оруж 
WHERE Нахождение_оруж.ИД_об = obj_id AND Оружие.ИД = Нахождение_оруж.ИД_ор;
$$;

alter function obj_am(integer) owner to s225039;

