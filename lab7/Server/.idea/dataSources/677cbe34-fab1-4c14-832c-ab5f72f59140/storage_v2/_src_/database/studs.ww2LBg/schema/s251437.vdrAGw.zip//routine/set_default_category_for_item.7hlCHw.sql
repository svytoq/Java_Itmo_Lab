create function set_default_category_for_item() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO
        category_item_relation(item_id, category_id)
    VALUES(new.id, 5);

    RETURN new;
END;
$$;

alter function set_default_category_for_item() owner to s251437;

