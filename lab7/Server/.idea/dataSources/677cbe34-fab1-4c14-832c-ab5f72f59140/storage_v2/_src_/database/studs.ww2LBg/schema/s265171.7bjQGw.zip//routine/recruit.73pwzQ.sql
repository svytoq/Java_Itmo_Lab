create function recruit(don_id integer, soldier_id integer, cost integer) returns boolean
    language plpgsql
as
$$
declare
      don_family family;
      employee soldier;
    begin
      select into don_family * from (select * from family
        where name=(select don.family from don where don_id=id)) as f;
      select into employee * from (select * from soldier where soldier_id=id) as e;
      if employee.family is null then
          if don_family.budget>=cost then
            update soldier set family=don_family.name where id=soldier_id;
            update family
            set budget=don_family.budget-cost where name=don_family.name;
            return true;
          else
            raise exception 'Unable to recruit % with id %',
              employee.name, soldier_id
              using hint='The family budget is too low';
          end if;
      else
        raise exception 'Unable to recruit % with id %',
          employee.name, soldier_id
          using hint='He may be working for another family';
      end if;
      return null;
    end;
$$;

alter function recruit(integer, integer, integer) owner to s265171;

