create function frid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_ДРУГА := nextval('friends_seq');
	return new;
end
$$;

alter function frid() owner to s225120;

