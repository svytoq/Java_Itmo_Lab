create function print() returns trigger
    language plpgsql
as
$$
BEGIN
		RAISE NOTICE 'Произошло событие: % %', TG_EVENT, TG_TAG;
	END;
$$;

alter function print() owner to s223868;

