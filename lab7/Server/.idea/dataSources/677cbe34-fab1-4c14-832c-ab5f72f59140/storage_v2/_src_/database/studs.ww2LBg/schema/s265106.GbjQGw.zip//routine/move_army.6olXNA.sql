create function move_army(army_id integer, finish_planet integer) returns text
    language plpgsql
as
$$
declare
    start_planet int;
    start_sys    int;
    finish_sys   int;
begin
    select planet_id into strict start_planet from army where id = army_id limit 1;
    select system into strict start_sys from space_objects where space_objects.id = start_planet limit 1;
    select so.system
    into strict finish_sys
    from space_objects as so
             inner join stellar_systems as ss
                        on so.system = ss.id
    where so.id = finish_planet
    limit 1;
    if exists(select 1
              from mas_relays
              where system_1 = finish_sys and system_2 = start_sys
                 or system_1 = start_sys and system_2 = finish_sys) then
        update army set (planet_id) = (finish_planet) where id = army_id;
        return 'ok';
    else
        return 'where aren t mas_relays for this systems';
    end if;
end;
$$;

alter function move_army(integer, integer) owner to s265106;

