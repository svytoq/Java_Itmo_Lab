create function check_order_not_started() returns trigger
    language plpgsql
as
$$
BEGIN
    IF old.project_id IS NOT NULL THEN
        RAISE EXCEPTION 'order already has a project and cannot be changed';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_order_not_started() owner to s264458;

