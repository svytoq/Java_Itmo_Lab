create function check_teams(championship_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    team_size integer;
    cur_team  team%rowtype;
BEGIN
    FOR cur_team IN (SELECT * FROM team WHERE team.championship_id = check_teams.championship_id)
        LOOP
            IF ((SELECT COUNT(*) FROM mentor_team WHERE (mentor_team.team_id = cur_team.team_id)) > 2) THEN
                RAISE EXCEPTION 'Team can not have more than 2 mentors';
            END IF;

            SELECT COUNT(*) FROM participant WHERE team_id = cur_team.team_id INTO team_size;

            IF (team_size < 2) THEN
                RAISE EXCEPTION 'Team can not have less than 2 participants';
            END IF;

            IF (team_size > 5) THEN
                RAISE EXCEPTION 'Team can not have More than 5 participants';
            END IF;

            IF ((SELECT team_id
                 FROM participant
                 WHERE person_id = cur_team.leader_id
                   AND participant.championship_id = cur_team.championship_id) != cur_team.team_id) THEN
                RAISE EXCEPTION 'Leader should be from this team';
            END IF;
        END LOOP;
    RETURN true;
END;
$$;

alter function check_teams(integer) owner to s264448;

