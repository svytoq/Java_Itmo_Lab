create function get_score(integer) returns real
    language plpgsql
as
$$
DECLARE
	row RECORD;
	i RECORD;
	count REAL;
	error BOOLEAN;
BEGIN
	count := 0;
	FOR row IN 
		SELECT * FROM questions WHERE questions.test_id = (SELECT test_id FROM attempts WHERE attempt_id = $1)
	LOOP
		CASE (SELECT question_type_name as A FROM question_types WHERE question_type_id = row.question_type)
			WHEN 'альтернативный выбор' THEN
				IF (SELECT 'true' FROM answers WHERE attempt_id = $1 AND question_id = row.question_id AND answer_text IN (SELECT option_text FROM options WHERE question_id = row.question_id AND option_correct = true)) THEN
					count := count + row.question_cost;
				END IF;
			WHEN 'множественный выбор' THEN
				FOR i IN
					SELECT * FROM answers WHERE attempt_id = $1 AND  question_id = row.question_id
				LOOP
					IF (SELECT 'true' FROM answers WHERE attempt_id = $1 AND answer_text = i.answer_text AND question_id = row.question_id AND answer_text IN (SELECT option_text FROM options WHERE question_id = row.question_id AND option_correct = true)) THEN
						count := count + (cast(row.question_cost AS REAL) / (SELECT count(*) FROM options WHERE question_id = row.question_id AND option_correct = true));
					END IF;
				END LOOP;
			WHEN 'установление последовательности' THEN
				error := 'true';
				FOR i IN
					SELECT * FROM answers WHERE attempt_id = $1 AND question_id = row.question_id
				LOOP
					IF (SELECT 'true' FROM answers WHERE attempt_id = $1 AND answer_text = i.answer_text AND question_id = row.question_id AND answer_number <> (SELECT option_number FROM options WHERE question_id = row.question_id AND option_text = i.answer_text)) THEN
						error := 'false';
					END IF;
				END LOOP;
				IF error THEN 
					count := count + row.question_cost;
				END IF;
			WHEN 'дополнение' THEN
				IF (SELECT 'true' FROM answers WHERE attempt_id = $1 AND question_id = row.question_id AND answer_text IN (SELECT option_text FROM options WHERE question_id = row.question_id AND option_correct = true)) THEN
					count := count + row.question_cost;
				END IF;
			ELSE RAISE EXCEPTION 'Не предусмотрена обработка данного типа вопроса, необходимо редактировать функцию get_scrore(integer).';
		END CASE;
	END LOOP;
	return count;
END;
$$;

alter function get_score(integer) owner to s173525;

