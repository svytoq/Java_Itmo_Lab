create function lgota_passazhira() returns trigger
    language plpgsql
as
$$
DECLARE
      vid_lgoti "ВИДЫ_ЛЬГОТ";
      srok_logot integer;
    BEGIN
      vid_lgoti = (SELECT "Вид_льготы" FROM "Льготники" WHERE "Льготники"."Код_льготы" = new."Код_льготы");
      srok_logot = (SELECT "Срок_действия_льготы" - "Дата_получения_права_на_льготу" FROM "Предоставление_льготы" WHERE "Код_предоставления_льготы" = new."Код_предоставления_льготы");
       
      if(srok_logot <= 0) 
        THEN RAISE EXCEPTION 'Добавление невозможно. Неверный срок льготы';
      end if;
      
      if ( (vid_lgoti = 'Учащийся общеобр. учреждения') AND(srok_logot<365 or srok_logot >3700  ))
        THEN RAISE EXCEPTION 'Добавление невозможно. Срок льготы не соответствует льготе пассажира';
      end if;
      if ( (vid_lgoti = 'Студент очной формы обучения') AND(srok_logot<365 or srok_logot >1500  ))
        THEN RAISE EXCEPTION 'Добавление невозможно. Срок льготы не соответствует льготе пассажира';
       end if;
      if ( (vid_lgoti != 'Учащийся общеобр. учреждения') AND (vid_lgoti != 'Студент очной формы обучения')AND( (srok_logot isnull) = false  ))
        THEN RAISE EXCEPTION 'Добавление невозможно. Срок льготы не соответствует льготе пассажира';
       end if;
      RETURN new;
    end;
$$;

alter function lgota_passazhira() owner to s244710;

