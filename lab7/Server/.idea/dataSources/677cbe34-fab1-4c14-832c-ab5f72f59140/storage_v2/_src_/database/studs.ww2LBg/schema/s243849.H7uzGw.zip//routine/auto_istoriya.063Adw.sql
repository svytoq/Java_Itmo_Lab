create function auto_istoriya() returns trigger
    language plpgsql
as
$$
BEGIN 
	IF (TG_OP = 'DELETE') THEN
		INSERT INTO История_службы (ID_Офицера, ID_Старого_участка, Дата_конца_службы) VALUES (OLD.ID_Офицера, OLD.ID_Участка, now());
		RETURN OLD;
	ELSIF (TG_OP = 'UPDATE') THEN
		INSERT INTO История_службы (ID_Офицера, ID_Нового_участка, ID_Старого_участка, Дата_изменения_службы) VALUES (NEW.ID_Офицера, NEW.ID_Участка, OLD.ID_Участка, now());
		RETURN NEW;
	ELSIF (TG_OP = 'INSERT') THEN 
		INSERT INTO История_службы (ID_Офицера, ID_Нового_участка, Дата_начала_службы) VALUES (NEW.ID_Офицера, NEW.ID_Участка, now());
		RETURN NEW;
	END IF;
	RETURN NULL;
END;
$$;

alter function auto_istoriya() owner to s243849;

