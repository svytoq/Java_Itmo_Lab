create function person_leaving() returns trigger
    language plpgsql
as
$$
DECLARE
    new_order_id integer;
BEGIN
    UPDATE person SET arrival_date = NULL, station = NULL, on_station = NULL WHERE person_id = NEW.person_id;
    INSERT INTO orders(to_Antarctida) VALUES (false) RETURNING new_order_id = order_id;
    INSERT INTO order_position(type, order_id, person_id) VALUES (order_type('person'), new_order_id, NEW.person_id);
    RETURN NEW;
END;
$$;

alter function person_leaving() owner to s265113;

