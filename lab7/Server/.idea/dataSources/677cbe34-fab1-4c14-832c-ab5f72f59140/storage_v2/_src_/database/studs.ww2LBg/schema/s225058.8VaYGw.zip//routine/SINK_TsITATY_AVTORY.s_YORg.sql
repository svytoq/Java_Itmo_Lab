create function "СИНК_ЦИТАТЫ_АВТОРЫ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.АВТОР!=0 THEN
IF (select not exists(select ИД from АВТОРЫ where ИД=new.АВТОР))=true then 
IF currval('АВТОРЫ_ИД_seq')!=NEW.АВТОР THEN
    NEW.АВТОР=nextval('АВТОРЫ_ИД_seq');
END IF; 
Insert into АВТОРЫ (ИД, ИМЯ) values (new.АВТОР, 'tochange');
END IF;   
RETURN NEW;
END IF;
RETURN NEW;
    END;
$$;

alter function "СИНК_ЦИТАТЫ_АВТОРЫ"() owner to s225058;

