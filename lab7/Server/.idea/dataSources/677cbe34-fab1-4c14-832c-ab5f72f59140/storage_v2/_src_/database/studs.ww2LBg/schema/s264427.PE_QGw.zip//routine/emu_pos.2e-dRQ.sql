create function emu_pos(wmode boolean)
    returns TABLE(emu_group_id integer, info_group text, square_with_emu integer)
    language plpgsql
as
$$
DECLARE
emu_group_size integer = 0;
info_target_group text;
now_square integer;
counter integer = 0;
writable boolean;
BEGIN
	SELECT count(*) INTO STRICT emu_group_size FROM emu_group;
	while counter < emu_group_size
	LOOP
		counter := counter + 1;
		SELECT ((disbandment_date IS NULL) = wmode) INTO STRICT writable FROM EMU_GROUP where EMU_GROUP.group_id = counter;
		IF (writable) THEN
			emu_group_id = counter;
			IF (wmode=true) THEN
				SELECT to_char(quantity, '9999') INTO STRICT info_target_group FROM emu_group where group_id = counter;
			ELSE
				SELECT to_char(disbandment_date, 'yyyy.mm.dd') INTO STRICT info_target_group FROM emu_group where group_id = counter;
			END IF;
			info_group = info_target_group;
			SELECT square_number INTO STRICT now_square FROM Migration_Data where Migration_Data.emu_group_id = counter ORDER BY migration_data_id DESC LIMIT 1;
			square_with_emu = now_square;
			RETURN next;
		END IF;
	END LOOP;
END;
$$;

alter function emu_pos(boolean) owner to s264427;

