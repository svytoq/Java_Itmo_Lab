create function "autoid_ГЕРОИ"() returns trigger
    language plpgsql
as
$$
DECLARE prevID smallint;
BEGIN
	IF (SELECT count(*) FROM ГЕРОИ) = 0 THEN
		NEW.ИД_ГЕРОЯ = 1;	
	ELSE
		prevID = (SELECT ИД_ГЕРОЯ FROM ГЕРОИ WHERE ИД_ГЕРОЯ = (SELECT MAX(ИД_ГЕРОЯ) FROM ГЕРОИ));
		NEW.ИД_ГЕРОЯ = prevID + 1;
	END IF;
	RETURN NEW;
END;
$$;

alter function "autoid_ГЕРОИ"() owner to s225123;

