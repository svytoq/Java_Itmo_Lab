create function getpowerhero(mode integer, name text) returns integer
    language plpgsql
as
$$
DECLARE
	power integer;
BEGIN
	IF $1 = 1 then
		select СИЛА_В_ЗАЩИТЕ into power from ЛИДЕР where ЛИДЕР.ИМЯ = $2;
	else
		select СИЛА_В_АТАКЕ into power from ЛИДЕР where ЛИДЕР.ИМЯ = $2;
	end if;
	return power;
END;
$$;

alter function getpowerhero(integer, text) owner to s264430;

