create function check_if_battle_artist() returns trigger
    language plpgsql
as
$$
DECLARE
    artist_type ARTIST_TYPES;
BEGIN
    SELECT a.ARTIST_TYPE INTO artist_type FROM artists AS a WHERE a.WORKER_ID = NEW.WORKER_ID;
    IF artist_type = 'battle artist' THEN
        INSERT INTO trigger_info(TG_OP, TG_RELNAME, TG_NAME, CREATION_TIME) VALUES(TG_OP, TG_RELNAME, TG_NAME, NOW());
        RETURN NEW;
    ELSE
        RETURN NULL;
    END IF;
END
$$;

alter function check_if_battle_artist() owner to s263229;

