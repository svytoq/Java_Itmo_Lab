create function check_firm_engine() returns trigger
    language plpgsql
as
$$
DECLARE
  rec INTEGER;
BEGIN

  rec := (SELECT firm.id FROM firm WHERE NEW.id_firm = firm.id AND firm.specialization = 'Tank');
  IF rec is not NULL THEN
    RAISE EXCEPTION 'Firm % cannot create engines', NEW.id_firm;
  END IF;

  RETURN NEW;

END;
$$;

alter function check_firm_engine() owner to s243858;

