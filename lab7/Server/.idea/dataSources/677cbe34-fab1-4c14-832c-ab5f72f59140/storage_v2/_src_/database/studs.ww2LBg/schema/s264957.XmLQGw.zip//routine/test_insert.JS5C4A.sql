create function test_insert() returns trigger
    language plpgsql
as
$$
BEGIN insert into participant values(NEW.participant_id, null, null, null, null, null, null, null, null) ON CONFLICT DO NOTHING;
    RETURN NEW;
    end;
$$;

alter function test_insert() owner to s264957;

