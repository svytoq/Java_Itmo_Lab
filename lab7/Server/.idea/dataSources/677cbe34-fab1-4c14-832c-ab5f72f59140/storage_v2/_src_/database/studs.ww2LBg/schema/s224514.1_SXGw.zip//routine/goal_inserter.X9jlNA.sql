create function goal_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	i INTEGER DEFAULT 1;
	id_match integer default 1;
	id_player integer default 1;
	time_of_goal timestamp default '2018-07-06 00:00:00';
	Goal text;
	typeGoal text[] = '{Пенальти, Обычный, Овертайм, Технический, Автогол}';
  maxNmatch integer;
	maxNplayer integer;
BEGIN
	Select count(ИД_МАТЧА) from МАТЧ into maxNmatch;
	Select count(ИД_ИГРОКА) from ИГРОК into maxNplayer;
  if (N / 7) > maxNmatch THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "МАТЧ"';
	END if;
	if (N / 7) > maxNplayer THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "ИГРОК"';
	END if;
	for i in 1..N loop
	if i % 7 = 0 THEN
		id_match = id_match + 1;
		Goal = typeGoal[i % 10 + 1];
	END IF;
		insert into "ГОЛ" values(DEFAULT, id_match, id_player, time_of_goal, CAST(Goal AS type_of_goal));
		time_of_goal = time_of_goal + interval '20 minutes';
		id_player = id_player + 1;
	end loop;
END;
$$;

alter function goal_inserter(integer) owner to s224514;

