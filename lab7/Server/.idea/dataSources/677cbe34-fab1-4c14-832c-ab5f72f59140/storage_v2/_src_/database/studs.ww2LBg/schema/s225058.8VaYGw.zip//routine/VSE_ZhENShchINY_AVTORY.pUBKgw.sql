create function "ВСЕ_ЖЕНЩИНЫ_АВТОРЫ"()
    returns TABLE("ИМЯ" character varying, "ФАМИЛИЯ" character varying, "ОТЧЕСТВО" character varying, "ДАТА_РОЖДЕНИЯ" date, "ДАТА_СМЕРТИ" date, "СТРАНА" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT АВТОРЫ.ИМЯ, АВТОРЫ.ФАМИЛИЯ, АВТОРЫ.ОТЧЕСТВО, АВТОРЫ.ДАТА_РОЖДЕНИЯ, АВТОРЫ.ДАТА_СМЕРТИ, АВТОРЫ.СТРАНА 
FROM АВТОРЫ WHERE ПОЛ='Ж';
END;
$$;

alter function "ВСЕ_ЖЕНЩИНЫ_АВТОРЫ"() owner to s225058;

