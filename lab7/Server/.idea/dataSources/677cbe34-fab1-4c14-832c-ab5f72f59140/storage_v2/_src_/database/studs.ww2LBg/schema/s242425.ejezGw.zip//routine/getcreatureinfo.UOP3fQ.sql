create function getcreatureinfo(id integer)
    returns TABLE(id integer, type text, name text, description text)
    language sql
as
$$
select
        ing.ИД_СУЩЕСТВА as id,
        (case
        when (isAlive(ing.ИД_ИНГРЕДИЕНТА) = true)
            then
                ('alive creature')
            else
                ('mineral creature')
        end) as type,
        (case
        when (isAlive(ing.ИД_ИНГРЕДИЕНТА) = true)
            then
                (
                    select ВИД
                    from ЖИВОЕ_СУЩЕСТВО as m
                    where m.ИД_СУЩЕСТВА = ing.ИД_СУЩЕСТВА
                )
            else
                (
                    select ХИМИЧЕСКИЙ_ТИП
                    from МИНЕРАЛЬНОЕ_ВЕЩЕСТВО as m
                    where m.ИД_СУЩЕСТВА = ing.ИД_СУЩЕСТВА
                )
        end) as name,
        (case
        when (isAlive(ing.ИД_ИНГРЕДИЕНТА) = true)
            then
                (
                    select КЛАСС
                    from ЖИВОЕ_СУЩЕСТВО as m
                    where m.ИД_СУЩЕСТВА = ing.ИД_СУЩЕСТВА
                )
            else
                (
                    select ОПИСАНИЕ
                    from МИНЕРАЛЬНОЕ_ВЕЩЕСТВО as m
                    where m.ИД_СУЩЕСТВА = ing.ИД_СУЩЕСТВА
                )
        end) as description
    from ИНГРЕДИЕНТ as ing
    where ing.ИД_ИНГРЕДИЕНТА = id;
$$;

alter function getcreatureinfo(integer) owner to s242425;

