create function get_reserved_food(reverse_health_of integer, name_food_of s225096.type_of_food, kind integer, id integer) returns integer
    language plpgsql
as
$$
DECLARE
	available_food_of INTEGER;
BEGIN
			SELECT count_of_food INTO available_food_of FROM food WHERE name_of_food= name_food_of;
			IF (available_food_of < reverse_health_of)
				THEN
				RAISE NOTICE 'AAA! ACHTUNG!';
  			INSERT INTO global_problem (id_of_kind, id_of_passenger, type) VALUES (kind, id, 'hunger');
					UPDATE food SET count_of_food = 0 WHERE name_of_food = name_food_of;
				ELSE
					UPDATE food SET count_of_food = count_of_food - reverse_health_of WHERE name_of_food = name_food_of;
					available_food_of := reverse_health_of;
			END IF;
  RETURN available_food_of;
END;
$$;

alter function get_reserved_food(integer, s225096.type_of_food, integer, integer) owner to s225096;

