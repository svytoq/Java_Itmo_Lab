create function buy_weapon(hunter integer, weapon integer) returns text
    language plpgsql
as
$$
DECLARE
    weapon_store_id int;
  BEGIN
    SELECT store_id INTO weapon_store_id FROM Weapon as w WHERE id = weapon;
    
    IF NOT FOUND OR weapon_store_id IS NULL THEN
      RAISE EXCEPTION 'You can`t buy this weapon in store';
    END IF;
    
    INSERT INTO Deal (hunter_id, store_id, weapon_id, is_buying) VALUES
    (hunter, weapon_store_id, weapon, 't');
    RETURN 'You`ve got new weapon. Try it out ASAP!!!';
  END;
$$;

alter function buy_weapon(integer, integer) owner to s263081;

