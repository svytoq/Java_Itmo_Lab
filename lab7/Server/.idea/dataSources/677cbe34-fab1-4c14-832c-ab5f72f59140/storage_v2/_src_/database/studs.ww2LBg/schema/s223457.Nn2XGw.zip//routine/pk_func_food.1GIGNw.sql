create function pk_func_food() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_food');
  RETURN new;
END;
$$;

alter function pk_func_food() owner to s223457;

