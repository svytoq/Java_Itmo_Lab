create function get_first_not_claimed_unit() returns integer
    language plpgsql
as
$$
DECLARE
	unit int;
BEGIN
	SELECT id INTO STRICT unit
		FROM unit_instances
		WHERE (NOT is_unit_instance_claimed(id))
		LIMIT 1;

	RETURN unit;
END;
$$;

alter function get_first_not_claimed_unit() owner to s244711;

