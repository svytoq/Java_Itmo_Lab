create function declarewar() returns trigger
    language plpgsql
as
$$
begin
      if new.relationship='B' then
        insert into war(duration, first_family, second_family)
        values ('5 days', new.first_family, new.second_family);
        update family set war_id=(select currval('"war_id_seq"'))
        where name=new.first_family or name=new.second_family;
      end if;
      return null;
    end;
$$;

alter function declarewar() owner to s263895;

