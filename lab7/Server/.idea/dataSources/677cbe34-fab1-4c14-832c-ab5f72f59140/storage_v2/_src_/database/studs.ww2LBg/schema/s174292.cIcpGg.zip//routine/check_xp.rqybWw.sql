create function check_xp() returns trigger
    language plpgsql
as
$$
BEGIN
    if ((select s174292.witcher.xp from s174292.witcher where s174292.witcher.id = NEW.id) >= 1000) then
        if ((select s174292.witcher.level from s174292.witcher where s174292.witcher.id = NEW.id) < 100) then
            update s174292.witcher
            set level=least(level + 1, 100),
                hp=least(hp + 20, 1000),
                mp=least(mp + 20, 1000),
                xp=xp - 1000
            where s174292.witcher.id = NEW.id;
        else
            update s174292.witcher set xp=xp - 1000 where s174292.witcher.id = NEW.id;
        end if;
    end if;
    return NEW;
end
$$;

alter function check_xp() owner to s174292;

