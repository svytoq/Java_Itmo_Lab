create function moneyprogramms() returns trigger
    language plpgsql
as
$$
declare money integer;
begin
	money:= 3000;
	update СОТРУДНИКИ set ОКЛАД = (ОКЛАД + money) where ИД_СОТРУДНИКА = new.ИД_СОТРУДНИКА;
	return new;
end;
$$;

alter function moneyprogramms() owner to s225120;

