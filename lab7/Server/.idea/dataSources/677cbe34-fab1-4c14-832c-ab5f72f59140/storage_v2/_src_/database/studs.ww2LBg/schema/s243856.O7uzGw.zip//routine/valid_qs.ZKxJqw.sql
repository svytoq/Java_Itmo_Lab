create function valid_qs() returns trigger
    language plpgsql
as
$$
BEGIN 
IF NOT is_prison_room_matches(NEW.id_creature) THEN 
RAISE EXCEPTION 'Invalid room for prisoner %', NEW.id_creature
USING HINT = 'Creature should be prisoned in more protected prison room';
END IF;
RETURN NEW;
END;
$$;

alter function valid_qs() owner to s243856;

