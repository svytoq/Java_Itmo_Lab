create function check_student_teacher_duplicate_function() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE DEBUG 'Trigger function check_student_teacher_duplicate_function() fired';
    IF EXISTS(
            SELECT 1
            FROM teachers
            WHERE teachers.id = new.id
        )
    THEN
        RAISE WARNING 'Student with id % already exists as teacher',
            new.id;
        RETURN NULL;
    ELSE
        RETURN new;
    END IF;
END;
$$;

alter function check_student_teacher_duplicate_function() owner to s268925;

