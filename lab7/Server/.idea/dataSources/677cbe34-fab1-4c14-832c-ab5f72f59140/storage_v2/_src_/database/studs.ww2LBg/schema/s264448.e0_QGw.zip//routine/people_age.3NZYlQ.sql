create function people_age(person integer) returns integer
    language plpgsql
as
$$
DECLARE
    age integer;

BEGIN
    SELECT date_part('year', age(birth_date))
    INTO age
    FROM people
    WHERE person_id = person;

    RETURN age;
END;

$$;

alter function people_age(integer) owner to s264448;

