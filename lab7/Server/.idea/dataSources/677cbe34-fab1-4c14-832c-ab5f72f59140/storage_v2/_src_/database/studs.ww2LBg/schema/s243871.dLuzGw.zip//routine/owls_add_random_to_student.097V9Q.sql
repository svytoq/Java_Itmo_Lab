create function owls_add_random_to_student(in_student_id bigint) returns void
    language plpgsql
as
$$
begin
with available_owls as (
select o.impl, o.occurrence from owls o
inner join students s on s.id = in_student_id and s.level >= o.level
), rand as (
select random() * (select sum(occurrence) from available_owls) r
)
insert into owls_students as os (student_id, owl_impl, owl_count, active_stages_left)
select in_student_id, sample.impl, 1, null
from (
-- https://stackoverflow.com/a/13040717/1726690
select impl, sum(occurrence) over (order by impl) occ, r
from available_owls
cross join rand
) as sample
where sample.occ > sample.r
order by sample.impl
limit 1
on conflict (student_id, owl_impl)
do update set owl_count = os.owl_count + 1;
end;
$$;

alter function owls_add_random_to_student(bigint) owner to s243871;

