create function prolong_book(reader_last_name character varying, book_title text, new_due_date date) returns void
    language plpgsql
as
$$
declare
    due_id int;
begin
    select bb.borrow_id
    into due_id
    from readers r
             natural join borrowed_books bb
             natural join books b
    where r.last_name = reader_last_name
      and b.title = book_title
      and bb.return_date is null;
    update borrowed_books set due_date = new_due_date where borrow_id = due_id;
end;
$$;

alter function prolong_book(varchar, text, date) owner to s265089;

