create function to_place(count integer) returns void
    language plpgsql
as
$$
DECLARE
  country VARCHAR(25);
  area    VARCHAR(30);
  address TEXT;
BEGIN
  FOR I IN 1..count LOOP
    IF I%2= 0 THEN
    country = 'РИМСКАЯ РЕСПУБИКА';
      IF I%3 = 0 THEN
        area = 'ПОМПЕИ';
                address = 'ДОМ_'||I/6;
        ELSEIF I%5 = 0 THEN
        area = 'КУРИОН';
        address = 'ДОМ_'||I/10;
        ELSE area = 'РИМ';
        address = 'ДОМ_'||I/2;
    END IF;
      ELSEIF I%3=0 AND I%2!=0 THEN
      country ='ЕИПЕТ';
      AREA ='АЛЕКСАНДРИЯ';
      address = 'ПОМЕЩЕНИЕ_'||I/3;
      ELSE
           country ='ГРЕЦИЯ';
      AREA ='СПАРТА';
      address = 'ЗДАНИЕ_'||I;

      END IF;
        INSERT INTO МЕСТОПОЛОЖЕНИЕ VALUES (DEFAULT, country, area, address);

  END LOOP;
  EXCEPTION WHEN OTHERS
  THEN RAISE;
END;
$$;

alter function to_place(integer) owner to s225081;

