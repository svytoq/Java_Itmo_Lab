create function user_go_up() returns trigger
    language plpgsql
as
$$
BEGIN
		IF (NEW.Дата_Выхода is not null AND OLD.Дата_Выхода is null) THEN
			NEW.Дата_Выхода := current_timestamp;
		END IF;
		RETURN NEW;
		END;
$$;

alter function user_go_up() owner to s243870;

