create function сгенерировать_группы(count integer) returns void
    language plpgsql
as
$$
BEGIN
        FOR i in 1 .. count LOOP
                insert into Группы(название) values(random_string(10));
        END LOOP;
END;
$$;

alter function сгенерировать_группы(integer) owner to s242395;

