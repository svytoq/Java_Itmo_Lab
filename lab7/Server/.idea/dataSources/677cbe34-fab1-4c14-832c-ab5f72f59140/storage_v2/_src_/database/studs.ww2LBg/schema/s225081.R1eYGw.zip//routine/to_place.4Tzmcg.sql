create function to_place(count integer, rand character varying) returns void
    language plpgsql
as
$$
DECLARE
country VARCHAR(25);
area VARCHAR(30);
address text;
  K INT;
BEGIN
  FOR I IN 1..count LOOP
country = random()::VARCHAR(25);
area = random()::VARCHAR(30) ;
    address = random()::VARCHAR(30);
      INSERT INTO МЕСТОПОЛОЖЕНИЕ VALUES ( DEFAULT, country, area,address);

END LOOP ;
EXCEPTION WHEN OTHERS THEN RAISE ;
  END ;
$$;

alter function to_place(integer, varchar) owner to s225081;

