create function create_message(sender_id_in integer, order_id_in integer, message text) returns text
    language plpgsql
as
$$
begin
    insert into message(message_text, sender_id, order_id, send_datetime)
    values (message, sender_id_in, order_id_in, current_timestamp);
    return 'message created';
end
$$;

alter function create_message(integer, integer, text) owner to s264451;

