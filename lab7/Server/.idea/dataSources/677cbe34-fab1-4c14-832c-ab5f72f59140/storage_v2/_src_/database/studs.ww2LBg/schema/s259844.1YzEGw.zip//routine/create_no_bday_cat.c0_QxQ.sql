create function create_no_bday_cat(cat_name text, breed_name text, cat_sex character, cat_color integer) returns s259844.cat
    language plpgsql
as
$$
DECLARE
BEGIN
    RETURN (SELECT create_cat(cat_name, breed_name , NULL, cat_sex, cat_color));
END;
$$;

alter function create_no_bday_cat(text, text, char, integer) owner to s259844;

