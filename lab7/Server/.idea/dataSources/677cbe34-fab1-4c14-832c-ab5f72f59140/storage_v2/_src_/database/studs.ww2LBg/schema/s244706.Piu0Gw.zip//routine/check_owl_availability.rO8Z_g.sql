create function check_owl_availability() returns trigger
    language plpgsql
as
$$
declare
  is_in_flight      boolean;
  is_being_repaired boolean;
begin
  is_in_flight := (select exists(
      select from delivery_owl_flights
      where owl_id = new.owl_id
        and ((returned_on is null and (new.returned_on is null or departed_on < new.returned_on))
        or (departed_on, returned_on) overlaps (new.departed_on, new.returned_on))));

  is_being_repaired := (select exists(
      select from delivery_owl_repair_jobs
      where owl_id = new.owl_id
        and ((finished_on is null and (new.returned_on is null or began_on < new.returned_on))
        or (began_on, finished_on) overlaps (new.departed_on, new.returned_on))));

  if is_in_flight
  then raise exception 'The requested owl is in flight during the requested time period';
  end if;
  if is_being_repaired
  then raise exception 'The requested owl is being repaired during the requested time period';
  end if;

  return new;
end;
$$;

alter function check_owl_availability() owner to s244706;

