create function add_to_com_news(n integer) returns void
    language plpgsql
as
$$
DECLARE
 SER INTEGER;
  AUTH INTEGER;
  CONT TEXT;
  DAT TIMESTAMP;
  ONCOM INTEGER;
  I INTEGER;
BEGIN
 FOR I IN 1..N LOOP
    SER = 19+I;
   AUTH = 18+I;
   CONT = 'COMMENT_TO_NEWS'||I;
   SELECT NOW() INTO DAT;
   INSERT INTO comment_on_news VALUES (DEFAULT ,SER,AUTH, CONT, DAT,NULL);
   ONCOM=I;
    INSERT INTO comment_on_news VALUES (DEFAULT,SER,AUTH, CONT, DAT,ONCOM);
 END LOOP;
END;

$$;

alter function add_to_com_news(integer) owner to s225081;

