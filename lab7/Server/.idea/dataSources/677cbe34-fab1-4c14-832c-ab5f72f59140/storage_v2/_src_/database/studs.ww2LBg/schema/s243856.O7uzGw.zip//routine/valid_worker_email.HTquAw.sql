create function valid_worker_email() returns trigger
    language plpgsql
as
$$
begin
  if not is_valid_email(new.email, false) then
    raise exception 'Invalid worker email %, that email belongs to the student', new.email;
  end if;
  return new;
end;
$$;

alter function valid_worker_email() owner to s243856;

