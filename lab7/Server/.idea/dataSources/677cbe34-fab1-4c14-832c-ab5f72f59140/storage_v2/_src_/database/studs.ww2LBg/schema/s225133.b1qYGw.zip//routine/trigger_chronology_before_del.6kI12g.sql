create function trigger_chronology_before_del() returns trigger
    language plpgsql
as
$$
BEGIN

    if (select count(*) from "Магия" a
    where a."id_хронологии"=OLD."id")>0
        then delete from "Магия" where "Магия"."id_хронологии"=OLD."id";
    end if;

    if (select count(*) from "Экипировка" a
    where a."id_хронологии"=OLD."id")>0
        then delete from "Экипировка" where "Экипировка"."id_хронологии"=OLD."id";
    end if;

    if (select count(*) from "Войско" a
    where a."id_хронологии"=OLD."id")>0
        then delete from "Войско" where "Войско"."id_хронологии"=OLD."id";
    end if;

    return OLD;
END;
$$;

alter function trigger_chronology_before_del() owner to s225133;

