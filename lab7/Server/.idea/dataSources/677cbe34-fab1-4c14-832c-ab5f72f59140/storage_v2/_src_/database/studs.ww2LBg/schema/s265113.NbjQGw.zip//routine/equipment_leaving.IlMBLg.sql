create function equipment_leaving() returns trigger
    language plpgsql
as
$$
DECLARE
    new_order_id integer;
BEGIN
    UPDATE equipment SET station = NULL WHERE equipment_id = NEW.equipment_id;
    INSERT INTO orders(to_Antarctida) VALUES (false) RETURNING new_order_id = order_id;
    INSERT INTO order_position(type, order_id, equipment_type) VALUES (order_type('equipment'), new_order_id, NEW.type);
    RETURN NEW;
END;
$$;

alter function equipment_leaving() owner to s265113;

