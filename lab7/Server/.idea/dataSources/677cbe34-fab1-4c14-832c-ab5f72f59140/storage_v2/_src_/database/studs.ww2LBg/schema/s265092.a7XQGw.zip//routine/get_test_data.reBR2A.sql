create function get_test_data()
    returns TABLE(mage_id integer, devil_id smallint, mage_name character varying, new_devil character varying, res boolean)
    language plpgsql
as
$$
BEGIN
RETURN QUERY
SELECT T.MAGE_ID, T.DEVIL_ID, M.NAME, D.NAME, T.RESULT FROM TEST T LEFT JOIN MAGE M USING(MAGE_ID) LEFT JOIN DEVIL D USING(DEVIL_ID);
    END;
$$;

alter function get_test_data() owner to s265092;

