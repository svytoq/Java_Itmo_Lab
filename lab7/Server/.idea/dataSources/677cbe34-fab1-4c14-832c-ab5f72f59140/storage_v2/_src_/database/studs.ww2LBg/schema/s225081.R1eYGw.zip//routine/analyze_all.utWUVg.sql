create function analyze_all(schem character varying) returns void
    language plpgsql
as
$$
DECLARE
  J VARCHAR(35);
BEGIN
  FOR J IN SELECT DISTINCT table_name
           FROM
             information_schema.columns
           WHERE
             table_schema = schem LOOP
    VACUUM ANALYSE J;
  END LOOP;
END;
$$;

alter function analyze_all(varchar) owner to s225081;

