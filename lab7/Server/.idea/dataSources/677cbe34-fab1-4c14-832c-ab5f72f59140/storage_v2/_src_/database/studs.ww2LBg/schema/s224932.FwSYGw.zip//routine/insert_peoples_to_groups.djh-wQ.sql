create function insert_peoples_to_groups() returns void
    language plpgsql
as
$$
DECLARE
        people record;
        groups record;
BEGIN
        FOR groups IN (SELECT ид from Группы)
        LOOP
                FOR people IN (SELECT ид from Люди)
                LOOP
                        insert into Люди_Группы 
                                values(people.ид,groups.ид);
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_peoples_to_groups() owner to s224932;

