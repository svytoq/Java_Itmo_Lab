create function "ДАТА_ТЕМА_АВТОЗАП_ФУНК"() returns trigger
    language plpgsql
as
$$
BEGIN

IF NEW.ТЕМА IS NULL THEN
NEW.ТЕМА = '(Без темы)';
END IF;

NEW.ДАТА = CURRENT_DATE;
RETURN NEW;
END;
$$;

alter function "ДАТА_ТЕМА_АВТОЗАП_ФУНК"() owner to s269331;

