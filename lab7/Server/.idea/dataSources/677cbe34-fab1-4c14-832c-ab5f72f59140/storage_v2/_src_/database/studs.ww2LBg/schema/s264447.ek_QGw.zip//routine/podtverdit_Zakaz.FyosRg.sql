create function "подтвердитьЗаказ"("заказ" integer) returns void
    language plpgsql
as
$$
declare
сегодня int;
begin
    select (добавитьКЗаказу(int,0));
    сегодня := (select id from Доставки where дата_отправления=now()::DATE);
    update ЛабораторныеИсследования
    set доставка_id=сегодня
    where заказ_id=заказ;
    commit;
end;
$$;

alter function "подтвердитьЗаказ"(integer) owner to s264447;

