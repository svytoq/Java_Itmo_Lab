create function insert_users(count integer) returns void
    language plpgsql
as
$$
BEGIN
        FOR i in 1 .. count LOOP
                insert into Пользователи(логин, пароль, фио, дата_регистрации)
                 values (random_string(10), random_string(10),random_string(20),random_date());
        END LOOP;
END;
$$;

alter function insert_users(integer) owner to s224932;

