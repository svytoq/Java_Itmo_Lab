create function new_user() returns trigger
    language plpgsql
as
$$
BEGIN
INSERT INTO "К_ГМы"(Id, Ник) VALUES(NEW.Id, NEW.Логин);
INSERT INTO "К_Игроки"(Id, Ник) VALUES(NEW.Id, NEW.Логин);

RETURN NEW;
END;
$$;

alter function new_user() owner to s242193;

