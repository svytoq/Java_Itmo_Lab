create function trigger_winner_takes_all() returns trigger
    language plpgsql
as
$$
BEGIN
      if
      (
          select count(*)
          from Битва, "Экипировка"
          where "Экипировка".id_героя="Битва".id_победителя AND "Битва".id=NEW."Битва"
      )=0
      THEN
            INSERT INTO "Экипировка" (id_героя, id_хронологии)VALUES
            (
              (
               select "Битва".id_победителя
               from "Битва"
               where "Битва".id=NEW."Битва"
              ),
              NEW.id
            );
      ELSE


          UPDATE "Экипировка" SET id_хронологии = NEW."id"
          WHERE id_хронологии =
           (
               select id_хронологии
               from "Хронология", "Битва", "Артефакт"
               where "Битва".id=NEW."Битва" AND "Экипировка".id_героя="Битва".id_победителя LIMIT 1
           );
      END IF;

      UPDATE "Артефакт" SET id_экипировки =
      (
        select "Экипировка".id
        from Битва, "Экипировка", "Артефакт"
        where "Битва".id=NEW."Битва" AND "Экипировка".id_героя="Битва".id_победителя AND "Артефакт".id="Битва"."Артефакт" LIMIT 1
      )

      WHERE id_экипировки =
      (
        select id_экипировки
        from Битва, "Экипировка", "Артефакт"
        where "Битва".id=NEW."Битва" AND "Экипировка".id_героя="Битва".id_проигравшего AND "Артефакт".id="Битва"."Артефакт" LIMIT 1
      );











    if
      (
          select count(*)
          from Битва, "Магия"
          where "Магия".id_героя="Битва".id_победителя AND "Битва".id=NEW."Битва"
      )=0
      THEN
            INSERT INTO "Магия" ("Название", "Атака", "Защита", "Восстановление", "Бонус", "Проклятие", id_героя, id_хронологии) VALUES
            (
              (
               select "Магия"."Название"
               from "Битва", "Магия"
               where "Битва".id=NEW."Битва" AND "Магия".id_героя="Битва".id_проигравшего ORDER BY id_героя DESC LIMIT 1
              ),

              (
               select "Магия"."Атака"
               from "Битва", "Магия"
               where "Битва".id=NEW."Битва" AND "Магия".id_героя="Битва".id_проигравшего ORDER BY id_героя DESC LIMIT 1
              ),

              (
               select "Магия"."Защита"
               from "Битва", "Магия"
               where "Битва".id=NEW."Битва" AND "Магия".id_героя="Битва".id_проигравшего ORDER BY id_героя DESC LIMIT 1
              ),

              (
               select "Магия"."Восстановление"
               from "Битва", "Магия"
               where "Битва".id=NEW."Битва" AND "Магия".id_героя="Битва".id_проигравшего ORDER BY id_героя DESC LIMIT 1
              ),

              (
               select "Магия"."Бонус"
               from "Битва", "Магия"
               where "Битва".id=NEW."Битва" AND "Магия".id_героя="Битва".id_проигравшего ORDER BY id_героя DESC LIMIT 1
              ),

              (
               select "Магия"."Проклятие"
               from "Битва", "Магия"
               where "Битва".id=NEW."Битва" AND "Магия".id_героя="Битва".id_проигравшего ORDER BY id_героя DESC LIMIT 1
              ),

              (
               select "Битва".id_победителя
               from "Битва"
               where "Битва".id=NEW."Битва"
              ),
              NEW.id
            );
      ELSE


          UPDATE "Магия" SET id_хронологии = NEW."id"
          WHERE id_хронологии =
           (
               select id_хронологии
               from "Хронология", "Битва", "Магия"
               where "Битва".id=NEW."Битва" AND "Магия".id="Битва"."Магия" LIMIT 1
           );
      END IF;

      UPDATE "Магия" SET id_героя =
      (
        select "Битва".id_победителя
        from Битва
        where "Битва".id=NEW."Битва"
      )

      WHERE id_героя =
      (
        select "Битва".id_проигравшего
        from Битва, "Магия"
        where "Битва".id=NEW."Битва" AND "Магия".id_хронологии=NEW.id AND "Магия".id="Битва"."Магия"
      );





















    return NEW;
END;
$$;

alter function trigger_winner_takes_all() owner to s225133;

