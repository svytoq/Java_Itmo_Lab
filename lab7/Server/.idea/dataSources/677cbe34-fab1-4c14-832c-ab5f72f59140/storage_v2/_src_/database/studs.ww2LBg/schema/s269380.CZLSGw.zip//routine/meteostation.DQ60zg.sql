create function meteostation() returns trigger
    language plpgsql
as
$$
BEGIN
        if NEW.Широта < 0 then
            Raise exception 'Широта < 0';
        end if;
        if NEW.Долгота < 0 then
            Raise exception 'Долгота < 0';
        end if;
        if NEW.Атм_давление < 0 then
            Raise exception 'Атм_давление < 0';
        end if;
        if NEW.Температура not between -80 and 55  then
            Raise exception 'Температура < -80 или > 55';
        end if;

        if NEW.Влажность not between 0 and 100  then
            Raise exception 'Влажность < 0 или > 100';
        end if;
        if NEW.Скорость_Ветра < 0 then
            Raise exception 'Скорость_Ветра < 0';
        end if;
        if NEW.Освещенность < 0 then
            Raise exception 'Освещенность < 0';
        end if;

        RETURN NEW;
    END;
$$;

alter function meteostation() owner to s269380;

