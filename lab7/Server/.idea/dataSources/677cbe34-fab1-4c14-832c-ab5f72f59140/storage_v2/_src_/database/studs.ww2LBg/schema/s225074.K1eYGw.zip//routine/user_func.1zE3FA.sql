create function user_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.user_id:= NEXTVAL('user_seq');
RETURN new;
END;
$$;

alter function user_func() owner to s225074;

