create function checkforms() returns trigger
    language plpgsql
as
$$
DECLARE
    form1 varchar(50);
    form2 varchar(50);
  BEGIN
    SELECT ЦВЕТ_ФОРМЫ_ИГРОКОВ INTO form1
    FROM ФОРМА_ИГРОКОВ
    WHERE ИД_ФОРМЫ_ИГРОКОВ = NEW.ИД_ФОРМЫ_ИГРОКОВ_1СТРАНЫ;

    SELECT ЦВЕТ_ФОРМЫ_ИГРОКОВ INTO form2
    FROM ФОРМА_ИГРОКОВ
    WHERE ИД_ФОРМЫ_ИГРОКОВ = NEW.ИД_ФОРМЫ_ИГРОКОВ_2СТРАНЫ;

    if (form1 != form2) THEN
      return NEW;
    ELSE RAISE EXCEPTION 'Цвет формы игроков совпадает!!';
    END IF;
  END;
$$;

alter function checkforms() owner to s224514;

