create function ins_epizod() returns trigger
    language plpgsql
as
$$
DECLARE
  cause text;
  problem text;
  decision text;
  cause2 text [];
  problem2 text [];
  decision2 text [];
  idi INTEGER;
  i integer DEFAULT 0;
  slova integer [];
  y integer;
  x text;
BEGIN
  IF tg_op!='DELETE' THEN
    IF NEW.ПРИЧИНА is not null THEN
      cause=NEW.ПРИЧИНА;
      cause=lower(cause);
      cause2 = regexp_split_to_array(cause, '(\. |, | |,|\.)');
    END IF;
    IF NEW.ПРОБЛЕМА is not null THEN
      problem=NEW.ПРОБЛЕМА;
      problem=lower(problem);
      problem2 = regexp_split_to_array(problem, '(\. |, | |,|\.)');
    END IF;
    IF NEW.РЕШЕНИЕ is not null THEN
      decision=NEW.РЕШЕНИЕ;
      decision=lower(decision);
      decision2 = regexp_split_to_array(decision, '(\. |, | |,|\.)');
    END IF;
  END IF;
  if tg_op!='INSERT' THEN
    IF cause is not null THEN
      delete from PLACE_OF_WORD where id_ep=OLD.ИД and where_is=1 RETURNING id_word into slova;
      raise notice '%', slova;
      if slova is not null THEN
        FOREACH y in ARRAY slova
        LOOP
          execute 'DELETE FROM WORDS WHERE ИД=' || y || ';';
        END LOOP;
      END IF;
    END IF;
    IF problem is not null THEN
      delete from PLACE_OF_WORD where id_ep=OLD.ИД and where_is=2 RETURNING id_word into slova;
      if slova is not null THEN
        FOREACH y in ARRAY slova
        LOOP
          execute 'DELETE FROM WORDS WHERE ИД=' || y || ';';
        END LOOP;
      END IF;
    END IF;
    IF decision is not null THEN
      delete from PLACE_OF_WORD where id_ep=OLD.ИД and where_is=3 RETURNING id_word into slova;
      raise notice '%', slova;
      if slova is not null THEN
        FOREACH y in ARRAY slova
        LOOP
          execute 'DELETE FROM WORDS WHERE ИД=' || y || ';';
        END LOOP;
      END IF;
    END IF;
  END IF;
  IF tg_op!='DELETE' THEN
    if cause2 is not null then
      FOREACH x in ARRAY cause2
      LOOP
        idi=null;
        i=i+1;
        EXECUTE 'select ИД from WORDS where word=''' || x || ''';' INTO idi;
        if idi is null then
          INSERT into WORDS values (1, x) RETURNING ИД into idi;
        END IF;
        INSERT into PLACE_OF_WORD values (idi, NEW.ИД, i, 1);
      END LOOP;
    END IF;
    i = 0;
    if problem2 is not null then
      FOREACH x in ARRAY problem2
      LOOP
        idi=0;
        i=i+1;
        EXECUTE 'select ИД from WORDS where word=''' || x || ''';' INTO idi;
        if idi is null then
          INSERT into WORDS values (1, x) RETURNING ИД into idi;
        END IF;
        INSERT into PLACE_OF_WORD values (idi, NEW.ИД, i, 2);
      END LOOP;
    END IF;
    i = 0;
    if decision2 is not null then
      FOREACH x in ARRAY decision2
      LOOP
        idi=0;
        i=i+1;
        EXECUTE 'select ИД from WORDS where word=''' || x || ''';' INTO idi;
        if idi is null then
          INSERT into WORDS values (1, x) RETURNING ИД into idi;
        END IF;
        INSERT into PLACE_OF_WORD values (idi, NEW.ИД, i, 3);
      END LOOP;
    END IF;
  END IF;
  RETURN new;
END;
$$;

alter function ins_epizod() owner to s225106;

