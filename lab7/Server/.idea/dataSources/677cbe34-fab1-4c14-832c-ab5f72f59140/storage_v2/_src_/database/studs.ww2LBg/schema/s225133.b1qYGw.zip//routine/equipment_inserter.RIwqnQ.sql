create function equipment_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
    N alias for $1;
    i INTEGER DEFAULT 1;
    count integer default 0;

    hero integer DEFAULT 1;
    counter INTEGER DEFAULT 1;
    num INTEGER DEFAULT null;

BEGIN

    for i in 1..N loop

      WHILE (hero in (SELECT "id_героя" FROM "Экипировка")) loop
            num:=trunc(random() * (SELECT COUNT(*) FROM "Герой")+1);
            hero = (SELECT "id" FROM "Герой" WHERE "id"=num);
            if (hero = (SELECT "id_героя" FROM "Экипировка" WHERE "id_героя"=num)) then
            ELSE
                hero = (SELECT "id" FROM "Герой" WHERE "id"=num);
                EXIT;
            END if;
        END loop;

        insert into "Экипировка"(id_героя, id_хронологии) values (hero, (SELECT id FROM "Хронология" ORDER BY random() LIMIT 1));

        count:=0;
        counter:=0;

    end loop;

END;
$$;

alter function equipment_inserter(integer) owner to s225133;

