create function recount_force_army(id integer) returns void
    language plpgsql
as
$$
DECLARE
	powerPet integer;
	BEGIN
		select getPowerPet($1) into powerPet;
		IF powerPet is null then
			powerPet := 0;
		END IF;
		UPDATE АРМИЯ SET БОЕВАЯ_МОЩЬ = ((select sum(БОЕВАЯ_МОЩЬ) from ОТРЯД
									   WHERE ОТРЯД.ID_АРМИИ = $1 ) + powerPet)
									   where АРМИЯ.ID = $1;
									
	END;
$$;

alter function recount_force_army(integer) owner to s264430;

