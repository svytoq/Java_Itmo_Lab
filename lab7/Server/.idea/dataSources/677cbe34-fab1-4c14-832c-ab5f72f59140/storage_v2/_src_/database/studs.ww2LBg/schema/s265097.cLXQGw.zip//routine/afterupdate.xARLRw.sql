create function afterupdate() returns integer
    language plpgsql
as
$$
declare 
begin
UPDATE "Tube" set "PotionId" = potionId Where "Id" = tubeId;
end;
$$;

alter function afterupdate() owner to s265097;

