create function "ВСЕ_ОТНОШЕНИЯ_В_КНИГЕ"(name character varying)
    returns TABLE("ФАМИЛИЯ_1" character varying, "ИМЯ_1" character varying, "ФАМИЛИЯ_2" character varying, "ИМЯ_2" character varying, "СУТЬ_ОТНОШЕНИЯ" text, "СТАДИЯ" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT A.ФАМИЛИЯ, A.ИМЯ, B.ФАМИЛИЯ, B.ИМЯ, A.СУТЬ_ОТНОШЕНИЯ, A.СТАДИЯ
FROM ((SELECT ПЕРСОНАЖИ.ФАМИЛИЯ, ПЕРСОНАЖИ.ИМЯ, ОТНОШЕНИЕ_ПЕРС.СУТЬ_ОТНОШЕНИЯ, ОТНОШЕНИЕ_ПЕРС.СТАДИЯ FROM ОТНОШЕНИЕ_ПЕРС JOIN ПЕРСОНАЖИ ON ПЕРСОНАЖИ.ИД=ОТНОШЕНИЕ_ПЕРС.ИД_П1 JOIN КНИГИ ON КНИГИ.ИД=ОТНОШЕНИЕ_ПЕРС.КНИГА WHERE КНИГИ.НАЗВАНИЕ = name) AS A 
JOIN (SELECT ПЕРСОНАЖИ.ФАМИЛИЯ, ПЕРСОНАЖИ.ИМЯ, ОТНОШЕНИЕ_ПЕРС.СУТЬ_ОТНОШЕНИЯ, ОТНОШЕНИЕ_ПЕРС.СТАДИЯ FROM ОТНОШЕНИЕ_ПЕРС JOIN ПЕРСОНАЖИ ON ПЕРСОНАЖИ.ИД=ОТНОШЕНИЕ_ПЕРС.ИД_П2 JOIN КНИГИ ON КНИГИ.ИД=ОТНОШЕНИЕ_ПЕРС.КНИГА WHERE КНИГИ.НАЗВАНИЕ = name) AS B 
ON (B.СУТЬ_ОТНОШЕНИЯ=A.СУТЬ_ОТНОШЕНИЯ AND B.СТАДИЯ=A.СТАДИЯ));
END;
$$;

alter function "ВСЕ_ОТНОШЕНИЯ_В_КНИГЕ"(varchar) owner to s225058;

