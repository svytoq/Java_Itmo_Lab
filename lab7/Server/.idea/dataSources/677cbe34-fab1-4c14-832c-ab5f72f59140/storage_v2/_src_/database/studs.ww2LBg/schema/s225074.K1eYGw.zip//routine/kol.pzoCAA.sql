create function kol() returns integer
    language plpgsql
as
$$
<<outerblock>>
DECLARE kol integer:= 0;
BEGIN
SAVEPOINT kol0;
UPDATE AUTHOR SET count_of_legend = (SELECT COUNT(*) FROM LEGEND WHERE LEGEND.author_id = new.author_id);
kol:= new.count_of_legend;
ROLLBACK TO SAVEPOINT kol0;
RETURN kol;
END;
$$;

alter function kol() owner to s225074;

