create function kr(i integer) returns integer
    language sql
as
$$
SELECT I * 2
$$;

alter function kr(integer) owner to s251806;

