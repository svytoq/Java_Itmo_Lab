create function check_reference_on_delete() returns trigger
    language plpgsql
as
$$
DECLARE
 t record;
BEGIN
  FOR t IN EXECUTE format('SELECT * FROM %I WHERE ИД = %s', OLD.tblname, OLD.ИД) LOOP
    IF t.ИД = OLD.ИД THEN
       RAISE EXCEPTION 'Удаление невозможно. Существует объект c ИД % в таблице %',
         OLD.ИД, OLD.tblname;
    END IF;
  END LOOP;
  RETURN OLD;
END
$$;

alter function check_reference_on_delete() owner to s225119;

