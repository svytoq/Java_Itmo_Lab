create function update_dragon_land_id() returns trigger
    language plpgsql
as
$$
begin
    update dragon set land_id = new.thief_land_id where id = new.dragon_id;
    return new;
end;
$$;

alter function update_dragon_land_id() owner to s264484;

