create function insert_user(id integer, first_name character varying, surname character varying, gender character varying, dob date, email character varying, mobile_phone character varying) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO users (id,
             first_name,
             surname,
             gender,
             dob,
             email,
             mobile_phone)

  VALUES (insert_user.id,
      insert_user.first_name,
      insert_user.surname,
      insert_user.gender,
      insert_user.dob,
      insert_user.email,
      insert_user.mobile_phone);
END;

$$;

alter function insert_user(integer, varchar, varchar, varchar, date, varchar, varchar) owner to s264458;

