create function check_correct_sender() returns trigger
    language plpgsql
as
$$
begin
    /*
        Ищем тот заказ, где курьер назначен и sender_id совпадает, если нету,
        то значит нельзя создать сообщение с таким order_id
    */
    if (exists(select 1
               from "order" o
               where new.order_id = o.id
                 and o.courier_id is not null
                 and (New.sender_id = o.courier_id or new.sender_id = o.customer_id)) = false) then
        raise exception 'you cannot create a message with this status or the sender is incorrect';
    end if;
    return NEW;
end
$$;

alter function check_correct_sender() owner to s264451;

