create function отклонить_заявку("н_спортсмен_ид" integer, "н_соревнование_ид" integer, "причина" text) returns void
    language plpgsql
as
$$
begin
            delete from Заявка
                where соревнование_ид = н_соревнование_ид and спортсмен_ид = н_спортсмен_ид;
            insert into Отклоненные_Заявки(спортсмен_ид, соревнование_ид, причина)
                values (н_спортсмен_ид, н_соревнование_ид, причина);
        end;
$$;

alter function отклонить_заявку(integer, integer, text) owner to s265091;

