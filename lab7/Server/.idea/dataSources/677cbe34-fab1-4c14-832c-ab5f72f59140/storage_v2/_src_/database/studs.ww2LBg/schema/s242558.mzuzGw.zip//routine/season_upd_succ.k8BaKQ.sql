create function season_upd_succ() returns trigger
    language plpgsql
as
$$
BEGIN
    IF new.ид<>old.ид THEN
        UPDATE стадии SET сезон_ид=new.ид WHERE сезон_ид=old.ид;
    END IF;
    IF new.начало<>old.начало THEN
        UPDATE стадии SET начало=new.начало WHERE начало=old.начало;
    END IF;
    IF (old.конец IS NULL) AND (new.конец IS NOT NULL) THEN
        INSERT INTO стадии(сезон_ид,типс_ид,конец) VALUES (new.ид, (SELECT ид FROM типы_стадий WHERE название LIKE 'Плей-офф'), new.конец);
    END IF;
    IF (old.конец IS NOT NULL) AND (new.конец<>old.конец) THEN
        UPDATE стадии SET конец=new.конец WHERE конец=old.конец;
    END IF;
    RETURN NEW;
END;
$$;

alter function season_upd_succ() owner to s242558;

