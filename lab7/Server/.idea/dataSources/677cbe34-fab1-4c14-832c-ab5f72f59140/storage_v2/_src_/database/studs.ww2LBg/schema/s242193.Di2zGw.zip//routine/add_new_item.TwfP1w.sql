create function add_new_item() returns trigger
    language plpgsql
as
$$
BEGIN
		INSERT INTO "К_Инвентарь" (Персонаж_ИД, Предмет_ИД, Номер ,Момент_Получения, Момент_Отдачи) VALUES(NEW.Id, NEW.Логин);

		RETURN NEW;
	END;

$$;

alter function add_new_item() owner to s242193;

