create function divide_prize(tour_id integer) returns void
    language plpgsql
as
$$
declare
teams_amount integer;
prize_pool integer;
winner_id integer;
other_percent decimal;
begin
select Турниры.Призовой_фонд_дол into prize_pool from Турниры t where t.ID_Турнира = tour_id;
select Турниры.Колво_команд into teams_amount from Турниры t where t.ID_Турнира = tour_id;
select Турниры.Победитель into winner_id from Турниры t where t.ID_Турнира = tour_id;
other_percent = (prize_pool*0.4)/teams_amount;
UPDATE Команды t SET Бюджет = Бюджет + prize_pool*0.5 WHERE t.ID_Команды = winner_id;
UPDATE Команды t SET Бюджет = Бюджет + other_percent
FROM Команды te
INNER JOIN Турниры_Команды tt
ON tt.ID_Команды = t.ID_Команды
WHERE tt.ID_Турнира = tour_id;
end
$$;

alter function divide_prize(integer) owner to s241870;

