create function add_tea_to_cupboard(_tea_id integer, _cupboard_id integer, _amount real) returns boolean
    language plpgsql
as
$$
declare
    fact_amount real := 0;
    tea_amount_in_cupboard real := 0;
    tea_amount real := null;
begin
    select sum(amount) from cupboard_item where cupboard_id = _cupboard_id into tea_amount_in_cupboard;
    select amount from cupboard_item where cupboard_id = _cupboard_id and product_id = _tea_id into fact_amount;
    if (_amount + tea_amount_in_cupboard > fact_amount) then
        return false;
    else
        select amount from cupboard_item where product_id = _tea_id and cupboard_id = _cupboard_id into tea_amount;
        if tea_amount is null then
            insert into cupboard_item(product_id, cupboard_id, amount) values (_tea_id, _cupboard_id, _amount);
        else
            update cupboard_item
            set amount = _amount + tea_amount
            where cupboard_id = _cupboard_id and product_id = _tea_id;
        end if;
        return true;
    end if;
end
$$;

alter function add_tea_to_cupboard(integer, integer, real) owner to s264429;

