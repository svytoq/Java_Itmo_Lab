create function add_new_employee() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.interviewstage = 6 then
        INSERT INTO employee ( name , salary ,    work_experience  , position, work_mode)
        VALUES (NEW.name,NEW.salary, NEW. countyears,NEW.position ,1);
        DELETE FROM candidates  where candidates.id=NEW.id;
    end if;
    RETURN NEW;
END;
$$;

alter function add_new_employee() owner to s264431;

