create function checkmood() returns trigger
    language plpgsql
as
$$
DECLARE
    hasUnemployment int;
BEGIN
    SELECT count("Object_ID") FROM "Baggage" WHERE "Homeless_ID" = NEW.ID AND "Object_ID" = 28 into hasUnemployment;
    IF hasUnemployment = 1 AND NEW."Mood" > 50 THEN
        NEW."Mood" = 50;
    END IF;
    RETURN NEW;
END;
$$;

alter function checkmood() owner to s264425;

