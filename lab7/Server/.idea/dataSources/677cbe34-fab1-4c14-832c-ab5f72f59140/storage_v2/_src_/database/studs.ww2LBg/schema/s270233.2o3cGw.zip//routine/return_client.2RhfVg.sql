create function return_client() returns trigger
    language plpgsql
as
$$
DECLARE
    del_place integer;
    provider  integer;
BEGIN
    SELECT delivery_place_id FROM clients WHERE clients.id = NEW._from INTO del_place;
    SELECT id FROM providers WHERE providers.delivery_place_id = del_place INTO provider;
    NEW._to = provider;
    NEW.ret_time = localtime;
    RETURN NEW;
END;
$$;

alter function return_client() owner to s270233;

