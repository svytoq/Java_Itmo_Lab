create function tiid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_БИЛЕТА := nextval('tickets_seq');
	return new;
end
$$;

alter function tiid() owner to s225120;

