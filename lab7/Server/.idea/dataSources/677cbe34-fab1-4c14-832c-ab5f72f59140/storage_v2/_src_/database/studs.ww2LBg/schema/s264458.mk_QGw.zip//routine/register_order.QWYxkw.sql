create function register_order(id integer, customer_id integer, company_id integer, project_id integer, description text, deadline timestamp without time zone, cost numeric) returns void
    language plpgsql
as
$$
BEGIN

  PERFORM insert_order(id::integer, customer_id::integer, company_id::integer, project_id::integer, description::text, current_timestamp::timestamp, deadline::timestamp, cost::numeric);
  RAISE NOTICE 'Заказ сформирован';

END;

$$;

alter function register_order(integer, integer, integer, integer, text, timestamp, numeric) owner to s264458;

