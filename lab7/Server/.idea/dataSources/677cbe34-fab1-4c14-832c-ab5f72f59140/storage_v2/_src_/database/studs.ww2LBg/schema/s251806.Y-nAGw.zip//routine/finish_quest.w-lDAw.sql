create function finish_quest(q_id integer) returns void
    language plpgsql
as
$$
BEGIN
    UPDATE character_or_entity
    SET experience = experience + (SELECT experience FROM quest WHERE id = q_id)
    WHERE id = 0;
    UPDATE inventory SET gold = gold + (SELECT reward FROM quest WHERE id = q_id) WHERE character_id = 0;
    UPDATE active_quests SET status = 100 WHERE active_quests.quest_id = q_id;
END;
$$;

alter function finish_quest(integer) owner to s251806;

