create function toint(character varying) returns integer
    immutable
    strict
    language sql
as
$$
SELECT cast($1 as integer);
$$;

alter function toint(varchar) owner to s270235;

