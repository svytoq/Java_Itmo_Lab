create function get_dq(id integer) returns integer
    language plpgsql
as
$$
BEGIN
    RETURN (SELECT danger_q FROM find_creature where id_creature = id);
  END;
$$;

alter function get_dq(integer) owner to s243856;

