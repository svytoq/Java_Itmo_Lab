create function pk_func_st() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_st');
  RETURN new;
END;
$$;

alter function pk_func_st() owner to s223457;

