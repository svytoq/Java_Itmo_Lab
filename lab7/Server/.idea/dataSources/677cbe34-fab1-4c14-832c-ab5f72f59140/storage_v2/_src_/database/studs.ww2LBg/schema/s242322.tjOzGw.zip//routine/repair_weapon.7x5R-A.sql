create function repair_weapon(weapon integer, start_time timestamp without time zone, end_time timestamp without time zone) returns void
    language plpgsql
as
$$
declare
repair_man integer;
st timestamp;
et timestamp = end_time;
begin
if start_time is null then st = now();
else st = start_time;
end if;

update ОРУЖИЕ set ГОТОВО_ЕДИНИЦ = ГОТОВО_ЕДИНИЦ - 1 where ИД = weapon;
select ИД into repair_man from ЧЛЕНЫ_ПОЛИЦИИ where ОТДЕЛ = 4 or ОТДЕЛ in (select ИД from ОТДЕЛЫ where ПОДЧИНЯЕТСЯ = 4);
insert into РЕМОНТ_ОРУЖИЯ values (default, weapon, et, repair_man, st);
end;
$$;

alter function repair_weapon(integer, timestamp, timestamp) owner to s242322;

