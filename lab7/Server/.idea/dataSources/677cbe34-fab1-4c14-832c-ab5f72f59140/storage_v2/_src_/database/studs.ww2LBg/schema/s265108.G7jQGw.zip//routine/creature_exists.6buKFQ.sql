create function creature_exists(creature integer) returns boolean
    language plpgsql
as
$$
DECLARE
          creature_exists boolean;
        BEGIN
          SELECT 1 INTO creature_exists FROM Creatures c WHERE c.id = creature;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Такого существа нет, проверьте введенные данные';
    END IF;
        RETURN 'TRUE';
        END;
$$;

alter function creature_exists(integer) owner to s265108;

