create function return_provider() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    SELECT id_factory FROM providers WHERE providers.id_provider = NEW._from INTO NEW._to;
    NEW.ret_time = localtime;
    RETURN NEW;
END;
$$;

alter function return_provider() owner to s270235;

