create view product_order_with_user_info
            (user_profile_id, product_order_id, product_prototype_id, price, planned_delivery_date, delivery_address,
             additional_description, order_status, name, date_of_birth, email, telephone_number, password_hash,
             privilege)
as
SELECT product_order.user_profile_id,
       product_order.product_order_id,
       product_order.product_prototype_id,
       product_order.price,
       product_order.planned_delivery_date,
       product_order.delivery_address,
       product_order.additional_description,
       product_order.order_status,
       user_profile.name,
       user_profile.date_of_birth,
       user_profile.email,
       user_profile.telephone_number,
       user_profile.password_hash,
       user_profile.privilege
FROM s267880.product_order
         LEFT JOIN s267880.user_profile USING (user_profile_id);

alter table product_order_with_user_info
    owner to s267880;

