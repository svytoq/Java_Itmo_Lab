create function getpossibledeadpeople()
    returns TABLE(id integer, first_name character varying, last_name character varying)
    language sql
as
$$
SELECT a.id, first_name, last_name
from human_blood_flow_human AS a
         inner join human_blood_flow_organism as b on a.id = b.owner_id
         inner join human_blood_flow_circulatorysystem as c on b.id = c.organism_id
         inner join human_blood_flow_circulatorysystem_substances as d on c.id = d.circulatorysystem_id
         inner join human_blood_flow_substance as t on t.id = d.substance_id
where t.harmfulness > 60
$$;

alter function getpossibledeadpeople() owner to s278068;

