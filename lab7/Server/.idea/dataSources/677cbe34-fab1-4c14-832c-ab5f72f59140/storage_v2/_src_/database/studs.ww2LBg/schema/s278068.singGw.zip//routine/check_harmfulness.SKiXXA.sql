create function check_harmfulness() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.harmfulness > 60 then
        update human_blood_flow_organism as org
        set date_to_die = date_to_die - interval '1 day'
        where org.id = (
            select organism_id
            from human_blood_flow_circulatorysystem as a
                     inner join human_blood_flow_circulatorysystem_substances as b
                         on a.id = b.circulatorysystem_id
            where b.substance_id = NEW.id
        );
    END IF;
    RETURN NEW;
END;
$$;

alter function check_harmfulness() owner to s278068;

