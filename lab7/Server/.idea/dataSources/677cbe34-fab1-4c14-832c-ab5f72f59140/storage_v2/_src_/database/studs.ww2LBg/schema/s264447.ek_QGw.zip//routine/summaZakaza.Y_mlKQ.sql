create function "суммаЗаказа"("заказ" integer) returns integer
    language plpgsql
as
$$
BEGIN
    return (select sum(цена) from ЛабораторныеИсследования where заказ_id=заказ);
end;
$$;

alter function "суммаЗаказа"(integer) owner to s264447;

