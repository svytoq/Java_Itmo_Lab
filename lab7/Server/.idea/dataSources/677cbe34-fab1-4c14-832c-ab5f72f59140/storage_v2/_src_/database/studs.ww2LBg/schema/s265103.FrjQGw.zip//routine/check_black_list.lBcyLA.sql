create function check_black_list() returns trigger
    language plpgsql
as
$$
begin
    if NEW.Passenger_id not in (select * from Black_list)
    then return NEW;
    else return NULL;
    end if;
end;
$$;

alter function check_black_list() owner to s265103;

