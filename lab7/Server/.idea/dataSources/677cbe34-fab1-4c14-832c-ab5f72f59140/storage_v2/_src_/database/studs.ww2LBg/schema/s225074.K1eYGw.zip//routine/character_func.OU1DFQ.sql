create function character_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.character_id:= NEXTVAL('character_seq');
RETURN new;
END;
$$;

alter function character_func() owner to s225074;

