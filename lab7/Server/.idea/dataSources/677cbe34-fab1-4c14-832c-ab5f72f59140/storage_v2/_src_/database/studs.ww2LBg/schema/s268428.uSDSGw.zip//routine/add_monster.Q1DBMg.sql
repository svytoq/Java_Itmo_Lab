create function add_monster(name character, lev integer) returns integer
    language plpgsql
as
$$
begin
 
 INSERT INTO monster VALUES
 (DEFAULT, name, lev);
 
 RETURN 0;
 end
$$;

alter function add_monster(char, integer) owner to s268428;

