create function func_extra_marks() returns trigger
    language plpgsql
as
$$
DECLARE 
  current_mark integer = (select sum(балл) from индивидуальные_достижения_вуза 
                          natural join дополнительные_документы natural join абитуриент 
                          group by ид_абитуриента, ид_вуза 
                          having ид_абитуриента = new.ид_абитуриента and ид_вуза = new.ид_вуза);
  adding_mark integer = (select балл from индивидуальные_достижения_вуза where new.ид_достижения = ид_достижения and new.ид_вуза = ид_вуза);
BEGIN
  IF  current_mark + adding_mark > 10
    THEN RAISE NOTICE 'За индивидуальные достижения не может быть более 10 баллов'; RETURN NULL;
  END IF;
    RETURN NEW;
END;
$$;

alter function func_extra_marks() owner to s243859;

