create function eventdata(i integer) returns void
    language plpgsql
as
$$
DECLARE
j integer;
BEGIN
j = 0;
loop
j = j + 1;
insert into СОБЫТИЯ values('event'||'  '||j, 'plan'||' '||j, 'action'||' '||j);
if j = i then exit;
end if;
end loop;
END;
$$;

alter function eventdata(integer) owner to s223859;

