create function validate_fight() returns trigger
    language plpgsql
as
$$
BEGIN
 IF NEW.Дата < '01.01.2000'
 THEN
 RAISE EXCEPTION ' Дата битвы слишком старая';
END IF;
 RETURN NEW;
 END
$$;

alter function validate_fight() owner to s242467;

