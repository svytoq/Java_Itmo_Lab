create function insert_clan_members() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
    humId integer = trunc(random()*10000) + 1;
  BEGIN
    LOOP
      if NOT exists(Select * from clan_members where hum_id = humId)
        THEN
          INSERT INTO clan_members VALUES (DEFAULT, trunc(random()*20)+1, humId, insert_random(), '5/12/1998');
          count = count + 1;
        ELSE humId = trunc(random()*10000) + 1;
      END IF;
      EXIT WHEN count = 5000;
    END LOOP;
  END;
$$;

alter function insert_clan_members() owner to s225107;

