create function insert_rooms(count integer) returns void
    language plpgsql
as
$$
DECLARE
        cinema record;
BEGIN
        FOR cinema IN (SELECT ид from Кинотеатры)
        LOOP
                FOR i in 1 .. count LOOP
                insert into Залы(ид_кинотеатра, номер_зала) 
                        values(cinema.ид,i);
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_rooms(integer) owner to s224932;

