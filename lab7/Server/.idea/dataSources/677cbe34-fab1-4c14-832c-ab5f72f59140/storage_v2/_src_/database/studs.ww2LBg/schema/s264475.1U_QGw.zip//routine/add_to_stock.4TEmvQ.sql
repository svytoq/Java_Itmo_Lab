create function add_to_stock(_pharmacy_id integer, _trademark_id integer, _availability integer) returns integer
    language plpgsql
as
$$
DECLARE
    amount INTEGER;
BEGIN
    IF EXISTS(SELECT 1 FROM stock s WHERE (s.pharmacy_id, s.trademark_id) = (_pharmacy_id, _trademark_id)) THEN
        amount := (SELECT availability a
                   FROM stock s
                   WHERE ((s.pharmacy_id, s.trademark_id) = (_pharmacy_id, _trademark_id)));

        UPDATE stock s
        SET availability = amount + _availability
        WHERE ((s.pharmacy_id, s.trademark_id) = (_pharmacy_id, _trademark_id));
    ELSIF _availability < 0 THEN
        RAISE NOTICE 'Can''t buy ! This trademark doesn''t exist at this pharmacy';
    ELSE
        INSERT INTO stock(pharmacy_id, trademark_id, availability)
        VALUES (_pharmacy_id, _trademark_id, _availability);
    END If;
    RETURN (SELECT availability FROM stock s WHERE ((s.pharmacy_id, s.trademark_id) = (_pharmacy_id, _trademark_id)));
EXCEPTION
    WHEN check_violation THEN
        RAISE NOTICE 'Can''t buy such an amount! Bought just %', amount;
        UPDATE stock s
        SET availability = 0
        WHERE ((s.pharmacy_id, s.trademark_id) = (_pharmacy_id, _trademark_id));
        RETURN (SELECT availability
                FROM stock s
                WHERE ((s.pharmacy_id, s.trademark_id) = (_pharmacy_id, _trademark_id)));
END;
$$;

alter function add_to_stock(integer, integer, integer) owner to s264475;

