create function drop_inside_database() returns void
    language sql
as
$$
DROP TABLE IF EXISTS planet_rules_seq;
    DROP TABLE IF EXISTS planet_company_seq;
    DROP TABLE IF EXISTS tourist_flight_seq;
    DROP TABLE IF EXISTS sights;
    DROP TABLE IF EXISTS rules;
    DROP TABLE IF EXISTS garage;
    DROP TABLE IF EXISTS flight;
    DROP TABLE IF EXISTS spaceship;
    DROP TABLE IF EXISTS captain;
    DROP TABLE IF EXISTS employee;
    DROP TABLE IF EXISTS tourist;
    DROP TABLE IF EXISTS planet;
    DROP TABLE IF EXISTS company;

    drop function show_available_captains();

    drop function check_exp();
$$;

alter function drop_inside_database() owner to s243900;

