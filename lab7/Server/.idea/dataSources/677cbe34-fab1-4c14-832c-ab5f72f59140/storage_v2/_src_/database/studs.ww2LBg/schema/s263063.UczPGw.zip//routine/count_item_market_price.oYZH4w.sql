create function count_item_market_price(itemid integer, currencyid integer) returns double precision
    language plpgsql
as
$$
declare avgItemPrice float;
    begin
        avgItemPrice = (select avg(price) from item_listing where item_id = itemId and currency = currencyId);
        return avgItemPrice;
    end;
$$;

alter function count_item_market_price(integer, integer) owner to s263063;

