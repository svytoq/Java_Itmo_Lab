create function danger_quotient() returns trigger
    language plpgsql
as
$$
DECLARE
danger_quotient int = get_danger_q(NEW.id_creature);
BEGIN
NEW.danger_q = danger_quotient;
RETURN NEW;
END;
$$;

alter function danger_quotient() owner to s243856;

