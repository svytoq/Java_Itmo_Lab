create function aromorfoz_function() returns trigger
    language plpgsql
as
$$
begin
new.Код_ароморфоза=nextval('Ароморфозы_Код_ароморфоза_seq');
return new;
end;
$$;

alter function aromorfoz_function() owner to s225069;

