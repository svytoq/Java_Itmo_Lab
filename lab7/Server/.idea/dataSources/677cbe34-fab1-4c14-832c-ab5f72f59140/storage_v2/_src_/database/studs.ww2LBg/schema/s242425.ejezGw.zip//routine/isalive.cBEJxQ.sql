create function isalive(id integer) returns boolean
    language sql
as
$$
select spr.ЖИВОЕ as isAlive
    from СПРАВОЧНИК_СУЩЕСТВ as spr
        join ИНГРЕДИЕНТ as ing using(ИД_СУЩЕСТВА)
    where ing.ИД_ИНГРЕДИЕНТА=id
$$;

alter function isalive(integer) owner to s242425;

