create function canstudy(wizardid integer, lesson integer) returns integer
    language plpgsql
as
$$
declare 
begin
return (select count(*) from "Wizard" wz inner join "Teacher" tch on wz."Id" = tch."WizardId" inner join "StudyPermission" sp on sp."TeacherId" = tch."Id"  inner join "Lesson" ls on ls."Id" = sp."LessonId" where wz."Id" = wizardId and ls."Id" = lesson);
end;
$$;

alter function canstudy(integer, integer) owner to s265097;

