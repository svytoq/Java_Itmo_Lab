create function accidentlauncher() returns character varying
    language plpgsql
as
$$
BEGIN
UPDATE Truman_status SET level_awareness=0 WHERE id=2;
RETURN (SELECT level_awareness FROM Truman_status);
END;
$$;

alter function accidentlauncher() owner to s277686;

