create function stop_fixing_device() returns trigger
    language plpgsql
as
$$
DECLARE
   device_id device.id%type;
BEGIN
   SELECT id FROM device INTO device_id WHERE id = NEW.id AND NEW.damaged = False;
   UPDATE astronaut SET fixing_device_id = NULL WHERE fixing_device_id = device_id;
   RETURN NEW;
END;
$$;

alter function stop_fixing_device() owner to s270250;

