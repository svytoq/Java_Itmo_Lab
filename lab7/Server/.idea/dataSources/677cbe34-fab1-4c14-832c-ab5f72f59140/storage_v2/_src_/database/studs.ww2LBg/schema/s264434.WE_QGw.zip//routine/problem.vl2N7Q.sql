create function problem()
    returns TABLE(_id integer, _id_spaceship integer, _date timestamp with time zone, _description text, _is_solved boolean)
    language plpgsql
as
$$
declare
    spaceship_id integer;
    flight_planet_from integer;
    flight_date_start timestamp with time zone;
    flight_duration interval;
    prev_flight_planet_from integer;
    prev_flight_date_start timestamp with time zone;
    prev_flight_duration interval;
    id1 integer;
    id2 integer;
    count_couples integer;

BEGIN
    create temporary table if not exists "PlanetsShipsTime"
    (
        id          serial not null PRIMARY KEY,
        id_planet   integer not null,
        id_ships_kek    integer not null,
        from_date   timestamp with time zone,
        to_date     timestamp with time zone
    );
    truncate "PlanetsShipsTime";
    create temporary table if not exists "CoupleShips"
    (
        id_ships1    integer not null,
        id_ships2   integer not null
    );
    truncate "CoupleShips";
    for id1 in select id from "Spaceships" order by id
        LOOP
            for id2 in select id from "Spaceships" where id > id1 order by id
                LOOP
                    insert into "CoupleShips" values (id1, id2);
                end loop;
        end loop;

    for spaceship_id in select id from "Spaceships" order by id
        LOOP
            prev_flight_planet_from := id_planet_from from "Flights" where id_spaceship = spaceship_id order by date_start limit 1;
            prev_flight_date_start := date_start from "Flights" where id_spaceship = spaceship_id order by date_start limit 1;
            prev_flight_duration := duration from "Flights" where id_spaceship = spaceship_id order by date_start limit 1;

            insert into "PlanetsShipsTime"(id_planet, id_ships_kek, from_date, to_date) values (prev_flight_planet_from, spaceship_id, null, prev_flight_date_start);

            for flight_planet_from, flight_date_start, flight_duration in select id_planet_from, date_start, duration from "Flights" where id_spaceship = spaceship_id order by date_start offset 1
                LOOP
                    insert into "PlanetsShipsTime"(id_planet, id_ships_kek, from_date, to_date) values (flight_planet_from, spaceship_id, prev_flight_date_start + prev_flight_duration, flight_date_start);
                    prev_flight_date_start := flight_date_start;
                    prev_flight_planet_from := flight_planet_from;
                    prev_flight_duration := flight_duration;
                end loop;
        end loop;

    declare
        planets_ships_time_id_ships integer;
        planets_ships_time_to_date timestamp with time zone;
        planets_ships_time_from_date timestamp with time zone;
        id_ships_couple integer;
        planets_ships_time_id integer;
        planets_ships_time_planet integer;
    begin
        for planets_ships_time_id in select id from "PlanetsShipsTime" order by id_ships_kek
            LOOP
                planets_ships_time_id_ships := id_ships_kek from "PlanetsShipsTime" where id = planets_ships_time_id;
                planets_ships_time_to_date := to_date from "PlanetsShipsTime"  where id = planets_ships_time_id;
                planets_ships_time_from_date := from_date from "PlanetsShipsTime"  where id = planets_ships_time_id;
                planets_ships_time_planet := id_planet from "PlanetsShipsTime"  where id = planets_ships_time_id;

                for id_ships_couple in select id_ships_kek from "PlanetsShipsTime"
                                       where id_ships_kek != planets_ships_time_id_ships
                                         and id_planet = planets_ships_time_planet
                                         and ((from_date between planets_ships_time_from_date and planets_ships_time_to_date)
                                           or (to_date between planets_ships_time_from_date and planets_ships_time_to_date))
                    LOOP
                        if id_ships_couple is not null then
                            delete from "CoupleShips" where (id_ships1 = planets_ships_time_id_ships and id_ships2 = id_ships_couple)
                                                         or (id_ships2 = planets_ships_time_id_ships and id_ships1 = id_ships_couple);
                        end if;
                    end loop;
            end loop;
    end;
    count_couples := count(*) from "CoupleShips";
    raise notice  '% couples', count_couples;
    if(count_couples = 0) then
        RAISE 'Таких кораблей нет!';
    else
        return query select * from "Breakdowns" where id_spaceship=(select id_ships1 from "CoupleShips" limit 1) or id_spaceship=(select id_ships2 from "CoupleShips" limit 1);
    end if;

END;
$$;

alter function problem() owner to s264434;

