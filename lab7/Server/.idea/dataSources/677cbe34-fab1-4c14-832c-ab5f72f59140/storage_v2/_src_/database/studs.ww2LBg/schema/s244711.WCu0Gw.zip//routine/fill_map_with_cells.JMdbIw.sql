create function fill_map_with_cells(_map integer) returns void
    language plpgsql
as
$$
DECLARE
	map_size int;
	reliefs_amount smallint;
	relief smallint;
	is_passable boolean;
	command text;
BEGIN
	map_size = 
		(SELECT size
		FROM maps
		WHERE id = _map);

	IF (map_size > 1000) THEN
		RAISE EXCEPTION 'Cannot fill map with size > 1000';
	END IF;

	DELETE FROM cells WHERE map = _map;

	RAISE NOTICE 
		'Start filling map % that has size %',
		_map, map_size;

	reliefs_amount = 
		(SELECT MAX(id)
		FROM reliefs);

	FOR x IN 0 .. (map_size - 1) LOOP
		FOR y IN 0 .. (map_size - 1) LOOP
			INSERT INTO cells 
				(map, pos, relief_type, is_passable)
				VALUES (_map, (x, y), 
					(SELECT round(random() * (reliefs_amount - 1)) + 1), 
					(SELECT random() > 0.5));
		END LOOP;
	END LOOP;
END;
$$;

alter function fill_map_with_cells(integer) owner to s244711;

