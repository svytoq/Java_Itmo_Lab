create function sum_fuel_cons(station_id_arg integer) returns integer
    language plpgsql
as
$$
DECLARE
    res integer;
BEGIN
    SELECT sum(fuel_consumption) INTO res FROM snowmobile WHERE station = station_id_arg;
    RETURN res;
END;
$$;

alter function sum_fuel_cons(integer) owner to s265113;

