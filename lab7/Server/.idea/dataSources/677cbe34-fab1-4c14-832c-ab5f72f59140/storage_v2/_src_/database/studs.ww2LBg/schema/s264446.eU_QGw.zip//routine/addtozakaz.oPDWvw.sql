create function addtozakaz(zakaz integer, test integer) returns void
    language plpgsql
as
$$
declare
employee int;
begin
    employee := (select findEmployeeForTest(test));
    insert into tests (order_id, employee_id, test_kind_id)
    values (zakaz, employee, test);
end;
$$;

alter function addtozakaz(integer, integer) owner to s264446;

