create function film_info(name text, OUT "ИМЯ" text, OUT "НАЗВАНИЕ" text, OUT "ИСПОЛНИТЕЛЬ" text, OUT "НАЗВАНИЕ_Н" text) returns SETOF record
    language sql
as
$$
SELECT РЕЖИССЕР.ИМЯ, МУЗЫКА.НАЗВАНИЕ, МУЗЫКА.ИСПОЛНИТЕЛЬ, НАГРАДЫ.НАЗВАНИЕ_Н 
FROM ФИЛЬМ 
JOIN СЦЕНАРИЙ ON СЦЕНАРИЙ.ИД_Ф=ФИЛЬМ.ИД 
JOIN РЕЖИССЕР ON РЕЖИССЕР.ИД=СЦЕНАРИЙ.ИД_Р 
JOIN МУЗ_ФИЛЬМ ON ФИЛЬМ.ИД=МУЗ_ФИЛЬМ.ИД_Ф 
JOIN МУЗЫКА ON МУЗЫКА.ИД=МУЗ_ФИЛЬМ.ИД_М 
JOIN НАГРАДЫ_Ф ON НАГРАДЫ_Ф.ИД_Ф=ФИЛЬМ.ИД 
JOIN НАГРАДЫ ON НАГРАДЫ.ИД=НАГРАДЫ_Ф.ИД_Ф 
WHERE ФИЛЬМ.НАЗВАНИЕ=name;
$$;

alter function film_info(text, out text, out text, out text, out text) owner to s243886;

