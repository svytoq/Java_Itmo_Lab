create function star_cool_down(star_id integer) returns text
    language plpgsql
as
$$
declare
    star_object_id int;
    star_system_id int;
    star_is_main boolean;
  begin
    select star.object_id, star.is_main INTO star_object_id, star_is_main from star 
    where star.id = star_id and star.is_lighting = 't';
    
    if not found then
      raise exception 'No such lighting star';
    end if;
    
    select system_id into star_system_id from space_object where id = star_object_id;
    
    if star_is_main = 't' then
      update resource_space_object set quantity=0 
      where object_id in (select p.object_id from planet as p 
      inner join space_object as s_o on (s_o.id = p.object_id)
      where s_o.system_id = star_system_id) and resource_id in 
      (select id from resource where name != 'moskoviy');
    end if;
    
    update resource_space_object set quantity=0 
    where object_id = star_object_id and resource_id in 
    (select id from resource where name != 'moskoviy');
      
    update star set is_lighting = 'false' where id = star_id;
    return 'Star has cooled down';
  end;
$$;

alter function star_cool_down(integer) owner to s264482;

