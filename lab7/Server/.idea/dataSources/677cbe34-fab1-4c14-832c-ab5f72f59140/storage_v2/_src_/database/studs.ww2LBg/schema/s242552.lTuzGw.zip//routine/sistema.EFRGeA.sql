create function система() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.ID_фракции not IN (select ID from фракция) THEN
insert into фракция values(NEW.ID_фракции, 'отсутсвует', null);
END IF;
return NEW;
END;
$$;

alter function система() owner to s242552;

