create function update_dates() returns void
    language plpgsql
as
$$
DECLARE
t_row dead_creature%rowtype;
birth_date date;
d_date date;
BEGIN
FOR t_row IN SELECT * FROM dead_creature LOOP
birth_date = (SELECT birthday FROM creature 
WHERE id = t_row.id_creature);
d_date = t_row.death_date;
WHILE d_date <= birth_date LOOP
d_date = d_date + 365;
END LOOP;
d_date = d_date + (365 * (random() * 10 + 12))::int;
UPDATE dead_creature SET death_date = d_date
WHERE id_creature = t_row.id_creature;
END LOOP;
END;
$$;

alter function update_dates() owner to s243856;

