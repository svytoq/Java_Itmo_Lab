create function order_finished() returns trigger
    language plpgsql
as
$$
BEGIN
        IF NEW.СТАТУС = 'ЗАКРЫТ' THEN
            UPDATE ЗАКАЗЫ SET ВРЕМЯ_ЗАКРЫТИЯ = now(), ПОЛНАЯ_СТОИМОСТЬ = (SELECT SUM(БЛЮДА.ЦЕНА * КОЛИЧЕСТВО) FROM ЗАКАЗ_БЛЮДО JOIN БЛЮДА ON ЗАКАЗ_БЛЮДО.ИД_БЛЮДА = БЛЮДА.ИД WHERE ИД_ЗАКАЗА = OLD.ИД_ЗАКАЗА) WHERE ИД = OLD.ИД_ЗАКАЗА;
        END IF;
        RETURN NEW;
    END;
$$;

alter function order_finished() owner to s242297;

