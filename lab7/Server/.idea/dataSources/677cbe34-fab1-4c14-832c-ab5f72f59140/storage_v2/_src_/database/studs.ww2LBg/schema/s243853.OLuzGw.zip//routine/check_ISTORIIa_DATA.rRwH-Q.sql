create function "check_ИСТОРИЯ_ДАТА"() returns trigger
    language plpgsql
as
$$
BEGIN 
IF (NEW.ДАТА_НАЧАЛА < (SELECT ДАТА_ОСНОВАНИЯ FROM СОЮЗЫ WHERE ИД_СОЮЗА = NEW.ИД_СОЮЗА)) THEN
RAISE EXCEPTION 'ДАТА_НАЧАЛА некоторой ИСТОРИИ должна быть хронологически позже, чем ДАТА_ОСНОВАНИЯ СОЮЗА'; 
END IF; 
RETURN NEW;
END
$$;

alter function "check_ИСТОРИЯ_ДАТА"() owner to s243853;

