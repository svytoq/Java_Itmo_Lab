create function validate_note() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Убедимся, что заметка не слишком стара
    IF NEW.Дата < ANY(
            SELECT Дата_рождения FROM К_Пользователь
            WHERE ИД = NEW.ИД_Пользователя)
    THEN
        RAISE EXCEPTION 'Заметка % старше пользователя', NEW.ИД;
    END IF;
    RETURN NEW;
  END
$$;

alter function validate_note() owner to s248266;

