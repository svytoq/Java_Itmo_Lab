create function kill() returns void
    language sql
as
$$
DROP TABLE арены, голосование, города, дивизионы, команды, конференции, люди, матчи, награды, награждения, позиции, роли, сезоны, стадии, статистика, страны, типы_матчей, типы_стадий, участники CASCADE;
$$;

alter function kill() owner to s242558;

