create function "ПОКАЗАТЬ_РАСПИСАНИЕ_ГРУППЫ"(id integer) returns SETOF s265057."ЗАНЯТИЕ"
    language sql
as
$$
select * FROM ЗАНЯТИЕ WHERE ГРУППА_ИД=id
$$;

alter function "ПОКАЗАТЬ_РАСПИСАНИЕ_ГРУППЫ"(integer) owner to s265057;

