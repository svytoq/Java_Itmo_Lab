create function need_equipment() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO request_position(type, equipment_type) VALUES (order_type('equipment'), NEW.type);
    RETURN NEW;
END;
$$;

alter function need_equipment() owner to s265113;

