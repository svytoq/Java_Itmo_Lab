create function adddata() returns trigger
    language plpgsql
as
$$
begin insert into Протокол_ремонта(Номер_ремонта,Дата_ремонта) values(new.ИД_ремонта, current_date); return new; end;
$$;

alter function adddata() owner to s243882;

