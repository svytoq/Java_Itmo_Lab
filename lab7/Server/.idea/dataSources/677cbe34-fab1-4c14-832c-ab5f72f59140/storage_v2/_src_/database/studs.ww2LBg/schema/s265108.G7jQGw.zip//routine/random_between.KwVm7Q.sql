create function random_between(low integer, high integer) returns integer
    strict
    language plpgsql
as
$$
BEGIN
   RETURN floor(random()* (high-low + 1) + low);
END;
$$;

alter function random_between(integer, integer) owner to s265108;

