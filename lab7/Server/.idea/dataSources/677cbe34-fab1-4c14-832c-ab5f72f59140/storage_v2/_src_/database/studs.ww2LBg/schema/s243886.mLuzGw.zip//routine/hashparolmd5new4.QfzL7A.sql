create function hashparolmd5new4() returns trigger
    language plpgsql
as
$$
begin 
UPDATE ЧЕЛОВЕК 
set ПАРОЛЬ=md5(ПАРОЛЬ) 
WHERE ИД IN (SELECT ИД 
FROM ЧЕЛОВЕК 
ORDER BY ИД 
LIMIT 1); 
RETURN NEW; 
END;
$$;

alter function hashparolmd5new4() owner to s243886;

