create function insert_individuals(fnames character varying[], mnames character varying[], lnames character varying[]) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
    j integer := 0;
    k integer := 0;
    phone bigint := 0;
begin
    for i in 1..array_length(fnames, 1) loop
        for j in 1..array_length(mnames, 1) loop
            for k in 1..array_length(lnames, 1) loop
                if (random() < 0.4) then continue; end if;

                phone := (random() * (9999999999 - 9000000000) + 9000000000)::bigint;
                insert into customer(type, fname, mname, lname, email, phone)
                values ('individual', fnames[i], mnames[j], lnames[k], get_random_email(fnames[i], lnames[k]), phone)
                on conflict do nothing;
            end loop;
        end loop;
    end loop;

end
$$;

alter function insert_individuals(character varying[], character varying[], character varying[]) owner to s264429;

