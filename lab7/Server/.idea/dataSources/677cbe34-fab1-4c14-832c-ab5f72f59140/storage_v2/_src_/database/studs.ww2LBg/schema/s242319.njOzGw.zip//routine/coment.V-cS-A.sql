create function coment(id integer)
    returns TABLE("КОМЕНТАРИЙ" text)
    language sql
as
$$
SELECT КОМЕНТАРИЙ FROM КОМЕНТАРИИ inner JOIN КОМЕНТАРИИ_К_ЗАПИСИ on КОМЕНТАРИИ.ЗАПИСЬ_НА_ФОРУМЕ_ИД = КОМЕНТАРИИ_К_ЗАПИСИ.ИД_КОМЕНТАРИЯ WHERE КОМЕНТАРИИ_К_ЗАПИСИ.ИД_ЗАПИСИ = $1 ;
$$;

alter function coment(integer) owner to s242319;

