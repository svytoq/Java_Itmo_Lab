create function finish_project(project_id integer) returns void
    language plpgsql
as
$$
BEGIN

  IF EXISTS(SELECT * FROM project WHERE id = finish_project.project_id AND date_end NOTNULL) THEN
    RAISE EXCEPTION 'Project is already finished';
  END IF;

  UPDATE project SET date_end = current_date WHERE id = finish_project.project_id;

  RAISE NOTICE 'Проект завершен';

END;

$$;

alter function finish_project(integer) owner to s264458;

