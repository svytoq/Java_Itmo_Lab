create function obj_inv(table_name text, obj_id integer)
    returns TABLE(id integer, name text, col integer)
    language plpgsql
as
$$
BEGIN
IF table_name = 'Оружие' THEN
SELECT Оружие.ИД, Оружие.Модель_ор, Нахождение_оруж.Количество  
FROM Оружие, Нахождение_оруж 
WHERE Нахождение_оруж.ИД_чел = obj_id;
END IF;
IF table_name = 'Патроны' THEN
SELECT Патроны.ИД, Патроны.Модель_патрона, Нахождение_пат.Количество  
FROM Орудие, Нахождение_пат
WHERE Нахождение_пат.ИД_чел = obj_id;
END IF;
IF table_name = 'Продукты' THEN
SELECT Продукты.ИД, Продукты.Название_прод, Нахождение_прод.Количество  
FROM Продукты, Нахождение_прод 
WHERE Нахождение_прод.ИД_чел = obj_id;
END IF;
IF table_name = 'Медикаменты' THEN
SELECT Медикаменты.ИД, Медикаменты.Название, Нахождение_мед.Количество  
FROM Медикаменты, Нахождение_мед 
WHERE Нахождение_мед.ИД_чел = obj_id;
END IF;
END;
$$;

alter function obj_inv(text, integer) owner to s225039;

