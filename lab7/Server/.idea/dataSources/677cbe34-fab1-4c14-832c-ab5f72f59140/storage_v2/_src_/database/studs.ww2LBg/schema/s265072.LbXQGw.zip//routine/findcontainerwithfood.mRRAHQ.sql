create function findcontainerwithfood(shortyid integer) returns integer
    language plpgsql
as
$$
DECLARE 
	scene integer;
	cont integer;
	obj integer;
BEGIN 
	select scene_id into scene from Shorty where shorty_id = shortyId;
	IF (scene is NULL) THEN RETURN 0; END IF;
	FOR cont IN (SELECT container_id FROM Container JOIN Room using (room_id) WHERE scene_id = scene) LOOP
		IF (SELECT NOT EXISTS(SELECT 1 FROM Thing WHERE eatable = true AND cont = container_id)) THEN CONTINUE; END IF;
		UPDATE Shorty SET action_until_feed = (action_until_feed - 1) WHERE shorty_id = shortyId and action_until_feed != 0;
		SELECT object_id INTO obj FROM Changeable JOIN Container using (changeable_id) WHERE cont = container_id;
		INSERT INTO Object_to_action (shorty_id, action_id, subject_id, time) VALUES (shortyId, 7, obj, now());
		RETURN cont;
	END LOOP;
	UPDATE Shorty SET action_until_feed = (action_until_feed - 1) WHERE shorty_id = shortyId and action_until_feed != 0;
	SELECT object_id INTO obj FROM Changeable JOIN Container using (changeable_id) WHERE cont = container_id;
	INSERT INTO Object_to_action (shorty_id, action_id, subject_id, time) VALUES (shortyId, 7, obj, now());
	RETURN 0;
END;
$$;

alter function findcontainerwithfood(integer) owner to s265072;

