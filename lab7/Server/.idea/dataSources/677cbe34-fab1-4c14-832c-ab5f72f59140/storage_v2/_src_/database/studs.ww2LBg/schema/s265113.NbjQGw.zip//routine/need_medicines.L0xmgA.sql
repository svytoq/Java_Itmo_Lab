create function need_medicines() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO request_position(type, medicines_type, amount) VALUES (order_type('medicines'), NEW.type, 30);
    RETURN NEW;
END;
$$;

alter function need_medicines() owner to s265113;

