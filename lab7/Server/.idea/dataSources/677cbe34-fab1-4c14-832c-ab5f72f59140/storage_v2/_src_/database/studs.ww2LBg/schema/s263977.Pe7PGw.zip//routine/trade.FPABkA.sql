create function trade(trade_quantity integer, trade_name character varying, place_id integer) returns void
    language plpgsql
as
$$
BEGIN
    IF ((SELECT ready FROM transport WHERE name = trade_name AND isbs_id = place_id) = true) THEN
        IF ((SELECT quantity FROM market WHERE name = trade_name) > trade_quantity) THEN
            UPDATE transport SET
                                 distance = sqrt(((SELECT X^2 FROM isbs WHERE isbs.id = place_id))
                                     +(SELECT Y^2 FROM isbs WHERE isbs.id = place_id)),
                                 quantity = trade_quantity,
                                 ready = false
            WHERE (name = trade_name AND isbs_id = place_id);
            UPDATE market SET quantity = quantity - trade_quantity WHERE name = trade_name;
            UPDATE total_money SET money = money - trade_quantity * (SELECT cost FROM market WHERE name = trade_name) WHERE money = money;
            RAISE NOTICE 'Закупка совершена. Груз прибудет через % дней',
                round(sqrt(((SELECT X^2 FROM isbs WHERE isbs.id = place_id))
                    +(SELECT Y^2 FROM isbs WHERE isbs.id = place_id)));
        ELSE RAISE NOTICE 'На рынке недостаточно товара, осталось %',
            (SELECT quantity FROM market WHERE name = trade_name);
        END IF;
    ELSE
        RAISE NOTICE 'Транспорт не готов, либо такого товара нет в базе';
    END IF;
END
$$;

alter function trade(integer, varchar, integer) owner to s263977;

