create function register_developer(id integer, user_id integer, level text, profession_title text, salary numeric) returns void
    language plpgsql
as
$$
BEGIN

  IF people_age(user_id) < 18 THEN RAISE EXCEPTION 'User should be over 18'; END IF;
  PERFORM insert_developer(id, user_id, level, profession_title, salary);
  RAISE NOTICE 'Разработчик создан';

END;

$$;

alter function register_developer(integer, integer, text, text, numeric) owner to s264458;

