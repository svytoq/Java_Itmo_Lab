create function check_number_of_units() returns trigger
    language plpgsql
as
$$
begin
    if new.squad_type is null then
        raise exception 'squad_type cannot be null';
    end if;
    if new.unit_number is null then
        raise exception 'unit_number cannot be null';
    end if;
    if (select (squad_type.base_number >= new.unit_number)
        from squad_type
        where squad_type.id = new.squad_type
        limit 1) then
        return new;
    else
        raise exception 'too much units';
    end if;
end ;
$$;

alter function check_number_of_units() owner to s265106;

