create function updatetrust(fighterid integer, traderid integer) returns integer
    language plpgsql
as
$$
declare begin UPDATE "trust" SET "trust_level" = trust_level + 1 WHERE "fighter_id" = fighterID AND "trader_id" = traderID; return 1; end;
$$;

alter function updatetrust(integer, integer) owner to s263884;

