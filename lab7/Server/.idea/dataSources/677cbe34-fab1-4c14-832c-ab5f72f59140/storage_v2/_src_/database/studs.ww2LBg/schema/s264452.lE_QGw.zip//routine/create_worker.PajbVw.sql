create function create_worker(new_name character varying, new_surname character varying, new_age integer, gender character varying, bio text, new_document_type character varying, new_document_id integer, new_work_book_id integer) returns text
    language plpgsql
as
$$
declare
    id_employee uuid;
begin
    if not exists(select e.id from employee e where e.name = new_name AND e.surname = new_surname AND e.age = new_age) then
        insert into employee(age, biography, name, sex, surname) values
        (new_age, bio, new_name, gender, new_surname) returning id into id_employee;
        insert into employee_docs(document_id, document_type, work_book_id, owner_id) values
        (new_document_id, new_document_type, new_work_book_id, id_employee);
    end if;
    return 'Worker created. Id: ' || id_employee;
end;
$$;

alter function create_worker(varchar, varchar, integer, varchar, text, varchar, integer, integer) owner to s264452;

