create function check_event_participation_date_belonging_to_event_timespan() returns trigger
    language plpgsql
as
$$
declare
  event events;
begin
  select * into event from events where events.id = new.event_id;

  if (new.date not between event.started_on and event.ended_on)
  then raise exception 'Event participation date is not included in the event time span';
  end if;

  return new;
end;
$$;

alter function check_event_participation_date_belonging_to_event_timespan() owner to s244706;

