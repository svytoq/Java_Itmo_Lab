create function to_cancel_ticket(tic_id integer) returns void
    language plpgsql
as
$$
begin
delete from ticket where id=tic_id;
end;
$$;

alter function to_cancel_ticket(integer) owner to s265061;

