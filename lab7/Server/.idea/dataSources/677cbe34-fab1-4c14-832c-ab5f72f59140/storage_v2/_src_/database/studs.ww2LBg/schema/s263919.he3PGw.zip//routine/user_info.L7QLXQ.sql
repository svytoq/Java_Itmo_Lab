create function user_info(originator integer)
    returns TABLE(recipient_id integer, customer_name character varying)
    language plpgsql
as
$$
begin
    return query select DISTINCT m.recipient_id, c.customer_name from message m join customer c  on (m.recipient_id = c.customer_id) where (m.sender_id = originator) or (m.recipient_id = originator);
end;
$$;

alter function user_info(integer) owner to s263919;

