create function insert_skill_after_lesson() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((SELECT COUNT(ИД_ПОЛЬЗОВАТЕЛЯ) FROM НАВЫКИ_ПОЛЬЗОВАТЕЛЯ WHERE ((ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛЬЗОВАТЕЛЯ) 
AND (ИД_НАВЫКА = (SELECT ИД_НАВЫКА FROM ЗАНЯТИЯ WHERE ИД_ЗАНЯТИЯ = NEW.ИД_ЗАНЯТИЯ))) GROUP BY ИД_ПОЛЬЗОВАТЕЛЯ) > 0) THEN
IF (((SELECT КОЭФФИЦИЕНТ_ВЛАДЕНИЯ FROM НАВЫКИ_ПОЛЬЗОВАТЕЛЯ WHERE ((ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛЬЗОВАТЕЛЯ) 
AND (ИД_НАВЫКА = (SELECT ИД_НАВЫКА FROM ЗАНЯТИЯ WHERE ИД_ЗАНЯТИЯ = NEW.ИД_ЗАНЯТИЯ))))
 + (SELECT КОЭФФИЦИЕНТ FROM ЗАНЯТИЯ WHERE ИД_ЗАНЯТИЯ = NEW.ИД_ЗАНЯТИЯ)) >= 100)
THEN
UPDATE НАВЫКИ_ПОЛЬЗОВАТЕЛЯ SET КОЭФФИЦИЕНТ_ВЛАДЕНИЯ = 100 WHERE ((ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛЬЗОВАТЕЛЯ) 
AND (ИД_НАВЫКА = (SELECT ИД_НАВЫКА FROM ЗАНЯТИЯ WHERE ИД_ЗАНЯТИЯ = NEW.ИД_ЗАНЯТИЯ)));
ELSE
UPDATE НАВЫКИ_ПОЛЬЗОВАТЕЛЯ SET КОЭФФИЦИЕНТ_ВЛАДЕНИЯ = КОЭФФИЦИЕНТ_ВЛАДЕНИЯ + (SELECT КОЭФФИЦИЕНТ FROM ЗАНЯТИЯ WHERE ИД_ЗАНЯТИЯ = NEW.ИД_ЗАНЯТИЯ) 
WHERE ((ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛЬЗОВАТЕЛЯ) AND (ИД_НАВЫКА = (SELECT ИД_НАВЫКА FROM ЗАНЯТИЯ WHERE ИД_ЗАНЯТИЯ = NEW.ИД_ЗАНЯТИЯ)));
END IF;
ELSE
INSERT INTO НАВЫКИ_ПОЛЬЗОВАТЕЛЯ VALUES (NEW.ИД_ПОЛЬЗОВАТЕЛЯ, (SELECT ИД_НАВЫКА FROM ЗАНЯТИЯ WHERE ИД_ЗАНЯТИЯ = NEW.ИД_ЗАНЯТИЯ),  
(SELECT КОЭФФИЦИЕНТ FROM ЗАНЯТИЯ WHERE ИД_ЗАНЯТИЯ = NEW.ИД_ЗАНЯТИЯ));
END IF;
RETURN NEW;
END;
$$;

alter function insert_skill_after_lesson() owner to s242361;

