create function random_st(i integer, rand character varying) returns character varying
    language plpgsql
as
$$
DECLARE
cut VARCHAR(5);

BEGIN
  IF I%2=0 THEN
   cut =substr(rand,i,3) ;
    rand = OVERLAY(rand PLACING '' FROM I FOR 3);
    rand = rand||cut;
    rand =reverse(rand);
    cut = substr(rand,i,4);
        rand = OVERLAY(rand PLACING '' FROM I FOR 4);
    rand = rand||cut;
    rand = md5(rand);
    RETURN rand ;
  END IF;
  IF I%2=1 THEN
    cut =substr(rand,i,5) ;
        rand = OVERLAY(rand PLACING '' FROM I FOR 5);
    cut=reverse(cut);
    rand = rand||cut;
      cut = substr(rand,i,3);
          rand = OVERLAY(rand PLACING '' FROM I FOR 3);
    rand = rand||cut;
    rand = md5(rand);
    RETURN rand;

  END IF;

END ;
$$;

alter function random_st(integer, varchar) owner to s225081;

