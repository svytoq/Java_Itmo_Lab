create function check_s_w() returns trigger
    language plpgsql
as
$$
BEGIN

  IF (NEW.lev > 14)
  THEN
    UPDATE skill_witcher set lev = 14 where witcher_id = NEW.witcher_id and skill_id = NEW.skill_id;
  END IF;
  
   RETURN NEW;
END;
$$;

alter function check_s_w() owner to s268428;

