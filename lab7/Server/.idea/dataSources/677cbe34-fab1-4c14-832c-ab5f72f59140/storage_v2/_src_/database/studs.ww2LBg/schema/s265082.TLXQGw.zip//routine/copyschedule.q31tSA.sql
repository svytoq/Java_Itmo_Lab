create function copyschedule(schedule integer, client integer) returns integer
    strict
    language plpgsql
as
$$
DECLARE
newSchedId int;
BEGIN
INSERT INTO расписание(название, id_клиента, описание, состояние) SELECT название, client, описание, 'E'  FROM расписание WHERE id = schedule RETURNING id INTO newSchedId;
	INSERT INTO запись_расписания(название, id_расписания, id_заказа, день_недели, время) SELECT название, newSchedId, id_заказа, день_недели, время FROM запись_расписания WHERE id_расписания = schedule;
	RETURN newSchedId;
END;
$$;

alter function copyschedule(integer, integer) owner to s265082;

