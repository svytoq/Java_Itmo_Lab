create function findemployeefortest(test integer) returns integer
    language plpgsql
as
$$
begin
    return (
        select employee_id 
        from employees_tests 
        where employees_tests.test_id=test
        order by RANDOM() limit 1);
end;
$$;

alter function findemployeefortest(integer) owner to s264446;

