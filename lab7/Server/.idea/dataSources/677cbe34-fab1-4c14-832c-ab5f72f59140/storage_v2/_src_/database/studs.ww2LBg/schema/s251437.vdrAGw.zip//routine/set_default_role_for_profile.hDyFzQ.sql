create function set_default_role_for_profile() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO
        role_profile_relation(role_id, profile_id)
    VALUES(1, new.id);

    RETURN new;
END;
$$;

alter function set_default_role_for_profile() owner to s251437;

