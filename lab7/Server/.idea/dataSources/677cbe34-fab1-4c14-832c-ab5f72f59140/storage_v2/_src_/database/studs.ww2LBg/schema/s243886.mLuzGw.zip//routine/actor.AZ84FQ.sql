create function actor(name text, OUT "АННОТАЦИЯ" text, OUT "ИМЯ" character varying) returns SETOF record
    language sql
as
$$
SELECT РЕЦЕНЗИЯ.АННОТАЦИЯ, ЧЕЛОВЕК.ИМЯ FROM РЕЦЕНЗИЯ JOIN ФИЛЬМ ON РЕЦЕНЗИЯ.ИД_Ф= ФИЛЬМ.ИД JOIN КРИТИК ON КРИТИК.ИД_Ч= РЕЦЕНЗИЯ.ИД_К JOIN ЧЕЛОВЕК ON ЧЕЛОВЕК.ИД = КРИТИК.ИД_Ч WHERE ФИЛЬМ.НАЗВАНИЕ = name;
$$;

alter function actor(text, out text, out varchar) owner to s243886;

