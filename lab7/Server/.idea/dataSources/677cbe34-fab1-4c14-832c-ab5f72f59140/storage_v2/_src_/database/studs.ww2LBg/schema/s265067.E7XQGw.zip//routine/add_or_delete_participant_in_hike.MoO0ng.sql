create function add_or_delete_participant_in_hike() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP = 'INSERT' THEN
    UPDATE hikes
    SET number_people = number_people + 1
    where hike_id = new.hike_id;
    return new;

  ELSEIF TG_OP = 'DELETE' THEN
    UPDATE hikes
    SET number_people = number_people - 1
    where hike_id = old.hike_id;
    return OLD;
  END IF;

end;
$$;

alter function add_or_delete_participant_in_hike() owner to s265067;

