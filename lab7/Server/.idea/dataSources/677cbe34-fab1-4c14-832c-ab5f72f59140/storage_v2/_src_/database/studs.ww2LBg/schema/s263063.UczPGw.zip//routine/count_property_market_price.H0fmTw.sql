create function count_property_market_price(propertyid integer, currencyid integer) returns double precision
    language plpgsql
as
$$
declare avgPropertyPrice float;
    begin
        avgPropertyPrice = (select avg(price) from property_listing where property_id = propertyId
                                                                                        and currency_id = currencyId);
        return avgPropertyPrice;
    end;
$$;

alter function count_property_market_price(integer, integer) owner to s263063;

