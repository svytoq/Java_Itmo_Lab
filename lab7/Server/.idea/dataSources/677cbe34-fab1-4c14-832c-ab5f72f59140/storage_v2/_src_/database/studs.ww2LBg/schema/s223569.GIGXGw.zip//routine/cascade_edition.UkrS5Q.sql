create function cascade_edition() returns trigger
    language plpgsql
as
$$
BEGIN
DELETE FROM "Покупка" WHERE "Издание_ИД" = old.ИД;
    RETURN OLD;
  END;
$$;

alter function cascade_edition() owner to s223569;

