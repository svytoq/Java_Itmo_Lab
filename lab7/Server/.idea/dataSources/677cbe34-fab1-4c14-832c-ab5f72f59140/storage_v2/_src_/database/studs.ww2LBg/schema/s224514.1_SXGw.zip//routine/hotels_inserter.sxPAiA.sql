create function hotels_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	rand INTEGER;
	length integer;
	i INTEGER DEFAULT 1;
	count integer default 0;
	chars text[] = '{a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z}';
	name text;
	adress text;

BEGIN
	for i in 1..N loop

		rand = random();
		length = random() * 10;

		while count<length or name=null or adress=null loop
			name = concat(chars[1+random()*(array_length(chars, 1)-1)], name);
			adress = concat(chars[1+random()*(array_length(chars, 1)-1)], adress);
			count = count+1;
		end loop;

		insert into "ОТЕЛЬ" values(DEFAULT, initcap(name), initcap(adress));
		name = NULL;
		adress = NULL;
		count = 0;

	end loop;
END;
$$;

alter function hotels_inserter(integer) owner to s224514;

