create function authenticate_user_profile(email text, password_hash text) returns SETOF s267880.user_profile
    language sql
as
$$
select * from user_profile where email = $1 and password_hash = $2;
$$;

alter function authenticate_user_profile(text, text) owner to s267880;

