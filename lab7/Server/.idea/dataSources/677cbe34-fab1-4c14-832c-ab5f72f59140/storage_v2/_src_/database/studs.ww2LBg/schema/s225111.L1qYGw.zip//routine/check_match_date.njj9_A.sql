create function check_match_date() returns trigger
    language plpgsql
as
$$
BEGIN
    -- если не установлен турнир, то ничего не проверяем
    IF NEW.tournament_id IS NULL
    THEN
      RETURN NEW;
    END IF;

    -- проверяем, что дата лежит в пределах дат проведения турнира
    -- а также, что победитель либо установлен, либо не установлен потому, что еще не окончен матч
    IF NEW.date < (SELECT date_begin FROM tournament WHERE tournament_id = NEW.tournament_id) AND
          NEW.date >= (SELECT date_end FROM tournament WHERE tournament_id = NEW.tournament_id) AND
       (
         (NEW.winner_nickname IS NOT NULL) OR
         (current_date > (SELECT date_begin FROM tournament WHERE tournament_id = NEW.tournament_id))
       )
    THEN
      RETURN NEW;
    END IF;

    -- если что-то не выполнилось, отменяем действие
    RETURN NULL;
  END;
$$;

alter function check_match_date() owner to s225111;

