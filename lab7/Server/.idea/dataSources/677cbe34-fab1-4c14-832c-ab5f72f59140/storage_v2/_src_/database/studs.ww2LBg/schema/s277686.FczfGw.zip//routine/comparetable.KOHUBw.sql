create function comparetable() returns boolean
    language plpgsql
as
$$
BEGIN
RETURN (SELECT COUNT(*) =2 FROM
(SELECT time, activity FROM Truman_schedule
UNION
SELECT time, activity FROM show_schedule) AS compare_table WHERE time = '08:00:00');
END
$$;

alter function comparetable() owner to s277686;

