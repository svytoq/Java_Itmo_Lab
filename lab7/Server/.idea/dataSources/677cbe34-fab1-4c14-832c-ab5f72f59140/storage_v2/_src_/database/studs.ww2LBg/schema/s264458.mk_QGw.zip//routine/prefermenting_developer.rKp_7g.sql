create function prefermenting_developer(id_developer integer, skill_level text, rang text) returns void
    language plpgsql
as
$$
BEGIN

  UPDATE developer
  SET level = prefermenting_developer.skill_level, profession_title = prefermenting_developer.rang
  WHERE id = prefermenting_developer.id_developer;

END;

$$;

alter function prefermenting_developer(integer, text, text) owner to s264458;

