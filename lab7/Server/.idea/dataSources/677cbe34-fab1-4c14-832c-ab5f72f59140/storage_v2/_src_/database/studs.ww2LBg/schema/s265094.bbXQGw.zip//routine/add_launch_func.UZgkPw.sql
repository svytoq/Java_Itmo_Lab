create function add_launch_func() returns trigger
    language plpgsql
as
$$
DECLARE amountOfLaunches INTEGER;
BEGIN
    amountOfLaunches = (select count(*) from launches where launch_date = new.launch_date and base_id = new.base_id);
    IF amountOfLaunches + 1 > (select max_launch_amount from base where base.base_id = new.base_id) THEN
        RAISE EXCEPTION 'Превышен лимит запусков за день!';
    ELSE RETURN new;
    end if;
END
$$;

alter function add_launch_func() owner to s265094;

