create function takeoffsuit(shortyid integer) returns boolean
    language plpgsql
as
$$
DECLARE 
	scene integer;
BEGIN
	SELECT scene_id INTO scene FROM Shorty WHERE shorty_id = shortyId;
	IF (scene is NULL) THEN RETURN false; END IF;
	IF (SELECT NOT is_space_suit FROM Shorty WHERE shorty_id = shortyId) THEN RETURN false; END IF;
	IF (scene = 1)  THEN RETURN false; END IF;
	IF (SELECT 1 FROM Door JOIN Changeable using (changeable_id) WHERE is_state = true AND (scene = scene1_id OR scene = scene2_id) AND (scene1_id = 1 OR scene2_id = 1)) THEN RETURN false; END IF;
	UPDATE Shorty SET is_space_suit = false WHERE shorty_id = shortyId;
	UPDATE Shorty SET action_until_feed = (action_until_feed - 1) WHERE shorty_id = shortyId and action_until_feed != 0;
	INSERT INTO Object_to_action (shorty_id, action_id, time) VALUES (shortyId, 4, now());
	RETURN true;
END;
$$;

alter function takeoffsuit(integer) owner to s265072;

