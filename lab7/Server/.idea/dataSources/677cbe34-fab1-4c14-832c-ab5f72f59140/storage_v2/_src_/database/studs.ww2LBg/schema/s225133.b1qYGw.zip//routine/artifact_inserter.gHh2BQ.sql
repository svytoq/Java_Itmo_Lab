create function artifact_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
    N alias for $1;
    length integer;
    i INTEGER DEFAULT 1;
    count integer default 0;
    k integer;
    chars text[] := '{A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z}';
    name text := '';
    place text := '';
    rarity text := '';
    bonus text := '';

BEGIN

    if((select max(id) from "Артефакт") >= i)THEN
      i:=(select max(id) from "Артефакт") + 1;
    END If;

    for k in i..(N + i - 1) loop

        length:=random() * 1 + 13;

        while count<length or name=null or place=null or rarity=null or bonus=null loop
            name := name || chars[1+random()*(array_length(chars, 1)-1)];
            place := place || chars[1+random()*(array_length(chars, 1)-1)];
            rarity := rarity || chars[1+random()*(array_length(chars, 1)-1)];
            bonus := bonus || chars[1+random()*(array_length(chars, 1)-1)];
            count:=count+1;
        end loop;

        insert into "Артефакт" values(k, initcap(name), initcap(place), initcap(rarity), initcap(bonus), (SELECT id FROM "Экипировка" ORDER BY random() LIMIT 1));
        name := '';
        place:= '';
        rarity:= '';
        bonus:= '';
        count:= 0;

    end loop;

END;
$$;

alter function artifact_inserter(integer) owner to s225133;

