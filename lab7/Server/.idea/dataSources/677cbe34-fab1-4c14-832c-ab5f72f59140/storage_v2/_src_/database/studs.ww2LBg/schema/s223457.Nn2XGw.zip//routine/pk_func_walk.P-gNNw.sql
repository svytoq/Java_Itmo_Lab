create function pk_func_walk() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_walk');
  RETURN new;
END;
$$;

alter function pk_func_walk() owner to s223457;

