create function snowmobile_leaving() returns trigger
    language plpgsql
as
$$
DECLARE
    new_order_id integer;
BEGIN
    UPDATE snowmobile SET station = NULL, on_station = NULL WHERE snowmobile_id = NEW.snowmobile_id;
    INSERT INTO orders(to_Antarctida) VALUES (false) RETURNING new_order_id = order_id;
    INSERT INTO order_position(type, order_id, snowmobile_id)
    VALUES (order_type('snowmobile'), new_order_id, NEW.snowmobile_id);
    RETURN NEW;
END;
$$;

alter function snowmobile_leaving() owner to s265113;

