create function register(customer_nick character varying) returns void
    language plpgsql
as
$$
declare
is_user_exist boolean;
begin

SELECT * 
FROM customer
WHERE EXISTS (SELECT 1
              FROM customer c
              WHERE customer_nick_name = customer_nick);

end;
$$;

alter function register(varchar) owner to s263919;

