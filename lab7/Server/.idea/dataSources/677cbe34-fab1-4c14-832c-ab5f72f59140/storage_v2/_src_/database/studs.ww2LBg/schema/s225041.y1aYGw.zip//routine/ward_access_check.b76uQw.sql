create function ward_access_check() returns trigger
    language plpgsql
as
$$
DECLARE
	rooms record;
BEGIN
	FOR rooms IN (
		SELECT ROOM.id FROM ROOM 
		JOIN ACCESS_REGIME ON ACCESS_REGIME.access_fk = ROOM.access_fk	
		WHERE ROOM.id=NEW.ward_fk
		AND ACCESS_REGIME.regime_fk=NEW.regime_fk
	) 
	LOOP
		RETURN NEW;
	END LOOP;
	RAISE EXCEPTION 'Prisoner has no access to the ward!'; 
END;
$$;

alter function ward_access_check() owner to s225041;

