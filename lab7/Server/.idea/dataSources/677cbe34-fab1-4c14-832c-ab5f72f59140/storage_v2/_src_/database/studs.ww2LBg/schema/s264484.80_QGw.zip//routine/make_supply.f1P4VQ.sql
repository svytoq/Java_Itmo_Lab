create function make_supply() returns trigger
    language plpgsql
as
$$
begin
    if (tg_op = 'INSERT') then
        if (not is_enough_res(new.supplier_id, new.client_id, new.resource_type, new.resource_count)) then
            raise exception 'У поставщика недостаточно ресурсов';
        end if;
        return new;
    elsif (tg_op = 'UPDATE') then
        --update запрещен
        raise exception 'Изменение данных запрещено';
    elsif (tg_op = 'DELETE') then
        if (not is_enough_res(old.client_id, old.supplier_id, old.resource_type, old.resource_count)) then
            raise exception 'У клиента недостаточно ресурсов, чтобы вернуть их';
        end if;
        return old;
    end if;
end;
$$;

alter function make_supply() owner to s264484;

