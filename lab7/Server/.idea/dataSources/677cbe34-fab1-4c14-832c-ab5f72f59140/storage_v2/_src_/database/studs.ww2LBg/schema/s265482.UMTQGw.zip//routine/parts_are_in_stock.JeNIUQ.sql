create function parts_are_in_stock() returns void
    language plpgsql
as
$$
declare
        rec record;
        base record;
        part_num int;
        ok bool = true;
    begin
        select * from builds where id = new.build_id limit 1 into rec;
        select * from bases where id = rec.base_id limit 1 into base;
        --base
        part_num = base.part_number;
        if ((select count_left from shipments where part_number = part_num) <= 0) then
            raise exception 'naaah';
        end if;
        --cpu
        part_num = (select part_number from cpus where id = base.cpu_id);
        if ((select count_left from shipments where part_number = part_num) <= 0) then
            raise exception 'naaah';
        end if;
        --display
        part_num = (select part_number from displays where id = base.display_id);
        if ((select count_left from shipments where part_number = part_num) <= 0) then
            raise exception 'naaah';
        end if;
        --gpu
        part_num = (select part_number from gpus where id = rec.gpu_id);
        if ((select count_left from shipments where part_number = part_num) <= 0) then
            raise exception 'naaah';
        end if;
        --ram
        if (rec.ram1_id = rec.ram2_id) then
            part_num = (select part_number from ram where id = rec.ram1_id);
            if ((select count_left from shipments where part_number = part_num) <= 1) then
                raise exception 'naaah';
            end if;
            else
                part_num = (select part_number from ram where id = rec.ram1_id);
                if ((select count_left from shipments where part_number = part_num) <= 0) then
                    raise exception 'naaah';
                end if;
                part_num = (select part_number from ram where id = rec.ram2_id);
                if ((select count_left from shipments where part_number = part_num) <= 0) then
                    raise exception 'naaah';
                end if;
        end if;
        --drive
        if (rec.drive1_id = rec.drive2_id) then
            part_num = (select part_number from drives where id = rec.drive1_id);
            if ((select count_left from shipments where part_number = part_num) <= 1) then
                raise exception 'naaah';
            end if;
        else
            part_num = (select part_number from drives where id = rec.drive1_id);
            if ((select count_left from shipments where part_number = part_num) <= 0) then
                raise exception 'naaah';
            end if;
            part_num = (select part_number from drives where id = rec.drive2_id);
            if ((select count_left from shipments where part_number = part_num) <= 0) then
                raise exception 'naaah';
            end if;
        end if;
    return;
    end
$$;

alter function parts_are_in_stock() owner to s265482;

