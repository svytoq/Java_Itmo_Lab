create function do_delivery_by_miner_id(min_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	part_miner text;
BEGIN
	SELECT part INTO part_miner FROM Brigade_record WHERE Brigade_record.miner_id = min_id;
	IF (part_miner = 'КОПАТЕЛЬ') THEN
		PERFORM do_delivery_equipment(min_id, 'ЛОПАТА'); 
	ELSEIF (part_miner = 'БУРИЛЬЩИК') THEN
		PERFORM do_delivery_equipment(min_id, 'БУР'); 
	ELSE
		PERFORM do_delivery_auto(min_id);
	END IF;
	RETURN TRUE;
END;
$$;

alter function do_delivery_by_miner_id(integer) owner to s264905;

