create function check_machine_strength(machine_type integer, strength integer) returns boolean
    language sql
as
$$
SELECT (t1.base_strength >= strength) FROM machine_type as t1 WHERE t1.ID = machine_type
$$;

alter function check_machine_strength(integer, integer) owner to s265106;

