create function "ЗАМЕНИТЬ_ПРЕПОДАВАТЕЛЯ"(event_id integer, teacher_id integer, is_lesson boolean) returns boolean
    language plpgsql
as
$$
BEGIN
	if (is_lesson=TRUE) THEN
		UPDATE ЗАНЯТИЕ SET ПРЕП_ИД=teacher_id WHERE ЗАНЯТИЕ_ИД=event_id;
	ELSE
		UPDATE ЭКЗАМЕН SET ПРЕП_ИД=teacher_id WHERE ЭКЗАМЕН_ИД=event_id;
	END IF;
	RETURN TRUE;
END;
$$;

alter function "ЗАМЕНИТЬ_ПРЕПОДАВАТЕЛЯ"(integer, integer, boolean) owner to s265057;

