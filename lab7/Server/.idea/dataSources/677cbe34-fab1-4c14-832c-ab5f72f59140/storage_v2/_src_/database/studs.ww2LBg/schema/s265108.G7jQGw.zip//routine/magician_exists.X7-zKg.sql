create function magician_exists(magician integer) returns boolean
    language plpgsql
as
$$
DECLARE
          mag_exists boolean;
        BEGIN
          SELECT 1 INTO mag_exists FROM Magicians m WHERE m.person_id = magician;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Такого мага нет, проверьте введенные данные';
    END IF;
        RETURN 'TRUE';
        END;
$$;

alter function magician_exists(integer) owner to s265108;

