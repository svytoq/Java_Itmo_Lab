create function update_arch() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW.ДАТА_СМЕРТИ - NEW.ДАТА_РОЖДЕНИЯ < 0) THEN
            RAISE EXCEPTION 'Dates are impossible.';
    END IF;
    RETURN NEW;
END;
$$;

alter function update_arch() owner to s243843;

