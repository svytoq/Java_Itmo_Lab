create function changestatus() returns trigger
    language plpgsql
as
$$
DECLARE
    statusID text;
BEGIN
    SELECT "Status"."Name" FROM "Status" WHERE "Rating" <= NEW."Rating" ORDER BY "Rating" DESC LIMIT 1 INTO statusID;
    NEW."Status_ID" = statusID;
    RETURN NEW;
END;
$$;

alter function changestatus() owner to s264425;

