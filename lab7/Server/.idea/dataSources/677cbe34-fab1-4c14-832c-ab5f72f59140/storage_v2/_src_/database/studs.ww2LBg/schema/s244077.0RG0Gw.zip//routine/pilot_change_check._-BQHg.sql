create function pilot_change_check() returns trigger
    language plpgsql
as
$$
DECLARE
  BEGIN
   IF (NOT(
     (SELECT team_id FROM pit_stop_places WHERE (pit_stop_places.id = NEW.place_id)) =
     (SELECT team_id FROM cars WHERE (cars.id = NEW.car_id))))
     THEN RAISE EXCEPTION 'Place and car must be in one team';
     RETURN NULL;
  END IF;
  IF (NOT(
     (SELECT team_id FROM pit_stop_places WHERE (pit_stop_places.id = NEW.place_id)) =
     (SELECT team_id FROM team_members WHERE (team_members.user_id = NEW.pilot_id))))
     THEN RAISE EXCEPTION 'Pilot and car must be in one team';
     RETURN NULL;
  END IF;
  IF (NOT((SELECT spec FROM users WHERE (users.id = NEW.pilot_id)) = 'RACER'))
    THEN RAISE EXCEPTION 'Not a pilot';
      RETURN NULL;
    END IF;
  RETURN NEW;
END;
$$;

alter function pilot_change_check() owner to s244077;

