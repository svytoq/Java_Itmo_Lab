create function pk_func_people() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_people');
  RETURN new;
END;
$$;

alter function pk_func_people() owner to s223457;

