create function "ПОКАЗАТЬ_УЧЕНИКОВ_ГРУППЫ"(id integer) returns record
    language sql
as
$$
SELECT УЧЕНИК_ИД,ФАМИЛИЯ,ИМЯ,ДАТА_РОЖДЕНИЯ,УРОВЕНЬ FROM УЧЕНИК WHERE УЧЕНИК.ГРУППА_ИД=$1
$$;

alter function "ПОКАЗАТЬ_УЧЕНИКОВ_ГРУППЫ"(integer) owner to s265057;

