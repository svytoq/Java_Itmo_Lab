create function list_of_future_sin(n integer)
    returns TABLE(tormentedname text, specificsinname text)
    language plpgsql
as
$$
begin
    return query
    SELECT Tormented.TormentedName, SpecificSin.SpecificSinName
FROM tormented
inner join tormented_has_specificsin on tormented.idTormented=Tormented_idTormented
inner join specificsin on idSpecificSin=SpecificSin_idSpecificSin
inner join subcircle on specificsin.idSpecificSin=subcircle.idSpecificSin
where idTormented=n ;
end;
$$;

alter function list_of_future_sin(integer) owner to s242430;

