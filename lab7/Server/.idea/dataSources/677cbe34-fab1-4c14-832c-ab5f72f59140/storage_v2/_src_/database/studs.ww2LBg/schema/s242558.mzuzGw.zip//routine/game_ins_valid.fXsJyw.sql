create function game_ins_valid() returns trigger
    language plpgsql
as
$$
BEGIN
    IF new.поб_ид=new.про_ид THEN
        RAISE EXCEPTION 'Одна команда не может быть победившей и проигравшей одновременно!';
    END IF;
    RETURN NEW;
END;
$$;

alter function game_ins_valid() owner to s242558;

