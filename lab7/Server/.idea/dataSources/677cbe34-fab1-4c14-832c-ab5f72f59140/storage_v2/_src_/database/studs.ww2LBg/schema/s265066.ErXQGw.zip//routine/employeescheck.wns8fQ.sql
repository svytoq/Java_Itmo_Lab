create function employeescheck() returns trigger
    language plpgsql
as
$$
begin
    if (select counterpart from People where person_id = NEW.person_id) is NULL then
        raise exception 'counterpart not found';
    end if;

    return NEW;
end;
$$;

alter function employeescheck() owner to s265066;

