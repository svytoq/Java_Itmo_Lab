create function "ПЕРСОНАЛ_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  telo uuid;
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
telo = (SELECT "ИД_ЧЕЛОВЕКА" FROM "ЧЕЛОВЕК" OFFSET floor(random()*500) LIMIT 1);
IF (NOT (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."ИД_ЧЕЛОВЕКА" = telo))) THEN
IF (exists(SELECT FROM "ЧЕЛОВЕК" WHERE "ЧЕЛОВЕК"."ИД_ЧЕЛОВЕКА" = telo)) THEN
INSERT INTO "ПЕРСОНАЛ" ("ИД_ЧЕЛОВЕКА","ЗАРПЛАТА", "НОМЕР_ПАСПОРТА","ДАТА_ПРИЁМА","ДАТА_УВОЛЬНЕНИЯ")
VALUES (telo,w,(select trunc(random() * 9999999 + 10000)),date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)),date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)));
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END IF;
END IF;
END LOOP;
END;
$$;

alter function "ПЕРСОНАЛ_ТЕСТ"(integer) owner to s223443;

