create function raisea() returns void
    language plpgsql
as
$$
BEGIN
  raise 'Ура-Ура-Ура';
  drop rule deny_update
  on refill;
end;
$$;

alter function raisea() owner to s243872;

