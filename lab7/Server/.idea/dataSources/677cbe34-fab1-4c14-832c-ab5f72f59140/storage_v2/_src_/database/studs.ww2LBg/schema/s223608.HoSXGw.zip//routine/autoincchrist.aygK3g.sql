create function autoincchrist() returns trigger
    language plpgsql
as
$$
BEGIN
   NEW.ID := nextval('IdChristSequence');
   Return NEW;
 END;
$$;

alter function autoincchrist() owner to s223608;

