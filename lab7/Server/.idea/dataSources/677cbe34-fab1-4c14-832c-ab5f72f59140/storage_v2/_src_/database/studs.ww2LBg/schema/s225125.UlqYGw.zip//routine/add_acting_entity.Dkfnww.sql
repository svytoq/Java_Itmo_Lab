create function add_acting_entity(id integer, tbl text) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO Действ_сущности (ИД, tblname) values (id, tbl);
  PERFORM * FROM Действ_сущности WHERE ИД = id;
  IF FOUND THEN
    RAISE INFO 'FOUND';
  END IF;
END
$$;

alter function add_acting_entity(integer, text) owner to s225125;

