create function new_object() returns trigger
    language plpgsql
as
$$
DECLARE
 men_id integer;
 obj_id integer;
BEGIN
 men_id = OLD.ИД;
 obj_id = max(Объект.ИД) + 1;
 INSERT INTO Объект VALUES (obj_id, OLD.Фамилия, OLD.ИД_район);
 WITH old_am AS(
   SELECT ИД_ор, Количество FROM Амуниция
      WHERE ИД_чел = men_id)
 INSERT INTO Нахождение_оруж VALUES(old_am.ИД_ор, obj_id, old_am.Количество);
 WITH old_bz AS(
   SELECT ИД_пат, Количество FROM БЗ
   WHERE ИД_чел = men_id)
 INSERT INTO Нахождение_пат VALUES (old_bz.ИД_пат, obj_id, old_bz.Количество);
 WITH old_pr AS(
   SELECT ИД_прод, Количество FROM Запас_прод
   WHERE ИД_чел = men_id)
 INSERT INTO Нахождение_прод VALUES (old_pr.ИД_прод, obj_id, old_pr.Количество);
 WITH old_med AS(
   SELECT ИД_мед, Количество FROM Аптечка
   WHERE ИД_чел = men_id)
 INSERT INTO Нахождение_мед VALUES (old_med.ИД_мед, obj_id, old_med.Количество);
 RETURN OLD;
END;
$$;

alter function new_object() owner to s225039;

