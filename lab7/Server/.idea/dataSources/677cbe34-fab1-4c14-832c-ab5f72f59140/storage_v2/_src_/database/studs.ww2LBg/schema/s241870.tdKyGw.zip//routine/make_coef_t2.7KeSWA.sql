create function make_coef_t2(matchid integer) returns numeric
    language plpgsql
as
$$
declare
team1_b integer ;
team2_b integer ;
team2_coef decimal ;
begin
SELECT Команды.Бюджет into team1_b FROM Команды t
INNER JOIN Матчи m ON t.ID_Команды = m.ID_Команды1
WHERE m.ID_Матча = matchid;
SELECT Команды.Бюджет into team2_b FROM Команды t
INNER JOIN Матчи m ON t.ID_Команды = m.ID_Команды2
WHERE m.ID_Матча = matchid;
team2_coef =((team1_b/team2_b)*0.5)+1;
return team2_coef;
end
$$;

alter function make_coef_t2(integer) owner to s241870;

