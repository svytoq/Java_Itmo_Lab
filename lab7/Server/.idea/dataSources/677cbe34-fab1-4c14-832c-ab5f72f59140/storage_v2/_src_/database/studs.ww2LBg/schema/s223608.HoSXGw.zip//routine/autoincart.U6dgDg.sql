create function autoincart() returns trigger
    language plpgsql
as
$$
BEGIN
     NEW.ID := nextval('IdArtSequence');
   Return NEW;
 END;
$$;

alter function autoincart() owner to s223608;

