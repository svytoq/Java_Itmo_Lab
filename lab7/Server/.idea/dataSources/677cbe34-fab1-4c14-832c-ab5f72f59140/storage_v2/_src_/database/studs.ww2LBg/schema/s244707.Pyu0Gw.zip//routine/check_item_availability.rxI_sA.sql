create function check_item_availability() returns trigger
    language plpgsql
as
$$
DECLARE
  has_unavailable_items BOOLEAN;
BEGIN
  has_unavailable_items := (with
    items_available as (
      select p.amount, p.part_number from products p, products_users pc, orders o
      where p.part_number = pc.part_number
    ), items_required as (
      select amount, part_number from products_users where id_user = new.id_customer
    )
select exists(
    select from items_required p
    inner join items_available a on (p.part_number = a.part_number)
    where p.amount > a.amount));

  IF has_unavailable_items
  THEN RAISE EXCEPTION 'Not enough items';
  END IF;
	return new;
END;
$$;

alter function check_item_availability() owner to s244707;

