create function create_wish(vtype_id bigint, vcategory bigint, vcom_ncom text, vparticipant_id bigint, vmonth text) returns bigint
    language plpgsql
as
$$
DECLARE
  ret bigint;
BEGIN
  INSERT INTO wishes(type_id, category, com_ncom, participant_id, month)
  VALUES (vtype_id, vcategory, vcom_ncom,vparticipant_id, vmonth) returning wish_id into ret;
  RETURN ret;
END;
$$;

alter function create_wish(bigint, bigint, text, bigint, text) owner to s265067;

