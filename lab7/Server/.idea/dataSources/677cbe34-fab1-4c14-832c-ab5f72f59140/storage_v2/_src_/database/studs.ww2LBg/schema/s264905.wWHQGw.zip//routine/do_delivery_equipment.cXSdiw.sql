create function do_delivery_equipment(miner_id integer, equipment_name text) returns boolean
    language plpgsql
as
$$
DECLARE
	equip_id integer;
BEGIN
	SELECT equipment_id INTO equip_id FROM Equipment WHERE Equipment.name = equipment_name AND NOT(equipment_id IN (SELECT equipment_id FROM Delivery_Equipment)) LIMIT 1;
	INSERT INTO Delivery_equipment (equipment_id, miner_id, delivery_date) VALUES (equip_id, miner_id, current_date);	
	RETURN TRUE;
END;
$$;

alter function do_delivery_equipment(integer, text) owner to s264905;

