create function "КНИГИ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('КНИГИ_ИД_seq')!=NEW.ИД THEN
    NEW.ИД=nextval('КНИГИ_ИД_seq');
        RETURN NEW;
ELSE
RETURN NEW;
END IF;   
    END;
$$;

alter function "КНИГИ_ИД"() owner to s225058;

