create function get_all_bonus_for_contract(con_id integer)
    returns TABLE(contact character varying, reason text, bonus text, description text)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY select c.number, cb.reason, b.name, b.description
                 FROM CONTRACT AS c
                          join contract_bonus cb on c.id = cb.contract_id
                          join bonus b on b.id = cb.bonus_id
                 WHERE c.id = con_id;
end;
$$;

alter function get_all_bonus_for_contract(integer) owner to s265109;

