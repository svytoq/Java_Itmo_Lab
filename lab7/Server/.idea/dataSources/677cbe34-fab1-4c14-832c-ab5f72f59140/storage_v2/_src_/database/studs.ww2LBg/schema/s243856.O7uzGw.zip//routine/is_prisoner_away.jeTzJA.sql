create function is_prisoner_away(id integer) returns boolean
    language plpgsql
as
$$
DECLARE
id_prisoner int = (SELECT id_creature FROM find_creature 
WHERE id_creature = id);
BEGIN
IF id_prisoner != null THEN 
RETURN false;
END IF;
RETURN true;
END;
$$;

alter function is_prisoner_away(integer) owner to s243856;

