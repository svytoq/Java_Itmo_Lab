create function remove_tmp_123() returns integer
    language plpgsql
as
$$
DECLARE
    check_table varchar;
    count_rows integer;
    removed_tables integer;
BEGIN
    removed_tables := 0;
    FOR check_table IN
        SELECT table_name
        FROM information_schema.tables
        where 1=1
            and table_catalog = 'you_db_name'
            and table_type = 'BASE TABLE'
            and table_name ilike 'tmp_123%'
    LOOP
        execute format('SELECT COUNT(*) from  %I ;', check_table) into count_rows;
        IF (count_rows = 0)
        then
            execute format('DROP TABLE  %I ;', check_table);
            removed_tables := removed_tables + 1;
        end IF;
    END LOOP;

RETURN removed_tables;
END;
$$;

alter function remove_tmp_123() owner to s243880;

