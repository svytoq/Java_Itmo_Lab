create function insert_people_rel() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
    hum_1 INTEGER = trunc(random()*10000)+1;
    hum_2 INTEGER = trunc(random()*10000)+1;
  BEGIN
    LOOP
      if (NOT EXISTS(SELECT * FROM people_rel WHERE hum1 = hum_1 AND hum2 = hum_2))
        AND (NOT EXISTS(SELECT * FROM people_rel WHERE hum1 = hum_2 AND hum2 = hum_1))
        AND (NOT hum_1 = hum_2)
        THEN
          INSERT INTO people_rel VALUES (DEFAULT, hum_1, hum_2, trunc(random()*50)+1);
          count = count + 1;
        ELSE
          hum_1 = trunc(random()*10000)+1;
          hum_2 = trunc(random()*10000)+1;
      END IF;
      EXIT WHEN count = 5000;
    END LOOP;
  END;
$$;

alter function insert_people_rel() owner to s225107;

