create function getobservatoryequipmentoccupiedtimetable(observatory_name text)
    returns TABLE(equipment_name text, startts timestamp without time zone, endts timestamp without time zone)
    language plpgsql
as
$$
DECLARE
    observatory_id_local int;
BEGIN
    select id into observatory_id_local from observatory where name = observatory_name;
    return query
        select equipment.name, starttimestamp, endtimestamp
        from equipment
                 inner join observatory on equipment.observatoryid = observatory.id
                 inner join equipmentoccupiedintervals on equipment.id = equipmentoccupiedintervals.equipmentid
                 inner join timestampinterval on timestampinterval.id = equipmentoccupiedintervals.timestampintervalid
        where observatoryid = observatory_id_local;
END;
$$;

alter function getobservatoryequipmentoccupiedtimetable(text) owner to s265111;

