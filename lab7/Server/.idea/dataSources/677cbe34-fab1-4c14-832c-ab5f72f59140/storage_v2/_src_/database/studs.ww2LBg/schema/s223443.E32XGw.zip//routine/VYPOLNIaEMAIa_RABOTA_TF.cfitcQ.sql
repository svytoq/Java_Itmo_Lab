create function "ВЫПОЛНЯЕМАЯ_РАБОТА_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW."ИД_РАБОТЫ" IS NULL THEN
   NEW."ИД_РАБОТЫ" = generate_UUID();
END IF;
IF (exists(SELECT FROM "ВЫПОЛНЯЕМАЯ_РАБОТА" WHERE "ВЫПОЛНЯЕМАЯ_РАБОТА"."ИД_РАБОТЫ" = NEW."ИД_РАБОТЫ")) THEN
RAISE 'Работа с указанным ид уже существует';
END IF;
IF NEW."НАЗВАНИЕ" IS NULL THEN
RAISE 'Графа "Название" не может быть пустой.';
END IF;
IF NEW."ОПИСАНИЕ" IS NULL THEN
RAISE 'Графа "Описание" не может быть пустой.';
END IF;
return NEW;
END;
$$;

alter function "ВЫПОЛНЯЕМАЯ_РАБОТА_ТФ"() owner to s223443;

