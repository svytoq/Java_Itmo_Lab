create function caid() returns trigger
    language plpgsql
as
$$
begin
	new.НОМЕР_КАССЫ := nextval('casses_seq');
	return new;
end
$$;

alter function caid() owner to s225120;

