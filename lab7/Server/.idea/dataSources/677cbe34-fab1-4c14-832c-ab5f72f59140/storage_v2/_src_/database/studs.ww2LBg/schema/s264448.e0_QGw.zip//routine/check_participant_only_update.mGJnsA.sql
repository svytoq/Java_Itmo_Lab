create function check_participant_only_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.team_id IS NULL OR NEW.team_id != OLD.team_id THEN
        DELETE FROM team
        WHERE team_id = OLD.team_id;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_participant_only_update() owner to s264448;

