create function dup(integer, OUT f1 integer, OUT f2 text) returns record
    language sql
as
$$
SELECT $1, CAST($1 AS text) || ' is text'
$$;

alter function dup(integer, out integer, out text) owner to s243858;

