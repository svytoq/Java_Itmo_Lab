create function pk_func_worker() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_worker');
  RETURN new;
END;
$$;

alter function pk_func_worker() owner to s223457;

