create function generate_data() returns integer
    language plpgsql
as
$$
DECLARE
region_one int;
BEGIN
  INSERT INTO Regions(id, order_id, name)
  SELECT i, random_between(1,3), md5(RANDOM()::TEXT) FROM generate_series(5, 1005) as i;

  FOR region_one IN
        SELECT id FROM regions
    LOOP
        RAISE NOTICE 'regions generated(%)', region_one;
    END LOOP;
  
  INSERT INTO People(id, region_id, name, sex, date_of_birth)
  SELECT i, random_between(5,1005), md5(RANDOM()::TEXT), 'm', CURRENT_DATE FROM generate_series(7, 30007) as i;
  
  INSERT INTO Magic_things(id, name, power)
  SELECT i, md5(RANDOM()::TEXT), random_between(1,10) FROM generate_series(10, 10000) as i;
  
  INSERT INTO Magicians(person_id, thing_id, order_id, mag_type)
  SELECT i, i, random_between(1, 3), 'l' FROM generate_series(10, 10000) as i;
  
  INSERT INTO Locations(id, nearest_region_id, name) 
  SELECT i, random_between(1, 1000), md5(RANDOM()::TEXT) FROM generate_series(5, 5005) as i;
  
  INSERT INTO Creatures(location_id, name)
  SELECT random_between(5, 5005), md5(RANDOM()::TEXT) FROM generate_series(1, 20000);
  
  INSERT INTO Spells(id, name)
  SELECT i, md5(RANDOM()::TEXT) FROM generate_series(5, 10005) as i;
  
  INSERT INTO Spell_to_magician(magician_id, spell_id)
  SELECT i, random_between(5, 10005) FROM generate_series(10, 10000) as i;
  
  INSERT INTO Huntings (creature_id)
  SELECT random_between(50, 15000) FROM generate_series(10, 10000);
  
  INSERT INTO Magician_to_hunting (magician_id, hunting_id)
  SELECT i, i FROM generate_series(10, 1000) as i;
  
  RETURN 1;
END;
$$;

alter function generate_data() owner to s265108;

