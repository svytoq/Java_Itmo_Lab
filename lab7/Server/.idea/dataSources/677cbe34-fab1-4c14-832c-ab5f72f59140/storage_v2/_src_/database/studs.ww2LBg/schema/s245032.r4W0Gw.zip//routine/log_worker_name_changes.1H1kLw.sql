
BEGIN
IF NEW.WorkerName <> OLD.WorkerName THEN
INSERT INTO workers_log(worker_id,workername,changed_on) VALUES (OLD.WorkerID,OLD.WorkerName,now());
END IF;
RETURN NEW;
END;
