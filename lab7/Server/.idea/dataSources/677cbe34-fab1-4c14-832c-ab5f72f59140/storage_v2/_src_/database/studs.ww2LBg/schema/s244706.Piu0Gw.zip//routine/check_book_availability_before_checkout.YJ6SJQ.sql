create function check_book_availability_before_checkout() returns trigger
    language plpgsql
as
$$
declare
  is_unavailable boolean;
begin
  is_unavailable := (select exists(
      select from book_lendings
      where book_id = new.book_id
        and ((checked_in_on is null and (new.checked_in_on is null or checked_out_on < new.checked_in_on)
        or (checked_in_on, checked_out_on) overlaps (new.checked_in_on, new.checked_out_on)))));

  if is_unavailable
  then raise exception 'The required book is not available during the specified time period.';
  end if;

  return new;
end;
$$;

alter function check_book_availability_before_checkout() owner to s244706;

