create function to_depart(count integer) returns void
    language plpgsql
as
$$
DECLARE
  GOV INT;
  I   INT;
  NUM INT;
  NM  VARCHAR(30);
  MX  INT;
BEGIN
  GOV = 0;
  FOR I IN 1..COUNT LOOP 
    NM = 'ОТДЕЛ'||I;
    NUM = RANDOM() * (1024 - 16) + 16 :: INT;
    SELECT COUNT(*)
    FROM ОТДЕЛЫ_СЕНАТА
    INTO MX;
    SELECT ID_ЧЛЕНА
    FROM ЧЛЕНЫ_СЕНАТА
    WHERE ID_ЧЛЕНА > GOV
    INTO GOV;
    INSERT INTO ОТДЕЛЫ_СЕНАТА VALUES (DEFAULT, NM, NUM, GOV);
  END LOOP;
END;
$$;

alter function to_depart(integer) owner to s225081;

