create function checkid() returns trigger
    language plpgsql
as
$$
BEGIN-----------------------------------------------------------------------------------------------BEGIN 
IF TG_OP='INSERT' THEN 
IF NEW.ID<>(NEXTVAL(TG_TABLE_NAME||'_ID_seq')-1) THEN 
RAISE NOTICE 'You do not need to specify id, it generates automatically'; 
NEW.ID=(NEXTVAL(TG_TABLE_NAME||'_ID_seq')-1); 
END IF; 
ELSE 
IF NEW.ID<>OLD.ID THEN 
RAISE NOTICE 'You do not need to specify id, it generates automatically'; 
NEW.ID=OLD.ID; 
END IF; 
END IF; 
PERFORM SETVAL(TG_TABLE_NAME||'_ID_seq',(NEXTVAL(TG_TABLE_NAME||'_ID_seq')-2)); 
RETURN NEW; 
END;
$$;

alter function checkid() owner to s225051;

