create function insert_company(id integer, title character varying, inn character varying, kpp character varying, ogrn character varying, creation date, close_date date, ipo boolean, wallet character varying) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO company (id,
             title,
             inn,
             kpp,
             ogrn,
             creation,
             close_date,
             ipo,
             wallet)

  VALUES (insert_company.id,
      insert_company.title,
      insert_company.inn,
      insert_company.kpp,
      insert_company.ogrn,
      insert_company.creation,
      insert_company.close_date,
      insert_company.ipo,
      insert_company.wallet);
END;

$$;

alter function insert_company(integer, varchar, varchar, varchar, varchar, date, date, boolean, varchar) owner to s264458;

