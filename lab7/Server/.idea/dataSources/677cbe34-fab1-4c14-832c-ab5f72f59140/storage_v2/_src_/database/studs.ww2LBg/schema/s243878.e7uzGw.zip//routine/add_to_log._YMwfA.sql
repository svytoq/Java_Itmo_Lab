create function add_to_log() returns trigger
    language plpgsql
as
$$
DECLARE
    msg varchar(40);
    planetName varchar(32);
    systemName varchar(32);
    retstr varchar(256);
BEGIN
    IF  TG_OP = 'INSERT' THEN
        IF NEW.Название IS NULL THEN 
            RAISE EXCEPTION 'Не указано название планеты'; END IF;
        IF NEW.ID_Планетной_системы IS NULL THEN 
            RAISE EXCEPTION 'Не указана планетная система';  END IF;  
        planetName = NEW.Название;
        msg := 'Добавлена новая планета ';
        retstr := msg || planetName;
        INSERT INTO Logs(Текст, Добавлено) values (retstr,NOW());
        RETURN NEW;
        
    ELSIF TG_OP = 'DELETE' THEN
        planetName = OLD.name;
        msg := 'Удалена планета ';
        
        retstr := msg || planetName ;
        INSERT INTO Logs(Текст, Добавлено) values (retstr,NOW());
        RETURN OLD;
    END IF;
END;
$$;

alter function add_to_log() owner to s243878;

