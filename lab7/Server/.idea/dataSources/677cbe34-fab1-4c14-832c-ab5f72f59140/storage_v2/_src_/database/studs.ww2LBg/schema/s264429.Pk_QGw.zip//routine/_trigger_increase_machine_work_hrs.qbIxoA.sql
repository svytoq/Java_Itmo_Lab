create function _trigger_increase_machine_work_hrs() returns trigger
    language plpgsql
as
$$
declare
    machine_speed real = null;
begin
    select speed_items_per_hour from circuit_board_machine_param_item
        where machine_id = new.assembled_by and
              board_model_id = new.model_id and
              board_model_version = new.model_version
    into machine_speed;

    if machine_speed is not null then
        update circuit_board_machine set work_hrs = work_hrs + 1/machine_speed where id = new.assembled_by;
    end if;

    return new;
end;
$$;

alter function _trigger_increase_machine_work_hrs() owner to s264429;

