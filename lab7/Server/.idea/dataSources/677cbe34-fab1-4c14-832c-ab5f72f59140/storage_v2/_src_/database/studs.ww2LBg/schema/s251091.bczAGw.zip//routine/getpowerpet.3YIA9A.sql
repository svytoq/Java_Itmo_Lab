create function getpowerpet(id integer) returns integer
    language sql
as
$$
select СИЛА from ОТРЯД
inner join АРМИЯ on АРМИЯ.ID = $1
inner join ЛИДЕР on ЛИДЕР.ИМЯ = АРМИЯ.ЛИДЕР
inner join ПИТОМЕЦ on ЛИДЕР.ПИТОМЕЦ = ПИТОМЕЦ.КЛИЧКА
$$;

alter function getpowerpet(integer) owner to s251091;

