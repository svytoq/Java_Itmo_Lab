create function upd_warrior() returns trigger
    language plpgsql
as
$$
BEGIN
  IF  OLD.ПОДРАЗДЕЛЕНИЕ!= NEW.ПОДРАЗДЕЛЕНИЕ THEN
    UPDATE ПОДРАЗДЕЛЕНИЕ SET КОМАНДИР = NULL WHERE КОМАНДИР= OLD.ID_ВОИНА;
    ELSEIF OLD.ПОДРАЗДЕЛЕНИЕ = NEW.ПОДРАЗДЕЛЕНИЕ AND OLD.ID_ВОИНА != NEW.ID_ВОИНА THEN
        UPDATE ПОДРАЗДЕЛЕНИЕ SET КОМАНДИР = NEW.ID_ВОИНА WHERE ГЛАВА= OLD.ID_ВОИНА;
END IF;
  RETURN  NULL;
  END;
$$;

alter function upd_warrior() owner to s225081;

