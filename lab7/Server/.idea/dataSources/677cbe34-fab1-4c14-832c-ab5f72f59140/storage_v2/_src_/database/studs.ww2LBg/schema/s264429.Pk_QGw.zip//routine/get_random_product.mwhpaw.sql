create function get_random_product() returns integer
    language plpgsql
as
$$
declare
        result integer := 0;
    begin
        select id from product order by random() limit 1 into result;
        return result;
    end;
$$;

alter function get_random_product() owner to s264429;

