create function set_penalties() returns trigger
    language plpgsql
as
$$
declare
    order_number integer;
begin
--     speed = (select speed_in_km_h from ride where ride_id = old.ride_id);
    if (new.speed_in_km_h > 180) then
        order_number = (select rating_id from orders where ride_id = old.ride_id);
        update rating
        set penalties = true
        where rating_id = order_number;
    end if;
    return new;
end
$$;

alter function set_penalties() owner to s263138;

