create function create_mail(p_mail text) returns void
    language plpgsql
as
$$
declare
v_mail text;
begin
v_mail := mail;
if exists (select mail from ВЛАДЕЛЕЦ where ВЛАДЕЛЕЦ.mail = v_mail) then 
raise exception 'mail already exists';
end if;
end;
$$;

alter function create_mail(text) owner to s242319;

