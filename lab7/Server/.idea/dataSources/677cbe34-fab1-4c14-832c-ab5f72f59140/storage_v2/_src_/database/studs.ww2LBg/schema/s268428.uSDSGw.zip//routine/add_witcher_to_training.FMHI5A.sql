create function add_witcher_to_training(tr_id integer, w_id integer) returns integer
    language plpgsql
as
$$
DECLARE
tr_type CHAR(20);
lr INTEGER;
rl INTEGER;
begin
 
 INSERT INTO training_witcher VALUES
 (w_id, tr_id);
 
 SELECT INTO tr_type type FROM training where training_id = tr_id;
 SELECT INTO rl role_id FROM witcher where witcher_id = w_id;
 SELECT INTO lr learnability FROM role where role_id = rl;
 lr = lr/29*4 + 1;
 IF tr_type = 'sword_fight' 
 THEN
 UPDATE skill_witcher set lev = lev + 3*lr WHERE (skill_id = 1 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 4*lr WHERE (skill_id = 2 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 5*lr WHERE (skill_id = 3 AND witcher_id = w_id);
 end if;
 
 IF tr_type = 'survival' 
  THEN
 UPDATE skill_witcher set lev = lev + 5*lr WHERE (skill_id = 6 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 4*lr WHERE (skill_id = 2 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 2*lr WHERE (skill_id = 3 AND witcher_id = w_id);
 end if;
 
  IF tr_type = 'reading' 
  THEN
 UPDATE skill_witcher set lev = lev + 2*lr WHERE (skill_id = 6 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 6*lr WHERE (skill_id = 5 AND witcher_id = w_id);
 end if;
 
 RETURN 0;
 end
$$;

alter function add_witcher_to_training(integer, integer) owner to s268428;

