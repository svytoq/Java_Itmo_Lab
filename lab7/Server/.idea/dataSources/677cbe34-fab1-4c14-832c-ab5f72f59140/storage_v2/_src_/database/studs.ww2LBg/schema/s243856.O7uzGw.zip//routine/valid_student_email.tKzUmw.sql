create function valid_student_email() returns trigger
    language plpgsql
as
$$
begin
  if not is_valid_email(new.email, true) then
    raise exception 'Invalid student email %, this email belongs to the worker', new.email;
  end if;
  return new;
end;
$$;

alter function valid_student_email() owner to s243856;

