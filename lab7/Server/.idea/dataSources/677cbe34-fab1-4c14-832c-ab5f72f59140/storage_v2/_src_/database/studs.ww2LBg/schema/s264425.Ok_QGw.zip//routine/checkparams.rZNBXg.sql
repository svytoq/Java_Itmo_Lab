create function checkparams() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW."Health") > 100 THEN NEW."Health" = 100; END IF;
    IF (NEW."Health") < 0 THEN NEW."Health" = 0; END IF;

    IF (NEW."Satiety") > 100 THEN NEW."Satiety" = 100; END IF;
    IF (NEW."Satiety") < 0 THEN NEW."Satiety" = 0; END IF;

    IF (NEW."Mood") > 100 THEN NEW."Mood" = 100; END IF;
    IF (NEW."Mood") < 0 THEN NEW."Mood" = 0; END IF;

    RETURN NEW;
END;
$$;

alter function checkparams() owner to s264425;

