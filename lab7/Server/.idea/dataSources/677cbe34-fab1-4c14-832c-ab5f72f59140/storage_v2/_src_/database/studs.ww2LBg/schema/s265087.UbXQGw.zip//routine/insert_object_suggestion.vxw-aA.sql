create function insert_object_suggestion(name_suggestion character varying, description_suggestion character varying, object_id integer, author_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    SUGGESTION_ID INTEGER;
BEGIN
    INSERT INTO SUGGESTION (NAME, DESCRIPTION, CREATION_DATE, AUTHOR)
    VALUES (NAME_SUGGESTION, DESCRIPTION_SUGGESTION, CURRENT_TIMESTAMP, AUTHOR_ID)
    RETURNING id INTO SUGGESTION_ID;
    INSERT INTO OBJECT_SUGGESTION (ID, OBJECT)
    VALUES (SUGGESTION_ID, OBJECT_ID);
    UPDATE OBJECT obj SET OBJECT_STATE='SHARED' WHERE obj.ID=OBJECT_ID;
    RETURN 1;
END;
$$;

alter function insert_object_suggestion(varchar, varchar, integer, integer) owner to s265087;

