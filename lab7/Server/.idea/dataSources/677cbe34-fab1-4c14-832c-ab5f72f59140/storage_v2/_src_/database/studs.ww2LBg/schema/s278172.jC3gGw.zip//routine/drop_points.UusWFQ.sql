create function drop_points() returns void
    language plpgsql
as
$$
BEGIN
    UPDATE students SET points=0;
END
$$;

alter function drop_points() owner to s278172;

