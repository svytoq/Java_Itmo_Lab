create function tt() returns trigger
    language plpgsql
as
$$
BEGIN
IF NOT EXISTS (SELECT Наличие_сверхспособностей,Персонаж_ИД FROM Персонажи WHERE Наличие_сверхспособностей='yes' AND Персонаж_ИД = NEW.Персонаж_ИД) THEN 
RAISE EXCEPTION 'Данный персонаж является человеком' using hint = 'Проверьте наличие свехспособностей у персонажа';
END IF;
END;
$$;

alter function tt() owner to s242243;

