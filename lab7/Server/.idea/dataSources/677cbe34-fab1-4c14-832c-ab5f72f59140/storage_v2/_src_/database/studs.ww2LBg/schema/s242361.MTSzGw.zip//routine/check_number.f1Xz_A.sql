create function check_number() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.КОРАБЛЬ <> (SELECT КОРАБЛЬ FROM КАЮТЫ WHERE ИД_КАЮТЫ = NEW.КАЮТА) THEN
RAISE WARNING 'Введён неверный номер корабля или каюты';
NEW.КОРАБЛЬ = NULL;
END IF;
RETURN NEW;
END;
$$;

alter function check_number() owner to s242361;

