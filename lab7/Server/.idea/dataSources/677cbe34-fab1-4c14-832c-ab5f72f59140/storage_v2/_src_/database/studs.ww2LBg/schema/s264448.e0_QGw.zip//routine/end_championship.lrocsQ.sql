create function end_championship(championship_id integer) returns void
    language plpgsql
as
$$
DECLARE
    score_value real;
    cur_project project%rowtype;
    cur_team team%rowtype;
    cur_score score%rowtype;
    cur_place integer;
    prev_points real;
BEGIN
    IF (SELECT MAX(performance_time) FROM performance
        JOIN project ON project.project_id = performance.project_id
        JOIN team ON project.team_id = team.team_id
        WHERE team.championship_id = end_championship.championship_id) > NOW() THEN
        RAISE EXCEPTION 'Some performances are not started yet!';
    END IF;

    IF EXISTS(SELECT * FROM performance
        JOIN project ON project.project_id = performance.project_id
        JOIN team ON project.team_id = team.team_id
        WHERE team.championship_id = end_championship.championship_id AND points IS NULL) THEN
        RAISE EXCEPTION 'Some performances are not rated!';
    END IF;

    FOR cur_team IN
        (SELECT * FROM team WHERE team.championship_id = end_championship.championship_id)
    LOOP
        score_value := 0;

        FOR cur_project IN
            (SELECT * FROM project WHERE team_id = cur_team.team_id)
        LOOP
            score_value := score_value + (SELECT AVG(points) FROM performance WHERE project_id = cur_project.project_id);
        END LOOP;

        INSERT INTO score (team_id, final_score) VALUES (cur_team.team_id, score_value);
    END LOOP;

    cur_place := 0;
    prev_points := -1;
    FOR cur_score IN
        (SELECT * FROM score
            WHERE (SELECT team.championship_id FROM team WHERE team.team_id = score.team_id) = end_championship.championship_id
        ORDER BY final_score DESC)
    LOOP
        IF (cur_score.final_score != prev_points) THEN
            cur_place := cur_place + 1;
            prev_points := cur_score.final_score;
        END IF;
        IF (cur_score.final_score = prev_points) THEN
            cur_place := cur_place;
        END IF;

        UPDATE score
        SET place = cur_place,
            special_award = CASE
                WHEN cur_place = 1 THEN 'Golden award'
                WHEN cur_place = 2 THEN 'Silver award'
                WHEN cur_place = 3 THEN 'Bronze award'
                ELSE 'Participant'
            END
        WHERE team_id = cur_score.team_id;
    END LOOP;
    UPDATE championship
    SET end_date = now()
    WHERE championship.championship_id = end_championship.championship_id;
END;
$$;

alter function end_championship(integer) owner to s264448;

