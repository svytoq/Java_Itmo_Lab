create function season_succ() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO стадии(сезон_назв, типс_ид, начало) VALUES (new.название, (SELECT ид FROM типы_стадий WHERE название LIKE 'Регулярный сезон'), new.начало);
    IF new.конец IS NOT NULL THEN
        INSERT INTO стадии(сезон_назв, типс_ид, конец) VALUES (new.название, (SELECT ид FROM типы_стадий WHERE название LIKE 'Плей-офф'), new.конец);
    END IF;
    RETURN NEW;
END;
$$;

alter function season_succ() owner to s242558;

