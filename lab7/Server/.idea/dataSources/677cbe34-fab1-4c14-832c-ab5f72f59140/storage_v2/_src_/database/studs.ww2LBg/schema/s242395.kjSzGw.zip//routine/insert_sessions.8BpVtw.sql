create function insert_sessions(count integer) returns void
    language plpgsql
as
$$
DECLARE
        film record;
        room record;
        film_time timestamp;
BEGIN
        FOR room IN (SELECT ид from Залы)
        LOOP
                FOR film IN (SELECT * from Фильмы)
                LOOP
                        film_time = (film.дата_премьеры + ('1 months')::interval)::timestamp;
                        insert into Сеансы(ид_фильма, ид_зала, дата_начала, дата_конца) 
                                values(film.ид, room.ид, 
                                        film_time, (film_time + ('1 hour')::interval)::timestamp);
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_sessions(integer) owner to s242395;

