create view working_employees
            (employee_id, first_name, last_name, patronymic, birth_date, start_date, end_date, department_id) as
SELECT employees.employee_id,
       employees.last_name  AS first_name,
       employees.first_name AS last_name,
       employees.patronymic,
       employees.birth_date,
       employees.start_date,
       employees.end_date,
       employees.department_id
FROM s265089.employees
WHERE employees.end_date IS NULL;

alter table working_employees
    owner to s265089;

