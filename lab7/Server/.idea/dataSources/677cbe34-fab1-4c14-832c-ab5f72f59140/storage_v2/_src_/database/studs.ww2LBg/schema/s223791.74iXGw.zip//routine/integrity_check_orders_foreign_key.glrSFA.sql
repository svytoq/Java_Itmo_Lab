create function integrity_check_orders_foreign_key() returns boolean
    language plpgsql
as
$$
BEGIN
                INSERT INTO ORDERS(child_id, customer_id, status, address) VALUES (-1, -1, 'CREATED', 'spb');
                RETURN FALSE;
            EXCEPTION WHEN foreign_key_violation THEN
                RETURN TRUE;
            END;
$$;

alter function integrity_check_orders_foreign_key() owner to s223791;

