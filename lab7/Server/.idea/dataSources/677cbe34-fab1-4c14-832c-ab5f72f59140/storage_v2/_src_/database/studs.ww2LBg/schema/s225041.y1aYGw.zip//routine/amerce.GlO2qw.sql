create function amerce() returns trigger
    language plpgsql
as
$$
BEGIN
			UPDATE PRISONER SET freedom=freedom + '4 weeks'::INTERVAL
					WHERE PRISONER.id = NEW.owner_fk;
			RETURN NEW;
		END;

$$;

alter function amerce() owner to s225041;

