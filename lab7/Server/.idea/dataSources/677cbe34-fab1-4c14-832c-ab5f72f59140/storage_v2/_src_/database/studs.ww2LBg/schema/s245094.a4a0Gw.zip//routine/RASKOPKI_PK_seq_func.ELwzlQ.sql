create function "РАСКОПКИ_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "РАСКОП_ИД" FROM "РАСКОПКИ");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."РАСКОП_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''РАСКОПКИ_РАСКОП_ИД_seq'', max("РАСКОП_ИД") + 1) FROM "РАСКОПКИ"';
                        NEW."РАСКОП_ИД" := max_id + 1;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "РАСКОПКИ_PK_seq_func"() owner to s245094;

