create function emplpositionscheck() returns trigger
    language plpgsql
as
$$
declare
    cp_id bigint;
    pers_id bigint;
    cp_dep departments;
    cp_departments departments[];
    cur_acc access_levels;
    pos_acc access_levels;
    acc_levels access_levels[];
begin
    select person_id into pers_id from Employees where employee_id = NEW.employee_id;

    perform employment_check(pers_id, NEW.position_id);
    
    select acc_lvl into cur_acc from Employees where employee_id=NEW.employee_id;
    select acc_lvl into pos_acc from Positions where position_id=NEW.position_id;

    acc_levels = array['restricted', 'standard', 'high', 'max'];

    if array_position(acc_levels, pos_acc) > array_position(acc_levels, cur_acc) then
        update Employees set acc_lvl=pos_acc
            where employee_id=NEW.employee_id;
    end if;

    return NEW;
end;
$$;

alter function emplpositionscheck() owner to s265066;

