create function create_building(settlement_id_ integer, building_name character varying) returns void
    language plpgsql
as
$$
DECLARE
 building_id_ integer;
    tech_required_id_ integer;
    resource_required_id_ INTEGER;
    resource_required_amount_ integer;
    civilization_id_ integer;
    resource_amount_ INTEGER;
    research_progress_ INTEGER;
    lazy_people_ INTEGER;
    capacity_ INTEGER;
    worker_id_ integer;
    rand_fraction_id_ INTEGER;
    counter_ integer;
    
 BEGIN
 select building.id into building_id_ from building where building.name = building_name;
    select count(building_id) into counter_ from buildings_in_settlement where building_id = building_id_ 
    and settlement_id_ = settlement_id;
    if counter_ = 0 then
    SELECT tech_requirement_id into tech_required_id_ from building where id= building_id_;
    SELECT resource_required_id into resource_required_id_ from building where id = building_id_;
    SELECT resource_required_amount into resource_required_amount_ from building where id = building_id_;
    SELECT planet.civilization_id into civilization_id_ from planet, settlement where planet.id =
    (select planet_id from settlement where id = settlement_id_);
    SELECT amount into resource_amount_ from resources_obtained_by_civilization where civilization_id = civilization_id_ 
    and resource_id = resource_required_id_;
    select progress into research_progress_ from researches_in_civilization where civilization_id = civilization_id_ 
    and tech_id = tech_required_id_;
    SELECT amount into lazy_people_ from citizens_in_settlement where settlement_id = settlement_id_ and citizen_class_id = 3;
    SELECT capacity into capacity_ from building where id = building_id_;
  
if research_progress_ = 100 and resource_amount_ >= resource_required_amount_ and (lazy_people_ - 2) >= capacity_  then 
INSERT INTO buildings_in_settlement (settlement_id, building_id) VALUES (settlement_id_, building_id_);
UPDATE resources_obtained_by_civilization set amount = (resource_amount_ - resource_required_amount_) 
where civilization_id = civilization_id_  and resource_id = resource_required_id_;
        UPDATE citizens_in_settlement set amount = (lazy_people_ - capacity_) 
        where settlement_id = settlement_id_ and citizen_class_id = 3;
        
        SELECT id into rand_fraction_id_ from fraction order by random() limit 1;
        SELECT citizen_class_working_id into worker_id_ from building where id = building_id_;
        INSERT INTO citizens_in_settlement (citizen_class_id, settlement_id, fraction_id, amount)
    VALUES (worker_id_, settlement_id_, rand_fraction_id_, capacity_); 
RAISE NOTICE 'Building created successfully';
    ELSE
        if research_progress_ != 100 THEN
        RAISE NOTICE 'You do not obtain technology for this building';
        ELSE
        if resource_amount_ < resource_required_amount_ THEN
            RAISE NOTICE 'You do not obtain resourses for this building';
            else
            RAISE NOTICE 'You do not obtain workers for this building';
            end if;
         end if;
    END if;
    ELSE
    RAISE NOTICE 'You already obtain this building in settlement';
    end if;
                
 END
$$;

alter function create_building(integer, varchar) owner to s264483;

