create function testvalidatename() returns trigger
    language plpgsql
as
$$
BEGIN
    raise exception 'John is not allowed!';
END
$$;

alter function testvalidatename() owner to s248266;

