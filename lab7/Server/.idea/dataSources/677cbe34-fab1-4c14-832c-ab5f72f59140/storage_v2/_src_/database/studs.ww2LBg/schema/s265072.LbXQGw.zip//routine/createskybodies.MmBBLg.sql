create function createskybodies(count integer) returns boolean
    language plpgsql
as
$$
DECLARE
	obj_id integer;
	move_id integer;
	new_name varchar(255);
BEGIN
	IF (count < 0) THEN RETURN false; end if;
	WHILE (count > 0) LOOP
	INSERT INTO Object (type) VALUES ('двигаемый') RETURNING object_id INTO obj_id;
	INSERT INTO Moveable (kind, scene_id, object_id) VALUES ('небесное тело', 1, obj_id) RETURNING moveable_id INTO move_id;
	new_name := concat('планета_', move_id);
	INSERT INTO SkyBody (moveable_id, name) VALUES (move_id, new_name);
	count := count - 1;
	END LOOP;
	RETURN true;
END;
$$;

alter function createskybodies(integer) owner to s265072;

