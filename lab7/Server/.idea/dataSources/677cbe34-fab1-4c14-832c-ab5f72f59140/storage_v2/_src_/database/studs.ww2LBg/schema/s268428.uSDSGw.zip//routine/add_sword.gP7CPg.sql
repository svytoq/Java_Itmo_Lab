create function add_sword(name character, stamina_b integer, agility_b integer, strength_b integer, founded date, material character, in_use boolean, owner integer) returns integer
    language plpgsql
as
$$
DECLARE
sword_id INTEGER;
begin
 sword_id = nextval('sword_sword_id_seq');
 
 INSERT INTO sword VALUES
 (sword_id, stamina_b, agility_b, strength_b, founded, material, in_use, owner);

 RETURN sword_id;
 end
$$;

alter function add_sword(char, integer, integer, integer, date, char, boolean, integer) owner to s268428;

