create function createreportcheck() returns trigger
    language plpgsql
as
$$
BEGIN
    if exists(SELECT 1 FROM researchreport WHERE researchreport.resultof = NEW.resultof) then
        raise exception 'Only one report should be created for each request!';
    end if;
    RETURN NEW;
END;
$$;

alter function createreportcheck() owner to s265111;

