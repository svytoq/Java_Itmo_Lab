create function "ПУБЛИКАЦИИ_ЖУРНАЛА"(name character varying)
    returns TABLE("НАЗВАНИЕ_ЖУРНАЛА" character varying, "НАЗВАНИЕ_ПРОИЗВЕДЕНИЯ" character varying, "ДАТА" date, "ФОРМАТ" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"ПУБЛИКАЦИИ"."НАЗВАНИЕ_ЖУРНАЛА", "ПУБЛИКАЦИИ"."НАЗВАНИЕ_ПРОИЗВЕДЕНИЯ", "ПУБЛИКАЦИИ"."ДАТА", "ПУБЛИКАЦИИ"."ФОРМАТ"
FROM "ПУБЛИКАЦИИ" WHERE "ПУБЛИКАЦИИ"."НАЗВАНИЕ_ЖУРНАЛА" = name;
END;
$$;

alter function "ПУБЛИКАЦИИ_ЖУРНАЛА"(varchar) owner to s225071;

