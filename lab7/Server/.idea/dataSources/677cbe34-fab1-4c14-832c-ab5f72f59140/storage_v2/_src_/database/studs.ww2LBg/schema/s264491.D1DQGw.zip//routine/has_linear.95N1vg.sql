create function has_linear(action_type_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    res bool;
BEGIN
    SELECT (AT.linear_id IS NOT NULL) INTO res FROM ACTION_TYPE AT WHERE AT.id = action_type_id;
    RETURN res;
END;
$$;

alter function has_linear(integer) owner to s264491;

