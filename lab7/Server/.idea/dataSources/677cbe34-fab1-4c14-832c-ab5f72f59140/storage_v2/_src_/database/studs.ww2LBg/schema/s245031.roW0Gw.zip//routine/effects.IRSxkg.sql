create function effects() returns trigger
    language plpgsql
as
$$
begin
update Характеристики
set СИЛ=СИЛ-coalesce(old.СИЛ_бнс, 0)+coalesce(new.СИЛ_бнс, 0), 
ВСП=ВСП-coalesce(old.ВСП_бнс, 0)+coalesce(new.ВСП_бнс, 0), 
ВНС=ВНС-coalesce(old.ВНС_бнс, 0)+coalesce(new.ВНС_бнс, 0), 
ИНТ=ИНТ-coalesce(old.ИНТ_бнс, 0)+coalesce(new.ИНТ_бнс, 0), 
ХАР=ХАР-coalesce(old.ХАР_бнс, 0)+coalesce(new.ХАР_бнс, 0), 
ЛВК=ЛВК-coalesce(old.ЛВК_бнс, 0)+coalesce(new.ЛВК_бнс, 0), 
УДЧ=УДЧ-coalesce(old.УДЧ_бнс, 0)+coalesce(new.УДЧ_бнс, 0)
where id in (select Люди.Характеристики from Люди 
join Инвентарь on Люди.Инвентарь=Инвентарь.id
join Броня on Инвентарь.носимая_броня=Броня.id
where Броня.эффект=new.id);
return new;
end;
$$;

alter function effects() owner to s245031;

