create function сгенерировать_билеты() returns void
    language plpgsql
as
$$
DECLARE
        sess RECORD;
        seat RECORD;
BEGIN
        FOR sess IN (SELECT ид, ид_зала FROM Сеансы) LOOP
                FOR seat IN (SELECT ид FROM Места WHERE Места.ид_зала = sess.ид_зала) LOOP
                        if (random() > 0.8) THEN
                        INSERT INTO Билеты (ид_сеанса, ид_места, стоимость, статус)
                        VALUES (sess.ид, seat.ид, random() * 500 + 100, random() * 2);
                                END IF;
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_билеты() owner to s242395;

