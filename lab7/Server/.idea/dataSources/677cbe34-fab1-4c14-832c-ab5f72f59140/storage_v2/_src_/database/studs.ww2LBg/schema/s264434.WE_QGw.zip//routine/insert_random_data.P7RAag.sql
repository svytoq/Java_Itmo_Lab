create function insert_random_data() returns void
    language plpgsql
as
$$
declare
    detector_id integer;
BEGIN
    for i in 1..2 loop
        select pg_sleep(5);
        FOR detector_id IN select id from "Detectors"
            LOOP
                insert into "Data"(id_detector, value) VALUES (detector_id, floor(random() * 100 + 1)::int);
            END LOOP;
    end loop;
END;
$$;

alter function insert_random_data() owner to s264434;

