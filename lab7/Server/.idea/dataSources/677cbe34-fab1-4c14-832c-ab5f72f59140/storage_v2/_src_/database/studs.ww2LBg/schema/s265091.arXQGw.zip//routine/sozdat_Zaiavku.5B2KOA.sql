create function "создатьЗаявку"("н_спортсмен_ид" integer, "н_соревнование_ид" integer) returns void
    language plpgsql
as
$$
begin
            insert into Заявка(спортсмен_ид, соревнование_ид)
                values(н_спортсмен_ид, н_соревнование_ид);
        end;
$$;

alter function "создатьЗаявку"(integer, integer) owner to s265091;

