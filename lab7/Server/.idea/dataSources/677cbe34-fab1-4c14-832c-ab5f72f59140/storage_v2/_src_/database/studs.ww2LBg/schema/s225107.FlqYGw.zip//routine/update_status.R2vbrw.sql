create function update_status() returns trigger
    language plpgsql
as
$$
BEGIN
	CASE
		WHEN NEW.loyal>=10000
			THEN NEW.status = 21;
		WHEN (NEW.loyal>=1000 AND NEW.loyal<10000)
			THEN NEW.status = 22;
		WHEN (NEW.loyal>=0 AND NEW.loyal <1000)
			THEN NEW.status = 23;
		WHEN (NEW.loyal>=-1000 AND NEW.loyal <0)
			THEN NEW.status = 24;
		WHEN (NEW.loyal <-1000 )
			THEN NEW.status = 25;
	END CASE;
		RETURN NEW;
	END;
$$;

alter function update_status() owner to s225107;

