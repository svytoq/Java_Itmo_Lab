create function get_trigers_by_table(table_name text)
    returns TABLE("COLUMN NAME" name, "TRIGGER NAME" name)
    language sql
as
$$
select attname, tgname
from studs.pg_catalog.pg_trigger
         join pg_class pc on pc.oid = pg_trigger.tgrelid
         left join pg_catalog.pg_attribute pa
                   on pa.attnum = ANY (tgattr) and pa.attrelid = pg_trigger.tgrelid
WHERE relname = table_name and tgisinternal = false
$$;

alter function get_trigers_by_table(text) owner to s224907;

