create function forbid_update() returns trigger
    language plpgsql
as
$$
BEGIN
  RAISE EXCEPTION 'Нельзя изменять строки в таблице %', TG_TABLE_NAME;
END
$$;

alter function forbid_update() owner to s225125;

