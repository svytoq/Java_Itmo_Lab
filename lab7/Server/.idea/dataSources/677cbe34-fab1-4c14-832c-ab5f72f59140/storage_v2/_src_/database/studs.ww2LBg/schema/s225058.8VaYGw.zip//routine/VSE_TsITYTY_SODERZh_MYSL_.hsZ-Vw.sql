create function "ВСЕ_ЦИТЫТЫ_СОДЕРЖ_МЫСЛЬ"(mysli text)
    returns TABLE("ЦИТАТА" text)
    language plpgsql
as
$$
BEGIN 
RETURN QUERY SELECT ЦИТАТЫ.ЦИТАТА
FROM МЫСЛИ JOIN МЫСЛЬ_И_ЦИТАТА ON МЫСЛИ.ИД=ИД_МЫСЛИ
JOIN ЦИТАТЫ ON ЦИТАТЫ.ИД=ИД_ЦИТАТЫ WHERE СУТЬ = mysli; 
END;
$$;

alter function "ВСЕ_ЦИТЫТЫ_СОДЕРЖ_МЫСЛЬ"(text) owner to s225058;

