create function creator() returns trigger
    language plpgsql
as
$$
BEGIN
new."КОГДА_СОЗДАЛ" := now();
new."КТО_СОЗДАЛ" :=user;
return new;
END;
$$;

alter function creator() owner to s244702;

