create function setrelationships() returns trigger
    language plpgsql
as
$$
declare
    neighbor family;
    first_family text;
    second_family text;
    begin
      for neighbor in select * from family
      where city=new.city and name!=new.name
      loop
        if neighbor.name <= new.name then
          first_family = neighbor.name;
          second_family = new.name;
        else
          first_family = new.name;
          second_family = neighbor.name;
        end if;
        insert into families_relationship (first_family, second_family)
        values (first_family, second_family);
      end loop;
      return null;
    end;
$$;

alter function setrelationships() owner to s265171;

