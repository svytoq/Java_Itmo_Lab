create function user_go_del() returns trigger
    language plpgsql
as
$$
BEGIN
		IF (OLD.Момент_Снятия is null) THEN
			UPDATE "К_Пользователи" SET Дата_Выхода = current_timestamp WHERE
			"К_Пользователи".ИД = OLD.ИД;
		END IF;
		RETURN NULL;
		END;
$$;

alter function user_go_del() owner to s243870;

