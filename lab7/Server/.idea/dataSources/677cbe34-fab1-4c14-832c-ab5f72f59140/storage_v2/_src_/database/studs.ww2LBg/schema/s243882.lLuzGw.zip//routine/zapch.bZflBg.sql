create function zapch() returns trigger
    language plpgsql
as
$$
begin insert into Производство_запчастей(Наименование_детали,Серия_детали,Завод) values(new.Наименование_детали,new.Серия_детали,new.ИД_производителя); return new;end;
$$;

alter function zapch() owner to s243882;

