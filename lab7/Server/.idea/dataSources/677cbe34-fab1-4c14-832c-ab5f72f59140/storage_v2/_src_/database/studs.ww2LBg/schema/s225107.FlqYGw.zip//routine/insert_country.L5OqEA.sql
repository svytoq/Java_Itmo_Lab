create function insert_country() returns void
    language plpgsql
as
$$
DECLARE
    count INTEGER = 0;
    name text = insert_random();
  BEGIN
    LOOP
      IF NOT EXISTS(SELECT * FROM country WHERE country = name)
        THEN
          INSERT INTO country VALUES(DEFAULT, name);
          count = count + 1;
        ELSE name = insert_random();
      END IF;
      EXIT WHEN count = 10;
    END LOOP;
  END;
$$;

alter function insert_country() owner to s225107;

