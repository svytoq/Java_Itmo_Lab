create function final_trial(s_id integer, ending date) returns integer
    language plpgsql
as
$$
DECLARE

hh INTEGER;
pers INTEGER;
str integer;
sta integer;
agi integer;
r_id INTEGER;
witcherJr RECORD;
res INTEGER = 0;
general_q INTEGER;
sorcerer_lvl INTEGER;
survived BOOLEAN;
steel INTEGER;
silver INTEGER;
begin
SELECT INTO hh h_h_id from stream where stream_id = s_id ;

select into general_q sum(quality) from ingridient as i where (h_h_id = hh and (type = 'bruxa' or type = 'forktail' or type = 'manticore' or type = 'bryonia' or type = 'ribleaf' or type = 'mandrake'));
 

SELECT INTO sorcerer_lvl lev from sorcerer where h_h_id = hh;
sorcerer_lvl = sorcerer_lvl/2.9;
for witcherJr in 
SELECT sw.witcher_id as w_id, sw.lev as lvl  from witcher as w join skill_witcher as sw on w.witcher_id = sw.witcher_id where (w.role = 'witcherJr' and w.stream_id = s_id  and sw.skill_id = 6)

LOOP
res = (witcherJr.lvl/1.4*10*sorcerer_lvl/10 + 1)/2 + general_q/12;
if (res < 50) 
THEN
survived = FALSE;
ELSE
survived = TRUE;
end IF;

INSERT INTO monster VALUES
(DEFAULT,  survived, witcherJr.w_id);

if (survived)
THEN
select into str lev from skill_witcher where witcher_id = witcherJr.w_id and skill_id = 1;
select into agi lev from skill_witcher where witcher_id = witcherJr.w_id and skill_id = 2;
select into sta lev from skill_witcher where witcher_id = witcherJr.w_id and skill_id = 3;

if((str + agi + sta)/3 < 8)
THEN
str = str + str*2;
sta = sta + sta*2;
agi = agi + agi*2;
ELSE
str = str*2;
sta = sta*2;
agi = agi*2;
end if;
steel = nextval('sword_sword_id_seq'); 
silver = nextval('sword_sword_id_seq'); 
INSERT INTO sword VALUES
(steel, sta, agi, str, ending, 'steel', true, witcherJr.w_id),
(silver, (sta + 5), (agi + 5), (str + 5), ending, 'silver', true, witcherJr.w_id);

select INTO r_id role_id from witcher where witcher_id = witcherJr.w_id;

UPDATE role set learnability = NULL, sil_sword = silver, st_sword = steel, name = 'witcher' where role.role_id = r_id;

ELSE 
SELECT INTO pers person_id from witcher where witcher_id = witcherJr.w_id;
UPDATE person set is_alive = false where person_id = pers;
end if;

end LOOP;


UPDATE sorcerer set h_h_id = NULL where h_h_id = hh;
UPDATE witcher set stream_id = NULL where stream_id = s_id;
UPDATE h_h set end_date = ending where h_h_id = hh;
UPDATE stream set end_date = ending where stream_id = s_id;
RETURN 0;
end
$$;

alter function final_trial(integer, date) owner to s268428;

