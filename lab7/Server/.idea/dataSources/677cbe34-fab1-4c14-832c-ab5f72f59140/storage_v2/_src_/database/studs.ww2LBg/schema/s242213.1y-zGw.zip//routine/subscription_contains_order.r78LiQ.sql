create function subscription_contains_order() returns trigger
    language plpgsql
as
$$
BEGIN
            IF NEW."ИД_ПОДПИСКИ" IS NULL THEN
	                RETURN NEW;
			        END IF;
				        IF EXISTS (SELECT 1 FROM
"ПОДПИСКА" WHERE 
                    NEW."ИД_ПОДПИСКИ" = "ИД_ПОДПИСКИ"
		                        AND NEW."К_ДАТАВРЕМЯ" >=
"НАЧАЛО"
                    AND NEW."К_ДАТАВРЕМЯ" <= "КОНЕЦ"
		                        AND "СТАТУС" = 'АКТИВНА') THEN
					                        RETURN NEW;

END IF;
        RAISE EXCEPTION 'ОТСУТСТВУЕТ ПОДПИСКА';
	    END;

$$;

alter function subscription_contains_order() owner to s242213;

