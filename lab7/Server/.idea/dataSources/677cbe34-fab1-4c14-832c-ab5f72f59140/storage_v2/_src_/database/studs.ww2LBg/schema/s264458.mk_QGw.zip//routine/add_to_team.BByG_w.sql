create function add_to_team(developer_id integer[], team_id integer) returns void
    language plpgsql
as
$$
DECLARE
  d_id INTEGER;

BEGIN

  IF EXISTS(SELECT * FROM team WHERE id = add_to_team.team_id AND close_date NOTNULL) THEN
    RAISE EXCEPTION 'Cannot add developer to closed/non-existing team';
  END IF;

  FOREACH d_id IN ARRAY developer_id
    LOOP
      PERFORM insert_developer_team(d_id, team_id);
      RAISE NOTICE 'Разработчик добавлен в команду "%"',team_name(team_id);
    END LOOP;

END;

$$;

alter function add_to_team(integer[], integer) owner to s264458;

