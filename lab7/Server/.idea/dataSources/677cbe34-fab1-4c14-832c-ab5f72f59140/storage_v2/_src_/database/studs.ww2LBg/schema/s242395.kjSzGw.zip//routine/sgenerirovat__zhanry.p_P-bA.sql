create function сгенерировать_жанры() returns void
    language plpgsql
as
$$
BEGIN
        insert into Жанры(название) values('Космическая опера');
        insert into Жанры(название) values('Комедия');
        insert into Жанры(название) values('Боевик');
        insert into Жанры(название) values('Триллер');
        insert into Жанры(название) values('Трагедия');
        insert into Жанры(название) values('Научная фантастика');
        insert into Жанры(название) values('Ужасы');
        insert into Жанры(название) values('Мелодрама');
        insert into Жанры(название) values('Приключения');
        insert into Жанры(название) values('Фэнтези');
        insert into Жанры(название) values('Документальное кино');
        insert into Жанры(название) values('Биография');
END;
$$;

alter function сгенерировать_жанры() owner to s242395;

