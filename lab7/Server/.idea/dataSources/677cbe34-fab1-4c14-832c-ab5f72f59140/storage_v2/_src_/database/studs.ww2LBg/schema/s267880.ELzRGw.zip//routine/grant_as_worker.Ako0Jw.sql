create function grant_as_worker(user_profile_id integer, description text) returns integer
    language sql
as
$$
update user_profile set privilege = 'worker' where user_profile_id = $1;
    insert into worker (worker_id, description) values ($1, $2)
    on conflict (worker_id) do update set description = $2
    returning worker_id;
$$;

alter function grant_as_worker(integer, text) owner to s267880;

