create function str_to_asoiaftime(t text) returns s225125.asoiaftime
    language plpgsql
as
$fun$
DECLARE
  int_ar int[7];
  match text[];
  gr text;
BEGIN
  IF t IS NULL THEN
    RETURN (NULL::int, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint);
  END IF;

  match = regexp_matches(t, '^([0-9]{1,5}|\?)/([0-9]{1,2}|\?)/([0-9]{1,2}|\?)(?:\s([0-9]{2}|\?):([0-9]{2}|\?):([0-9]{2}|\?))?(?:\s(до З.Э.|от З.Э.))|(Рассветная эпоха|Долгая Ночь|Век Героев|Вторжение андалов|Не наступило)$');
  
  IF match IS NULL THEN
    RAISE EXCEPTION $$Неверный формат даты, формат даты: 
    (<year>|?)['/'(<month>|?)['/'(<day>|?)]][' '(<hour>|?)[':'(<minutes>|?)[':'(<seconds>|?)]]]('до З.Э.'|'от З.Э.')$$;
  END IF;

  IF match[8] = 'Рассветная эпоха' THEN
    RETURN (12000, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint, -1::smallint);
  ELSEIF match[8] = 'Долгая Ночь' OR match[8] = 'Век Героев' THEN
    RETURN (8000, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint, -1::smallint);
  ELSEIF match[8] = 'Вторжение андалов' THEN
    RETURN (4000, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint, NULL::smallint, -1::smallint);
  ELSEIF match[8] = 'Не наступило' THEN
    RETURN (301, 12::smallint, 30::smallint, 23::smallint, 59::smallint, 59::smallint, 1::smallint);
  END IF;

  FOR i IN 1..3 LOOP
    IF match[i] IS NOT NULL AND match[i] != '?' THEN
      int_ar[i] = match[i]::int;
    ELSE
      int_ar[i] = NULL;
    END IF;
  END LOOP;

  FOR i IN 4..6 LOOP
    IF match[i] IS NOT NULL AND match[i] != '?' THEN
      int_ar[i] = match[i]::int;
    ELSE
      int_ar[i] = NULL;
    END IF;
  END LOOP;

  IF match[7] = 'до З.Э.' THEN
    int_ar[7] = -1;
  ELSE
    int_ar[7] = 1;
  END IF;

  IF int_ar[1]*int_ar[7] < -12000 OR int_ar[1]*int_ar[7] > 300 OR
     int_ar[2] < 1 OR int_ar[2] > 12 OR
     int_ar[3] < 1 OR int_ar[3] > 30 OR
     int_ar[4] > 23 OR
     int_ar[5] > 59 OR
     int_ar[6] > 59 THEN
       RAISE EXCEPTION 'Время или дата вне допустимого диапозона'
         USING HINT = 'Допустимый диапозон: 12000/12/30 23:59:59 до З.Э. - 300/12/30 23:59:59 от З.Э.';
  END IF;

  RETURN (int_ar[1], int_ar[2]::smallint, int_ar[3]::smallint, int_ar[4]::smallint, int_ar[5]::smallint, int_ar[6]::smallint, int_ar[7]::smallint);
END
$fun$;

alter function str_to_asoiaftime(text) owner to s225125;

