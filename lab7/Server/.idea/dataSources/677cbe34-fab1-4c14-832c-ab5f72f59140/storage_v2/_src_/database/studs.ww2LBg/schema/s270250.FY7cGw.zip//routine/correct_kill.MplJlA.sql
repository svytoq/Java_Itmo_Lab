create function correct_kill() returns trigger
    language plpgsql
as
$$
DECLARE
--         Здесь все, что связано с убийством
        mafia_id integer;
        owner_id integer;
        time_die timestamp;
        person_respect integer;
        mafia_authority real;
        authority_up real;
        killer_job varchar(20);
        victim_job varchar(20);
    BEGIN
        SELECT time_to_die INTO time_die FROM Kills k WHERE k.victim = NEW.killer;
        IF FOUND THEN
            IF (time_die > NEW.time_to_die) THEN
            RAISE EXCEPTION 'Убийца уже умер, поэтому убийство не могло быть совершенно';
            END IF;
        END IF;

        SELECT job INTO killer_job FROM Persons p WHERE p.id = NEW.killer;
        SELECT job INTO victim_job FROM Persons p WHERE p.id = NEW.victim;

        IF (killer_job != 'mafia') THEN
            RAISE EXCEPTION 'Только мафия может убивать';
        ELSIF (killer_job = 'mafia' AND victim_job = 'officer') THEN
            RAISE EXCEPTION 'Мафия не может убить офицера';
        ELSE
--             убытки и прибыль (денег, авторитет) для нормального убийства.
            SELECT owner INTO owner_id FROM Districts d WHERE d.id = NEW.crime_place;
            SELECT mafia_family INTO mafia_id FROM Persons p WHERE p.id = NEW.killer;
            SELECT respect INTO person_respect FROM Persons p WHERE p.id = NEW.victim;
            SELECT authority INTO mafia_authority FROM Mafies m WHERE m.id = mafia_id;
--             приход авторитета зависит от авторитета общего.
            authority_up := person_respect * (10 - mafia_authority) / 100;
            IF (mafia_id = owner_id) THEN
                UPDATE Mafies m SET authority = authority + authority_up WHERE m.id = owner_id;
            ELSE
                UPDATE Mafies m SET authority = authority + 1.5 * authority_up,
                                  wealth = wealth - person_respect * 100 WHERE m.id = mafia_id;
            END IF;
            RETURN NEW;
        END IF;
    END;
$$;

alter function correct_kill() owner to s270250;

