create function set_roles(arg s251437.profile[]) returns void
    language plpgsql
as
$$
DECLARE
    t profile;
BEGIN
    FOREACH t IN ARRAY arg LOOP
                INSERT INTO
                    role_profile_relation(role_id, profile_id)
                VALUES(1, t.id);
        END LOOP;
END
$$;

alter function set_roles(s251437.profile[]) owner to s251437;

