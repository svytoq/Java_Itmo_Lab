create function not_enough_watcher() returns trigger
    language plpgsql
as
$$
BEGIN
IF (select count(*) from watcher natural join subcircle where subcircle.idsubcircle=NEW.idsubcircle) <
   ( (select PunismentRequiredWatcherAmountOnOne / PunishmentCapacity from punishment natural join subcircle where idsubcircle=NEW.idsubcircle)*(SELECT count(*) FROM
tormented where idsubcircle = NEW.idsubcircle)+1) THEN
RAISE EXCEPTION 'Слишком мало наблюдателей!';
END IF;
RETURN NEW;
END;
$$;

alter function not_enough_watcher() owner to s242430;

