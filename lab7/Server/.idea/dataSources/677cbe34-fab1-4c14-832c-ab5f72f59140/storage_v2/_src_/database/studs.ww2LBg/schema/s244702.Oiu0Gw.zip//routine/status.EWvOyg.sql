create function status() returns trigger
    language plpgsql
as
$$
DECLARE AGE date;
        LEVEL_ NUMERIC;
  LEVELL_ NUMERIC;
BEGIN

   AGE:=(select production_date from device_information where new.device_id = device_id);
  LEVELL_:=date_part('year',age(AGE::date));
  LEVEL_:=new.maintenance;
  IF LEVELL_>LEVEL_  THEN
    UPDATE device_information set tech_status= 'on' where  device_id = new.device_id;
	else UPDATE device_information set tech_status= 'off' where device_id = new.device_id;
  END IF;
  return null ;
  --raise  exception '(%) (%)',LEVEL_,LEVELL_;
  --return new;

END;
$$;

alter function status() owner to s244702;

