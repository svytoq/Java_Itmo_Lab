create function kiid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_ВИДА_ПРОГРАММЫ := nextval('kinds_seq');
	return new;
end
$$;

alter function kiid() owner to s225120;

