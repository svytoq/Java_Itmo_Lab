create function insert_events() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
  BEGIN
    LOOP
      INSERT INTO events VALUES (DEFAULT, trunc(random()*10000)+1, '5/12/1998', trunc(random()*20)+1);
      count = count + 1;
      EXIT WHEN count = 100;
    END LOOP;
  END;
$$;

alter function insert_events() owner to s225107;

