create function tech_to_building(bname text)
    returns TABLE(tech_name text, points integer, features text)
    language plpgsql
as
$$
BEGIN
		RETURN QUERY SELECT technologies.tech_name, technologies.points, technologies.features FROM  (technologies JOIN building_tech ON technologies.id = building_tech.tech_id) JOIN buildings ON building_tech.building_id = buildings.id WHERE buildings.name = bname; 
	END;
$$;

alter function tech_to_building(text) owner to s225102;

