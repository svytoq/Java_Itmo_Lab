create function count_breakdown_with_the_same_problem(_id_detector integer, _id_device integer)
    returns TABLE(count bigint)
    language plpgsql
as
$$
begin
    return query select count(*) from breakdown_with_the_same_problem(_id_detector, _id_device);
end;
$$;

alter function count_breakdown_with_the_same_problem(integer, integer) owner to s264434;

