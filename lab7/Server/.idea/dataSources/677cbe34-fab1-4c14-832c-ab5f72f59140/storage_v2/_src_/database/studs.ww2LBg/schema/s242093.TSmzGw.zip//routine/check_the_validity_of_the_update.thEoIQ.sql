create function check_the_validity_of_the_update() returns trigger
    language plpgsql
as
$$
BEGIN
DELETE FROM C_UPDATE WHERE ID_MOD = NEW.ID_MOD;
return NEW;
END;
$$;

alter function check_the_validity_of_the_update() owner to s242093;

