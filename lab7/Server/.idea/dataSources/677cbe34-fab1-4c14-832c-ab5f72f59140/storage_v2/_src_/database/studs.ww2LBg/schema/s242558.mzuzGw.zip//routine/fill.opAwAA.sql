create function fill() returns void
    language sql
as
$$
SELECT fillt();
SELECT fill1();
SELECT fill2();
SELECT fill3();
SELECT fill4();
SELECT fill5();
SELECT fill6();
SELECT fill7();
SELECT fill8();
SELECT closeAllVote();
SELECT filli();
$$;

alter function fill() owner to s242558;

