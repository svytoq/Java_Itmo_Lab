create function insert_tickets_for_session(session_id integer) returns void
    language plpgsql
as
$$
DECLARE
        room_id int;
        place_id record;
BEGIN
        room_id = (SELECT ид_фильма FROM Сеансы where Сеансы.ид = session_id);
        FOR place_id IN (SELECT ид from Места where ид_зала=room_id)
        LOOP
                INSERT INTO Билеты(ид_места, ид_сеанса, стоимость, статус) 
        values(place_id.ид, session_id, random()::int, 0);
        END LOOP;
END;
$$;

alter function insert_tickets_for_session(integer) owner to s242395;

