create function "добавитьКЗаказу"("заказ" integer, "исследование" integer) returns void
    language plpgsql
as
$$
declare
сотрудник int;
begin
    сотрудник := (select найтиСотрудникаДляИсследования(исследование));
    insert into ЛабораторныеИсследования (заказ_id, исполнитель_id, исследование_тип_id)
    values (заказ, сотрудник, исследование);
end;
$$;

alter function "добавитьКЗаказу"(integer, integer) owner to s264446;

