create function adding_university(org_name character varying, org_address character varying, rect character varying) returns bigint
    language plpgsql
as
$$
declare
    o_id integer;
begin
insert into organization(name, address) values (org_name, org_address) returning id into o_id;
insert into university VALUES (o_id, rect);
return o_id;
end;
$$;

alter function adding_university(varchar, varchar, varchar) owner to s263975;

