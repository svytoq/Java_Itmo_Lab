create function find_order_responsible() returns integer
    language plpgsql
as
$$
BEGIN
        RETURN (
            SELECT emp.id FROM employee AS emp
            LEFT JOIN customer_order AS ord ON ord.responsible_id = emp.id
            WHERE emp.department = 'sales'
            GROUP BY emp.id
            ORDER BY count(ord.id)
            LIMIT 1
        );
    END;
$$;

alter function find_order_responsible() owner to s264443;

