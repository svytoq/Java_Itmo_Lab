create function testevent(i integer) returns void
    language plpgsql
as
$$
DECLARE
j integer;
BEGIN

insert into ПЕРСОН_СОБЫТИЕ values((select * FROM(SELECT ИМЯ FROM ПЕРСОНАЖИ ORDER BY RANDOM()) AS POP LIMIT 1), (select * FROM(SELECT НАЗВАНИЕ_СОБ FROM СОБЫТИЯ ORDER BY RANDOM()) AS POP LIMIT 1));

END;
$$;

alter function testevent(integer) owner to s223859;

