create function "СОБРАНИЯ_ИД_АПДЕЙТ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ИД_СОБРАНИЯ!=NEW.ИД_СОБРАНИЯ THEN
 NEW.ИД_СОБРАНИЯ=OLD.ИД_СОБРАНИЯ;
 RETURN NEW;
ELSE
RETURN NEW;
END IF;
 END;
$$;

alter function "СОБРАНИЯ_ИД_АПДЕЙТ"() owner to s225071;

