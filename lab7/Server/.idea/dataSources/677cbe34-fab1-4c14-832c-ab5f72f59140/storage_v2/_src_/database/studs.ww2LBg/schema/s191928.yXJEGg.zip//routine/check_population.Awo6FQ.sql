create function check_population() returns trigger
    language plpgsql
as
$$
declare
err character(35);
begin 
err := 'Population cannot be less than 0.';
if new.population < 0 then raise notice '%', err;
return null;
end if;
return new;
end
$$;

alter function check_population() owner to s191928;

