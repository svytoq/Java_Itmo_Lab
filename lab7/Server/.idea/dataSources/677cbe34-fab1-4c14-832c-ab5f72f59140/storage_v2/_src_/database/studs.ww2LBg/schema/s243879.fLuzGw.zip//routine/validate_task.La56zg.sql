create function validate_task() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.Дата < ANY(
SELECT Дата_рождения FROM Г_Пользователь
WHERE ИД = NEW.ИД_Пользователя) THEN
RAISE EXCEPTION 'Задача % старше пользователя', NEW.ИД;
END IF; 
RETURN NEW; END
$$;

alter function validate_task() owner to s243879;

