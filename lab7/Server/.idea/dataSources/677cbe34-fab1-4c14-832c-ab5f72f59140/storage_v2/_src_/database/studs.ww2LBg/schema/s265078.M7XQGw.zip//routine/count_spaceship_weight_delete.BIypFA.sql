create function count_spaceship_weight_delete() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE spaceships AS s SET weight = t.sum_weight FROM spaceships INNER JOIN ( SELECT ship_details.spaceship_id, SUM(details.weight) sum_weight FROM ship_details INNER JOIN details ON ship_details.detail_id = details.detail_id WHERE spaceship_id = OLD.spaceship_id GROUP BY ship_details.spaceship_id ) t ON t.spaceship_id = spaceships.spaceship_id WHERE s.spaceship_id = OLD.spaceship_id;
RETURN OLD;
END;
$$;

alter function count_spaceship_weight_delete() owner to s265078;

