create function shattlecheck() returns trigger
    language plpgsql
as
$$
declare
    count integer := 0;
begin
    count = (select count(*) from human where shattleid = new.shattleid);
    
    if(count > 0) then
        raise notice 'error. count: %', count;
        return null;
    else
        raise notice 'ok. count: %', count;
        return new;
    end if; 
end;
$$;

alter function shattlecheck() owner to s265574;

