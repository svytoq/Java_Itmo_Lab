create function get_current_recommendations()
    returns TABLE(id integer, full_name character varying, title character varying, depart character varying, salary numeric, option numeric, bonus numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT R.id,
                        W.full_name,
                        P.title,
                        D.name,
                        P.salary,
                        R.option,
                        R.bonus
                 from RECOMMENDATION R
                          INNER JOIN POSITION P on R.position_id = P.id
                          INNER JOIN DEPARTMENT D on D.id = R.department_id
                          INNER JOIN WORKER W on W.id = R.worker_id;

END;
$$;

alter function get_current_recommendations() owner to s264491;

