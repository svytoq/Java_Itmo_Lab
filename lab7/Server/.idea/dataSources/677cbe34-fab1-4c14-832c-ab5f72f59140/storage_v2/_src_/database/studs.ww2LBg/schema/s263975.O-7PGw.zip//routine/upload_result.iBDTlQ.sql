create function upload_result(st_name character varying, st_surname character varying, st_birthday date, event_name character varying, point double precision) returns void
    language plpgsql
as
$$
declare
    st_id    integer;
    event_id integer;
begin
    st_id := (select student.id
              from student
              where student.name ~* st_name
                and student.surname ~* st_surname
                and student.birthday = st_birthday
              limit 1);

    if st_id is null then
        raise exception 'Error: Student ''% %'' not found', st_name, st_surname;
    end if;

    event_id := (select event.id from event where name ~* event_name limit 1);

    if event_id is null then
        raise exception 'Error: Event ''%'' not fount', event_name;
    end if;

    if (select 1
        from student_participation
        where student_participation.stud_id = st_id
          and student_participation.ev_id = event_id) is null then
        insert into student_participation(stud_id, ev_id) values (st_id, event_id);
        insert into result(ev_id, stud_id, points) values (event_id, st_id, point);
    else
        update result set points = point where result.ev_id = event_id and result.stud_id = st_id;
    end if;

end;
$$;

alter function upload_result(varchar, varchar, date, varchar, double precision) owner to s263975;

