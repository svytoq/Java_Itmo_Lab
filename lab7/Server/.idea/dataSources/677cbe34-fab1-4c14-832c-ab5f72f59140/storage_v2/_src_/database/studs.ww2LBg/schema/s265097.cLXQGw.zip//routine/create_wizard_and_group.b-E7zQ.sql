create function create_wizard_and_group(s_name text, age integer, g_name text) returns integer
    language plpgsql
as
$$
declare 
myid integer;
gid integer;
begin
Insert into "Wizard"("Name", "Age") values(s_name, age);
select "Id" into myid from "Wizard" where "Name" = s_name;
insert into "Group"("Name", "AdminId") values(g_name, myid);
select "Id" into gid from "Group" where "Name" = g_name;
update "Wizard" set "GroupId" = gid where "Id" = myid;
return myid;
end;
$$;

alter function create_wizard_and_group(text, integer, text) owner to s265097;

