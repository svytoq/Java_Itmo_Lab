create function get_owning_product_prototypes(user_profile_id integer) returns SETOF s267880.product_prototype
    language sql
as
$$
select * from product_prototype where owner_id = user_profile_id;
$$;

alter function get_owning_product_prototypes(integer) owner to s267880;

