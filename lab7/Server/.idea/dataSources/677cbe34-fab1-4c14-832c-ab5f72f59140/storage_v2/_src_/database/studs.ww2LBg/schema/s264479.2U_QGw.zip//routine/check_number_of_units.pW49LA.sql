create function check_number_of_units(squad_type integer, unit_number integer) returns boolean
    language sql
as
$$
SELECT (t1.base_number >= unit_number) FROM squad_type as t1 WHERE t1.ID = squad_type;
$$;

alter function check_number_of_units(integer, integer) owner to s264479;

