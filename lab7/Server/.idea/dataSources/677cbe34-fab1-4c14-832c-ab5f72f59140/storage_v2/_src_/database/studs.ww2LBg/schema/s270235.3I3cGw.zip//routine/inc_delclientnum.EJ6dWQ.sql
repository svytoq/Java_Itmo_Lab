create function inc_delclientnum() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE delivery_places
    SET client_num = client_num + 1
    WHERE delivery_places.id_delivery_place = NEW.id_delivery_place;
    RETURN NEW;
END;
$$;

alter function inc_delclientnum() owner to s270235;

