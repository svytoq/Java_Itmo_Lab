create function details_boat("id_ЛОДКИ" integer)
    returns TABLE("ИД_ЛОДКИ" integer, "ИД_ДЕТАЛИ" integer, "ВЕС" integer, "ВЛИЯНИЕ_НА_СКОРОСТЬ" integer, "ВЛИЯНИЕ_НА_УПРАВЛЯЕМОСТЬ" integer, "ВЛИЯНИЕ_НА_УСКОРЕНИЕ" integer)
    language sql
as
$$
SELECT ИД_ЛОДКИ, ИД_ДЕТАЛИ, ВЕС, ВЛИЯНИЕ_НА_СКОРОСТЬ,
ВЛИЯНИЕ_НА_УПРАВЛЯЕМОСТЬ, ВЛИЯНИЕ_НА_УСКОРЕНИЕ FROM ДЕТАЛИ 
INNER JOIN ДЕТАЛИ_НА_ЛОДКЕ ON ДЕТАЛИ_НА_ЛОДКЕ.ИД_ДЕТАЛИ =
ДЕТАЛИ.ИД WHERE ДЕТАЛИ_НА_ЛОДКЕ.ИД_ЛОДКИ = $1;
$$;

alter function details_boat(integer) owner to s242319;

