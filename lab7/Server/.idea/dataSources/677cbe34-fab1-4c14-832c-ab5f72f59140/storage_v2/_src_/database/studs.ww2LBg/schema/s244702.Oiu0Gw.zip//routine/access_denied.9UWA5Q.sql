create function access_denied() returns trigger
    language plpgsql
as
$$
DECLARE AGE date;
        LEVEL_ NUMERIC;
BEGIN
   AGE:=(select birthday from userr where new.user_id = user_id);
   LEVEL_:=(select level from access where access.access_id=new.access_id);
  IF date_part('year',age(AGE::date))<18 THEN
    if LEVEL_ = 3 THEN raise exception 'Невозможно предоставить полный доступ несовершеннолетнему';
    end if;
  END IF;
  
  RETURN new;

END;
$$;

alter function access_denied() owner to s244702;

