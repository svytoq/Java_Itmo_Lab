create function add_sorcerer_to_school(sc_id integer, sorc_id integer) returns integer
    language plpgsql
as
$$
begin
 
 INSERT INTO school_sorcerer VALUES
 (sorc_id, sc_id);
 
 RETURN 0;
 end
$$;

alter function add_sorcerer_to_school(integer, integer) owner to s268428;

