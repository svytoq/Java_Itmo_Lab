create function add_to_stream(id integer, stream integer) returns integer
    language plpgsql
as
$$
begin

 UPDATE witcher set stream_id = stream WHERE witcher_id = id;
 
 RETURN schl;
 end
$$;

alter function add_to_stream(integer, integer) owner to s268428;

