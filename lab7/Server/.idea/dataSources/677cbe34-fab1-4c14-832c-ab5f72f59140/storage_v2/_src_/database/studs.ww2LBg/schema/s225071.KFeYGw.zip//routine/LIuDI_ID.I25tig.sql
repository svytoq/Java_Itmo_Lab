create function "ЛЮДИ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('ЛЮДИ_ИД_ЧЕЛОВЕК_seq')!=NEW.ИД_ЧЕЛОВЕК THEN NEW.ИД_ЧЕЛОВЕК=nextval('ЛЮДИ_ИД_ЧЕЛОВЕК_seq');
  RETURN NEW;
ELSE
  RETURN NEW;
END IF;
END;
$$;

alter function "ЛЮДИ_ИД"() owner to s225071;

