create function upd_people() returns trigger
    language plpgsql
as
$$
BEGIN
  IF OLD.ИМЯ != NEW.ИМЯ OR OLD.СОСЛОВИЕ != NEW.СОСЛОВИЕ OR OLD.ПОЛ != NEW.ПОЛ
  THEN
    RAISE NOTICE 'ЧЕЛОВЕК НЕ МОЖЕТ ИЗМЕНИТЬ ИМЯ, СОСЛОВИЕ ИЛИ ПОЛ';
    RETURN NULL;
  ELSE RETURN NEW;
  END IF;
END;

$$;

alter function upd_people() owner to s225081;

