create function check_squad_application() returns trigger
    language plpgsql
as
$$
begin
    if new.squad_type is null then
        raise exception 'squad_type cannot be null';
    end if;
    if new.army_id is null then
        raise exception 'army_id cannot be null';
    end if;
    if (select (army.army_type = squad_type.application_area)
        from squad_type,
             army
        where squad_type.id = new.squad_type
          and army.id = new.army_id
        limit 1) then
        return new;
    else
        raise exception 'this squad can t take part in this army';
    end if;
end ;
$$;

alter function check_squad_application() owner to s265106;

