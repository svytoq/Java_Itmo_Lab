create function onegm() returns trigger
    language plpgsql
as
$$
DECLARE
busy integer;
gm_id integer;
BEGIN
SELECT ГМ_ИД INTO gm_id FROM "К_Партии" WHERE Id = NEW.Партия_ИД;
SELECT count(*) INTO busy FROM "К_Сессии" WHERE Партия_ИД IN (SELECT Id FROM "К_Партии" WHERE ГМ_ИД = gm_id) AND
((cast(NEW.Дата_Начала as timestamp) + '00:30:00' > Дата_Начала AND cast(NEW.Дата_Начала as timestamp) < Дата_Начала)
OR (Дата_Начала + '00:30:00' > cast(NEW.Дата_Начала as timestamp) AND cast(NEW.Дата_Начала as timestamp) > Дата_Начала));
IF (busy >= 1) THEN
RETURN NULL;
END IF;
RETURN NEW;
END;
$$;

alter function onegm() owner to s242193;

