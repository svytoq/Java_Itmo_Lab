create function actor_info(name text, OUT "НАЗВАНИЕ_Н" text, OUT "НАЗВАНИЕ" text) returns SETOF record
    language sql
as
$$
SELECT НАГРАДЫ.НАЗВАНИЕ_Н, ФИЛЬМ.НАЗВАНИЕ FROM АКТЕР JOIN (НАГРАДЫ_А JOIN НАГРАДЫ ON (НАГРАДЫ.ИД = НАГРАДЫ_А.ИД_Н)) ON (АКТЕР.ИД = НАГРАДЫ_А.ИД_А) join  АКТЕРСКИЙ_СОСТАВ on (АКТЕРСКИЙ_СОСТАВ.ИД_А=АКТЕР.ИД ) join ФИЛЬМ on (ФИЛЬМ.ИД=АКТЕРСКИЙ_СОСТАВ.ИД_Ф) WHERE АКТЕР.ИМЯ = name;
$$;

alter function actor_info(text, out text, out text) owner to s243886;

