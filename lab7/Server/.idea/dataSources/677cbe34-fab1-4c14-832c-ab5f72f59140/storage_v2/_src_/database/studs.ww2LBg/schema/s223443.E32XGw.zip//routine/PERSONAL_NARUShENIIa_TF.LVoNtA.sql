create function "ПЕРСОНАЛ_НАРУШЕНИЯ_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF (exists(SELECT FROM "ПЕРСОНАЛ_НАРУШЕНИЯ" WHERE "ПЕРСОНАЛ_НАРУШЕНИЯ"."ИД_ПЕРСОНАЛ" = NEW."ИД_ПЕРСОНАЛ"))
AND
(exists(SELECT FROM "ПЕРСОНАЛ_НАРУШЕНИЯ" WHERE "ПЕРСОНАЛ_НАРУШЕНИЯ"."ИД_НАРУШЕНИЕ" = NEW."ИД_НАРУШЕНИЕ"))
THEN
RAISE 'Такое отношение уже записано в БД.';
END IF;
IF NOT (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."ИД_ПЕРСОНАЛ" = NEW."ИД_ПЕРСОНАЛ"))
THEN
RAISE 'Такого персонала нет в БД.';
END IF;
IF NOT (exists(SELECT FROM "НАРУШЕНИЯ" WHERE "НАРУШЕНИЯ"."ИД_НАРУШЕНИЕ" = NEW."ИД_НАРУШЕНИЕ"))
THEN
RAISE 'Такого нарушения нет в БД.';
END IF;
return NEW;
END;
$$;

alter function "ПЕРСОНАЛ_НАРУШЕНИЯ_ТФ"() owner to s223443;

