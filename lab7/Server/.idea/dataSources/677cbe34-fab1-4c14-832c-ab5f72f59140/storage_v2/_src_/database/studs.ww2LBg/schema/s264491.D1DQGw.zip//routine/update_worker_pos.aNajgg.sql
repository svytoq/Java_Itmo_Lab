create function update_worker_pos() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE WORKER
    SET position_id   = NEW.position_id,
        department_id = NEW.department_id,
        option        = NEW.option,
        bonus         = NEW.bonus
    WHERE NEW.worker_id = id;
    RETURN NEW;
END;
$$;

alter function update_worker_pos() owner to s264491;

