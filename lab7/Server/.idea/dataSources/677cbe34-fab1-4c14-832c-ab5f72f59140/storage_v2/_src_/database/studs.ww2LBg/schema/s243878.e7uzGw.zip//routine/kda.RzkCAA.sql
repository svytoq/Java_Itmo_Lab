create function kda()
    returns TABLE(nazv text, kda numeric)
    language plpgsql
as
$$
BEGIN 
RETURN query 
select tournament.name, max((stats.kills+stats.assists)::numeric/ case 
when stats.deaths > 0 then stats.deaths::numeric
when stats.deaths = 0 then 1
end) 
from tournament
join tournament_result on tournament.id = tournament_result.tournament_id
join team on first_id = team.id
join player on first_id = player.team_id
join stats on stats.player_id = player.id
join match on stats.match_id = match.id
where 
match.tournament_id = tournament.id
group by tournament.name, player.nickname;
END;
$$;

alter function kda() owner to s243878;

