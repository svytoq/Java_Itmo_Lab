create function "ПОЛЬЗОВАТЕЛЬ_ИД_ОБН"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ПОЛЬЗОВАТЕЛЬ_ИД!=NEW.ПОЛЬЗОВАТЕЛЬ_ИД THEN
NEW.ПОЛЬЗОВАТЕЛЬ_ИД=OLD.ПОЛЬЗОВАТЕЛЬ_ИД;
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function "ПОЛЬЗОВАТЕЛЬ_ИД_ОБН"() owner to s242456;

