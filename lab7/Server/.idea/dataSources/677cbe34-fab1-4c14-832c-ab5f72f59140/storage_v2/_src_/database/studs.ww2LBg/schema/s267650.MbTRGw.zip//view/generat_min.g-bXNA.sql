create view generat_min(generate_series) as
SELECT generate_series.generate_series
FROM generate_series(now() + 30::double precision * '00:01:00'::interval, (((SELECT "о"."Занято_с"
                                                                             FROM s267650."Очередь_дверь" "о"
                                                                                      JOIN s267650."Дверь_времени" "д" ON "о"."Дверь_ИД" = "д"."ИД"
                                                                             WHERE "о"."Билет_ИД" = 1
                                                                               AND "д"."Тип_двери" = 'Вход'::text
                                                                             ORDER BY "о"."Занято_с" DESC
                                                                             LIMIT 1)) + 2::double precision *
                                                                                         '00:01:00'::interval)::timestamp with time zone,
                     '00:01:00'::interval) generate_series(generate_series);

alter table generat_min
    owner to s267650;

