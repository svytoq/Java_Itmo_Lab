create function "исследованиеГотово"("исследование" integer) returns void
    language plpgsql
as
$$
DECLARE
количествоНеготовых int;
заказ int;
BEGIN
    заказ := (select заказ_id from Исследования where id=исследование limit 1);
    количествоНеготовых := (select count(*) from ЛабораторныеИсследования where заказ_id=заказ AND готов='f');
    if количествоНеготовых=0 then
        update Заказы
        set готов='t'
        where id=заказ;
    end if;
end;
$$;

alter function "исследованиеГотово"(integer) owner to s264446;

