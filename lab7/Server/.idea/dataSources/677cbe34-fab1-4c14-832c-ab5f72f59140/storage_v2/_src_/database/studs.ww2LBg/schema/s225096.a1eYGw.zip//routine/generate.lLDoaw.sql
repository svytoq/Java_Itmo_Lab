create function generate() returns trigger
    language plpgsql
as
$$
DECLARE
	one_of INTEGER;
	second_of INTEGER;
BEGIN
	FOR counter IN 1..new.count_of LOOP
	one_of := floor(random()*(new.range_end-new.range_start+1))+new.range_start;
	second_of := floor(random()*(new.range_end-new.range_start+1))+new.range_start;
 		INSERT INTO pairing (id_of_male, id_of_female) VALUES (one_of, second_of);
  END LOOP;
	RETURN new;
END;
$$;

alter function generate() owner to s225096;

