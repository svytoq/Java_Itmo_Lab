create function "П_ДНЕВНИК_АВТОЗАП_ФУНК"() returns trigger
    language plpgsql
as
$$
BEGIN

IF NEW.ЗАГОЛОВОК IS NULL THEN
NEW.ЗАГОЛОВОК = '(Без темы)';
END IF;

NEW.ДАТА_СОЗДАНИЕ = CURRENT_DATE;

RETURN NEW;
END;
$$;

alter function "П_ДНЕВНИК_АВТОЗАП_ФУНК"() owner to s269331;

