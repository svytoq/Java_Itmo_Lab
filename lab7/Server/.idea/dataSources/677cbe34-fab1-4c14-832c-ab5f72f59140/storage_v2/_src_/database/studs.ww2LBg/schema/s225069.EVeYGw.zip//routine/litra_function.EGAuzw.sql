create function litra_function() returns trigger
    language plpgsql
as
$$
begin
new.Book_ID=nextval('Literature_Book_ID_seq');
return new;
end;
$$;

alter function litra_function() owner to s225069;

