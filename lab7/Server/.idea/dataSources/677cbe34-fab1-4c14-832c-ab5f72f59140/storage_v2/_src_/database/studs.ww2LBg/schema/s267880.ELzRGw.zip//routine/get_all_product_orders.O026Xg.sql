create function get_all_product_orders() returns SETOF s267880.detailed_product_order
    language sql
as
$$
select * from detailed_product_order order by planned_delivery_date;
$$;

alter function get_all_product_orders() owner to s267880;

