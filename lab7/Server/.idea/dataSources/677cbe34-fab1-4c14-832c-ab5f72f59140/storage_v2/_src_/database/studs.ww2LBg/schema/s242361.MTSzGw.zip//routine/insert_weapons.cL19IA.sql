create function insert_weapons() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((SELECT ИД_ОРУЖИЯ FROM ОРУЖИЕ JOIN ПОДАРКИ USING(НАЗВАНИЕ) WHERE ИД_ПОДАРКА = NEW.ИД_ПОДАРКА) IS NOT NULL) THEN
INSERT INTO ОРУЖИЕ_В_ИГРЕ VALUES (NEW.ИД_ТРИБУТА,(SELECT ИД_ОРУЖИЯ FROM ОРУЖИЕ JOIN ПОДАРКИ USING(НАЗВАНИЕ) WHERE ИД_ПОДАРКА = NEW.ИД_ПОДАРКА));
RETURN NEW;
ELSE RETURN NULL;
END IF;
END;
$$;

alter function insert_weapons() owner to s242361;

