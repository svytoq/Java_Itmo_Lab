create function travel_to_planet(hunter integer, planet integer) returns text
    language plpgsql
as
$$
DECLARE
    hunter_ship_id int;
    hunter_current_planet int;
    travel_gate_id int;
  BEGIN
  
    SELECT h.ship_id, ss.planet_id INTO hunter_ship_id, hunter_current_planet 
    FROM Hunter as h 
    INNER JOIN Space_ship as ss ON (ss.id = h.ship_id)
    WHERE h.id = hunter;
    
    SELECT sg.id INTO travel_gate_id FROM Space_gate as sg 
    WHERE sg.come_from = hunter_current_planet AND sg.go_to = planet;
    
    IF NOT FOUND THEN
      RAISE EXCEPTION 'There is no avalaible gates to travel to this planet';
    END IF;
    
    INSERT INTO Travel (ship_id, gate_id) VALUES (hunter_ship_id, travel_gate_id);
    
    RETURN 'You`ve moved to another planet';
  END;
$$;

alter function travel_to_planet(integer, integer) owner to s263081;

