create function check_info_has_row() returns trigger
    language plpgsql
as
$$
declare
	info_has_id boolean;
begin
	if tg_table_name = 'other_resources' then
		info_has_id := (
			select exists(select from information where type = 'Прочие ресурсы' and new.id=information.id)
		);
	elsif tg_table_name = 'mechanic_details' then
		info_has_id := (
			select exists(select from information where type = 'Механическая деталь' and new.id=information.id)
		);
	elsif tg_table_name = 'sensors' then
		info_has_id := (
			select exists(select from information where type = 'Сенсор' and new.id=information.id)
		);
	elsif tg_table_name = 'controllers' then
		info_has_id := (
			select exists(select from information where type = 'Контроллер' and new.id=information.id)
		);
	elsif tg_table_name = 'motors' then
		info_has_id := (
			select exists(select from information where type = 'Мотор' and new.id=information.id)
		);
	elsif tg_table_name = 'platforms' then
		info_has_id := (
			select exists(select from information where type = 'Платформа' and new.id=information.id)
		);
	end if;

  if not info_has_id
  	then raise exception 'Information has no rofl for you';
  end if;
	return new;
end;
$$;

alter function check_info_has_row() owner to s244707;

