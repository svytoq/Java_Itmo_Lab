create function "СКИДКА_ИД_ОБН"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.СКИДКА_ИД!=NEW.СКИДКА_ИД THEN
NEW.СКИДКА_ИД=OLD.СКИДКА_ИД;
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function "СКИДКА_ИД_ОБН"() owner to s242456;

