create function add_publication(person_id integer, publication_id integer) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO people_publication (person_id, publication_id)
    VALUES (add_publication.person_id,
            add_publication.publication_id);
END;
$$;

alter function add_publication(integer, integer) owner to s264448;

