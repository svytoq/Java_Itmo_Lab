create function check_players_amount() returns trigger
    language plpgsql
as
$$
DECLARE
	maxPlayers constant smallint = 8;
BEGIN
	IF ((SELECT COUNT(*)
		FROM players p
		WHERE p.world = NEW.world) > maxPlayers) THEN
		RAISE EXCEPTION 
			'Players amount in world cannot be more than %
			world % player %',
			maxPlayers, NEW.world, NEW.id;
	END IF;

	RETURN NEW;
END;
$$;

alter function check_players_amount() owner to s244711;

