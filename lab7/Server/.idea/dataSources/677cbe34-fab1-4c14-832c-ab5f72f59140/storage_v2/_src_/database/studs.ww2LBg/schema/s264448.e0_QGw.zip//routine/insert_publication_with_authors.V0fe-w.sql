create function insert_publication_with_authors(name text, description text, authors integer[]) returns integer
    language plpgsql
as
$$
DECLARE
    cur_author  integer;
    publication_number integer;
BEGIN
    SELECT insert_publication(name, description) INTO publication_number;

    FOREACH cur_author IN ARRAY authors
        LOOP
            PERFORM add_publication(cur_author, publication_number);
        END LOOP;

    RETURN publication_number;
END;
$$;

alter function insert_publication_with_authors(text, text, integer[]) owner to s264448;

