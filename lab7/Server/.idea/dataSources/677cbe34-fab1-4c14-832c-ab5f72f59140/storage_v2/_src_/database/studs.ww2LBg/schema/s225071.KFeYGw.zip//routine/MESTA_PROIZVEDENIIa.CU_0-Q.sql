create function "МЕСТА_ПРОИЗВЕДЕНИЯ"(name character varying)
    returns TABLE("НАЗВАНИЕ_МЕСТА" character varying, "СТРАНА" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"МЕСТА"."НАЗВАНИЕ_МЕСТА", "МЕСТА"."СТРАНА"
FROM "МЕСТА" NATURAL JOIN "МЕСТА_ПРОИЗВЕДЕНИЯ" WHERE "МЕСТА_ПРОИЗВЕДЕНИЯ"."НАЗВАНИЕ_ПРОИЗВЕДЕНИЯ" = name;
END;
$$;

alter function "МЕСТА_ПРОИЗВЕДЕНИЯ"(varchar) owner to s225071;

