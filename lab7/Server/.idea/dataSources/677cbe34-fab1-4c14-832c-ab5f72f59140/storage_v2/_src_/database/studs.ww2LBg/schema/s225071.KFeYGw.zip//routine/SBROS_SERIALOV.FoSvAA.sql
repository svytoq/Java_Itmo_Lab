create function "СБРОС_СЕРИАЛОВ"() returns void
    language plpgsql
as
$$
BEGIN
alter sequence "ЛЮДИ_ИД_ЧЕЛОВЕК_seq" restart; 
alter sequence "АДАПТАЦИИ_ИД_АДАПТАЦИИ_seq" restart; 
alter sequence "ДУЭЛИ_ИД_ДУЭЛЬ_seq" restart; 
alter sequence "ЛИТ_ЖУРНАЛ_ИД_ЖУРНАЛА_seq" restart; 
alter sequence "РЕДАКЦИИ_ИД_РЕДАКЦИИ_seq" restart; 
alter sequence "СОБРАНИЯ_ИД_СОБРАНИЯ_seq" restart;
END;
$$;

alter function "СБРОС_СЕРИАЛОВ"() owner to s225071;

