create function create_game(p_name text, p_budget integer, genres integer[], employees integer[], p_platform integer) returns void
    language plpgsql
as
$$
Declare
    x integer;
    number integer;
Begin
    INSERT INTO game ( name , status , budget ,  platform , profit, number ) VALUES
    (p_name,1,p_budget,p_platform,NULL,NULL);
    Select  INTO number id from game where name=p_name;
    FOREACH x IN ARRAY employees
        LOOP
            INSERT INTO employes_games( game_id , employee_id ) VALUES (number,x);
        END LOOP;
    FOREACH x IN ARRAY genres
        LOOP
            INSERT INTO games_genres( game_id , genre_id ) VALUES (number,x);
        END LOOP;
end;
$$;

alter function create_game(text, integer, integer[], integer[], integer) owner to s264431;

