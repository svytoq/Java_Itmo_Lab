create function disband_team(developer_id integer, current_team_id integer, new_team_id integer) returns void
    language plpgsql
as
$$
BEGIN

  PERFORM add_to_team(ARRAY[developer_id], current_team_id);
  PERFORM remove_developer_from_team(developer_id, new_team_id);

END;

$$;

alter function disband_team(integer, integer, integer) owner to s264458;

