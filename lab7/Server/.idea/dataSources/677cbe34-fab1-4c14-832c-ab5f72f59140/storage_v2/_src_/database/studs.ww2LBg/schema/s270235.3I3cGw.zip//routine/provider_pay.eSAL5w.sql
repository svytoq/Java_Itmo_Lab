create function provider_pay() returns trigger
    language plpgsql
as
$$
DECLARE
    factory integer;
BEGIN
    SELECT id_factory FROM providers WHERE providers.id_provider = NEW.id_provider INTO factory;
    NEW.id_factory = factory;
    NEW.paying = TRUE;
    NEW.payment_date = current_date;
    RETURN NEW;
END
$$;

alter function provider_pay() owner to s270235;

