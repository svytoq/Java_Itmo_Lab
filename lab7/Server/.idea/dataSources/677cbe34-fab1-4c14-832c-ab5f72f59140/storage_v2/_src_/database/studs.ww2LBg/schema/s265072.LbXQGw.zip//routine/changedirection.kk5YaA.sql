create function changedirection(shortyid integer, new_x integer, new_y integer, new_z integer) returns boolean
    language plpgsql
as
$$
DECLARE 
	shorty_scene integer;
	control_scene integer;
	control_machine_state boolean;
	rocketId integer;
BEGIN 
	select scene_id into shorty_scene from Shorty where shorty_id = shortyId;
	IF (shorty_scene is NULL) THEN RETURN false; END IF;
	select scene_id into control_scene from Room where name ~* 'кабина управления';
	if (control_scene is NULL) then return false; end if;
	if (control_scene != shorty_scene) then return false; end if;
	select Room.rocket_id into rocketId from Room join Shorty on (Shorty.scene_id = Room.scene_id) where Shorty.shorty_id = shortyId;
	select is_state into control_machine_state from Changeable join Control_Machine using (changeable_id) where name = 'Машина управления' and rocket_id = rocketId;
	if (control_machine_state is NULL or control_machine_state = false) then return false; end if;
	update Control_machine set x_direction = new_x, y_direction = new_y, z_direction = new_z where rocket_id = rocketId;
	return true;
END;
$$;

alter function changedirection(integer, integer, integer, integer) owner to s265072;

