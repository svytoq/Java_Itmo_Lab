create function get_current_actions_by_worker(work_id integer)
    returns TABLE(id integer, rtime timestamp without time zone, act_name character varying, full_name character varying, pos character varying, lin_desc text, worker_coeff numeric, worker_delta numeric, corp_coeff numeric, corp_delta numeric)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT A.id,
                        A.rtime,
                        T.name,
                        W.full_name,
                        P.title,
                        L.description,
                        L.worker_coeff,
                        L.worker_delta,
                        L.corp_coeff,
                        L.corp_delta
                 FROM ACTION A
                          INNER JOIN ACTION_TYPE T on T.id = A.atype_id
                          INNER JOIN WORKER W on W.id = A.worker_id
                          INNER JOIN POSITION P on P.id = W.position_id
                          LEFT JOIN LINEAR L on L.id = T.linear_id
                 WHERE work_id = A.worker_id;

END;
$$;

alter function get_current_actions_by_worker(integer) owner to s264491;

