create function "ОБНОВИТЬ_ГРУППУ"() returns trigger
    language plpgsql
as
$$
DECLARE
	count_studs smallint;
BEGIN
	IF (NEW.ГРУППА_ИД IS NOT NULL) THEN
		IF ((OLD.ГРУППА_ИД IS NOT NULL AND OLD.ГРУППА_ИД!=NEW.ГРУППА_ИД) OR (OLD.ГРУППА_ИД IS NULL)) THEN
			SELECT INTO count_studs КОЛИЧЕСТВО_УЧЕНИКОВ FROM ГРУППА WHERE ГРУППА_ИД=NEW.ГРУППА_ИД;
			count_studs=count_studs+1;
			UPDATE ГРУППА SET КОЛИЧЕСТВО_УЧЕНИКОВ=count_studs WHERE ГРУППА_ИД=NEW.ГРУППА_ИД;
			IF (OLD.ГРУППА_ИД IS NOT NULL) THEN
				SELECT INTO count_studs КОЛИЧЕСТВО_УЧЕНИКОВ FROM ГРУППА WHERE ГРУППА_ИД=OLD.ГРУППА_ИД;
				count_studs=count_studs-1;
				UPDATE ГРУППА SET КОЛИЧЕСТВО_УЧЕНИКОВ=count_studs WHERE ГРУППА_ИД=OLD.ГРУППА_ИД;
			END IF;
		END IF;
	ELSE 
		IF (OLD.ГРУППА_ИД IS NOT NULL) THEN
			SELECT INTO count_studs КОЛИЧЕСТВО_УЧЕНИКОВ FROM ГРУППА WHERE ГРУППА_ИД=OLD.ГРУППА_ИД;
			count_studs=count_studs-1;
			UPDATE ГРУППА SET КОЛИЧЕСТВО_УЧЕНИКОВ=count_studs WHERE ГРУППА_ИД=OLD.ГРУППА_ИД;
		END IF;
	END IF;
	RETURN NEW;
END;
$$;

alter function "ОБНОВИТЬ_ГРУППУ"() owner to s265057;

