create function проверка_сеансов() returns trigger
    language plpgsql
as
$$
DECLARE 
	премьера timestamp;
BEGIN
SELECT Фильмы.премьера INTO премьера FROM "Фильмы" WHERE ид = NEW.ид_фильма;
IF NEW.начало < премьера THEN
	RAISE EXCEPTION 'Дата премьеры фильма (%) не может быть позже, чем дата начала показа (%)', премьера, NEW.начало;
END IF;

RETURN NEW;
END;
$$;

alter function проверка_сеансов() owner to s224932;

