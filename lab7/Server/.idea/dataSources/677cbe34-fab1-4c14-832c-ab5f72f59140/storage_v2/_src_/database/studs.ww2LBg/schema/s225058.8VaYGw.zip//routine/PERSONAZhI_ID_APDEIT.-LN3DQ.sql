create function "ПЕРСОНАЖИ_ИД_АПДЕЙТ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ИД!=NEW.ИД THEN
    NEW.ИД=OLD.ИД;
        RETURN NEW;
ELSE
RETURN NEW;
END IF;   
    END;
$$;

alter function "ПЕРСОНАЖИ_ИД_АПДЕЙТ"() owner to s225058;

