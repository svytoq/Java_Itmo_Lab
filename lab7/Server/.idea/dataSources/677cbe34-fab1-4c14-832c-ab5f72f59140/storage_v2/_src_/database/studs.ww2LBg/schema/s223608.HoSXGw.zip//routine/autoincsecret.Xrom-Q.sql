create function autoincsecret() returns trigger
    language plpgsql
as
$$
BEGIN
   NEW.ID := nextval('IdSecretSequence');
   Return NEW;
 END;
$$;

alter function autoincsecret() owner to s223608;

