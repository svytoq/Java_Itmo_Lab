create function valid_user() returns trigger
    language plpgsql
as
$$
begin
  -- value 2 means worker, 1 means student
  if new.type = 2 then
    if (not new.date_birth is null) or (not new.serial_number is null) then
      raise exception 'Worker can''t have date_birth or serial_number';
    end if;
  elseif new.type = 1 then
    if new.serial_number is null or new.date_birth is null then
      raise exception 'Student must have birth date and serial number';
    end if;
  else
    raise exception 'Type value can be 1 or 2';
  end if;
  return new;
  end;
$$;

alter function valid_user() owner to s243852;

