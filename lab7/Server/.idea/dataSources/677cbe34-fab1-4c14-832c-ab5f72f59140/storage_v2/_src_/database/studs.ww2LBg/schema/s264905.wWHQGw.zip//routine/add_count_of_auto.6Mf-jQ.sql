create function add_count_of_auto() returns trigger
    language plpgsql
as
$$
DECLARE
	count_of_auto integer;
BEGIN
	IF (SELECT EXISTS(SELECT 1 FROM Counter WHERE Counter.name = 'АВТО')) THEN
		UPDATE Counter SET count = count + 1 WHERE Counter.name = 'АВТО';
	ELSE
		INSERT INTO Counter VALUES ('АВТО', 1);
	END IF;
    RETURN NEW;
END;
$$;

alter function add_count_of_auto() owner to s264905;

