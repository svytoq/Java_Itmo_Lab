create function men_in_district(id integer) returns SETOF s225039."Человек"
    language sql
as
$$
SELECT * FROM Человек WHERE ИД_район = id
$$;

alter function men_in_district(integer) owner to s225039;

