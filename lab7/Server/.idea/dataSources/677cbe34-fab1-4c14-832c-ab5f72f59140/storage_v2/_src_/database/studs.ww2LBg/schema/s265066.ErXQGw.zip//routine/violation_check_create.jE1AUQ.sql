create function violation_check_create(violation integer, employee integer) returns integer
    language plpgsql
as
$$
declare
    check_id integer;
begin
    insert into Violation_checks(violation_id)
        values(violation)
        returning violation_check_id into check_id;
    insert into Violation_check_employees(employee_id, violation_check_id)
        values(employee, check_id);
    update Violations set 
        violation_state='reviewing'
        where violation_id=violation;
    return check_id;
end;
$$;

alter function violation_check_create(integer, integer) owner to s265066;

