create function f2() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE ОРДЕН SET ОРДЕН_ЧИСЛЕННОСТЬ= ОРДЕН_ЧИСЛЕННОСТЬ +1
WHERE ОРДЕН_ИД = NEW.КОСМОДЕСАНТНИК_ОРДЕН;
RETURN NEW;
END;
$$;

alter function f2() owner to s242534;

