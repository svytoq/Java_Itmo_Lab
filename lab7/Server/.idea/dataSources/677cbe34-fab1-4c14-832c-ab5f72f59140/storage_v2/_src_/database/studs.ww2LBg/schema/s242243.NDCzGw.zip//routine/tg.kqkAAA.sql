create function tg() returns trigger
    language plpgsql
as
$$
DECLARE
a integer;
b integer;
k integer;
BEGIN
k:=0;
IF NOT EXISTS(SELECT Группа_ИД FROM Учебные_группы WHERE Преподаватель_ИД=NEW.Преподаватель_ИД) THEN
RETURN NEW;
ELSE
FOR a IN
SELECT DISTINCT Группа_ИД FROM Учебные_группы JOIN Студенты USING(Группа_ИД) WHERE Преподаватель_ИД=NEW.Преподаватель_ИД and Год=2018
 LOOP
k:=k+1;
END LOOP;

IF(k>5) THEN
RAISE EXCEPTION 'Невозможно добавить группу преподавателю'
USING HINT='У преподавателя уже 6 групп';
END IF;
END IF;
END;
$$;

alter function tg() owner to s242243;

