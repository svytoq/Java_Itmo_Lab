create function hashparolmd5() returns trigger
    language plpgsql
as
$$
begin 
UPDATE ЧЕЛОВЕК set ПАРОЛЬ=md5(ПАРОЛЬ);
RETURN NEW; 
END;
$$;

alter function hashparolmd5() owner to s243886;

