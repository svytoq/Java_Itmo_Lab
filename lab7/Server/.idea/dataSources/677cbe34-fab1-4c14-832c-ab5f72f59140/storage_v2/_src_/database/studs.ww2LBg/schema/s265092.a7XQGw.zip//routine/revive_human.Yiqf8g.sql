create function revive_human(humanid integer, mageid integer) returns integer
    language plpgsql
as
$$
DECLARE
    ABIL VARCHAR(25);
BEGIN
IF (SELECT ALIVE FROM HUMAN WHERE PERSON_ID = HUMANID) THEN
RETURN 2;
END IF;
    ABIL = (SELECT ABILITY FROM SMOKE JOIN MAGE ON MAGE.SMOKE_ID = SMOKE.SMOKE_ID WHERE MAGE_ID = MAGEID);
    IF (ABIL = 'Revival' AND (SELECT ALIVE FROM MAGE WHERE MAGE_ID = MAGEID)) THEN
        UPDATE HUMAN
        SET ALIVE = TRUE
        WHERE PERSON_ID = HUMANID;
UPDATE MAGE
        SET MONEY = MONEY + 500
        WHERE MAGE_ID = MAGEID;
ELSE RETURN 1;
    END IF;
RETURN 0;
END;
$$;

alter function revive_human(integer, integer) owner to s265092;

