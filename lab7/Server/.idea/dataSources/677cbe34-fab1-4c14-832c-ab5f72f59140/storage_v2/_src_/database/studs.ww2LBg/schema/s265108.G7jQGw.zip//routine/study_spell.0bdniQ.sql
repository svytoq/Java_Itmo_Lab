create function study_spell(spell integer, magician integer) returns text
    language plpgsql
as
$$
DECLARE
  spell_power int;
  does_know boolean := 'FALSE';
  can_learn boolean;
  magician_effort int;
BEGIN
  IF magician_exists(magician) AND spell_exists(spell) THEN

  SELECT 'TRUE' INTO does_know FROM Spell_to_magician stm 
  WHERE stm.magician_id = magician AND stm.spell_id = spell;
  IF does_know = 'TRUE' THEN
    RAISE EXCEPTION 'Вы уже знаете данное заклинание';
  END IF;
  
  SELECT m.effort_level INTO magician_effort FROM Magicians m
  WHERE m.person_id = magician;
  
  SELECT s.power INTO spell_power FROM Spells s WHERE s.id = spell;
  
  
  IF (magician_effort < spell_power) THEN
    UPDATE Magicians SET effort_level = magician_effort + 1;
    INSERT INTO Tasks (magician_id, spell_id, difficulty, is_success) 
    VALUES (magician, spell, spell_power, 'FALSE');
    RETURN 'Недостаточно старались, попробуйте еще раз';
  ELSE
    INSERT INTO Tasks (magician_id, spell_id, difficulty, is_success) 
    VALUES (magician, spell, spell_power, 'TRUE');
    RETURN 'Вы успешно выучили заклинание';
  END IF;
  END IF;
END;
$$;

alter function study_spell(integer, integer) owner to s265108;

