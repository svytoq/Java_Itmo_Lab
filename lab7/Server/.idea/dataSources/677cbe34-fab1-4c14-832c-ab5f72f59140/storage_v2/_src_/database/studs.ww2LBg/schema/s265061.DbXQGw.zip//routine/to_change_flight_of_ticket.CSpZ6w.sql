create function to_change_flight_of_ticket(tic_id integer, new_flight integer, new__seat character varying, am double precision) returns void
    language plpgsql
as
$$
begin
update  ticket set seat_id=(select id from seat where number=new_seat and flight_id=new_flight), amount=am where id=tic_id;
end;
$$;

alter function to_change_flight_of_ticket(integer, integer, varchar, double precision) owner to s265061;

