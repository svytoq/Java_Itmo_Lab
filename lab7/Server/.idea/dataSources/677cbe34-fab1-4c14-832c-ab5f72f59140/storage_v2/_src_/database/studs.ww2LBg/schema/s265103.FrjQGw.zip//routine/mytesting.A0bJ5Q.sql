create function mytesting() returns void
    language plpgsql
as
$$
declare
        my_max_time timestamp;
        min_time timestamp;
        channel_free timestamp;
begin
        select max(taken_to) into channel_free from Channels_queue where Channel_id = 41;
        select max(taken_from) into my_max_time from doors_queue where Door_id = 6;
        if my_max_time < current_timestamp + interval '32 min'
        then my_max_time := current_timestamp + interval '32 min';
        end if;

        SELECT date_trunc('min', x) into min_time
        FROM   generate_series(current_timestamp + interval '30 min'
                   , my_max_time
                   , interval  '1 min') t(x)
        WHERE date_trunc('min', x) not in (select  taken_from from Doors_queue d where d.door_id = 6)
          and date_trunc('min', x) >= channel_free - interval '1 min'
        limit 1;

        raise notice '%', min_time;
end;
$$;

alter function mytesting() owner to s265103;

