create function d112() returns trigger
    language plpgsql
as
$$
DECLARE
  num int;
BEGIN
  num:= (select number from phone_book where phone_book.sub_id=new.sub_id);
  IF (num = 0) OR (NUM is NULL ) then
    UPDATE PHONE_BOOK SET NUMBER = 112
    WHERE phone_book.sub_id=NEW.sub_id;
  end if;
  RETURN new;
END;
$$;

alter function d112() owner to s244702;

