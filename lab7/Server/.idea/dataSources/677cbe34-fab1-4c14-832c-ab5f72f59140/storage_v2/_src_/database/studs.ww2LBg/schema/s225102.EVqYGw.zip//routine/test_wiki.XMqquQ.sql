create function test_wiki() returns void
    language plpgsql
as
$$
declare
    res text ;
    res1 int;
    flag bool := true;
begin
    raise notice 'Creating test Wiki';
    insert into wiki values (22, '\x', 'text', 'test');

    raise notice 'Check that created';
    select title from wiki where id=22 into res;
    if res='test' then
        raise notice 'CREATED OK';
    else
        raise notice 'NOT CREATED';
        flag := false;
    end if;
    begin     -- try
        raise notice 'Inserting with same ID';
        insert into wiki values (22, '\x', 'text', 'test1');
        flag := false;
    exception -- catch
        when sqlstate '23505' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Id should be unique';
    end ;
    begin     -- try
        raise notice 'Inserting with same Title';
        insert into wiki values (23, '\x', 'text', 'test');
        flag := false;
    exception -- catch
        when sqlstate '23505' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Title should be unique';
    end ;

    raise notice 'Deleting row';
    delete from wiki where id=22;
    select count(*) from wiki where id=22 into res1;

    if res1=0 then
        raise notice 'DELETED OK';
    else
        raise notice 'NOT DELETED';
        flag := false;
    end if;
    raise notice 'Test accomplished: %', flag;
end;
$$;

alter function test_wiki() owner to s225102;

