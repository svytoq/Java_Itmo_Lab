create function isdoortospace(ch_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
scene integer;
BEGIN
	IF (select NOT exists(select 1 from Changeable where name = 'Дверь' and is_state = false AND changeable_id = ch_id)) 
	Then RETURN false; end if;
	IF (select exists(select 1 from Door where scene1_id != 1 AND scene2_id != 1 AND changeable_id = ch_id)) 
	THEN RETURN false; end if;
	
	SELECT CASE scene1_id WHEN 1 THEN scene2_id ELSE scene1_id END INTO scene FROM Door WHERE changeable_id = ch_id;
	
	IF ((select count(*) from Door join Changeable using (changeable_id) where is_state = true and (scene1_id = scene or scene2_id = scene)) > 0) 
	THEN RETURN true; end if;
	IF ((select count(*) from Shorty where (is_space_suit = false and scene_id = scene)) > 0) 
	THEN RETURN true; end if;
	RETURN false;
END;
$$;

alter function isdoortospace(integer) owner to s265072;

