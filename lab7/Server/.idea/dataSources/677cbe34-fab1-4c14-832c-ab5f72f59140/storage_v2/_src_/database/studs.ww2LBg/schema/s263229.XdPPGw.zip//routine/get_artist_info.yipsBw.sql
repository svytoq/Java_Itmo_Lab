create function get_artist_info(artist_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text, artist_type s263229.artist_types, using_technology s263229.using_technologies)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT a.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH, a.ARTIST_TYPE, a.USING_TECHNOLOGY FROM artists AS a 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE a.WORKER_ID = artist_id;
END
$$;

alter function get_artist_info(integer) owner to s263229;

