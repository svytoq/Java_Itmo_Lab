create function thing_info(thing_id_find integer)
    returns TABLE(thing_id integer, customer_id integer, trading_platform_id integer, is_selling boolean, rarity s263919.rarities, thing_name character varying, price integer)
    language plpgsql
as
$$
begin
    return query select * from thing t where thing_id_find = t.thing_id;
end;
$$;

alter function thing_info(integer) owner to s263919;

