create function tank_valid() returns trigger
    language plpgsql
as
$$
DECLARE
   rec INTEGER;
 BEGIN

   rec := (SELECT chassis.id FROM chassis WHERE NEW.id_chassis = chassis.id AND NEW.id_model = chassis.id_model);
   IF rec is NULL THEN
     RAISE EXCEPTION 'Problem with chassis and model';
   END IF;

   rec := (SELECT tower_weapon.id_tower FROM tower_weapon, firm_weapon, firm_tower
             WHERE NEW.sn_tower = firm_tower.serial_no AND firm_tower.id_tower = tower_weapon.id_tower
               AND NEW.sn_weapon = firm_weapon.serial_no AND firm_weapon.id_weapon = tower_weapon.id_weapon);

   IF rec is NULL THEN
     RAISE EXCEPTION 'Problem tower and weapon';
   END IF;

   RETURN NEW;

 END;
$$;

alter function tank_valid() owner to s184884;

