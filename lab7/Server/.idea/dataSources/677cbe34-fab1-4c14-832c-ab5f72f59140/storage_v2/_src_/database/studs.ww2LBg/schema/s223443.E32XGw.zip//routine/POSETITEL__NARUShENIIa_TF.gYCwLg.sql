create function "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF (exists(SELECT FROM "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ" WHERE "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ"."ИД_ПОСЕТИТЕЛЬ" = NEW."ИД_ПОСЕТИТЕЛЬ"))
AND
(exists(SELECT FROM "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ" WHERE "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ"."ИД_НАРУШЕНИЕ" = NEW."ИД_НАРУШЕНИЕ"))
THEN
RAISE 'Такое отношение уже записано в БД.';
END IF;
IF NOT (exists(SELECT FROM "ПОСЕТИТЕЛЬ" WHERE "ПОСЕТИТЕЛЬ"."ИД_ПОСЕТИТЕЛЬ" = NEW."ИД_ПОСЕТИТЕЛЬ"))
THEN
RAISE 'Такого посетителя нет в БД.';
END IF;
IF NOT (exists(SELECT FROM "НАРУШЕНИЯ" WHERE "НАРУШЕНИЯ"."ИД_НАРУШЕНИЕ" = NEW."ИД_НАРУШЕНИЕ"))
THEN
RAISE 'Такого нарушения нет в БД.';
END IF;
return NEW;
END;
$$;

alter function "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ_ТФ"() owner to s223443;

