create function buy_thing(first_customer_nick character varying, selling_thing_id integer) returns void
    language plpgsql
as
$$
declare
    enough_money boolean;
    buyer_money integer;
    thing_price integer;

begin
    select price into thing_price from thing t where t.thing_id = selling_thing_id;
    select p.customer_balance into buyer_money from customer c join paymentmethod p using(customer_nick_name) where first_customer_nick = c.customer_nick_name;
    if (buyer_money >= thing_price) then
        UPDATE thing t SET customer_nick_name = first_customer_nick, is_selling = false WHERE t.thing_id = selling_thing_id;
        UPDATE paymentmethod p SET customer_balance = (buyer_money - thing_price) WHERE p.customer_nick_name = first_customer_nick;
        insert into transaction(first_customer_nick , sec_customer_nick , first_thing_id, sec_thing_id, platform_id, transaction_type  ) values(first_customer_nick, null, selling_thing_id, null, 1, 'Sale');
    end if;
end;
$$;

alter function buy_thing(varchar, integer) owner to s263919;

