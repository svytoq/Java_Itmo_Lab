create function count_earnings3() returns trigger
    language plpgsql
as
$$
declare
earnings1 integer;
gain_earn integer;
gain_idd integer;
stuff_salary integer;

BEGIN
Gain_idd = (select event.gain_id from event where event_id = event.event_id);
Gain_earn = (select gain.earnings from gain where gain_idd = gain.gain_id);
stuff_salary = (select stuff.salary from stuff where old.stuff_id = stuff.stuff_id);
Earnings1 = gain_earn + stuff_salary;
Update gain SET gain_id = gain_idd, earnings = earnings1 WHERE gain_id = gain_idd;
Return NULL;
end;
$$;

alter function count_earnings3() owner to s265447;

