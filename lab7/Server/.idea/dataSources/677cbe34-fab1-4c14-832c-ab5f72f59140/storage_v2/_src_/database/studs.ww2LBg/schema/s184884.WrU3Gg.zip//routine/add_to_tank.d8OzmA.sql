create function add_to_tank(id_model integer, id_chassis integer, sn_engine integer, sn_tower integer, sn_weapon integer, team_number integer) returns void
    language plpgsql
as
$$
BEGIN
INSERT INTO tank(id_model, id_chassis, sn_engine, sn_tower, sn_weapon, team_number)
VALUES(id_model, id_chassis, sn_engine, sn_tower, sn_weapon, team_number);
END
$$;

alter function add_to_tank(integer, integer, integer, integer, integer, integer) owner to s184884;

