create function listofsin(n integer)
    returns TABLE(tormentedname text, specificsinname text)
    language plpgsql
as
$$
begin
    return query
    select tormented.TormentedName ,specificsin.specificsinname
FROM tormented
join assignment on tormented.idTormented=assignment.idTormented
join subcircle on assignment.idSubcircle=subcircle.idSubcircle
join specificsin on subcircle.idSpecificSin=specificsin.idspecificsin
where tormented.idTormented=n  and assignment.assignmentapproval=TRUE order by assignment.assignmentdate;

end;
$$;

alter function listofsin(integer) owner to s242430;

