create function check_suggestion_status() returns trigger
    language plpgsql
as
$$
DECLARE
    STATUS "STATUS" := (SELECT STATUS
                       FROM SUGGESTION
                       WHERE ID = NEW.SUGGESTION);
BEGIN
    IF STATUS != 'OPEN' THEN
        RETURN NULL;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_suggestion_status() owner to s265090;

