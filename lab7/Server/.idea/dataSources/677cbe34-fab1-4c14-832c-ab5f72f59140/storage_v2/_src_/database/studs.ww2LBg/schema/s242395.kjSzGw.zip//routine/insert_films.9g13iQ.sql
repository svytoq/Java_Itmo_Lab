create function insert_films(count integer) returns void
    language plpgsql
as
$$
DECLARE
        film_date timestamp;
BEGIN
        film_date = random_date();
        FOR i in 1 .. count LOOP
                insert into Фильмы(название, дата_начала_съемок, дата_конца_съемок,дата_премьеры,продолжительность,бюджет,возрастной_рейтинг) 
        values(random_string(20),film_date,(film_date + ('12 months')::interval)::timestamp,
                (film_date + ('13 months')::interval)::timestamp,'121','11000','G');
        END LOOP;
END;
$$;

alter function insert_films(integer) owner to s242395;

