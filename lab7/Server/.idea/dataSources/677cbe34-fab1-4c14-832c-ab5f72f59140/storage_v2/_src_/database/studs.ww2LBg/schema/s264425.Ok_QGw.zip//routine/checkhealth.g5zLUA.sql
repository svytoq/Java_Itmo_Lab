create function checkhealth() returns trigger
    language plpgsql
as
$$
DECLARE
    hasDisability int;
BEGIN
    SELECT count("Object_ID") FROM "Baggage" WHERE "Homeless_ID" = NEW.ID AND "Object_ID" = 29 into hasDisability;
    IF hasDisability = 1 AND NEW."Health" > 50 THEN
        NEW."Health" = 50;
    END IF;
    RETURN NEW;
END;
$$;

alter function checkhealth() owner to s264425;

