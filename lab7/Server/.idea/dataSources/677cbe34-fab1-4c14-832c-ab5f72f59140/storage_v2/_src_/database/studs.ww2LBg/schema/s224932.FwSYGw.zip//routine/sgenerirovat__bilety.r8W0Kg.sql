create function сгенерировать_билеты() returns void
    language plpgsql
as
$$
DECLARE
        sess RECORD;
        seat RECORD;
        checker integer;
BEGIN
        checker = 1;
        FOR sess IN (SELECT ид, ид_зала FROM Сеансы) LOOP
                FOR seat IN (SELECT ид FROM Места WHERE Места.ид_зала = sess.ид_зала) LOOP

                        IF (checker > 0) THEN
                        INSERT INTO Билеты (ид_сеанса, ид_места, стоимость, статус)
                        VALUES (sess.ид, seat.ид, random() * 500 + 100, random() * 2);
                                END IF;
                        checker = checker * (-1);
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_билеты() owner to s224932;

