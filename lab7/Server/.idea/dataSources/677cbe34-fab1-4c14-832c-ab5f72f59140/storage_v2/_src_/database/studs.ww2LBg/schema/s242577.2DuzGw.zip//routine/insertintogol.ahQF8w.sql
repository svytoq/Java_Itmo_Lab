create function insertintogol() returns trigger
    language plpgsql
as
$$
DECLARE
IDFIRSTTEAM INT;
IDSECONDTEAM INT;
GOL1 INT;
GOL2 INT;
IGROK INT;
TIMEGOL INT;
  HOUR INT;
  MIN INT;
  SEC INT;

BEGIN
GOL1 = NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ПЕРВОЙ_КОМАНДОЙ;
GOL2 = NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ВТОРОЙ_КОМАНДОЙ;
IDFIRSTTEAM=NEW.ПЕРВАЯ_КОМАНДА;
IDSECONDTEAM=NEW.ВТОРАЯ_КОМАНДА;

WHILE GOL1 > 0 LOOP

  MIN = 0+random()*90;
  TIMEGOL = MIN;

  SELECT ИГРОКИИД INTO IGROK FROM КОМАНДА_ИГРОКИ WHERE КОМАНДАИД=IDFIRSTTEAM AND ГОДИД= NEW.ГОДИД ORDER BY random() LIMIT 1;

  INSERT INTO СПИСОК_ЗАБИТЫХ(МАТЧИИД,ИГРОКИИД,ВРЕМЯ) VALUES(NEW.ИД,IGROK,TIMEGOL);
  GOL1 = GOL1-1;
END LOOP;

WHILE GOL2 > 0 LOOP

  MIN = 0+random()*90;

  TIMEGOL = MIN;

SELECT ИГРОКИИД INTO IGROK FROM КОМАНДА_ИГРОКИ WHERE КОМАНДАИД=IDFIRSTTEAM AND ГОДИД= NEW.ГОДИД ORDER BY random() LIMIT 1;
INSERT INTO СПИСОК_ЗАБИТЫХ(МАТЧИИД,ИГРОКИИД,ВРЕМЯ) VALUES(NEW.ИД,IGROK,TIMEGOL);
GOL2= GOL2-1;
END LOOP ;


  RETURN NEW;
END

$$;

alter function insertintogol() owner to s242577;

