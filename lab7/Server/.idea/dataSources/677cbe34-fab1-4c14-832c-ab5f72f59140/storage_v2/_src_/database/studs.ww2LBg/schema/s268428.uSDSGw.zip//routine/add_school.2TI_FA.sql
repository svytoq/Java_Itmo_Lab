create function add_school(name character, headmaster integer) returns integer
    language plpgsql
as
$$
DECLARE
id INTEGER;
schl INTEGER;
begin
 schl = nextval('school_school_id_seq'); 
 INSERT INTO school VALUES
 (schl, name, headmaster);
 SELECT INTO id role_id FROM witcher where witcher_id = headmaster;
 UPDATE role set school_id = schl WHERE role_id = id;
 
 RETURN schl;
 end
$$;

alter function add_school(char, integer) owner to s268428;

