create function mine_star(mining_army integer, star_to_mine integer) returns text
    language plpgsql
as
$$
declare
    star_object_id int;
  begin
    select object_id into star_object_id from star where id = star_to_mine;
    
    if not found then
      raise exception 'There is no such star';
    end if;
    
    insert into mining (object_id, army_id) values (star_object_id, mining_army);
    
    return 'You`ve mined this star and returned back';
  end;
$$;

alter function mine_star(integer, integer) owner to s264482;

