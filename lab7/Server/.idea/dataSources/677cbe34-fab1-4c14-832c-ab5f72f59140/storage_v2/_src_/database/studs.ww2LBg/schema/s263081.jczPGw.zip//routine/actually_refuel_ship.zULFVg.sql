create function actually_refuel_ship() returns trigger
    language plpgsql
as
$$
DECLARE
  hunter_current_planet int;
  hunter_id int;
  hunter_money_amount bigint;
  planet_space_yard int;
  space_yard_price bigint;
BEGIN
  IF NEW.litres_num <=0 THEN
    RAISE EXCEPTION 'Invalid litres number';
  END IF;
  
  SELECT h.id, h.money_amount, ss.planet_id, p.yard_id
  INTO hunter_id, hunter_money_amount, hunter_current_planet, planet_space_yard
  FROM Space_ship as ss
  INNER JOIN Hunter as h ON (h.ship_id=ss.id)
  INNER JOIN Planet as p ON (ss.planet_id = p.id)
  WHERE ss.id = NEW.ship_id;
  
  IF planet_space_yard != NEW.yard_id THEN
    RAISE EXCEPTION 'Invalid space yard';
  END IF;
  
  SELECT price INTO space_yard_price FROM Space_yard WHERE id = planet_space_yard;
  
  IF hunter_money_amount < (space_yard_price*NEW.litres_num) THEN
    RAISE EXCEPTION 'Not enough money';
  END IF;
  
  UPDATE Space_ship SET fuel = fuel + NEW.litres_num WHERE id = NEW.ship_id;
  UPDATE Hunter SET money_amount = money_amount - (space_yard_price * NEW.litres_num) 
  WHERE id = hunter_id;
  RETURN NEW;
END;
$$;

alter function actually_refuel_ship() owner to s263081;

