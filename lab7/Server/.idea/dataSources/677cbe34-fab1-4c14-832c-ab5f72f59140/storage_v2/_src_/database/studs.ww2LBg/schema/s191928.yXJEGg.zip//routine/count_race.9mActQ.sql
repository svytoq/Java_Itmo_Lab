create function count_race(srace character) returns bigint
    language sql
as
$$
select count(*) from citizens where citizens.race = srace;
$$;

alter function count_race(char) owner to s191928;

