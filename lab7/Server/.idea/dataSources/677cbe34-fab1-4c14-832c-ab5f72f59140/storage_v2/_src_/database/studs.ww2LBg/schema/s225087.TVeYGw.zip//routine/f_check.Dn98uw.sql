create function f_check() returns trigger
    language plpgsql
as
$$
begin
select into new.result case when (select count(p_f_id) from pok_fights where fight_id=new.fight_id and result=true)=1 then false else true end;
return new;
end;
$$;

alter function f_check() owner to s225087;

