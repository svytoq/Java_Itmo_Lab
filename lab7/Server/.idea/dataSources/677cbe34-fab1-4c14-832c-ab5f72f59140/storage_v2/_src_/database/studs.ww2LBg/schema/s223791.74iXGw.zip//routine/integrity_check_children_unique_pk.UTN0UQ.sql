create function integrity_check_children_unique_pk() returns boolean
    language plpgsql
as
$$
DECLARE
                field_name text;
            BEGIN
                INSERT INTO CHILDREN(id, iq, birthday, sex, weight, status) VALUES (1,1,'2014-01-01', true, 25, 'AVAILABLE');
                RETURN FALSE;
            EXCEPTION WHEN unique_violation THEN
                RETURN TRUE;
            END;
$$;

alter function integrity_check_children_unique_pk() owner to s223791;

