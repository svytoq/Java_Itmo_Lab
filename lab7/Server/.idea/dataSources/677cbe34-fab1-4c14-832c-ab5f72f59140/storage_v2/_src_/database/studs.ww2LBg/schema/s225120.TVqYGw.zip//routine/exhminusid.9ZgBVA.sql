create function exhminusid() returns trigger
    language plpgsql
as
$$
begin
	insert into addition values (old.ИД_ВЫСТАВКИ);
	return old;
end;
$$;

alter function exhminusid() owner to s225120;

