create function giveorder(don_id integer, order_id integer) returns boolean
    language plpgsql
as
$$
declare
      current_order "order";
      don_family family;
      soldiers soldier;
      lawyers lawyer;
    begin
      select into current_order * from "order" where order_id=id;
      select into don_family * from family
      where name=(select don.family from don where don_id=id);
      if don_family.budget>=current_order.cost then
        select into soldiers from soldier where family=don_family.name;
        select into lawyers from lawyer where family=don_family.name;
        return true;
      else
        raise exception 'Unable to give an order with id % % %',
          order_id, don_family.budget, current_order.cost
          using hint='The family budget is too low';
      end if;
      return null;
    end;
$$;

alter function giveorder(integer, integer) owner to s265171;

