create function taskcomplete(fighterid integer) returns integer
    language plpgsql
as
$$
declare
TR integer;
CT integer;
begin
SELECT "current_task" INTO CT FROM Fighter WHERE "id" = fighterID;
SELECT "reward" into TR FROM Tasks WHERE "id" = CT;
UPDATE Fighter SET Money = Money + TR, "current_task" = NULL WHERE "id" = fighterID;
UPDATE Tasks SET Reward = CAST((Reward * 0.5) AS INTEGER) WHERE "id" = CT;
return 1;
end;
$$;

alter function taskcomplete(integer) owner to s263884;

