create function shopping_costs(shopping_id integer) returns real
    language plpgsql
as
$$
BEGIN
		RETURN (SELECT sum(товар.количество * товар.стоимость) FROM товар JOIN поход_в_магазин USING (id_списка_покупок) WHERE id_похода_в_магазин = shopping_id);
	END
$$;

alter function shopping_costs(integer) owner to s265099;

