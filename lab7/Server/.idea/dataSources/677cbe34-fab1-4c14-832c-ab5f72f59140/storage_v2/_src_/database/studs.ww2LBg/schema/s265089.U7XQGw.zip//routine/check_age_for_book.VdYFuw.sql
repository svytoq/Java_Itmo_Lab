create function check_age_for_book(b_reader_id integer, b_book_id integer) returns boolean
    language plpgsql
as
$$
declare
        reader_age      int;
        book_department text;
    begin
        select date_part('year', age(birth_date))::int
        into reader_age
        from readers
        where readers.reader_id = b_reader_id;
        select d.name
        into book_department
        from books b
                 natural join departments d
        where b.book_id = b_book_id;
        if reader_age < 18 and book_department <> 'Детский' then
            return false;
        else
            return true;
        end if;
    end
$$;

alter function check_age_for_book(integer, integer) owner to s265089;

