create function add_new_donation(fio text, adress text, phone text, donation integer) returns boolean
    strict
    language plpgsql
as
$$
begin
    insert into "ПОЖЕРТВОВАНИЯ" ("ФИО", "АДРЕС", "ТЕЛЕФОН", "РАЗМЕР_ПОЖЕРТВОВАНИЯ") values (fio,adress,phone,donation);
    return true;
end
$$;

alter function add_new_donation(text, text, text, integer) owner to s265080;

