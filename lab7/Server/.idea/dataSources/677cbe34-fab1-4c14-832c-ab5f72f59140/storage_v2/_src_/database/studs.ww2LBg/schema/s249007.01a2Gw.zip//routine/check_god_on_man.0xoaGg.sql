create function check_god_on_man() returns trigger
    language plpgsql
as
$$
declare man_count_id integer;
begin
  select into man_count_id count(*) from kira where kira.killer_id = new.killer_id;
  if(man_count_id != 0) then
    raise exception 'No one god can be man';
    return null;
  end if;
  return new;
end;
$$;

alter function check_god_on_man() owner to s249007;

