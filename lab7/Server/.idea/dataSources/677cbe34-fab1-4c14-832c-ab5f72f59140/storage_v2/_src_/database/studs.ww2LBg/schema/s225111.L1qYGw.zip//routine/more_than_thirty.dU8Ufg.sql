create function more_than_thirty() returns trigger
    language plpgsql
as
$$
BEGIN
		--проверяем, не превышает ли 30 карт
		IF ((SELECT COUNT(*) FROM DECK_CARD WHERE (DECK_ID = NEW.DECK_ID)) = 30) THEN
			RAISE EXCEPTION 'deck already contains 30 cards';
		END IF;
		--проверяем, не кладут ли третью одинаковую карту
		IF ((SELECT COUNT(*) FROM DECK_CARD WHERE (DECK_ID = NEW.DECK_ID AND CARD_ID = NEW.CARD_ID)) = 2) THEN
			RAISE EXCEPTION 'deck can not contain more than two equal cards';
		END IF;
	END;
$$;

alter function more_than_thirty() owner to s225111;

