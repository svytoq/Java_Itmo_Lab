create function getlevel(integer) returns real
    language plpgsql
as
$$
DECLARE
res real;
BEGIN
select SUM(x)/5 from (select AVG(Оценка_Персонажа) as "x" from К_Участники
inner join К_Сессии on (К_Участники.Сессия_ИД = К_Сессии.Id)
where Персонаж_ИД = $1 group by Партия_ИД) as new_res into res;
if(res is null) then
res:= 0;
end IF;
RETURN (res);
END;
$$;

alter function getlevel(integer) owner to s243870;

