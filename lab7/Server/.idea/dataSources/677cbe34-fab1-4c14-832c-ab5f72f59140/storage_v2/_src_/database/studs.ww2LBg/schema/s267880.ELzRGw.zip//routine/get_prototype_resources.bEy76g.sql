create function get_prototype_resources(product_prototype_id integer) returns SETOF s267880.product_prototype_resource
    language sql
as
$$
select * from product_prototype_resource where product_prototype_id = $1;
$$;

alter function get_prototype_resources(integer) owner to s267880;

