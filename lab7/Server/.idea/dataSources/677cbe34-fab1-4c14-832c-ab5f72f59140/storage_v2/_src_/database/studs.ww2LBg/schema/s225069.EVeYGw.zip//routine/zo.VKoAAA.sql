create function zo() returns trigger
    language plpgsql
as
$$
begin
new.Код_экземпляра=old.Код_экземпляра;
return new;
end;
$$;

alter function zo() owner to s225069;

