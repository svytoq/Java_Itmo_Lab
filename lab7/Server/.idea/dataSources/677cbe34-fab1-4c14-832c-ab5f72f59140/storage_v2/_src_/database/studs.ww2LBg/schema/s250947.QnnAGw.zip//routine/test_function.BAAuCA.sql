create function test_function() returns trigger
    language plpgsql
as
$$
BEGIN
    if(NEW.status = 'ACCEPTED') then
        update spaceships set current_spaceport = NEW.spaceport_id WHERE id = NEW.spaceship_id;
    end if;
END
$$;

alter function test_function() owner to s250947;

