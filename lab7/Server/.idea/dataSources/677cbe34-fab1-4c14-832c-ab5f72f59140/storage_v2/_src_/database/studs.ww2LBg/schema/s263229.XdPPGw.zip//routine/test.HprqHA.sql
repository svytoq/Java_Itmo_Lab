create function test(name character varying)
    returns TABLE(dino_name character varying, dino_height numeric)
    language plpgsql
as
$$
DECLARE param TEXT := 'name'; BEGIN RETURN QUERY EXECUTE FORMAT('SELECT d.NAME, d.HEIGHT FROM dinosaur as d WHERE d.%I LIKE $1', param) USING name; END
$$;

alter function test(varchar) owner to s263229;

