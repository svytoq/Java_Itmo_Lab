create function battle(witchernamein text, monsternamein text) returns text
    language plpgsql
as
$$
DECLARE
    witcherHealth int;
    witcherAttack int;
    witcherAttackTemp int;
    witcherDefence int;
    witcherDefenceTemp int;
    attackType int;
    defenceType int;
    monsterType int;
    monsterHealth int;
    monsterAttack int;
begin
    select health into witcherHealth from witcher where witcher.witchername = witcherNameIn;
    select atack into witcherAttack from witcher join sword s on witcher.swordname = s.swordname where witcher.witchername = witcherNameIn;
    select prot into witcherDefence from witcher join armor a on a.armorname = witcher.armorname where witcher.witchername = witcherNameIn;
    select atack into witcherAttackTemp from witcher join oil o on witcher.oilname = o.oilname where witcher.witchername = witcherNameIn;
    select prot into witcherDefenceTemp from witcher join potion p on witcher.potionname = p.potionname where witcher.witchername = witcherNameIn;
    select typeid into attackType from witcher join oil o on witcher.oilname = o.oilname where witcher.witchername = witcherNameIn;
    select typeid into defenceType from witcher join potion p on witcher.potionname = p.potionname where witcher.witchername = witcherNameIn;
    select health into monsterHealth from monster where monster.monstername = monsterNameIn;
    select atack into monsterAttack from monster where monster.monstername = monsterNameIn;
    select type_id into monsterType from monster where monster.monstername = monsterNameIn;

    if attackType = monsterType then witcherAttack = witcherAttack + witcherAttackTemp; end if;
    if defenceType = monsterType then witcherDefence = witcherDefence + witcherDefenceTemp; end if;


    while (witcherHealth > 0 and monsterHealth > 0) loop
            witcherHealth = witcherHealth - (monsterAttack - witcherDefence);
            monsterHealth = monsterHealth - witcherAttack;
    end loop;

    if witcherHealth > 0 then return 'Победил ведьмак';
    else return 'Ведьмак умер'; end if;

end;
$$;

alter function battle(text, text) owner to s263143;

