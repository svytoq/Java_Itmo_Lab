create function ti() returns trigger
    language plpgsql
as
$$
DECLARE
a time;
k integer;
BEGIN

IF NOT EXISTS(SELECT Группа_ИД FROM Тренировки_групп WHERE Группа_ИД = NEW.Группа_ИД AND Время_проведения = NEW.Время_проведения)THEN
RETURN NEW;
ELSE
RAISE EXCEPTION 'В это время у группы % уже есть занятия',NEW.Группа_ИД;
END IF;

if not exists(select Время_проведения from Тренировки_групп where Группа_ИД=NEW.Группа_ИД and День_недели=NEW.День_недели) then
 RETURN NEW;
ELSE
for a in
select Время_проведения from Тренировки_групп where Группа_ИД=NEW.Группа_ИД and День_недели=NEW.День_недели
LOOP
if(a<NEW.Время_проведения) THEN
if((extract(hour from New.Время_проведения)-extract(hour from a))<1) THEN
raise exception 'Интервал между занятиями слишком мал';
end if;
else
if((extract(hour from a)-extract(hour from New.Время_проведения))<1) THEN
raise exception 'Интервал между занятиями слишком мал';
end if;
end if;
end loop;
end if;
return NEW;
end;
$$;

alter function ti() owner to s242243;

