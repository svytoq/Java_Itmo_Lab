create function "ВСЕ_КНИГИ_АВТОРА"(firstname character varying, secondname character varying)
    returns TABLE("НАЗВАНИЕ" character varying, "СТРАНА" character varying, "ДАТА_ПУБЛИКАЦИИ" date, "ЖАНР" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT КНИГИ.НАЗВАНИЕ,КНИГИ.СТРАНА,КНИГИ.ДАТА_ПУБЛИКАЦИИ,КНИГИ.ЖАНР FROM АВТОРЫ JOIN КНИГИ ON АВТОРЫ.ИД=КНИГИ.АВТОР WHERE ИМЯ = firstname and ФАМИЛИЯ = secondname;
END;
$$;

alter function "ВСЕ_КНИГИ_АВТОРА"(varchar, varchar) owner to s225058;

