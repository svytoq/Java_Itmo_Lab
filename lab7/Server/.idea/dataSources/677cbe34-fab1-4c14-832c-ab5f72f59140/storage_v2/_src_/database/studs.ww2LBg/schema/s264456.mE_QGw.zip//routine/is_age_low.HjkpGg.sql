create function is_age_low() returns trigger
    language plpgsql
as
$$
BEGIN
IF (SELECT max_age  FROM vaccines 
WHERE NOW.vaccine_id = vaccines.vaccine_id) <
(current_timestamp - (SELECT birthday FROM humans
WHERE NOW.INN = humans.INN))
THEN
RAISE EXCEPTION 'The person is too old for the this vaccine.';
END IF;
END;
$$;

alter function is_age_low() owner to s264456;

