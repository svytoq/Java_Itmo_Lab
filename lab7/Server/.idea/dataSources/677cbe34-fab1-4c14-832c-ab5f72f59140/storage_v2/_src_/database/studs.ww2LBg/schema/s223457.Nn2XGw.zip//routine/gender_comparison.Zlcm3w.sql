create function gender_comparison() returns trigger
    language plpgsql
as
$$
begin

  IF (Select ПОЛ from КОНЮШНИ where ИД =new.ИД_КОНЮШНИ) = (Select ПОЛ from ЛОШАДИ where ИД =new.ИД_ЛОШАДИ)
  then
    return NEW;
  else
    RAISE EXCEPTION 'Пол лошади не соответсвует полу конюшни';
  end if;
end;

$$;

alter function gender_comparison() owner to s223457;

