create function payment() returns trigger
    language plpgsql
as
$$
DECLARE
    client_payment   integer;
    price            integer;
    factory          integer;
    provider_payment integer;
BEGIN
    SELECT id_client_payment
    FROM clients_payments
    WHERE (id_client = NEW._from AND id_provider = NEW._to AND dept_date = current_date AND
           paying = FALSE)
    INTO client_payment;
    SELECT sausages.price FROM sausages WHERE (sausages.id_sausage = NEW.id_sausage) INTO price;
    IF (client_payment IS NOT NULL AND client_payment <> 0) THEN
        UPDATE clients_payments
        SET sum = sum + price * NEW.sausages_weight
        WHERE id_client_payment = client_payment;
    ELSE
        INSERT INTO clients_payments(id_client, id_provider, sum, dept_date, paying, payment_date)
        VALUES (NEW._from, NEW._to, price * NEW.sausages_weight, current_date, FALSE, NULL);
    END IF;

    SELECT id_factory FROM providers WHERE providers.id_provider = NEW._to INTO factory;
    SELECT id_provider_payment
    FROM providers_payments
    WHERE (id_provider = NEW._to AND id_factory = factory AND dept_date = current_date AND paying = FALSE)
    INTO provider_payment;
    IF (provider_payment IS NOT NULL AND provider_payment <> 0) THEN
        UPDATE providers_payments
        SET sum = sum + price * NEW.sausages_weight
        WHERE id_provider_payment = provider_payment;
    ELSE
        INSERT INTO providers_payments(id_provider, id_factory, sum, dept_date, paying, payment_date)
        VALUES (NEW._to, factory, price * NEW.sausages_weight, current_date, FALSE, NULL);
    END IF;
    RETURN NEW;
END
$$;

alter function payment() owner to s270235;

