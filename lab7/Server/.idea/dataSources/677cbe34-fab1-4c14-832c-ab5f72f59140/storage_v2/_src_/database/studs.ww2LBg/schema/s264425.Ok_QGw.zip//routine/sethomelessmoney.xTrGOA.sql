create function sethomelessmoney() returns trigger
    language plpgsql
as
$$
DECLARE
    money int;
BEGIN
    SELECT "Start_capital" FROM "Level" WHERE "Name" = NEW."Level_ID" into money;
    NEW."Rubles" = money;
    RETURN NEW;
END;
$$;

alter function sethomelessmoney() owner to s264425;

