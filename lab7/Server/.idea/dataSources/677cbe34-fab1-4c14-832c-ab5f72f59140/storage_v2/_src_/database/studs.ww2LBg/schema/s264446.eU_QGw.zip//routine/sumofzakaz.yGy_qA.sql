create function sumofzakaz(zakaz integer) returns integer
    language plpgsql
as
$$
BEGIN
    return (select sum(price) from tests where order_id=zakaz);
end;
$$;

alter function sumofzakaz(integer) owner to s264446;

