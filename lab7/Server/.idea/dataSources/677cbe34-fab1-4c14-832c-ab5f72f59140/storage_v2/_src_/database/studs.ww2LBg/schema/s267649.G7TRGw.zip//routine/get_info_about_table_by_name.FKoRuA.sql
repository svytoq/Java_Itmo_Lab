create function get_info_about_table_by_name(table_name character varying)
    returns TABLE("№" bigint, "Имя столбца" name, "Аттрибуты" text)
    language plpgsql
as
$$
BEGIN
 return query select row_number() over () as N,
 columns.attname as "Имя столбца",
 concat('Type ',': ',pt.typname, ' ', E'\n', 'Comment ', ': ', pd.description, E'\n', 'Constr ', ': ', (case constraints.consrc when null then 'Empty' else constraints.consrc end), E'\n') as "Аттрибуты"
 FROM pg_attribute columns
 inner join pg_class tables
 ON columns.attrelid = tables.oid
 inner join pg_type pt
 on columns.atttypid = pt.oid
 left join pg_namespace n on n.oid = tables.relnamespace
 left join pg_tablespace t on t.oid = tables.reltablespace
 left join pg_description pd on (pd.objoid = tables.oid and pd.objsubid = columns.attnum)
 LEFT JOIN pg_constraint constraints
 ON constraints.conrelid = columns.attrelid AND columns.attnum = ANY(constraints.conkey)
 where tables.relname = table_name and columns.attnum > 0 and constraints.contype = 'c';
end;
$$;

alter function get_info_about_table_by_name(varchar) owner to s267649;

