create function get_storyboard_process_info(storyboard_process_id integer)
    returns TABLE(process_id integer, frame_number integer, duration integer, deadline_date date, description text, status s263229.process_status, estimation_time interval, start_date date, artifact_id integer, artifact_type s263229.artifact_types, size integer, upload_date timestamp without time zone, main_worker_id integer)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT 
    sp.PROCESS_ID, sp.FRAME_NUMBER, mpa.DURATION, mpa.DEADLINE_DATE, mpa.DESCRIPTION, mpa.STATUS, mpa.ESTIMATION_TIME, 
    mpa.START_DATE, mpa.ARTIFACT_ID, mpa.ARTIFACT_TYPE, mpa.SIZE, mpa.UPLOAD_DATE, mpa.MAIN_WORKER_ID
    FROM storyboard_process AS sp JOIN get_main_process_joined_artifacts_info() AS mpa USING(MAIN_PROCESS_ID) 
    WHERE sp.PROCESS_ID=storyboard_process_id;
END
$$;

alter function get_storyboard_process_info(integer) owner to s263229;

