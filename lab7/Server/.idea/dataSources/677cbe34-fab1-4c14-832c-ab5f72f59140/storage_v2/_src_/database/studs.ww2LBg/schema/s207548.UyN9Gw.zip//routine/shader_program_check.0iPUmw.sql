create function shader_program_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (SELECT COUNT(*) FROM Shader WHERE Shader.ShaderProgramID = NEW.ShaderProgramID AND Shader."type" = NEW."type") != 0 THEN
		RAISE EXCEPTION 'It is illegal to have two equal shader types';
	END IF;

	RETURN NEW;
END;
$$;

alter function shader_program_check() owner to s207548;

