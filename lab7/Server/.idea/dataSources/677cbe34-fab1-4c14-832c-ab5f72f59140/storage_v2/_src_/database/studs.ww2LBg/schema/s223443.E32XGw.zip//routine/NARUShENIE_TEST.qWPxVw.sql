create function "НАРУШЕНИЕ_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "НАРУШЕНИЯ" ("ОПИСАНИЕ", "ОТКАЗ_В_ДОСТУПЕ","ШТРАФ","ВЫПЛАЧЕННАЯ_ЧАСТЬ_ШТРАФА")
VALUES (random_string(random()::integer*10+4),'True',s,w);
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END LOOP;
END;
$$;

alter function "НАРУШЕНИЕ_ТЕСТ"(integer) owner to s223443;

