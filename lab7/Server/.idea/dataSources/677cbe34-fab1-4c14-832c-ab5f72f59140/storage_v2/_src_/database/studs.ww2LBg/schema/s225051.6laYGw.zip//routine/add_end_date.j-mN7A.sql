create function add_end_date() returns trigger
    language plpgsql
as
$$
declare
ed date;
begin
ed=new.start_date;
if((select atmosphere_id from ships where ships.id=new.ship_id)=(select atmosphere_id from details inner join exemplars on details.id=exemplars.detail_id where exemplars.id=new.exemplar_id))
then
if(exists(SELECT * from changes where exemplar_id=new.exemplar_id and end_date is null))
then
return new;
else
RAISE EXCEPTION 'Несовместимость типов детали и корабля!';
return null;
end if;
end if;
end;
$$;

alter function add_end_date() owner to s225051;

