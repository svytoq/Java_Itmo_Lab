create function peoplecheck() returns trigger
    language plpgsql
as
$$
begin
    if NEW.birth_date > current_date then return NULL; end if;

    if NEW.knows = false then
        if NEW.current_dim is not NULL and NEW.birth_dim != NEW.current_dim then
            return NULL;
        end if;
    end if;    

    if NEW.death_date is not NULL then
        if NEW.person_state = 'alive' or NEW.death_date < NEW.birth_date then
            return NULL;
        end if;
    end if;

    return NEW;
end;
$$;

alter function peoplecheck() owner to s265066;

