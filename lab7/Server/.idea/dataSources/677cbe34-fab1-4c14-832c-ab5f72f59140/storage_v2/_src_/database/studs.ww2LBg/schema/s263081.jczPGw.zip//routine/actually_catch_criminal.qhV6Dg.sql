create function actually_catch_criminal() returns trigger
    language plpgsql
as
$$
DECLARE
  hunter_current_planet int;
  criminal_current_planet int;
  criminal_skills_level int;
  criminal_price bigint;
  hunter_best_weapon_level int;
  hunter_skills_level int;
  current_planet_jail_id int;
  hunter_can_pay boolean;
  planet_to_move int;
BEGIN
  SELECT ss.planet_id, h.skills INTO hunter_current_planet, hunter_skills_level 
  FROM Hunter as h
  INNER JOIN Space_ship as ss ON (ss.id = h.ship_id)
  WHERE h.id = NEW.hunter_id;
  
  SELECT c.planet_id, c.skills, c.price 
  INTO criminal_current_planet, criminal_skills_level, criminal_price 
  FROM Criminal as c WHERE c.id = NEW.criminal_id;
  
  IF hunter_current_planet != criminal_current_planet THEN
    RAISE EXCEPTION 'You can`t do it on this planet';
  END IF;
  
  SELECT max(w.level) INTO hunter_best_weapon_level FROM Hunter as h
  INNER JOIN Inventory as i ON (i.id = h.inventory_id)
  INNER JOIN Weapon as w ON (w.inventory_id = i.id)
  WHERE h.id = NEW.hunter_id;
  
  IF NOT FOUND THEN
    hunter_best_weapon_level = 0;
  END IF;
  
  IF (hunter_skills_level + hunter_best_weapon_level) > hunter_skills_level THEN
    NEW.is_success = 't';
    SELECT p.jail_id INTO current_planet_jail_id FROM Planet as p 
    WHERE p.id = criminal_current_planet;
    
    UPDATE Criminal SET jail_id = current_planet_jail_id WHERE id = NEW.criminal_id;
    UPDATE Hunter SET money_amount = money_amount + criminal_price WHERE id = NEW.hunter_id;
  ELSE 
    NEW.is_success = 'f';
    SELECT (h.money_amount >= criminal_price/2) INTO hunter_can_pay 
    FROM Hunter as h WHERE h.id = NEW.hunter_id;
    
    IF hunter_can_pay = 't' THEN
      UPDATE Hunter SET money_amount = money_amount - criminal_price/2 WHERE id = NEW.hunter_id;
    ELSE
      UPDATE Hunter SET money_amount = 0 WHERE id = NEW.hunter_id;
    END IF;
    
    SELECT p.id INTO planet_to_move FROM Planet as p WHERE p.id != criminal_current_planet LIMIT 1;
    
    UPDATE Criminal SET planet_id = planet_to_move WHERE id = NEW.criminal_id;
   
  END IF;
  
  RETURN NEW;
END;
$$;

alter function actually_catch_criminal() owner to s263081;

