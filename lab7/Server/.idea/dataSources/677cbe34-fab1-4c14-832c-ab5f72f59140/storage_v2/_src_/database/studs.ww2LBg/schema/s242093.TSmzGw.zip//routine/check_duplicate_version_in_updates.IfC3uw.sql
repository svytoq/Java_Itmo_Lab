create function check_duplicate_version_in_updates() returns trigger
    language plpgsql
as
$$
DECLARE
updated_mod_version varchar(20);
updated_mod_id int;
current_mod_version varchar(20);
current_mod_id int;
BEGIN
with tmp as (select c_update.id_mod,VERSION from c_update
inner join c_mod 
on c_update.id_mod = c_mod.id
and c_update.new_version = c_mod.version)
select tmp.id_mod into current_mod_id from tmp;

with tmp as (select c_update.id_mod,VERSION from c_update
inner join c_mod 
on c_update.id_mod = c_mod.id
and c_update.new_version = c_mod.version)
select tmp.version into current_mod_version from tmp;

select NEW.ID_MOD into updated_mod_id from c_update;
select NEW.NEW_VERSION into updated_mod_version from c_update;
 IF updated_mod_id = current_mod_id then
IF updated_mod_version = current_mod_version then
 raise exception  'It is the current mod version!';
END IF;
END IF;
return NEW;
END;
$$;

alter function check_duplicate_version_in_updates() owner to s242093;

