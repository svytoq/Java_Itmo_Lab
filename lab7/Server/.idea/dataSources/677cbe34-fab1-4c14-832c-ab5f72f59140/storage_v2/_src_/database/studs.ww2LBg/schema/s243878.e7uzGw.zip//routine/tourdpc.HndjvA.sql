create function tourdpc() returns trigger
    language plpgsql
as
$$
BEGIN
		IF (NEW.prize_pool IS NULL) THEN
			RAISE EXCEPTION 'Define the prize_pool for the tournament';
		END IF;

		IF (NEW.prize_pool >= 1000000) THEN
			NEW.dpc_points = NEW.prize_pool/1000*1.5;
		ELSE
			NEW.dpc_points = NEW.prize_pool/1000;
		END IF;
		RETURN NEW;
	END;
$$;

alter function tourdpc() owner to s243878;

