create function new_purchase(p_employee_id integer, p_supplier text, p_delivery_date date, isbns character[], amounts integer[]) returns boolean
    language plpgsql
as
$$
declare
    employee employees;
    p_id     int;
begin
    if array_length(ISBNs, 1) <> array_length(amounts, 1) then
        RAISE EXCEPTION 'Length of ISBNs (%) <> length of amounts(%)', array_length(ISBNs, 1), array_length(amounts, 1)
            USING HINT = 'Check information';
    end if;
    if p_delivery_date <= current_date then
        RAISE EXCEPTION 'Delivery date is earlier than today'
            USING HINT = 'Check information';
    end if;
    select * into employee from employees e where e.employee_id = p_employee_id;
    if not FOUND then
        RAISE EXCEPTION 'No employee with id = %', p_employee_id
            USING HINT = 'Check information';
    end if;
    insert into purchases (employee_id, supplier, delivery_date)
    VALUES (p_employee_id, p_supplier, p_delivery_date)
    returning purchase_id into p_id;

    for i in 1..array_length(ISBNs, 1)
        loop
            insert into purchases_books (purchase_id, isbn, amount) VALUES (p_id, ISBNs[i], amounts[i]);
        end loop;
    return true;
end
$$;

alter function new_purchase(integer, text, date, character[], integer[]) owner to s265089;

