create function choose_kage_candidates(old_kage integer, war integer) returns SETOF s263909.ninja
    language plpgsql
as
$$
declare
    village_of_kage integer;
begin
    village_of_kage = (select village from ninja where ninja_id = old_kage limit 1);
    return query select ninja.ninja_id, ninja.name, ninja.age, ninja.sex, ninja.village, ninja.clan, ninja.status
                  from heroes
                           join ninja on ninja.ninja_id = heroes.ninja_id
                  where village = village_of_kage;
end;
$$;

alter function choose_kage_candidates(integer, integer) owner to s263909;

