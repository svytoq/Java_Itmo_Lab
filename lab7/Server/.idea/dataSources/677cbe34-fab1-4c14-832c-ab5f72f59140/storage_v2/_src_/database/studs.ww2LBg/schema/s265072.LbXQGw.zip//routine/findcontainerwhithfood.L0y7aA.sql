create function findcontainerwhithfood(shortyid integer) returns integer
    language plpgsql
as
$$
DECLARE 
	scene integer;
	cont integer;
	id integer;
BEGIN 
	select scene_id into scene from Shorty where shorty_id = shortyId;
	IF (scene is NULL) THEN RETURN false; END IF;
	FOR cont IN (SELECT container_id FROM Container WHERE scene_id = scene) LOOP
		IF (SELECT NOT EXISTS(SELECT 1 INTO id FROM Thing WHERE eatable = true AND cont = container_id)) THEN CONTINUE; END IF;
		RETURN cont;
	END LOOP;
	RETURN 0;
END;
$$;

alter function findcontainerwhithfood(integer) owner to s265072;

