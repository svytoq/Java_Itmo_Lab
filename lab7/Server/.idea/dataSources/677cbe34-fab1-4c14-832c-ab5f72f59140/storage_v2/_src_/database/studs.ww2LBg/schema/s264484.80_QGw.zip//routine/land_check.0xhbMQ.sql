create function land_check() returns trigger
    language plpgsql
as
$$
begin
    if (tg_op = 'INSERT') then
        if (new.from_which_land_id = new.reviewed_land_id) then
            raise exception 'Посол оценивает свою же страну, так нельзя!';
        end if;
    end if;
    return new;
end;
$$;

alter function land_check() owner to s264484;

