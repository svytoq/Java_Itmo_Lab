create function season_is_valid() returns trigger
    language plpgsql
as
$$
DECLARE 
    temp varchar(9);
    v1 integer;
    v2 integer;
BEGIN  
    IF new.название IS NULL OR new.начало IS NULL THEN 
        RAISE EXCEPTION 'Введите все обязательные поля! 
        (название, начало)'; 
    END IF;
    IF LENGTH(new.название)<>9 THEN 
        RAISE EXCEPTION 'Название не соответствует формату! 
        (неверная длина)';
    END IF;
    IF SUBSTR(new.название,5,1) NOT LIKE '/' THEN
        RAISE EXCEPTION 'Название не соответствует формату! 
        ("/" не обнаружено)';
    END IF;
    IF SUBSTR(new.название,1,1) LIKE '0' OR SUBSTR(new.название,6,1) LIKE '0' THEN 
        RAISE EXCEPTION 'Название не соответствует формату! 
        (год начинается с "0")';
    END IF;
    temp := new.название;
    FOR i IN 1..9 LOOP
        IF i<>5 AND POSITION(SUBSTR(temp,i,1) in '0123456789')=0 THEN
            RAISE EXCEPTION 'Название не соответствует формату! 
        (в нем содержится еще что-то, кроме косой черты и цифр)';
        END IF;
    END LOOP;
    
    v1 := SUBSTR(temp,1,4)::integer;
    v2 := SUBSTR(temp,6,4)::integer;
    
    IF (v2-v1)<>1 THEN 
        RAISE EXCEPTION 'Название не соответствует формату! 
        (год справа от косой черты должен быть ровно на один год больше года слева)';
    END IF;
    IF EXISTS(SELECT 1 FROM сезоны WHERE date_part('year', начало::timestamp)=date_part('year', new.начало::timestamp)) THEN
        RAISE EXCEPTION 'Сезон с началом в таком году уже существует!';
    END IF;
    
    IF new.конец IS NOT NULL THEN
        IF (v2)<>(DATE_PART('year',new.конец::timestamp))::integer THEN 
            RAISE EXCEPTION 'Название не соответствует формату! 
        (год справа должен быть равен году из даты окончания сезона)';
        END IF;
        IF EXISTS(SELECT 1 FROM сезоны WHERE date_part('year', конец::timestamp)=date_part('year', new.конец::timestamp)) THEN
            RAISE EXCEPTION 'Сезон с окончанием в таком году уже существует!';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function season_is_valid() owner to s242558;

