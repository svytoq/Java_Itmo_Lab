create function get_editor_info(editor_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text, genres character varying[], pos s263229.editor_positions)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT e.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH, e.GENRES, e.POSITION FROM editors AS e 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE e.WORKER_ID = editor_id;
END
$$;

alter function get_editor_info(integer) owner to s263229;

