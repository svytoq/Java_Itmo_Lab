create function "ВСЕ_ПРЕМИИ_АВТОРА"(firstname character varying, secondname character varying)
    returns TABLE("НАЗВАНИЕ" character varying, "ГОД" date, "СТЕПЕНЬ" character varying, "НОМЕНАЦИЯ" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT ПРЕМИИ.НАЗВАНИЕ,ПРЕМИИ.ГОД,ПРЕМИИ.СТЕПЕНЬ,ПРЕМИИ.НОМЕНАЦИЯ FROM АВТОРЫ JOIN ПРЕМИИ ON АВТОРЫ.ИД=ПРЕМИИ.АВТОР WHERE ИМЯ = firstname and ФАМИЛИЯ = secondname;
END;
$$;

alter function "ВСЕ_ПРЕМИИ_АВТОРА"(varchar, varchar) owner to s225058;

