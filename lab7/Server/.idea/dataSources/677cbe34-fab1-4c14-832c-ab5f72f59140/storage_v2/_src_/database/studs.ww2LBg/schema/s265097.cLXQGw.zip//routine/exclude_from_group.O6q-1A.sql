create function exclude_from_group(s_name text) returns integer
    language plpgsql
as
$$
declare 
w_id integer;
is_adm integer;
begin
select "Id" into w_id from "Wizard" where "Name" = s_name;
select count(*) into is_adm from "Group" where "AdminId" = w_id;
update "Wizard" set "GroupId" = null where "Id" = w_id and is_adm = 0;
Select case when (is_adm = 1) then 0 else 1 end as res into is_adm;
return is_adm;
end;
$$;

alter function exclude_from_group(text) owner to s265097;

