create function i_want_die()
    returns TABLE(my_col timestamp without time zone)
    language plpgsql
as
$$
declare
        my_max_time timestamp;
        channel_free timestamp;
        g text;
begin
        select max(taken_to) into channel_free from Channels_queue where Channel_id = 41;
        raise notice  '%', channel_free;
        select max(taken_from) into my_max_time from doors_queue where Door_id = 6;
        if channel_free < current_timestamp + interval '30 min'
        then channel_free = current_timestamp + interval '30 min';
        end if;

        if my_max_time < channel_free
        then my_max_time := channel_free;
        end if;
        return query
            SELECT date_trunc('min', x)
            FROM generate_series( (channel_free)::timestamp,  (my_max_time + interval '1 min')::timestamp, interval  '1 min') t(x)
            WHERE date_trunc('min', x) not in (select taken_from from Doors_queue where door_id = 6);


end
$$;

alter function i_want_die() owner to s265103;

