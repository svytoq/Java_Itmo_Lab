create function change_pass() returns trigger
    language plpgsql
as
$$
begin
    NEW.pass := 'XXXXXXXXX';
    return NEW;
 end
$$;

alter function change_pass() owner to s247411;

