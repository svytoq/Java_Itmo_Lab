create function create_skybodies(count integer) returns boolean
    language plpgsql
as
$$
DECLARE
	obj_id integer;
	cnt integer;
	new_name varchar(255);
BEGIN
	IF (count < 0) THEN RETURN false; end if;
	WHILE (count > 0) LOOP
	INSERT INTO Object (type) VALUES ('двигаемый') RETURNING object_id INTO obj_id;
	SELECT count(*) INTO cnt from SkyBody;
	new_name := concat('планета_', cnt + 1);
	INSERT INTO SkyBody (name, x, y, z) VALUES (new_name, random() * 1000 + 239, random() * 1000 + 239, random() * 1000 + 239);
	count := count - 1;
	END LOOP;
	RETURN true;
END;
$$;

alter function create_skybodies(integer) owner to s265072;

