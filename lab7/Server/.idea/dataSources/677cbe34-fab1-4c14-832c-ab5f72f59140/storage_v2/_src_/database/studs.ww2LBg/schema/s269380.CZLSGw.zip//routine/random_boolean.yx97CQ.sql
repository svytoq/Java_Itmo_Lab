create function random_boolean() returns integer
    language sql
as
$$
select round(random())::int
$$;

alter function random_boolean() owner to s269380;

