create function sell_of_item() returns trigger
    language plpgsql
as
$$
declare
price real;
BEGIN
Select Цена into price from К_Предметы where ИД = OLD.Предмет_ИД;
UPDATE "К_Персонажи" SET "Деньги" = "К_Персонажи".Деньги + price WHERE "К_Персонажи".ИД = OLD.Персонаж_ИД;
RETURN OLD;
END;
$$;

alter function sell_of_item() owner to s243870;

