create view hz("Название_машины") as
SELECT "Гонщик"."Название_машины"
FROM s265059."Заезд",
     s265059."Гонщик"
WHERE "Гонщик".id = "Заезд"."ID_гонщика";

alter table hz
    owner to s265059;

