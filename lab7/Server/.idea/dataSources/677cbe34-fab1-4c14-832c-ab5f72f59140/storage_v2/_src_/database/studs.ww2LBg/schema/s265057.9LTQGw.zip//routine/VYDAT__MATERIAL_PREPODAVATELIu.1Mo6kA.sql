create function "ВЫДАТЬ_МАТЕРИАЛ_ПРЕПОДАВАТЕЛЮ"(name character varying, level_book smallint, OUT resultat text) returns text
    language plpgsql
as
$$
DECLARE
	teacher_id RECORD;
	mid_result text;
BEGIN
	FOR teacher_id in SELECT ПРЕП_ИД FROM ПРЕПОДАВАТЕЛЬ LOOP
		mid_result:=(SELECT ВЫДАТЬ_МАТЕРИАЛ_ПРЕПОДАВАТЕЛЮ(teacher_id.ПРЕП_ИД,name,level_book));
	END LOOP;
	resultat:='Материалы преподавателям успешно выданы';
END;
$$;

alter function "ВЫДАТЬ_МАТЕРИАЛ_ПРЕПОДАВАТЕЛЮ"(varchar, smallint, out text) owner to s265057;

