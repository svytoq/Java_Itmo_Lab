create function never_delete() returns trigger
    language plpgsql
as
$$
begin
    RAISE EXCEPTION 'Removing passengers is not allowed';
    return NULL;
end;
$$;

alter function never_delete() owner to s265103;

