create function process_state() returns trigger
    language plpgsql
as
$$
BEGIN
    if ((SELECT next_id FROM next WHERE process_id=NEW.process_id)<NEW.process_id)
        then
            RAISE NOTICE 'The current process has failed.';
    else
        RAISE NOTICE 'The current process is successful!';
    end if;
    RETURN NEW;
end;
$$;

alter function process_state() owner to s249413;

