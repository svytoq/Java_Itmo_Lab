create function kill(integer) returns void
    language plpgsql
as
$$
BEGIN
DELETE FROM Peasant WHERE ID= $1;
END
$$;

alter function kill(integer) owner to s265104;

