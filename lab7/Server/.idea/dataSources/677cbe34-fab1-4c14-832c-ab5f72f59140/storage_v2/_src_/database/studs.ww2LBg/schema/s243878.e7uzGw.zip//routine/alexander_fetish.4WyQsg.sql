create function alexander_fetish()
    returns TABLE(league_name text, prize_pool integer, team text, player_nickname text, player_top_kda numeric, max_kills integer, most_val_item text, least_val_item text, most_dmg_hero text, most_ka_hero text)
    language plpgsql
as
$$
BEGIN 
RETURN query 
  SELECT
    league,
    prize,
    team_name,
    player_name,
    round(player_kda, 2), 
    stats.kills,
    CASE
    WHEN greatest(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item1.cost
      THEN item1.name
    WHEN greatest(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item2.cost
      THEN item2.name
    WHEN greatest(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item3.cost
      THEN item3.name
    WHEN greatest(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item4.cost
      THEN item4.name
    WHEN greatest(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item5.cost
      THEN item5.name
    WHEN greatest(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item6.cost
      THEN item6.name
    END
      AS most_val_item,

    CASE
    WHEN least(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item1.cost
      THEN item1.name
    WHEN least(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item2.cost
      THEN item2.name
    WHEN least(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item3.cost
      THEN item3.name
    WHEN least(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item4.cost
      THEN item4.name
    WHEN least(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item5.cost
      THEN item5.name
    WHEN least(item1.cost, item2.cost, item3.cost, item4.cost, item5.cost, item6.cost) = item6.cost
      THEN item6.name
    END
      AS least_val_item,
    most_dmg,
    most_ka

  FROM (SELECT *
        FROM func()) AS main_table
    JOIN stats ON main_table.playerid = stats.player_id
    JOIN match ON stats.match_id = match.id
    JOIN item AS item1 ON stats.item_1 = item1.id
    JOIN item AS item2 ON stats.item_2 = item2.id
    JOIN item AS item3 ON stats.item_3 = item3.id
    JOIN item AS item4 ON stats.item_4 = item4.id
    JOIN item AS item5 ON stats.item_5 = item5.id
    JOIN item AS item6 ON stats.item_6 = item6.id
    JOIN tournament ON match.tournament_id = tournament.id

    LEFT JOIN ((
                SELECT
                  tourid,
                  plid,
                  name AS most_dmg
                FROM (SELECT
                        player.id                                    AS plid,
                        tournament.id                                AS tourid,
                        max(stats.damage + 1.5 * stats.tower_damage) AS dmg
                      FROM tournament
                        JOIN match ON match.tournament_id = tournament.id
                        JOIN team ON team.id = team_1 OR team.id = team_2
                        JOIN player ON player.team_id = team.id
                        JOIN stats ON stats.match_id = match.id
                                      AND stats.player_id = player.id
                        JOIN (
                                SELECT
                                  tournament.id,
                                  avg(stats.damage + 1.5 * stats.tower_damage) AS avgdmg
                                FROM
                                  tournament
                                  JOIN match ON match.tournament_id = tournament.id
                                  JOIN team ON team.id = team_1 OR team.id = team_2
                                  JOIN player ON player.team_id = team.id
                                  JOIN stats ON stats.match_id = match.id
                                                AND stats.player_id = player.id
                                GROUP BY tournament.id) AS subqq ON (subqq.id = tournament.id)
                      WHERE stats.damage + 1.5 * stats.tower_damage > avgdmg
                      GROUP BY player.id, tournament.id) AS subq1
                  JOIN (
                          SELECT
                            player.id                                    AS plid,
                            tournament.id                                AS tourid,
                            hero.name,
                            max(stats.damage + 1.5 * stats.tower_damage) AS dmg
                          FROM
                            tournament
                            JOIN match ON match.tournament_id = tournament.id
                            JOIN team ON team.id = team_1 OR team.id = team_2
                            JOIN player ON player.team_id = team.id
                            JOIN stats ON stats.match_id = match.id
                                          AND stats.player_id = player.id
                            JOIN hero ON stats.hero_id = hero.id
                          GROUP BY player.id, tournament.id, hero.name) AS subq2
                  USING (dmg, tourid, plid)
              ) AS dmgsubq

      FULL OUTER JOIN (
                        SELECT
                          tourid,
                          plid,
                          name AS most_ka
                        FROM (SELECT
                                player.id                        AS plid,
                                tournament.id                    AS tourid,
                                max(stats.kills + stats.assists) AS ka
                              FROM tournament
                                JOIN match ON match.tournament_id = tournament.id
                                JOIN team ON team.id = team_1 OR team.id = team_2
                                JOIN player ON player.team_id = team.id
                                JOIN stats ON stats.match_id = match.id
                                              AND stats.player_id = player.id
                                JOIN (
                                      SELECT
                                        tournament.id,
                                        avg(stats.kills + stats.assists) AS avgKA
                                      FROM tournament
                                        JOIN match ON match.tournament_id = tournament.id
                                        JOIN team ON team.id = team_1 OR team.id = team_2
                                        JOIN player ON player.team_id = team.id
                                        JOIN stats ON stats.match_id = match.id
                                                      AND stats.player_id = player.id
                                      GROUP BY tournament.id
                                    ) AS subqq ON (subqq.id = tournament.id)
                              WHERE stats.kills + stats.assists > avgKA
                              GROUP BY player.id, tournament.id
                            ) AS subq1

                          JOIN (
                                SELECT
                                  player.id                        AS plid,
                                  tournament.id                    AS tourid,
                                  hero.name,
                                  max(stats.kills + stats.assists) AS ka
                                FROM tournament
                                  JOIN match ON match.tournament_id = tournament.id
                                  JOIN team ON team.id = team_1 OR team.id = team_2
                                  JOIN player ON player.team_id = team.id
                                  JOIN stats ON stats.match_id = match.id
                                                AND stats.player_id = player.id
                                  JOIN hero ON stats.hero_id = hero.id
                                GROUP BY player.id, tournament.id, hero.name
                              ) AS subq2 USING (ka, tourid, plid)
                      ) AS kasubq USING (tourid, plid)) ON (tourid = tournament.id AND plid = main_table.playerid)

  WHERE tournament.name = league 
        AND stats.kills = (SELECT kills
                          FROM max_kills()
                          WHERE nazv = league AND playerid = player_id);
END;
$$;

alter function alexander_fetish() owner to s243878;

