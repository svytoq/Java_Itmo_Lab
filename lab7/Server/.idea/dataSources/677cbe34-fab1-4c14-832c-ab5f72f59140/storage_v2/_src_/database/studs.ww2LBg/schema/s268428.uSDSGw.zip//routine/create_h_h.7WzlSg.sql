create function create_h_h(beginning date, stream integer) returns integer
    language plpgsql
as
$$
DECLARE
id INTEGER;
begin
 
 id = nextval('h_h_h_h_id_seq'); 
 
 INSERT INTO h_h VALUES
 (id, beginning, NULL);

UPDATE stream set h_h_id = id WHERE stream_id = stream;
 
 RETURN id;
 end
$$;

alter function create_h_h(date, integer) owner to s268428;

