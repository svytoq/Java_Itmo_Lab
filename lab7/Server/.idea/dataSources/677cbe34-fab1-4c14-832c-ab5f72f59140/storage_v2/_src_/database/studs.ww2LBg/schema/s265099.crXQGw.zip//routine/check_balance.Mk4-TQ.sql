create function check_balance(user_id integer) returns real
    language plpgsql
as
$$
DECLARE income REAL;
DECLARE expenses REAL;
	BEGIN
		income = (SELECT calc_financial(user_id, 'доход'));
		expenses = (SELECT calc_financial(user_id, 'расход'));
		RETURN (income - expenses);
	END
$$;

alter function check_balance(integer) owner to s265099;

