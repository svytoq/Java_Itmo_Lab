create function do_the_log() returns trigger
    language plpgsql
as
$$
BEGIN
		INSERT INTO ACTION_LOG(USER_ID, TIME_OF_ACTION, TABLE_NAME, TYPE_OF_ACTION)
			VALUES (current_user, current_timestamp, TG_TABLE_NAME, TG_OP);
		RETURN NEW;
	END;
$$;

alter function do_the_log() owner to s243848;

