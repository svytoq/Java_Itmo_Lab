create function insert_person(first_name text, last_name text, birth_date date, phone_number text, email_address text, role text DEFAULT NULL::text) returns integer
    language plpgsql
as
$$
DECLARE
    person integer;

BEGIN
    SELECT NEXTVAL('people_person_id_seq') INTO person;

    INSERT INTO people (person_id, first_name, last_name, birth_date, role)
    VALUES (person, insert_person.first_name, insert_person.last_name, insert_person.birth_date, insert_person.role);

    INSERT INTO email (email, person_id) VALUES (insert_person.email_address, person);
    INSERT INTO phone (phone_number, person_id) VALUES (insert_person.phone_number, person);


    RETURN person;
END;
$$;

alter function insert_person(text, text, date, text, text, text) owner to s267649;

