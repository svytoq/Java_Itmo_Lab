create function playeravgstat(playerid integer)
    returns TABLE(avgk numeric, avgd numeric, avga numeric)
    language plpgsql
as
$$
BEGIN 
RETURN query 
SELECT avg(kills) as avgk, avg(deaths) as avgd, avg(assists) as avga 
FROM stats
where player_id = playerid 
group by player_id; 
END;
$$;

alter function playeravgstat(integer) owner to s243878;

