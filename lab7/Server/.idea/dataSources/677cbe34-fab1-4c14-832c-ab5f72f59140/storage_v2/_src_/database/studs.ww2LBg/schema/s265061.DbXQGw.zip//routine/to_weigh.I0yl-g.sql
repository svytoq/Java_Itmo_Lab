create function to_weigh(bag_id integer, tot_weight real) returns void
    language plpgsql
as
$$
declare max_weight real=(select max_weight from baggage where id=bag_id);
begin
update baggage set total_weight=tot_weight, status='accept' where id=bag_id;
if (max_weight<tot_weight ) then update ticket set amount=amount+100*(tot_weight-max_weight) where id=(select ticket_id from baggage where id=bag_id);
end if;
end;
$$;

alter function to_weigh(integer, real) owner to s265061;

