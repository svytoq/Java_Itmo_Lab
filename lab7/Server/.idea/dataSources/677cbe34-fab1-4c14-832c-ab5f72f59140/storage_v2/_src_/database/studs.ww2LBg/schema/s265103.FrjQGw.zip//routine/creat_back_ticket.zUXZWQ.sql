create function creat_back_ticket() returns trigger
    language plpgsql
as
$$
begin
    INSERT INTO Tickets (Passenger_id,Departure_station,Arrival_station,Purchase_datetime,Arrival_year,Ticket_is_in_queue)
    VALUES (NEW.Passenger_id,NEW.Arrival_station,NEW.Departure_station,CURRENT_TIMESTAMP,DATE_PART('year', CURRENT_TIMESTAMP),false);
    return NULL;
end;
$$;

alter function creat_back_ticket() owner to s265103;

