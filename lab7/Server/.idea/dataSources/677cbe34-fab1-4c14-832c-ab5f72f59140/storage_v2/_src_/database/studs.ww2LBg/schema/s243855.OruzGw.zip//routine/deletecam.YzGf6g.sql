create function deletecam() returns trigger
    language plpgsql
as
$$
begin
 delete from УСТРОЙСТВА where  УСТРОЙСТВА.ИД_ФРОНТАЛЬНОЙ_КАМЕРЫ = КАМЕРА.ИД or УСТРОЙСТВА.ИД_ТЫЛОВОЙ_КАМЕРЫ = КАМЕРА.ИД ;
 end;
$$;

alter function deletecam() owner to s243855;

