create function "ОПЛАТА_ТРУДА_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW."ИД_ОПЛАТЫ_ТРУДА" IS NULL THEN
   NEW."ИД_ОПЛАТЫ_ТРУДА" = generate_UUID();
END IF;
IF (exists(SELECT FROM "ОПЛАТА_ТРУДА" WHERE "ОПЛАТА_ТРУДА"."ИД_ОПЛАТЫ_ТРУДА" = NEW."ИД_ОПЛАТЫ_ТРУДА")) THEN
RAISE 'Оплата труда указанным ид уже существует';
END IF;
IF NOT (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."ИД_ПЕРСОНАЛА" = NEW."ИД_ПЕРСОНАЛА")) THEN
RAISE 'ПЕРСОНАЛА с указаным ИД нет в базе.';
END IF;
IF NOT (exists(SELECT FROM "РАСХОДЫ" WHERE "РАСХОДЫ"."ИД_РАСХОДОВ" = NEW."ИД_РАСХОДОВ")) THEN
RAISE 'Расходов с указаным ИД нет в базе.';
END IF;
IF NEW."ДАТА" IS NULL THEN
RAISE 'Графа "ДАТА" не может быть пустой.';
END IF;
return NEW;
END;
$$;

alter function "ОПЛАТА_ТРУДА_ТФ"() owner to s223443;

