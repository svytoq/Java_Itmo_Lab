create function sell_weapon(hunter integer, weapon integer) returns text
    language plpgsql
as
$$
DECLARE
    current_planet_store_id int;
  BEGIN
    SELECT s.id INTO current_planet_store_id FROM Store as s
    INNER JOIN Planet as p ON (p.store_id = s.id)
    INNER JOIN Space_ship as ss ON (ss.planet_id = p.id)
    INNER JOIN Hunter as h ON (h.ship_id = ss.id)
    WHERE h.id = hunter;
    
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Check your input';
    END IF;
    
    INSERT INTO Deal (hunter_id, store_id, weapon_id, is_buying) VALUES
    (hunter, current_planet_store_id, weapon, 'f');
    RETURN 'You`ve sold a weapon. Check your bank account!!!';
  END;
$$;

alter function sell_weapon(integer, integer) owner to s263081;

