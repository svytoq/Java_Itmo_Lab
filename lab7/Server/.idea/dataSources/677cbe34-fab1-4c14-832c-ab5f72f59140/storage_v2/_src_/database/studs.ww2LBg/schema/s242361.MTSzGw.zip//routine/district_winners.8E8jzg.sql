create function district_winners(district integer, OUT "ИД_ПОЛЬЗОВАТЕЛЯ" integer, OUT "ФАМИЛИЯ" character varying, OUT "ИМЯ" character varying, OUT "ИД_ИГРЫ" integer) returns SETOF record
    language sql
as
$$
select ПОЛЬЗОВАТЕЛИ.ИД_ПОЛЬЗОВАТЕЛЯ, ПОЛЬЗОВАТЕЛИ.ФАМИЛИЯ, ПОЛЬЗОВАТЕЛИ.ИМЯ, ТРИБУТЫ.ИД_ИГРЫ FROM ПОЛЬЗОВАТЕЛИ
JOIN ТРИБУТЫ USING(ИД_ПОЛЬЗОВАТЕЛЯ)
WHERE ДИСТРИКТ=district and ТРИБУТЫ.СТАТУС='Победитель'
$$;

alter function district_winners(integer, out integer, out varchar, out varchar, out integer) owner to s242361;

