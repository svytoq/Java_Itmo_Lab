create function get_info_about_table_by_name(table_name character varying) returns void
    language plpgsql
as
$$
declare
    -- tables int;
    -- columns int;
    -- indexes int;
    i record;
    k record;
    constr_printed boolean;
begin

    -- if not exists(select 1 from pg_class where relnamespace::regnamespace::text=schema_name limit 1)
    -- then
    --     raise notice 'Cхемы % не существует.', schema_name;
    --     return;
    -- end if;

    create temp table temp_table on commit drop as 
    select 
    row_number() over () as row_num, 
    attname, 
    typname,
    attrelid,
    attnum
    FROM pg_attribute columns
    inner join pg_class tables
    ON columns.attrelid = tables.oid
    inner join pg_type pt
    on columns.atttypid = pt.oid
    left join pg_namespace n on n.oid = tables.relnamespace
    left join pg_tablespace t on t.oid = tables.reltablespace
    left join pg_description pd on (pd.objoid = tables.oid and pd.objsubid = columns.attnum)
    where tables.relname = table_name
    and columns.attnum > 0;
    -- end;
    -- tables = (select count(*) from temp_table where relkind='r');
    -- columns = (select sum(relnatts) from (select relnatts from temp_table) as a);
    -- indexes = (select count(*) from temp_table where relkind='i');

    raise notice 'Таблица: %', table_name;
    raise notice ' ';
    -- raise notice 'Количество столбцов в схеме % - %', schema_name, columns;
    -- raise notice 'Количество индексов в схеме % - %', schema_name, indexes;

    -- raise notice ' ';
    -- raise notice '   Таблицы схемы %',  schema_name;
    -- raise notice ' ';

    raise notice '%', ' No. Имя столбца   Атрибуты';
    raise notice '%', ' --- -----------   ------------------------------------------------------';     

    for i in select * from (select * from temp_table) t
    loop
        raise notice '%', format('%-4s %-11s Type   : %-45s', i.row_num, i.attname, i.typname);
        constr_printed = false;
        for k in select * from (select * from pg_constraint constraints
                                WHERE constraints.conrelid = i.attrelid
                                -- AND i.attnum = ANY (constraints.conkey)
                                ) t
        loop
            if k.consrc is not NULL 
            then
                raise notice '%', format('                 Constr : %s', k.consrc);
                constr_printed = true;
            end if;
        end loop;
        if constr_printed then 
                raise notice ' ';
        end if;
    end loop;
end;
$$;

alter function get_info_about_table_by_name(varchar) owner to s265066;

