create function piloting_control() returns trigger
    language plpgsql
as
$$
DECLARE
  person_id INT;
  carr_id INT;
  t_p INT;
  t_c INT;
  us_spec user_spec;
  BEGIN
   person_id:=(SELECT racer_id FROM piloting WHERE (piloting.id = NEW.id));
   carr_id:=(SELECT car_id FROM piloting WHERE (piloting.id = NEW.id));
   t_p:=(SELECT team_id FROM team_members WHERE (team_members.user_id = person_id));
   t_c:=(SELECT team_id FROM cars WHERE (cars.id = carr_id));
   us_spec:=(SELECT spec FROM users WHERE (users.id = person_id));
   IF (NOT(us_spec = 'RACER'))
     THEN RAISE EXCEPTION 'Only racers can drive cars';
     RETURN NULL;
  END IF;
  IF (NOT(t_p = t_c))
    THEN RAISE EXCEPTION 'car and racer must be in one team';
      RETURN NULL;
      END IF;
  RETURN NEW;
END;
$$;

alter function piloting_control() owner to s244077;

