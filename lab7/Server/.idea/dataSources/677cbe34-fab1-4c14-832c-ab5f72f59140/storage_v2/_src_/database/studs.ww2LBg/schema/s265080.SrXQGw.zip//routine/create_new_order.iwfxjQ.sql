create function create_new_order() returns trigger
    language plpgsql
as
$$
BEGIN
        -- Проверить, что указаны имя сотрудника и зарплата;

        IF (SELECT sum("КОЛИЧЕСТВО") from "ПОСТУПЛЕНИЯ_РАСХОДЫ" where "ИД" = new."ИД" group by "ИД" ) < (select "НЕОБХОДИМОЕ_КОЛ-ВО" from "СКЛАД" where "СКЛАД"."ИД" = new."ИД") THEN
            INSERT into "СИСТЕМА_АВТОМАТИЧЕСКИХ_ЗАКУПОК" ("ИД_ОБЪЕКТА", "ИД_ПОСТАВЩИКА", "РАЗМЕР_ЗАКАЗА")
            values (new."ИД",(select "ТОВАРЫ_ПОСТАВЩИКИ"."ИД_ПОСТАВЩИКА" from "ТОВАРЫ_ПОСТАВЩИКИ" where "ИД_ТОВАРА" = new."ИД_ОБЪЕКТА"),((SELECT sum("КОЛИЧЕСТВО") from "ПОСТУПЛЕНИЯ_РАСХОДЫ" where "ИД" = new."ИД" group by "ИД" ) - (select "НЕОБХОДИМОЕ_КОЛ-ВО" from "СКЛАД" where "СКЛАД"."ИД" = new."ИД")));
        END IF;
    RETURN NEW;
    END;
$$;

alter function create_new_order() owner to s265080;

