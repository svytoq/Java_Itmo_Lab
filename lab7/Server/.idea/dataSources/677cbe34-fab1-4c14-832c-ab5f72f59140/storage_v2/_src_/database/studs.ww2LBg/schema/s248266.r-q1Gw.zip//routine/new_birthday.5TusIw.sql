create function new_birthday(userid integer, bornuserid integer, startdate date) returns void
    language plpgsql
as
$$
DECLARE
userName text;
eventId int;
BEGIN
    userName := (SELECT Имя FROM К_Пользователь WHERE ИД = bornUserId);
    INSERT INTO К_Событие (ИД_Пользователя, Название, Описание, Тип,
      Время_начала, Время_окончания) VALUES (userId, 'День рождения ' || userName,
      'У ' || userName || ' день рождения.', 'День рождения', startDate::timestamp,
      NULL) RETURNING ИД INTO eventId;
    INSERT INTO К_День_рождения (ИД_События, ИД_Именинника) VALUES (eventId,
      bornUserId);
END;
$$;

alter function new_birthday(integer, integer, date) owner to s248266;

