create function disband_team(team_id integer) returns void
    language plpgsql
as
$$
BEGIN

  DELETE FROM team WHERE id = disband_team.team_id;

  RAISE NOTICE 'Команда расформирована';

END;

$$;

alter function disband_team(integer) owner to s264458;

