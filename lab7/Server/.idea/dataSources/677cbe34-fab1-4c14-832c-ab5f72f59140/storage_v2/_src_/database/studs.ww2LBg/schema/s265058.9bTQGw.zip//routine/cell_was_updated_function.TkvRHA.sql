create function cell_was_updated_function() returns trigger
    language plpgsql
as
$$
BEGIN
        UPDATE pick_up_point
            SET number_of_free_cells = number_of_free_cells - 1
            WHERE pick_up_point_id = NEW.pick_up_point_id
                AND OLD.status = 'available'
                AND NEW.status != 'available';
        UPDATE pick_up_point
            SET number_of_free_cells = number_of_free_cells + 1
            WHERE pick_up_point_id = NEW.pick_up_point_id
                AND OLD.status != 'available'
                AND NEW.status = 'available';
        RETURN new;
    END;
$$;

alter function cell_was_updated_function() owner to s265058;

