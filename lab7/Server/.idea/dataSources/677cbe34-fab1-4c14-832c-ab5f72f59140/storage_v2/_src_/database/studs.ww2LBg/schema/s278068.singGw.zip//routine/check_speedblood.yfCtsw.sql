create function check_speedblood() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.speed >= 80
    THEN
        UPDATE human_blood_flow_organismstatus as status
        SET shortname='U will die',
            description = 'please dont drink and use'
        WHERE status.id = (
            SELECT status_id
            FROM human_blood_flow_organism AS org
            WHERE org.id = new.organism_id
        );
    END IF;
    IF NEW.speed < 80
    THEN
        UPDATE human_blood_flow_organismstatus as status
        SET shortname='Alright',
            description = 'person is alive'
        WHERE status.id = (
            SELECT status_id
            FROM human_blood_flow_organism AS org
            WHERE org.id = new.organism_id
        );
    END IF;
    RETURN NEW;
END;
$$;

alter function check_speedblood() owner to s278068;

