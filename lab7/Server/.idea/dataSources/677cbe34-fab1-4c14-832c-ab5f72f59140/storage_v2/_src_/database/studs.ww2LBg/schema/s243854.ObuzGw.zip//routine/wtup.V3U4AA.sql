create function wtup() returns trigger
    language plpgsql
as
$$
BEGIN
NEW.ТИП_МИРА := upper(NEW.ТИП_МИРА);
RETURN NEW;
END
$$;

alter function wtup() owner to s243854;

