create function foi() returns trigger
    language plpgsql
as
$$
BEGIN
NEW.ФАМИЛИЯ := fio(NEW.ФАМИЛИЯ);
NEW.ИМЯ := fio(NEW.ИМЯ);
IF NEW.ФАМИЛИЯ = '0' THEN RAISE EXCEPTION 'Неверно введенная фамилия';
END IF;
IF NEW.ИМЯ = '0' THEN RAISE EXCEPTION 'Неверно введенное имя';
END IF;
RETURN NEW;
END
$$;

alter function foi() owner to s243854;

