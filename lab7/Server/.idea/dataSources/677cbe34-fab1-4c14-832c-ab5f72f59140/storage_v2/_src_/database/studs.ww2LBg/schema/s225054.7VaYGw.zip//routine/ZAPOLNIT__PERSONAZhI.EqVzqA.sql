create function "ЗАПОЛНИТЬ_ПЕРСОНАЖИ"(count integer) returns void
    language plpgsql
as
$$
BEGIN
FOR i IN 1..count LOOP
INSERT INTO ПЕРСОНАЖИ VALUES(DEFAULT, 'Гарри' || i, 'Поттер', NULL, NULL, 'Карий', 'Черный', NULL, NULL, NULL, NULL);
END LOOP;
RETURN;
END;
$$;

alter function "ЗАПОЛНИТЬ_ПЕРСОНАЖИ"(integer) owner to s225054;

