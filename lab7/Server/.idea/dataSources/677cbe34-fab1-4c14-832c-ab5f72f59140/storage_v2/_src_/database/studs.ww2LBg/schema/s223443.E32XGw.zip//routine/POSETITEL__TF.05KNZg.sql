create function "ПОСЕТИТЕЛЬ_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
 IF NEW."ИД_ПОСЕТИТЕЛЬ" IS NULL THEN
 NEW."ИД_ПОСЕТИТЕЛЬ" = generate_UUID();
 END IF;
 IF NOT (exists(SELECT FROM "ЧЕЛОВЕК" WHERE "ЧЕЛОВЕК"."ИД_ЧЕЛОВЕКА" = NEW."ИД_ЧЕЛОВЕКА")) THEN
 RAISE 'Человека с указаным ИД нет в базе.';
 END IF;
IF (exists(SELECT FROM "ПОСЕТИТЕЛЬ" WHERE "ПОСЕТИТЕЛЬ"."ИД_ЧЕЛОВЕКА" = NEW."ИД_ЧЕЛОВЕКА")) THEN
RAISE 'Человек с данным ИД уже записан как посетитель.';
END IF;
 IF (exists(SELECT FROM "ПОСЕТИТЕЛЬ" WHERE "ПОСЕТИТЕЛЬ"."ТЕЛЕФОН" = NEW."ТЕЛЕФОН")) THEN
 RAISE 'Данный номер уже есть в базе. Один номер не может принадлежать нескольким клиентам.';
 END IF;
 IF (exists(SELECT FROM "ПОСЕТИТЕЛЬ" WHERE "ПОСЕТИТЕЛЬ"."ПОЧТА" = NEW."ПОЧТА")) THEN
 RAISE 'Данная почта уже есть в базе. Одна почта не может принадлежать нескольким клиентам.';
 END IF;
 return NEW;
 END;
$$;

alter function "ПОСЕТИТЕЛЬ_ТФ"() owner to s223443;

