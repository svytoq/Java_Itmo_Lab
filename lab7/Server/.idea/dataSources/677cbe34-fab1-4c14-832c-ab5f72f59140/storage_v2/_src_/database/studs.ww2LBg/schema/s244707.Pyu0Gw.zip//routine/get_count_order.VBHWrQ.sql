create function get_count_order(id_st integer, d integer) returns integer
    language plpgsql
as
$$
declare
	result integer;
begin
select count(id) from orders
where orders.id_store = id_st and extract(dow from date) = d into result;
	return result;
end;
$$;

alter function get_count_order(integer, integer) owner to s244707;

