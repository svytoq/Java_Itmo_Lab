create function insert_judge_team(judges integer[], championship_id integer) returns void
    language plpgsql
as
$$
DECLARE
    judge_team_number integer;
    cur_judge integer;
BEGIN
    SELECT NEXTVAL('judge_team_judge_team_id_seq') INTO judge_team_number;
    INSERT INTO judge_team (judge_team_id) VALUES (judge_team_number);

    FOREACH cur_judge IN ARRAY judges
        LOOP
            UPDATE judge
            SET judge_team_id = judge_team_number
            WHERE person_id = cur_judge AND judge.championship_id = insert_judge_team.championship_id;
        END LOOP;
END;
$$;

alter function insert_judge_team(integer[], integer) owner to s264448;

