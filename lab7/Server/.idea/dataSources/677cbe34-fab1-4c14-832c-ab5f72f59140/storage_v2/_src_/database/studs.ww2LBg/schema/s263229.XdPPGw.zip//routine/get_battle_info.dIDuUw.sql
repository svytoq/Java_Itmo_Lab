create function get_battle_info(name character varying, is_battle_name boolean)
    returns TABLE(character_name character varying, battle_name character varying, battle_duration numeric, ability_name character varying, ability_description text, ability_type s263229.ability_types, complexity_level integer)
    stable
    language plpgsql
as
$$
DECLARE
    table_attribute TEXT;
    table_name TEXT;
BEGIN
    IF is_battle_name IS TRUE THEN
        table_name := 'b';
        table_attribute := 'BATTLE_NAME';
    ELSE
        table_name := 'c';
        table_attribute := 'CHARACTER_NAME';
    END IF;
    RETURN QUERY EXECUTE FORMAT 
    ('SELECT c.CHARACTER_NAME, b.BATTLE_NAME, b.DURATION, a.ABILITY_NAME, a.DESCRIPTION, a.ABILITY_TYPE, a.COMPLEXITY_LEVEL 
    FROM character AS c JOIN battle_characters USING(CHARACTER_ID) JOIN battle AS b USING(BATTLE_ID) 
    JOIN battle_abilities USING(BATTLE_ID) JOIN abilities AS a USING(ABILITY_ID) 
    JOIN battle_location USING(BATTLE_ID) JOIN locations USING(LOCATION_ID) WHERE %2$I.%1$I LIKE $1', 
    table_attribute, table_name) USING name;
END
$$;

alter function get_battle_info(varchar, boolean) owner to s263229;

