create function cross_check(person bigint, depart_dim s265066.dimensions) returns boolean
    language plpgsql
as
$$
declare
    visa integer;
    visa_state visa_states;
    exp_date date;
    cur_trans integer;
    max_trans integer;
    person_cur_dim dimensions;
    person_birth_dim dimensions;
    restriction date;
begin
    select (visa_id, visa_state, exp_date, cur_trans, max_trans) 
    into visa, visa_state, exp_date, cur_trans, max_trans from Visas
        where person_id=person;

    select (current_dim, birth_dim, restrict_until) 
        into person_cur_dim, person_birth_dim, restriction
        from People
        where person_id=person;

    if visa is null or
        visa_state = 'ready' or
        visa_state = 'suspended' or
        person_dim != depart_dim or
        restriction >= current_date
    then return false;
    end if;

    if exp_date < current_date or
        cur_trans >= max_trans
    then visa_state = 'expired';
    end if;

    if visa_state = 'expired'
    then
        if depart_dim != person_birth_dim then    
            return true;
        end if;
        return false;
    end if;

    return true;
end;
$$;

alter function cross_check(bigint, s265066.dimensions) owner to s265066;

