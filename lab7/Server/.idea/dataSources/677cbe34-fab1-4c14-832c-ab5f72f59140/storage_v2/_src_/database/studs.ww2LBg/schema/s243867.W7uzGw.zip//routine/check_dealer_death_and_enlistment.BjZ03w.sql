create function check_dealer_death_and_enlistment() returns trigger
    language plpgsql
as
$$
DECLARE
    dealer_enlistment date;
    dealer_death date;
    BEGIN
    dealer_enlistment := (SELECT date_of_employment FROM employees WHERE id = NEW.dealer_id);
    dealer_death := (SELECT date_of_death FROM employees WHERE id = NEW.dealer_id);
    IF NEW.date > dealer_death THEN
      RAISE EXCEPTION 'Employee is already dead by the time of the deal.';
      ELSE IF NEW.date < dealer_enlistment THEN
        RAISE EXCEPTION 'Employee has not been enlisted yet by the time of the deal.';
      END IF;
    END IF;
    RETURN NEW;
  END;
$$;

alter function check_dealer_death_and_enlistment() owner to s243867;

