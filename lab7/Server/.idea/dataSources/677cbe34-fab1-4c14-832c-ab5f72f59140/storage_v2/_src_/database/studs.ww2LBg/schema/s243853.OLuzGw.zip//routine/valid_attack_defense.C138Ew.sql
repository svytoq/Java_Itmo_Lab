create function valid_attack_defense() returns trigger
    language plpgsql
as
$$
DECLARE
id_souz integer;
BEGIN
id_souz := (SELECT ИД_СОЮЗА FROM ГОСУДАРСТВА WHERE ИД = NEW.ИД_АТАК_СТРАНЫ);
IF id_souz = (SELECT ИД_СОЮЗА FROM ГОСУДАРСТВА WHERE ИД = NEW.ИД_ОБОРОН_СТРАНЫ) THEN
RAISE EXCEPTION 'Обороняющееся и нападающее государство не могу находится в одном союзе (ид_союза=%)',id_souz;
END IF;
RETURN NEW;
END
$$;

alter function valid_attack_defense() owner to s243853;

