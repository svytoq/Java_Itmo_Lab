create function check_book_permission_before_checkout() returns trigger
    language plpgsql
as
$$
declare
  requires_permission boolean;
begin
  requires_permission := (select books.requires_permission from books where id = new.book_id);

  if requires_permission and new.permitted_by_id is null
  then raise exception 'A permission is required to check out the requested book.';
  end if;

  return new;
end;
$$;

alter function check_book_permission_before_checkout() owner to s244706;

