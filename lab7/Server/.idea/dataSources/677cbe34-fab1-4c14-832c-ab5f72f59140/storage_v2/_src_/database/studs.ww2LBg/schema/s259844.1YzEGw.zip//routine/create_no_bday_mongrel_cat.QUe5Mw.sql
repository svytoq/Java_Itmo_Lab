create function create_no_bday_mongrel_cat(cat_name text, cat_sex character, cat_color integer) returns s259844.cat
    language plpgsql
as
$$
DECLARE
BEGIN
    RETURN (SELECT create_cat(cat_name, NULL, NULL, cat_sex, cat_color));
END;
$$;

alter function create_no_bday_mongrel_cat(text, char, integer) owner to s259844;

