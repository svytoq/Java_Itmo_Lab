create function create_contract(company_id uuid, employee_id uuid, created_date timestamp without time zone, end_date timestamp without time zone, name character varying, description character varying, doc_url character varying) returns text
    language plpgsql
as
$$
declare
    id_contract uuid;
begin
    if exists(select c.id from company c where c.id = company_id) then
        if exists(select e.id from employee e where e.id = employee_id) then
            insert into contract(created_date, description, doc_url, end_date, interrupted, interrupted_date, name, printed, company_id, employee_id)
            values (created_date, description, doc_url, end_date, false, null, name, false, company_id, employee_id)
            returning contract.id into id_contract;

            return 'Contract created. Id: ' || id_contract;
        else
            return 'No such employee_id: ' || employee_id;
        end if;
    else
        return 'No such company_id: ' || company_id;

    end if;
end;
$$;

alter function create_contract(uuid, uuid, timestamp, timestamp, varchar, varchar, varchar) owner to s264452;

