create function check_deck() returns trigger
    language plpgsql
as
$$
BEGIN
  -- если не установлен турнир, то ничего не проверяем
  IF NEW.tournament_id IS NULL
  THEN
    RETURN NEW;
  END IF;

  -- если уже существует колода с таким классом
  IF EXISTS(SELECT * FROM deck WHERE tournament_id=NEW.tournament_id AND class=NEW.class)
    THEN
    RETURN NULL;
  END IF;

  -- если количество карт в турнире больше количества игр + количества забаненых колод
  IF (SELECT COUNT(*) FROM deck WHERE tournament_id=NEW.tournament_id) >
    (SELECT SUM(games_num, banned_decks_num) FROM game_format WHERE game_format_id=
      (SELECT game_format_id FROM tournament WHERE tournament_id=NEW.torunament_id))
  THEN
    RAISE EXCEPTION 'Can''t add deck. Decks number must be <= games_num + banned_decks_num';
    RETURN NULL;
  END IF;

  RETURN NEW;
END;
$$;

alter function check_deck() owner to s225111;

