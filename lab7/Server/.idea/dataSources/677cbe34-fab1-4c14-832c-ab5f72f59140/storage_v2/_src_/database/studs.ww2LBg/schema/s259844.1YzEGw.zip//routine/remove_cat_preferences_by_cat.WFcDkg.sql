create function remove_cat_preferences_by_cat() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM food_preference WHERE
        food_preference.cat_id = NEW.cat_id AND
        food_preference.food_id IN (SELECT food_id FROM food_allergen
            WHERE food_allergen.allergen_id = NEW.allergen_id);

    RETURN NEW;
END;
$$;

alter function remove_cat_preferences_by_cat() owner to s259844;

