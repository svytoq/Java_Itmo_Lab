create function get_pet_list()
    returns TABLE(fio text, pet_name text)
    language plpgsql
as
$$
begin
	return query
    SELECT  "ЖЕЛАЮЩИЕ_ПРИЮТИТЬ"."ФИО", "ГРЫЗУНЫ"."ИМЯ" from "ЖЕЛАЮЩИЕ_ГРЫЗУНЫ"
        join "ГРЫЗУНЫ" on "ГРЫЗУНЫ"."ИД" = "ЖЕЛАЮЩИЕ_ГРЫЗУНЫ"."ИД_ГРЫЗУНА"
            join "ЖЕЛАЮЩИЕ_ПРИЮТИТЬ"  on "ЖЕЛАЮЩИЕ_ГРЫЗУНЫ"."ИД_ЖЕЛАЮЩЕГО" = "ЖЕЛАЮЩИЕ_ПРИЮТИТЬ"."ИД";
end;
$$;

alter function get_pet_list() owner to s265080;

