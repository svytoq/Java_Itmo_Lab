create function task3() returns text
    language plpgsql
as
$$
DECLARE 
housesOldCapacity int;
citizensInOldHouses int;
citizensMigration int;
freeSpace int;
energyFromFreeHouses real;
totalEnergyOutput int;
housesFreed int;
currentRemainingTime real;
reducedPart real;
res real;
BEGIN 
SELECT SUM("Вместимость") INTO STRICT housesOldCapacity FROM "Жилой дом" WHERE "ID_Дома" IN (SELECT DISTINCT "ID_Дома" FROM (SELECT "ID_Жителя", "Кол-во лет в партии", "ID_Дома" FROM "Житель" WHERE "Кол-во лет в партии" >= 5.0) AS res); 
SELECT COUNT(*) INTO STRICT citizensInOldHouses FROM "Житель" WHERE "ID_Дома" IN (SELECT DISTINCT "ID_Дома" FROM (SELECT "ID_Жителя", "Кол-во лет в партии", "ID_Дома" FROM "Житель" WHERE "Кол-во лет в партии" >= 5.0) AS res);
SELECT COUNT(*) INTO STRICT citizensMigration FROM "Житель" WHERE "ID_Дома" NOT IN (SELECT DISTINCT "ID_Дома" FROM (SELECT "ID_Жителя", "Кол-во лет в партии", "ID_Дома" FROM "Житель" WHERE "Кол-во лет в партии" >= 5.0) AS res);

freeSpace = housesOldCapacity - citizensInOldHouses - citizensMigration;

IF freeSpace >= 0 THEN

SELECT SUM("Потребляемая мощность") INTO STRICT energyFromFreeHouses FROM "Жилой дом" WHERE "ID_Дома" NOT IN (SELECT DISTINCT "ID_Дома" FROM (SELECT "ID_Жителя", "Кол-во лет в партии", "ID_Дома" FROM "Житель" WHERE "Кол-во лет в партии" >= 5.0) AS res);
SELECT COUNT("Потребляемая мощность") INTO STRICT housesFreed FROM "Жилой дом" WHERE "ID_Дома" NOT IN (SELECT DISTINCT "ID_Дома" FROM (SELECT "ID_Жителя", "Кол-во лет в партии", "ID_Дома" FROM "Житель" WHERE "Кол-во лет в партии" >= 5.0) AS res);

SELECT SUM("Выходная мощность") INTO STRICT totalEnergyOutput FROM "Термоядерный реактор";
SELECT SUM("Остаток часов работы") INTO STRICT currentRemainingTime FROM "Термоядерный реактор";

reducedPart = energyFromFreeHouses / totalEnergyOutput;

res = reducedPart * currentRemainingTime / 24 / 360;

RAISE NOTICE 'Жителей, подлежащих депортации: %', citizensMigration;
RAISE NOTICE 'Домов будет освобождено: %', housesFreed;
RAISE NOTICE 'Кол-во мощности, которое будет сохранено на нужны партии: %', energyFromFreeHouses;

RETURN 'Суммарное время жизни реакторов будет продлено на ' || res || ' лет. Рекомендуется незамедлительно приступить к депортации!'; 

END IF;

RETURN 'Невозможно продлить жизнь реактора. Руководство партии будет уведомлено незамедлительно!';
END
$$;

alter function task3() owner to s265082;

