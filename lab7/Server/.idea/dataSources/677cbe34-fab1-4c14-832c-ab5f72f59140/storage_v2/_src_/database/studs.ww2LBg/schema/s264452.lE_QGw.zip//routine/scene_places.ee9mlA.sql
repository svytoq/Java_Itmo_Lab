create function scene_places(scene_uuid uuid)
    returns TABLE(scene character varying, city character varying, country character varying, address character varying)
    language plpgsql
as
$$
begin
    return query
        select s.name, p.city, p.country, p.address
        from scene s
                 join scene_place sp on sp.scene_list_id = s.id
                 join place p on p.id = sp.place_id
        where s.id = scene_uuid;
end;
$$;

alter function scene_places(uuid) owner to s264452;

