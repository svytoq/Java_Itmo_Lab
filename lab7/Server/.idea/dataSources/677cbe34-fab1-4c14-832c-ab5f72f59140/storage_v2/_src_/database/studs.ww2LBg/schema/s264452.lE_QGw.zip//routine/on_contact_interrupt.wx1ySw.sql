create function on_contact_interrupt() returns trigger
    language plpgsql
as
$$
begin
    if new.interrupted IS true AND (old IS NULL OR old.interrupted IS false) then
        if (new.interrupted_date <= CURRENT_TIMESTAMP) then
            return new;
        else
            RAISE EXCEPTION 'the interrupted date should not be in the future';
        end if;
    end if;

    return new;
end;
$$;

alter function on_contact_interrupt() owner to s264452;

