create function random_film_date() returns timestamp without time zone
    language plpgsql
as
$$
DECLARE
        result timestamp;
BEGIN
        result = timestamp '1950-01-10 20:00:00' + random() * interval '68 years';
        return result;
END;
$$;

alter function random_film_date() owner to s242395;

