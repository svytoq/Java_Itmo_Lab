create function "Клиг"(id integer, "id_базы" integer, "название" character varying) returns boolean
    language plpgsql
as
$$
BEGIN
insert into корабль values(ID, 900, название, '[0, 10]', 2000, 'создается',1000, ID_базы, now(), null);
insert into оружие_корабль values(3, ID);
return true;
END;
$$;

alter function "Клиг"(integer, integer, varchar) owner to s243840;

