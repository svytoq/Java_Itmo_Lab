create function check_positive() returns trigger
    language plpgsql
as
$$
begin
if (new.BusinessPart < 0) or (new.Innovations < 0) then
raise exception 'result number % should be above zero', new.ResultID;
end if;
return new;
end;
$$;

alter function check_positive() owner to s243890;

