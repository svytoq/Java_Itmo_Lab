create function insert_user_project(user_id integer, project_id integer, wallet character varying) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO user_project (user_id,
                project_id,
                wallet)

  VALUES (insert_user_project.user_id,
      insert_user_project.project_id,
      insert_user_project.wallet);
END;

$$;

alter function insert_user_project(integer, integer, varchar) owner to s264458;

