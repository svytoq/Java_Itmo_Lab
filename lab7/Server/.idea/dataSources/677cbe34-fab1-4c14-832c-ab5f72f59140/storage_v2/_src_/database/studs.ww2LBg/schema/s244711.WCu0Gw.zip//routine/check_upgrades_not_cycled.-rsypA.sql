create function check_upgrades_not_cycled() returns trigger
    language plpgsql
as
$$
DECLARE
	upgrades_to int;
	id int;
BEGIN
	id = NEW.id;
	upgrades_to = NEW.upgrades_to;
	
	WHILE (upgrades_to IS NOT NULL) LOOP
		IF (upgrades_to IN (NEW.id, id)) THEN
			RAISE EXCEPTION 
				'% % cycled with %',
				TG_TABLE_NAME, NEW.id, NEW.upgrades_to;
		END IF;

		id = upgrades_to;

		EXECUTE format(
			'SELECT upgrades_to 
			FROM %I
			WHERE id = %L',
			TG_TABLE_NAME,
			id)
		INTO upgrades_to;
	END LOOP;

	RETURN NEW;
END;
$$;

alter function check_upgrades_not_cycled() owner to s244711;

