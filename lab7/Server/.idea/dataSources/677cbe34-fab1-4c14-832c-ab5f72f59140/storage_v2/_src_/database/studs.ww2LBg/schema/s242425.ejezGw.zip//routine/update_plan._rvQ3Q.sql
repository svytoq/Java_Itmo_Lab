create function update_plan() returns trigger
    language plpgsql
as
$$
DECLARE
id_order integer;
end_persent float;
end_date date;
 id_ingr integer;
 mass float; 
 finish boolean;
  
BEGIN 
IF (TG_OP = 'INSERT') THEN
 
SELECT МАССА, ИД_ЗАКАЗА INTO mass, id_order FROM ПЛАН_МАРШРУТ WHERE ИД_ИНГРЕДИЕНТА = NEW.ИД_ИНГРЕДИЕНТА AND СОБРАНО = FALSE;
mass := mass - NEW.МАССА;
NEW.ИСПОЛЬЗОВАНО = TRUE;
IF (mass > 0) THEN
finish := FALSE; 
 
IF ((SELECT НОМЕР_В_ОЧЕРЕДИ FROM СТАТУС_ЗАКАЗА WHERE ИД_ЗАКАЗА = id_order) <> 1) THEN
end_date := (SELECT MAX(ДАТА_ЗАВЕРШЕНИЯ) FROM СТАТУС_ЗАКАЗА) + round((SELECT MIN(distance) FROM get_loc(id_ingr, mass))/(select КОРАБЛЬ.СРЕДНЯЯ_СКОРОСТЬ from КОРАБЛЬ))::integer;
ELSE end_date := current_date + round((SELECT MIN(distance) FROM get_loc(id_ingr, mass))/(select КОРАБЛЬ.СРЕДНЯЯ_СКОРОСТЬ from КОРАБЛЬ))::integer;
END IF;
ELSE finish := TRUE; end_date := current_date;
END IF;
 
UPDATE ПЛАН_МАРШРУТ SET ДАТА_ЗАВЕРШЕНИЯ = end_date, МАССА = mass, СОБРАНО = finish WHERE ИД_ИНГРЕДИЕНТА = NEW.ИД_ИНГРЕДИЕНТА AND ИД_ЗАКАЗА = id_order;
 
end_persent := (SELECT COUNT(ИД_ЗАКАЗА) FROM ПЛАН_МАРШРУТ WHERE (ИД_ЗАКАЗА = id_order) AND (СОБРАНО = TRUE)) / 
(SELECT COUNT(ИД_ЗАКАЗА) FROM ПЛАН_МАРШРУТ WHERE (ИД_ЗАКАЗА = id_order));
SELECT MAX(ДАТА_ЗАВЕРШЕНИЯ)  INTO end_date  FROM ПЛАН_МАРШРУТ WHERE ИД_ЗАКАЗА = id_order;

UPDATE СТАТУС_ЗАКАЗА SET ВЫПОЛНЕНИЕ = end_persent, ДАТА_ЗАВЕРШЕНИЯ = end_date WHERE ИД_ЗАКАЗА = id_order;
RETURN NEW;
ELSIF (TG_OP = 'DELETE') THEN

SELECT МАССА, ИД_ЗАКАЗА INTO mass, id_order FROM ПЛАН_МАРШРУТ WHERE ИД_ИНГРЕДИЕНТА = OLD.ИД_ИНГРЕДИЕНТА AND СОБРАНО = FALSE;
mass := mass + OLD.МАССА;
 
 
IF ((SELECT НОМЕР_В_ОЧЕРЕДИ FROM СТАТУС_ЗАКАЗА WHERE ИД_ЗАКАЗА = id_order) <> 1) THEN
end_date := (SELECT MAX(ДАТА_ЗАВЕРШЕНИЯ) FROM СТАТУС_ЗАКАЗА) + round((SELECT MIN(distance) FROM get_loc(id_ingr, mass))/(select КОРАБЛЬ.СРЕДНЯЯ_СКОРОСТЬ from КОРАБЛЬ))::integer;
ELSE end_date := current_date + round((SELECT MIN(distance) FROM get_loc(id_ingr, mass))/(select КОРАБЛЬ.СРЕДНЯЯ_СКОРОСТЬ from КОРАБЛЬ))::integer;
END IF;
 
UPDATE ПЛАН_МАРШРУТ SET ДАТА_ЗАВЕРШЕНИЯ = end_date, МАССА = mass WHERE ИД_ИНГРЕДИЕНТА = OLD.ИД_ИНГРЕДИЕНТА AND ИД_ЗАКАЗА = id_order;
 
end_persent := (SELECT COUNT(ИД_ЗАКАЗА) FROM ПЛАН_МАРШРУТ WHERE (ИД_ЗАКАЗА = id_order) AND (СОБРАНО = TRUE)) / 
(SELECT COUNT(ИД_ЗАКАЗА) FROM ПЛАН_МАРШРУТ WHERE (ИД_ЗАКАЗА = id_order));
SELECT MAX(ДАТА_ЗАВЕРШЕНИЯ)  INTO end_date  FROM ПЛАН_МАРШРУТ WHERE ИД_ЗАКАЗА = id_order;

UPDATE СТАТУС_ЗАКАЗА SET ВЫПОЛНЕНИЕ = end_persent, ДАТА_ЗАВЕРШЕНИЯ = end_date WHERE ИД_ЗАКАЗА = id_order;
RETURN OLD; 
END IF;
END;
$$;

alter function update_plan() owner to s242425;

