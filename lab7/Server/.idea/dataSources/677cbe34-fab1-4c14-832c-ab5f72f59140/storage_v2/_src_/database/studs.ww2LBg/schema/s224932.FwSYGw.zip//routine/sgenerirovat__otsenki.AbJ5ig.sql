create function сгенерировать_оценки("число_оценок" integer) returns void
    language plpgsql
as
$$
DECLARE
        film RECORD;
        users RECORD;
BEGIN
        FOR users IN (SELECT ид FROM Пользователи)
        LOOP
                FOR film IN (SELECT ид, премьера FROM Фильмы)
                LOOP
                        INSERT INTO Оценки(ид_фильма,ид_пользователя, значение, комментарий, дата_время)
        VALUES(film.ид, users.ид, random()*9 + 1, random_string(5), (film.премьера + random_film_interval()));
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_оценки(integer) owner to s224932;

