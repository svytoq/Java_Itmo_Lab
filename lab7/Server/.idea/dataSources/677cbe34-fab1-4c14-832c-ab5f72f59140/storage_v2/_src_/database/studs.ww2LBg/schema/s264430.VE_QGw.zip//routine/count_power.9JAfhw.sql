create function count_power() returns trigger
    language plpgsql
as
$$
BEGIN
		IF NEW.id is null then
			raise exception 'not army';
		END IF;
		IF NEW.size IS NULL THEN
			RAISE EXCEPTION 'cant find size';
		END IF;
		IF NEW.char_id IS NULL THEN
			RAISE EXCEPTION 'army dont have characteristics';
		END IF;
		if new.leader_name is null then 
		NEW.power := NEW.size * (select (strength*1.5+agillity*1.25+intellect*2) from characteristics where characteristics.id = new.char_id);
		else new.power := new.size*(select (strength*1.5+agillity*1.25+intellect*2) from characteristics where characteristics.id = new.char_id)+
		(select (strength*1.5+agillity*1.25+intellect*2) from characteristics where characteristics.id IN (select char_id from leader where leader.name = new.leader_name));
		end if;
		RETURN NEW;
	END;
$$;

alter function count_power() owner to s264430;

