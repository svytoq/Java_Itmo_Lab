create function create_equipment(vtype_equipment text, vcost_day_rub bigint) returns bigint
    language plpgsql
as
$$
DECLARE
  ret bigint;
BEGIN
  INSERT INTO equipment(type_equipment, cost_day_rub) VALUES (vtype_equipment, vcost_day_rub) returning id into ret;
  RETURN ret;
END;
$$;

alter function create_equipment(text, bigint) owner to s265067;

