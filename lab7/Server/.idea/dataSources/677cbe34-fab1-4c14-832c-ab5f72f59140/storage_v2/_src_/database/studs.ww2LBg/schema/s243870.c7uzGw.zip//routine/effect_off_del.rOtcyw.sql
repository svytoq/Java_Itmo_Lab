create function effect_off_del() returns trigger
    language plpgsql
as
$$
BEGIN
IF (OLD.Момент_Снятия is null) THEN
UPDATE "К_Персонажи_Эффекты" SET Момент_Снятия = current_timestamp WHERE
"К_Персонажи_Эффекты".Эффект_ИД = OLD.Эффект_ИД AND "К_Персонажи_Эффекты".Персонаж_ИД = OLD.Персонаж_ИД;
END IF;
RETURN NULL;
END;
$$;

alter function effect_off_del() owner to s243870;

