create function set_categories(arg s251437.item[]) returns void
    language plpgsql
as
$$
DECLARE
    t item;
BEGIN
    FOREACH t IN ARRAY arg LOOP
            INSERT INTO
                category_item_relation(item_id, category_id)
            VALUES(t.id, 5);
        END LOOP;
END
$$;

alter function set_categories(s251437.item[]) owner to s251437;

