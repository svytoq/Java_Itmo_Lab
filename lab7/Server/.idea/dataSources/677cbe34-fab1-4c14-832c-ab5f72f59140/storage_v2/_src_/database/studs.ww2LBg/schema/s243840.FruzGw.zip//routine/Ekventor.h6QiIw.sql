create function "Эквентор"(id integer, "id_базы" integer, "название" character varying) returns void
    language plpgsql
as
$$
BEGIN
insert into корабль values(ID, 400, название, '[43, 47]' , 4800, 'создается',5800, ID_базы, now(), null);
insert into оружие_корабль values(4, ID);
insert into оружие_корабль values(9, ID);
insert into оружие_корабль values(13, ID);
END;
$$;

alter function "Эквентор"(integer, integer, varchar) owner to s243840;

