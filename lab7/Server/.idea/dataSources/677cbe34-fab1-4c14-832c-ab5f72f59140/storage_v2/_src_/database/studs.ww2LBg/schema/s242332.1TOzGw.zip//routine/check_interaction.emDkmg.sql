create function check_interaction() returns trigger
    language plpgsql
as
$$
declare hlth int;
	begin
		select
			Здоровье_после
		from Взаимодействия
			left join Инвентари
			on ИД_Инвентаря = Инвентари.ИД
		where Взаимодействия.ИД_Игры = NEW.ИД_Игры and Инвентари.ИД_Игрока in (
				select
					ИД_Игрока
				from
					Инвентари
				where
					NEW.ИД_Инвентаря = ИД)
		order by
			Взаимодействия.Время_взаимодействия
			desc
		limit
			1
		into
			hlth;
		
		if hlth != NEW.Здоровье_до then
			raise exception 'health before (%) not equals to current (%)', hlth, NEW.Здоровье_до;
		end if;

		return NEW;
	end;
$$;

alter function check_interaction() owner to s242332;

