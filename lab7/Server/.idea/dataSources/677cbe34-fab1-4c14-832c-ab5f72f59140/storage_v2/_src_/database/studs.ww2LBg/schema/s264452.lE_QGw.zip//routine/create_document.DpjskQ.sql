create function create_document(employee_uuid uuid, new_document_uuid uuid, new_document_type character varying, new_document_id integer, new_work_book_id integer) returns text
    language plpgsql
as
$$
DECLARE
    document_new_uuid uuid;
begin
    if not exists(
            select employee_docs.id
            from employee_docs) then
        insert into employee_docs(id, document_id, document_type, work_book_id, owner_id)
        values (new_document_uuid, new_document_id, new_document_type, new_work_book_id, employee_uuid)
        returning id into document_new_uuid;
        RAISE NOTICE 'Created document: %', document_new_uuid;
    else
        RAISE EXCEPTION 'Worker cant be created. Id collision : %', employee_uuid;
    end if;
end;
$$;

alter function create_document(uuid, uuid, varchar, integer, integer) owner to s264452;

