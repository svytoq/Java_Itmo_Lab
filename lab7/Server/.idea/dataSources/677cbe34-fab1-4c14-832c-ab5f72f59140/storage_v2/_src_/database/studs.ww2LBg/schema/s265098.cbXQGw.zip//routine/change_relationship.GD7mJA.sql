create function change_relationship(col1 integer, col2 integer, rel integer) returns void
    language sql
as
$$
INSERT INTO colony_relations (colony1_id, colony2_id, relationship) VALUES(col1, col2, rel) ON CONFLICT (colony1_id, colony2_id) DO UPDATE SET relationship = colony_relations.relationship + rel WHERE colony_relations.colony1_id = col1 AND colony_relations.colony2_id = col2;
    INSERT INTO colony_relations (colony1_id, colony2_id, relationship) VALUES(col2, col1, rel) ON CONFLICT (colony1_id, colony2_id) DO UPDATE SET relationship = colony_relations.relationship + rel WHERE colony_relations.colony1_id = col2 AND colony_relations.colony2_id = col1;
    --UPDATE colony_relations SET relationship = relationship + rel WHERE colony1_id = col1 AND colony2_id = col2;
    --UPDATE colony_relations SET relationship = relationship + rel WHERE colony1_id = col2 AND colony2_id = col1;
$$;

alter function change_relationship(integer, integer, integer) owner to s265098;

