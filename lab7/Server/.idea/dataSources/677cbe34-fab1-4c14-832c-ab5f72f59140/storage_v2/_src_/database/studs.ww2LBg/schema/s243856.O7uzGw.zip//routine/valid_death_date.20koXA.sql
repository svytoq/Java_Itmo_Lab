create function valid_death_date() returns trigger
    language plpgsql
as
$$
BEGIN
IF NOT is_valid_date(NEW.id_creature, NEW.death_date) THEN
 RAISE EXCEPTION 'Invalid death date %', NEW.death_date
 USING HINT = 'Death date must be higher then birth date';
END IF;
RETURN NEW;
END;
$$;

alter function valid_death_date() owner to s243856;

