create function change_confirm_status() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE "order_product" set need_confirm = true where product_count > 5;
    UPDATE "order_product" set need_confirm = false where product_count <= 5;
    RETURN NULL;
END
$$;

alter function change_confirm_status() owner to s224907;

