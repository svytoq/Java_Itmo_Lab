create view product_making_with_worker_and_profile
            (worker_id, product_order_id, deadline, is_finished, description, user_profile_id, name, date_of_birth,
             email, telephone_number, password_hash, privilege)
as
SELECT product_making.worker_id,
       product_making.product_order_id,
       product_making.deadline,
       product_making.is_finished,
       worker_with_profile.description,
       worker_with_profile.user_profile_id,
       worker_with_profile.name,
       worker_with_profile.date_of_birth,
       worker_with_profile.email,
       worker_with_profile.telephone_number,
       worker_with_profile.password_hash,
       worker_with_profile.privilege
FROM s267880.product_making
         LEFT JOIN s267880.worker_with_profile USING (worker_id);

alter table product_making_with_worker_and_profile
    owner to s267880;

