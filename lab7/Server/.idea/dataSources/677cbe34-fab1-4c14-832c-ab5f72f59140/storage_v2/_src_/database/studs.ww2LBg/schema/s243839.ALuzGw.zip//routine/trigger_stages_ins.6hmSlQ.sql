create function trigger_stages_ins() returns trigger
    language plpgsql
as
$$
DECLARE
ifnull INTEGER;
ifnotnull INTEGER;
BEGIN
IF NOT (EXISTS (SELECT ИД_МУЛЬТФИЛЬМА FROM ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА WHERE ИД_МУЛЬТФИЛЬМА=NEW.ИД_МУЛЬТФИЛЬМА)) THEN RETURN NULL;
END IF;
IF NEW."ИД_СЛЕД_ЭТАПА" IS NULL  THEN
  SELECT "ИД_ЭТАПА" INTO ifnull FROM "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА" WHERE "ИД_МУЛЬТФИЛЬМА" = NEW."ИД_МУЛЬТФИЛЬМА" AND "ИД_СЛЕД_ЭТАПА" IS NULL AND "ИД_ЭТАПА"!=NEW."ИД_ЭТАПА";
  UPDATE "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА" SET "ИД_СЛЕД_ЭТАПА" = NEW."ИД_ЭТАПА" WHERE "ИД_ЭТАПА" = ifnull;
ELSE
  SELECT "ИД_ЭТАПА" into ifnotnull FROM "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА" WHERE "ИД_МУЛЬТФИЛЬМА" = NEW."ИД_МУЛЬТФИЛЬМА" AND "ИД_СЛЕД_ЭТАПА" = NEW."ИД_СЛЕД_ЭТАПА";
  UPDATE "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА" SET "ИД_СЛЕД_ЭТАПА" = NEW."ИД_ЭТАПА" WHERE "ИД_ЭТАПА" = ifnotnull ;

END IF;
  RETURN null;
END;
$$;

alter function trigger_stages_ins() owner to s243839;

