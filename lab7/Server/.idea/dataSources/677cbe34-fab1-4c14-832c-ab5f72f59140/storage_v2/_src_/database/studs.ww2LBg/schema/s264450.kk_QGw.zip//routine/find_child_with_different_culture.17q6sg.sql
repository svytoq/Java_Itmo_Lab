create function find_child_with_different_culture()
    returns TABLE(character_name text, character_culture text, memory_description text, parent_id integer, memory_location text)
    language sql
as
$$
select character.name, character.culture_name, memory.description, first_character_id, location.culture_name
	from character join character_relation on character.id=character_relation.second_character_id
	join character_memory on first_character_id = character_memory.character_id
	join memory on memory_id = memory.id
	join time_vault on time_vault_id = time_vault.id
	join location on location = location.id
	where last_reincarnation is not null 
	and character_relation.description = 'Parent'
	and character.culture_name not like location.culture_name;
$$;

alter function find_child_with_different_culture() owner to s264450;

