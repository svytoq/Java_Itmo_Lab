create function "ОПРЕДЕЛИТЬ_КОЛВО_УЧЕНИКОВ"() returns trigger
    language plpgsql
as
$$
DECLARE
	counter SMALLINT;
BEGIN
	IF (TG_OP='INSERT') THEN 
		IF (NEW.КОЛИЧЕСТВО_УЧЕНИКОВ!=0) THEN
			RAISE NOTICE '% новая, в ней еще не может быть учеников', NEW.НАЗВАНИЕ;
			RETURN NULL;
		ELSE RETURN NEW;
		END IF;
	ELSE
		SELECT INTO counter COUNT(*) FROM УЧЕНИК WHERE (УЧЕНИК.ГРУППА_ИД=NEW.ГРУППА_ИД);
		IF (counter!=NEW.КОЛИЧЕСТВО_УЧЕНИКОВ) THEN
			RAISE NOTICE 'В группе % на самом деле количество учеников=%',NEW.ГРУППА_ИД,counter;
			RETURN NULL;
		ELSE RETURN NEW;
		END IF;
	END IF;
END;
$$;

alter function "ОПРЕДЕЛИТЬ_КОЛВО_УЧЕНИКОВ"() owner to s265057;

