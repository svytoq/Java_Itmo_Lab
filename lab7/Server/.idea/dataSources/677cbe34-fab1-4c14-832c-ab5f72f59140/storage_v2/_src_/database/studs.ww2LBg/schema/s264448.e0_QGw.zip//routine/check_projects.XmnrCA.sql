create function check_projects(championship_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    cur_project project%rowtype;
    cur_case    "case"%rowtype;
BEGIN
    IF NOT EXISTS(SELECT project_id
                  FROM project
                           INNER JOIN team ON team.team_id = project.team_id
                  WHERE team.championship_id = check_projects.championship_id) THEN
        RAISE EXCEPTION 'Championship should contains at least one project';
    END IF;

    FOR cur_project IN
        (SELECT *
         FROM project
         WHERE (
                   SELECT team.championship_id FROM team WHERE team.team_id = project.team_id
               ) = check_projects.championship_id)
        LOOP
            IF NOT EXISTS(SELECT *
                          FROM "case"
                          WHERE EXISTS(SELECT *
                                       FROM project_case
                                       WHERE "case".case_id = project_case.case_id
                                         AND cur_project.project_id = project_case.project_id)) THEN
                RAISE EXCEPTION 'Project should contains at least one case';
            END IF;

            FOR cur_case IN
                (SELECT *
                 FROM "case"
                 WHERE EXISTS(SELECT *
                              FROM project_case
                              WHERE "case".case_id = project_case.case_id
                                AND cur_project.project_id = project_case.project_id))
                LOOP
                    IF NOT EXISTS(SELECT *
                                  FROM championship_case
                                  WHERE case_id = cur_case.case_id
                                    AND championship_case.championship_id = check_projects.championship_id) THEN
                        RAISE EXCEPTION 'This case cant be used in that championship';
                    END IF;
                END LOOP;
        END LOOP;

    RETURN true;
END;
$$;

alter function check_projects(integer) owner to s264448;

