create function violationcheckscheck() returns trigger
    language plpgsql
as
$$
begin
    if NEW.is_finished then
        if NEW.verdict is null or not exists(
            select 1 from Violation_check_employees
            where violation_check_id=NEW.violation_check_id
        ) then 
            return NULL; 
        end if;

        if NEW.verdict != 'restriction'::violation_verdicts then
            NEW.restrict_until = NULL;
        end if;
    end if;
    return NEW;
end;
$$;

alter function violationcheckscheck() owner to s265066;

