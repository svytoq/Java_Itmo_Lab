create function to_delay(flid integer, interval) returns void
    language plpgsql
as
$$
begin
update flight set actual_departure=actual_departure+$2 where id=$1;
end;
$$;

alter function to_delay(integer, interval) owner to s265061;

