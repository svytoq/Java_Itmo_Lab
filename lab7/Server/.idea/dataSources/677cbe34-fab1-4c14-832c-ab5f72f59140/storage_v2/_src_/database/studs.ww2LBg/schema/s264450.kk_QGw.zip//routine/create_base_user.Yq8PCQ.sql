create function create_base_user(new_login text, new_password text, new_email text DEFAULT NULL::text) returns void
    language plpgsql
as
$$
BEGIN
insert into base_user(login, password, email) values (new_login, new_password, new_email);
END;
$$;

alter function create_base_user(text, text, text) owner to s264450;

