create function update_users_info() returns trigger
    language plpgsql
as
$$
BEGIN
        update distributor set main_person_id = new.id,  main_person_name = NEW.name where main_person_id = OLD.id;
    END;
$$;

alter function update_users_info() owner to s264957;

