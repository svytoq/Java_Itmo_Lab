create function weapon_moved() returns trigger
    language plpgsql
as
$$
DECLARE
  current_planet_store_id int;
  hunter_inventory_id int;
  weapon_price bigint;
  weapon_in_store boolean;
  hunter_has_money boolean;
BEGIN
  SELECT s.id INTO current_planet_store_id FROM Store as s
  INNER JOIN Planet as p ON (p.store_id = s.id)
  INNER JOIN Space_ship as ss ON (ss.planet_id = p.id)
  INNER JOIN Hunter as h ON (h.ship_id = ss.id)
  WHERE h.id = NEW.hunter_id;
  
  IF NEW.store_id != current_planet_store_id THEN
    RAISE EXCEPTION 'You can`t do it on this planet';
  END IF;
  
  SELECT h.inventory_id INTO hunter_inventory_id FROM Hunter as h WHERE h.id = NEW.hunter_id;
  SELECT price INTO weapon_price FROM Weapon WHERE id = NEW.weapon_id;
    
  IF NEW.is_buying = 't' THEN
  
    SELECT 't' INTO weapon_in_store FROM Weapon as w
    WHERE w.id = NEW.weapon_id AND w.store_id = NEW.store_id;
    
    IF NOT FOUND THEN
      RAISE EXCEPTION 'There`s no such weapon in this store';
    END IF;
    
    SELECT (h.money_amount >= weapon_price) INTO hunter_has_money FROM Hunter as h
    WHERE h.id = NEW.hunter_id;
    
    IF hunter_has_money = 'f' THEN
      RAISE EXCEPTION 'You don`t have enough money';
    END IF;
    
    UPDATE Weapon SET store_id = null, inventory_id = hunter_inventory_id WHERE id = NEW.weapon_id;
    UPDATE Hunter SET money_amount = money_amount - weapon_price WHERE id = NEW.hunter_id;
    
  ELSE
    
    UPDATE Weapon SET store_id = NEW.store_id, inventory_id = null WHERE id = NEW.weapon_id;
    UPDATE Hunter SET money_amount = money_amount + weapon_price WHERE id = NEW.hunter_id;
  
  END IF;
  RETURN NEW;
END;
$$;

alter function weapon_moved() owner to s263081;

