create function add_group_func() returns trigger
    language plpgsql
as
$$
DECLARE amountOfPoint INTEGER;
BEGIN
    amountOfPoint = (select count(*) from groups where zone = new.zone);
    IF amountOfPoint  > 2 THEN
        RAISE EXCEPTION '!!! amount of points cannot be pore than 3';
    ELSE RETURN new;
    END IF;
END
$$;

alter function add_group_func() owner to s265094;

