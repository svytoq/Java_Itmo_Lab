create function get_order_data(main_order_id integer)
    returns TABLE(customer_id integer, order_id integer, order_time timestamp without time zone, delivery_requested boolean, address character varying, delivery_time timestamp without time zone, assembly_ordered boolean, resolved boolean, resolve_time timestamp without time zone)
    language plpgsql
as
$$
BEGIN
        RETURN QUERY
            SELECT ord.customer_id, ord.id AS order_id, ord.order_time,
                   del.id IS NOT NULL AS delivery_requested, del.address,
                   del.delivery_time, del.assembly_ordered,
                   ord.resolve_time IS NOT NULL AS resolved, ord.resolve_time
            FROM customer_order ord
            LEFT JOIN delivery_order del ON del.order_id = ord.id
            WHERE ord.id = main_order_id
            ORDER BY ord.order_time;
    END;
$$;

alter function get_order_data(integer) owner to s264443;

