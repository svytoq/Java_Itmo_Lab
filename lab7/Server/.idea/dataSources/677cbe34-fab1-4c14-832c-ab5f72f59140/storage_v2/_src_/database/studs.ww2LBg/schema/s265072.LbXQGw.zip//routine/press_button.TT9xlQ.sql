create function press_button(shortyid integer, buttonid integer) returns boolean
    language plpgsql
as
$$
DECLARE 
	id integer;
	shorty_scene integer;
	button_scene integer;
	subject integer;
BEGIN
	SELECT changeable_id INTO id FROM Button WHERE button_id = buttonId;
	IF (id is NULL) then RETURN false; END IF;
	SELECT scene_id INTO shorty_scene FROM Shorty WHERE shorty_id = shortyId;
	IF (shorty_scene is NULL) then RETURN false; END IF;
	SELECT scene_id INTO button_scene FROM Button WHERE button_id = buttonid;
	IF (shorty_scene != button_scene) then RETURN false; END IF;
	SELECT subject_id INTO subject FROM Button WHERE button_id = buttonid;
	UPDATE Changeable SET is_state = NOT is_state WHERE changeable_id = id OR changeable_id = subject;
	RETURN true;
END;
$$;

alter function press_button(integer, integer) owner to s265072;

