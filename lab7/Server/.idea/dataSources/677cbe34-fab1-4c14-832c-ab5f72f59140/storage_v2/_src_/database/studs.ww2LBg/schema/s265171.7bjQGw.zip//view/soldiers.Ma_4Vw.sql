create view soldiers(id, family, is_busy) as
SELECT soldier.id,
       soldier.family,
       soldier.is_busy
FROM s265171.soldier
WHERE soldier.family = 'Corleone'::text
  AND soldier.is_busy = false
LIMIT 2;

alter table soldiers
    owner to s265171;

