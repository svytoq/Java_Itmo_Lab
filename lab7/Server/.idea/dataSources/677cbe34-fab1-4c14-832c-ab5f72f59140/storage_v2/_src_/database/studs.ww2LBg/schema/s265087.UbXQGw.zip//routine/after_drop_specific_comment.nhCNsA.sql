create function after_drop_specific_comment() returns trigger
    language plpgsql
as
$$
DECLARE
    COMMENT_ID INTEGER := (SELECT ID
                           FROM COMMENT
                           WHERE ID = OLD.COMMENT);
BEGIN
    DELETE FROM COMMENT WHERE ID = COMMENT_ID;
    RETURN OLD;
END;
$$;

alter function after_drop_specific_comment() owner to s265087;

