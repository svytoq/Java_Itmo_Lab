create function createnewbook(userid integer, bookname text) returns text
    language plpgsql
as
$$
declare
    id_ft int;
begin
    insert into fairy_tale(name, id_author) values (bookName, userId) returning id_fairy_tale into id_ft;
    insert into bookshelf values (userId, id_ft);
    return 'Ваша новая книга создана! id - ' || id_ft;
end;
$$;

alter function createnewbook(integer, text) owner to s264912;

