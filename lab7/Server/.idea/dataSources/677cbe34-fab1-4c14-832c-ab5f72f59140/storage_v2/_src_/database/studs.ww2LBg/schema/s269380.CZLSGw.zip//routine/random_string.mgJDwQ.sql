create function random_string(lengh integer) returns character varying
    language sql
as
$$
SELECT array_to_string(ARRAY(
SELECT substr('abcdefghijklmnopqrstuv',trunc(random()*21+1)::int,1) 
FROM generate_series(1,$1)),'')
$$;

alter function random_string(integer) owner to s269380;

