create function storage_check() returns trigger
    language plpgsql
as
$$
DECLARE
  BEGIN
   IF (NOT(NEW.team_id = (SELECT team_id FROM engine_storage WHERE (engine_storage.id = NEW.current_engine_id)) ))
     THEN RAISE EXCEPTION 'engine and car must belong to one team';
     RETURN NULL;
  END IF;
   IF (NOT(NEW.team_id = (SELECT team_id FROM chassis_storage WHERE (chassis_storage.id = NEW.current_chassis_id)) ))
     THEN RAISE EXCEPTION 'chassis and car must belong to one team';
     RETURN NULL;
  END IF;
   IF (NOT(NEW.team_id = (SELECT team_id FROM carcase_storage WHERE (carcase_storage.id = NEW.current_carcase_id)) ))
     THEN RAISE EXCEPTION 'carcase and car must belong to one team';
     RETURN NULL;
  END IF;
   IF (NOT(NEW.team_id = (SELECT team_id FROM electronics_storage WHERE (electronics_storage.id = NEW.current_electronics_id)) ))
     THEN RAISE EXCEPTION 'electronics and car must belong to one team';
     RETURN NULL;
  END IF;
  RETURN NEW;
END;
$$;

alter function storage_check() owner to s244077;

