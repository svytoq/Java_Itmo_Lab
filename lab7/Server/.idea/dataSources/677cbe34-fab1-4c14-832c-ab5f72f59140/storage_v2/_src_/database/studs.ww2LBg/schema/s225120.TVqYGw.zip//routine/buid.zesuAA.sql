create function buid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_ЗДАНИЯ := nextval('buildings_seq');
	return new;
end
$$;

alter function buid() owner to s225120;

