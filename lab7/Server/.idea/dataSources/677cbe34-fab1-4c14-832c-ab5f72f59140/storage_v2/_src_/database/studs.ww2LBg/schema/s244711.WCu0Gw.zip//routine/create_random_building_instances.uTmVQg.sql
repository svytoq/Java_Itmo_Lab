create function create_random_building_instances(amount integer) returns void
    language plpgsql
as
$$
DECLARE
	types_amount int;
BEGIN
	types_amount = 
		(SELECT MAX(id)
		FROM building_types);

	FOR i IN 1 .. amount LOOP
		INSERT INTO building_instances
			(type)
			VALUES
			((SELECT round(random() * (types_amount - 1)) + 1)); 
	END LOOP;
END;
$$;

alter function create_random_building_instances(integer) owner to s244711;

