create function visa_check_create(app_id integer) returns integer
    language plpgsql
as
$$
declare
    id integer;
begin
    insert into Visa_checks(visa_app_id)
        values(app_id)
        returning visa_check_id into id;
    update Visa_applications set 
        visa_app_state='reviewing'
        where visa_app_id=app_id;
    return id;
end;
$$;

alter function visa_check_create(integer) owner to s265066;

