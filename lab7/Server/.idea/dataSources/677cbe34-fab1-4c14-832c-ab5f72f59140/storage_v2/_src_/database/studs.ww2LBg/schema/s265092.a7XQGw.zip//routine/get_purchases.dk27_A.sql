create function get_purchases(mageid integer)
    returns TABLE(tradeid integer, buyer_name character varying, seller_name character varying, seller_id integer, smoke_ab character varying, drug_name character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY
SELECT TRADE.TRADE_ID, M.NAME, MA.NAME as sell_name, TM.SELLER_ID, SMOKE.ABILITY, DRUG.NAME FROM TRADE_MAGE TM
LEFT JOIN MAGE M ON TM.BUYER_ID = M.MAGE_ID LEFT JOIN TRADE using(TRADE_ID) 
LEFT JOIN SMOKE ON SMOKE.SMOKE_ID=TRADE.SMOKE_ID LEFT JOIN DRUG using(DRUG_ID)
LEFT JOIN MAGE MA ON TM.SELLER_ID = MA.MAGE_ID WHERE TM.BUYER_ID = MAGEID;

    END;
$$;

alter function get_purchases(integer) owner to s265092;

