create function attack_planet(attacking_army integer, attacked_planet integer, army_should_mine boolean) returns text
    language plpgsql
as
$$
declare
    planet_object_id int;
    army_current_planet int;
  begin
    select object_id into planet_object_id from planet where id = attacked_planet;
    
    if not found then
      raise exception 'There is no such planet';
    end if;
    
    select id into army_current_planet from planet where army_id = attacking_army;
    
    if not found then
      raise exception 'You can`t attack your planet';
    end if;
    
    insert into attack (attacker_id, object_id, should_mine) 
    values (attacking_army, planet_object_id, army_should_mine);
    
    return 'Function success';
  end;
$$;

alter function attack_planet(integer, integer, boolean) owner to s264482;

