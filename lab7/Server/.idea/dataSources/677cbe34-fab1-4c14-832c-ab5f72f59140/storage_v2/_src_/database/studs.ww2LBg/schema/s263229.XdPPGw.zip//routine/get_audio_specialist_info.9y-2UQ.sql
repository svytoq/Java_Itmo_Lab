create function get_audio_specialist_info(audio_specialist_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT a.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH FROM audio_specialist AS a 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE a.WORKER_ID = audio_specialist_id;
END
$$;

alter function get_audio_specialist_info(integer) owner to s263229;

