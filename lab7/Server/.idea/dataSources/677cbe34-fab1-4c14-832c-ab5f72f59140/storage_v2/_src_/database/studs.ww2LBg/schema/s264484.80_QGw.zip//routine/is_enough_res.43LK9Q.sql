create function is_enough_res(supplier_id integer, client_id integer, resource_type s264484.resource_type_enum, resource_count integer) returns boolean
    language plpgsql
as
$$
declare
    resource_count_supplier integer;
    resource_count_client   integer;
begin
    if (resource_type = 'food') then
        select food into resource_count_supplier from city where city.id = supplier_id;
        resource_count_supplier = resource_count_supplier - resource_count;
        if (resource_count_supplier >= 0) then
            update city set food = resource_count_supplier where id = supplier_id;
            if (client_id is not null) then
                select food into resource_count_client from city where city.id = client_id;
                resource_count_client = resource_count_client + resource_count;
                update city set food = resource_count_client where id = client_id;
            end if;
            return true;
        end if;
    elsif (resource_type = 'material') then
        select materials into resource_count_supplier from city where city.id = supplier_id;
        resource_count_supplier = resource_count_supplier - resource_count;
        if (resource_count_supplier >= 0) then
            update city set materials = resource_count_supplier where id = supplier_id;
            if (client_id is not null) then
                select materials into resource_count_client from city where city.id = client_id;
                resource_count_client = resource_count_client + resource_count;
                update city set materials = resource_count_client where id = client_id;
            end if;
            return true;
        end if;
    elsif (resource_type = 'arms') then
        select arms into resource_count_supplier from city where city.id = supplier_id;
        resource_count_supplier = resource_count_supplier - resource_count;
        if (resource_count_supplier >= 0) then
            update city set arms = resource_count_supplier where id = supplier_id;
            if (client_id is not null) then
                select arms into resource_count_client from city where city.id = client_id;
                resource_count_client = resource_count_client + resource_count;
                update city set arms = resource_count_client where id = client_id;
            end if;
            return true;
        end if;
    else
        select money into resource_count_supplier from city where city.id = supplier_id;
        resource_count_supplier = resource_count_supplier - resource_count;
        if (resource_count_supplier >= 0) then
            update city set money = resource_count_supplier where id = supplier_id;
            if (client_id is not null) then
                select money into resource_count_client from city where city.id = client_id;
                resource_count_client = resource_count_client + resource_count;
                update city set money = resource_count_client where id = client_id;
            end if;
            return true;
        end if;
    end if;
    return false;

end;
$$;

alter function is_enough_res(integer, integer, s264484.resource_type_enum, integer) owner to s264484;

