create function inset_genres_to_filmes() returns void
    language plpgsql
as
$$
DECLARE
        film record;
        genres record;
BEGIN
        FOR genres IN (SELECT ид from Жанры)
        LOOP
                FOR film IN (SELECT ид from Фильмы)
                LOOP
                        insert into Фильмы_Жанры 
                                values(film.ид, genres.ид);
                END LOOP;
        END LOOP;
END;
$$;

alter function inset_genres_to_filmes() owner to s242395;

