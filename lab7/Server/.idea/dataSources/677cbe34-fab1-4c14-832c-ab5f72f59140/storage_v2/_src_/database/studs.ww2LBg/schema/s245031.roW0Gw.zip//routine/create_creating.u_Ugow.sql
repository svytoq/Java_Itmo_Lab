create function create_creating() returns trigger
    language plpgsql
as
$$
begin
update Существа 
set Урон=NEW.СИЛ/2+(NEW.ЛВК+NEW.ВСП)/4+NEW.УДЧ/3, Защита=NEW.ВНС+NEW.УДЧ+NEW.Базовая_защита where id=new.id;
return new;
end;
$$;

alter function create_creating() owner to s245031;

