create function createcoffee(name text, price double precision, coffee_type text, recipe integer, weight integer) returns text
    strict
    language plpgsql
as
$$
DECLARE
ret int;
BEGIN
	INSERT INTO товар(название, стоимость, вес) VALUES(name, price, weight) RETURNING id INTO ret;
	INSERT INTO кофе(id, товар, тип, рецепт) VALUES(ret, ret, coffee_type, recipe);
	RETURN 'Кофе добавлен, id - ' || ret;
END;
$$;

alter function createcoffee(text, double precision, text, integer, integer) owner to s265082;

