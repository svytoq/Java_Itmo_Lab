create function getforecastforobservatory(observatory_name text)
    returns TABLE(startts timestamp without time zone, endts timestamp without time zone, airtemperature_ real, windspeed_ real, winddirection_ s265111.wind_direction, humidity_ real, pressure_ integer)
    language plpgsql
as
$$
DECLARE
    location_id_local int;
BEGIN
    select locationid into location_id_local from observatory where name = observatory_name;
    return query
        select starttimestamp, endtimestamp, airtemperature, windspeed, winddirection, humidity, pressure
        from forecast
                 inner join forecasttolocation on forecast.id = forecasttolocation.forecastid
                 inner join timestampinterval on timestampinterval.id = forecast.timestampintervalid
        where forecasttolocation.locationid = location_id_local;
END;
$$;

alter function getforecastforobservatory(text) owner to s265111;

