create function increaseaccidents() returns trigger
    language plpgsql
as
$$
begin
        update smoker
            set numberofaccidents = numberofaccidents + 1 where id = new.smokerid;
        RETURN new;
    end;
$$;

alter function increaseaccidents() owner to s207704;

