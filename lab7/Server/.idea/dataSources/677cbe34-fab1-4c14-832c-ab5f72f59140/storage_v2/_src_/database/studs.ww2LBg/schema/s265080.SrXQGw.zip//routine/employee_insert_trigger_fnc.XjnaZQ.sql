create function employee_insert_trigger_fnc() returns trigger
    language plpgsql
as
$$
BEGIN



    INSERT INTO "СИСТЕМА_КОНТРОЛЯ_СОТРУДНИКОВ" ("ЗАРПЛАТА", "ДАТА_НАЧАЛА_РАБОТЫ", "ПРЕМИЯ")
         VALUES(13000,now(),0);



RETURN NEW;

END;

$$;

alter function employee_insert_trigger_fnc() owner to s265080;

