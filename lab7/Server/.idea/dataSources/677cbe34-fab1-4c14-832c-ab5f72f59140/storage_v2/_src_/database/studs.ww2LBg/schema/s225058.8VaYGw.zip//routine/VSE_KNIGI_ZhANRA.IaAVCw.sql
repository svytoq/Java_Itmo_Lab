create function "ВСЕ_КНИГИ_ЖАНРА"(genre character varying)
    returns TABLE("НАЗВАНИЕ" character varying, "СТРАНА" character varying, "ДАТА_ПУБЛИКАЦИИ" date)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT КНИГИ.НАЗВАНИЕ, КНИГИ.СТРАНА, КНИГИ.ДАТА_ПУБЛИКАЦИИ 
FROM КНИГИ WHERE ЖАНР=genre;
END;
$$;

alter function "ВСЕ_КНИГИ_ЖАНРА"(varchar) owner to s225058;

