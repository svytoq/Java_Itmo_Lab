create function some_f(_tbl regclass, OUT result integer) returns integer
    language plpgsql
as
$$
BEGIN
EXECUTE format('SELECT * FROM %s ', _tbl)
INTO result;
END
$$;

alter function some_f(regclass, out integer) owner to s243858;

