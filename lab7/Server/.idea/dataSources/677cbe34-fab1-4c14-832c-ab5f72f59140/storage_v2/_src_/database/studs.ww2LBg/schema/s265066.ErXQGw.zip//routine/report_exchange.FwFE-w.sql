create function report_exchange(ex_state_text text, exc_id integer, msg_text text) returns integer
    language plpgsql
as
$$
declare
    ex_state msg_ex_states;
begin
    ex_state = ex_state_text::msg_ex_states;
    if ex_state='scheduled' then
        raise exception 'incorrect state';
    end if;
    if ex_state='ok' then
        perform exchange_ok(exc_id, msg_text);
    else
        perform exchange_fail(exc_id);
    end if;
    return 1;
end;
$$;

alter function report_exchange(text, integer, text) owner to s265066;

