create function degrant_worker(worker_id integer) returns void
    language sql
as
$$
update user_profile set privilege = 'worker' where user_profile_id = $1;
    -- must not delete from the worker table.
$$;

alter function degrant_worker(integer) owner to s267880;

