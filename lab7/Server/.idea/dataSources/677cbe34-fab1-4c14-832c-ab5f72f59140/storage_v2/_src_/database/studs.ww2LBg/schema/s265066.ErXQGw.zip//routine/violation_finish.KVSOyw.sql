create function violation_finish(check_id integer, verd s265066.violation_verdicts, restriction date, com text) returns integer
    language plpgsql
as
$$
declare
    violation integer;
    person bigint;
begin
    if not exists(
            select 1 from Violation_check_employees
            where violation_check_id=check_id
        ) 
    then return 0;
    end if;

    select violation_id into violation from Violation_checks 
        where violation_check_id=check_id;

    update Violation_checks set
        verdict = verd,
        restrict_until = restriction,
        verdict_date = current_date,
        verdict_comment = com,
        is_finished = true
        where violation_check_id = check_id;

    update Violations set violation_state = 'done'
        where violation_id = violation;

    select person_id into person from Violations
        where violation_id=violation;

    update People set restrict_until = restriction
        where person_id = person;

    if restriction > current_date then
        update Visas set visa_state = 'suspended'
            where person_id = person and
                visa_state != 'expired';
    end if;
    return 1;
end;
$$;

alter function violation_finish(integer, s265066.violation_verdicts, date, text) owner to s265066;

