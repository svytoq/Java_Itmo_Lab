create function сгенерировать_залы("число_на_кинотеатр" integer) returns void
    language plpgsql
as
$$
DECLARE
        currId int = 0;
        row RECORD;
BEGIN
            SELECT MAX(ид) + 1 INTO currId FROM Залы;
            IF currId IS NULL THEN
                currId = 0;
            END IF;

        FOR row IN SELECT * FROM Кинотеатры LOOP
                FOR j IN 1 .. число_на_кинотеатр LOOP
                        INSERT INTO Залы(ид, ид_кинотеатра, номер_зала) VALUES (currId, row.ид, currId + 1);
                        currId = currId + 1;
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_залы(integer) owner to s224932;

