create function add_to_ser(n integer) returns void
    language plpgsql
as
$$
DECLARE
  NM VARCHAR ;

  BODY TEXT;
  I INTEGER;
BEGIN
  NM = 'SERIA';
 BODY = 'ABRACADABRA';

 FOR I IN 1..N LOOP
   INSERT INTO SERIES VALUES (DEFAULT , BODY, NM);
   NM=NM||I;
     BODY=BODY||I;

 END LOOP;
END;

$$;

alter function add_to_ser(integer) owner to s225081;

