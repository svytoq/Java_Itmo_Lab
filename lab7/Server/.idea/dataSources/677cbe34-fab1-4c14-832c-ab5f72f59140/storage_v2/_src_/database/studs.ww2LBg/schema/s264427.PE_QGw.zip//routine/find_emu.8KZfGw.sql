create function find_emu(emu_group integer, scout integer, date_reg date DEFAULT '1932-11-30'::date) returns text
    language plpgsql
as
$$
DECLARE
	val text;
	counte integer = 1;
	counter_info integer;
	square_emu integer;
	square_scout integer;
	mas_size integer;
	mas_scout integer ARRAY[100];
BEGIN
	Select square_number INTO STRICT square_emu from Migration_data where Migration_data.emu_group_id = $1
		ORDER BY migration_data_id DESC LIMIT 1;
	Select square_number INTO STRICT square_scout from ScoutsOrnithologist where ScoutsOrnithologist.scout_id = $2;
	if square_emu = square_scout THEN 
		val := 'Emu don`t change reg';
	ELSE
		val := 'Migration`s data change';
		INSERT INTO Migration_Data (square_number, scout_id, emu_group_id, date_create) VALUES (square_scout, $2, $1, $3);
		Select array_agg(ScoutsOrnithologist.scout_id) INTO STRICT mas_scout from ScoutsOrnithologist 
			where ScoutsOrnithologist.square_number = square_scout;
		Select count(square_number) INTO STRICT mas_size from ScoutsOrnithologist 
			where ScoutsOrnithologist.square_number = square_scout;
		while counte <= mas_size
		LOOP
			Select ScoutsOrnithologist.counter_data INTO STRICT counter_info FROM ScoutsOrnithologist 
				where ScoutsOrnithologist.scout_id = mas_scout[counte];
			counter_info := 1 + counter_info;
			UPDATE ScoutsOrnithologist SET counter_data = counter_info 
				where ScoutsOrnithologist.scout_id = mas_scout[counte];
			counte := counte + 1;
		END LOOP;
	END IF;
	RETURN val;
END;
$$;

alter function find_emu(integer, integer, date) owner to s264427;

