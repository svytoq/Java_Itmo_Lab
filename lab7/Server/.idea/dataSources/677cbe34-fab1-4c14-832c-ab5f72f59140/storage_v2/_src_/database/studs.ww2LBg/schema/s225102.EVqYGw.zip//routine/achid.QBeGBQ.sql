create function achid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('achievements_id_seq')!=NEW.ID THEN
NEW.ID=nextval('achievements_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function achid() owner to s225102;

