create function add_musician_in_group(integer, integer, integer, character varying) returns void
    language sql
as
$$
START TRANSACTION;
	INSERT INTO музыкант
	VALUES ($1, $2)
	;
	INSERT INTO состав
	VALUES ($3, $1, $4)
	;
COMMIT;
$$;

alter function add_musician_in_group(integer, integer, integer, varchar) owner to s223758;

