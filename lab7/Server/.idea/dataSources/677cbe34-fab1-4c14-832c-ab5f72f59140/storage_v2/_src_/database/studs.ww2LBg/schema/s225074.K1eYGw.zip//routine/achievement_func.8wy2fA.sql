create function achievement_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.ach_id:= NEXTVAL('achievement_seq');
RETURN new;
END;
$$;

alter function achievement_func() owner to s225074;

