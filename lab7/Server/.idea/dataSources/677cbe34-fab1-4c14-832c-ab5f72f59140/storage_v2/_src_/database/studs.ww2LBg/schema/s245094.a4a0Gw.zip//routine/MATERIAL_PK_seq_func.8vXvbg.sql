create function "МАТЕРИАЛ_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "МАТЕР_ИД" FROM "МАТЕРИАЛ");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."МАТЕР_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''МАТЕРИАЛ_МАТЕР_ИД_seq'', max("МАТЕР_ИД") + 1) FROM "МАТЕРИАЛ"';
                        NEW."МАТЕР_ИД" := max_id + 1;
                END IF; 
                RETURN NEW;
        END;
$$;

alter function "МАТЕРИАЛ_PK_seq_func"() owner to s245094;

