create function checktime() returns trigger
    language plpgsql
as
$$
declare a time;
declare b time;
begin
	a := (Select min(ВРЕМЯ_НАЧАЛА_РАБОТЫ) from СОТРУДНИКИ inner join ПРИВЯЗКА_СОТРУДНИКА using (ИД_СОТРУДНИКА) inner join ОТДЕЛЫ using (ИД_ОТДЕЛА) inner join ЗДАНИЕ using (ИД_ЗДАНИЯ) where ИД_СОТРУДНИКА = new.ИД_СОТРУДНИКА);
	b := (Select min(ВРЕМЯ_КОНЦА_РАБОТЫ) from СОТРУДНИКИ inner join ПРИВЯЗКА_СОТРУДНИКА using (ИД_СОТРУДНИКА) inner join ОТДЕЛЫ using (ИД_ОТДЕЛА) inner join ЗДАНИЕ using (ИД_ЗДАНИЯ) where ИД_СОТРУДНИКА = new.ИД_СОТРУДНИКА);
	if (a > new.ВРЕМЯ_НАЧАЛА or a is null) then
	raise notice 'Time begin of programm must be greater then begin time of building';
	return null;
	else
	if (b < new.ВРЕМЯ_КОНЦА or b is null) then
	raise notice 'Time end of programm must be smaller then end time of building';
	return null;
	else
	return new;
	end if;
	end if;
end;
$$;

alter function checktime() owner to s225120;

