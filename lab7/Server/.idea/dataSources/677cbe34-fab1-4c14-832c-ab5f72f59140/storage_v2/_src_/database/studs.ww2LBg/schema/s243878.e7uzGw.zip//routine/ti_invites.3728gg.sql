create function ti_invites()
    returns TABLE(team text, team_id integer, region_name text, dpc_points integer)
    language plpgsql
as
$$
begin 
return query 
select team.name as team, team.id as team_id, region.name as region_name, team.dpc_points as dpc_points
from team 
join region on (team.region_id = region.id)
where team.dpc_points>=0
order by team.dpc_points desc
limit 8;
end
$$;

alter function ti_invites() owner to s243878;

