create function creature() returns trigger
    language plpgsql
as
$$
begin
new.Урон:=(select СИЛ/2+(ЛВК+ВСП)/4+УДЧ/3 from Характеристики where new.Характеристики=Характеристики.id);
new.Защита:=(select ВНС+УДЧ+Базовая_защита from Характеристики where new.Характеристики=Характеристики.id);
return new;
end;
$$;

alter function creature() owner to s245031;

