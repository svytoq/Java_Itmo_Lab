create function check_unit_not_claimed_by_many_entities() returns trigger
    language plpgsql
as
$$
DECLARE
	amount int;
	sum int = 0;
BEGIN
	IF (is_unit_instance_claimed(NEW.unit)) THEN
		RAISE EXCEPTION 
			'Unit % claimed by many entities
			%', NEW.unit, NEW;
	END IF;

	RETURN NEW;
END;
$$;

alter function check_unit_not_claimed_by_many_entities() owner to s244711;

