create function check_worm_occupation() returns trigger
    language plpgsql
as
$$
DECLARE
        req_occ text;
        flag int;
    BEGIN
        SELECT required_occupation INTO req_occ
            FROM weapons WHERE id = NEW.weapon_id;
        SELECT COUNT(*) INTO flag
            FROM worm_occupations WHERE worm_id = NEW.worm_id AND occupation = req_occ;
        IF flag = 0 THEN
            RAISE EXCEPTION 'Worm % does not have the required occupation for weapon %', NEW.worm_id, NEW.weapon_id;
        END IF;
        RETURN NEW;
    END;
$$;

alter function check_worm_occupation() owner to s265098;

