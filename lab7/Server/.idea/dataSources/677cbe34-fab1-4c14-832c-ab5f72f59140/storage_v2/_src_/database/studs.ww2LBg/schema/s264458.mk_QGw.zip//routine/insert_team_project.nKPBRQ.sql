create function insert_team_project(team_id integer, project_id integer) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO team_project (team_id,
                project_id)

  VALUES (insert_team_project.team_id,
      insert_team_project.project_id);
END;

$$;

alter function insert_team_project(integer, integer) owner to s264458;

