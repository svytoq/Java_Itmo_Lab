create function копировать_в_историю("ид_государства" integer, "дата_начала" timestamp without time zone, "дата_конца" timestamp without time zone, "титул" character varying) returns void
    language plpgsql
as
$$
DECLARE
id_king integer;
id_souz integer;
BEGIN
IF ид_государства IS NULL OR дата_конца IS NULL OR дата_начала IS NULL THEN
RAISE EXCEPTION 'Some fields can''t been null';
ELSE
id_king := (SELECT ИД_ПРАВИТЕЛЯ FROM ГОСУДАРСТВА WHERE ИД = ид_государства);
id_souz := (SELECT ИД_СОЮЗА FROM ГОСУДАРСТВА WHERE ИД = ид_государства);
INSERT INTO ИСТОРИЯ(ИД_ГОСУДАРСТВА,ДАТА_НАЧАЛА,ДАТА_КОНЦА,ИД_СОЮЗА,ИД_ПРАВИТЕЛЯ,ТИТУЛ_ПРАВИТЕЛЯ) VALUES 
( ид_государства,дата_начала,дата_конца,id_souz,id_king,титул);
END IF;
END
$$;

alter function копировать_в_историю(integer, timestamp, timestamp, varchar) owner to s243853;

