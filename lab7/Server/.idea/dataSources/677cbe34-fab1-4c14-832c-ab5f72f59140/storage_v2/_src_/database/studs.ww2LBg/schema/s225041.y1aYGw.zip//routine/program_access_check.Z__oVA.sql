create function program_access_check() returns trigger
    language plpgsql
as
$$
DECLARE 
		a_record record;
	BEGIN
		FOR a_record IN (
			SELECT * FROM ACCESS_REGIME
            JOIN ROOM ON ROOM.access_fk = ACCESS_REGIME.access_fk
            JOIN PRISONER ON PRISONER.regime_fk = ACCESS_REGIME.regime_fk
            JOIN PROGRAM ON PROGRAM.room_fk = ROOM.id
            WHERE PROGRAM.id = NEW.program_fk
           	AND PRISONER.id = NEW.prisoner_fk
		)
		LOOP 
			RETURN NEW;
		END LOOP;
		RAISE EXCEPTION 'Prisoner has no access to the room where the program happens.';
	END;
$$;

alter function program_access_check() owner to s225041;

