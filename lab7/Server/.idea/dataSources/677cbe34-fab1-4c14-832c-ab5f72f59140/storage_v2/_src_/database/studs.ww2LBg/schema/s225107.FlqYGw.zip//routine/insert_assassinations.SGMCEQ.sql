create function insert_assassinations() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
    killr integer = trunc(random()*10000)+1;
    victm integer = trunc(random()*10000)+1;
    result bool;
  BEGIN
    LOOP
      killr = trunc(random()*10000)+1;
      victm = trunc(random()*10000)+1;
      result = random()>0.5;
      IF (NOT  killr = victm)
        THEN
          INSERT INTO assassinations VALUES (DEFAULT, killr, victm, trunc(random()*10000)+1, '5/13/1998', result);
          count = count + 1;
      END IF;
      EXIT WHEN count = 1000;
    END LOOP;
  END;
$$;

alter function insert_assassinations() owner to s225107;

