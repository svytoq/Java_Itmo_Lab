create function getrichpeople()
    returns TABLE(id integer, first_name character varying, last_name character varying, lvl integer)
    language sql
as
$$
select a.id, first_name, last_name, lvl
from human_blood_flow_human as a
         inner join human_blood_flow_humanwealthlvl as b on a.wealth_id = b.id
where lvl > 40
$$;

alter function getrichpeople() owner to s278068;

