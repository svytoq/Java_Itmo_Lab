create function after_drop_specific_offer_request() returns trigger
    language plpgsql
as
$$
DECLARE
    REQUEST_ID INTEGER := (SELECT ID
                        FROM REQUEST
                        WHERE ID = OLD.REQUEST);
BEGIN
    DELETE FROM REQUEST WHERE ID = REQUEST_ID;
    RETURN OLD;
END;
$$;

alter function after_drop_specific_offer_request() owner to s265090;

