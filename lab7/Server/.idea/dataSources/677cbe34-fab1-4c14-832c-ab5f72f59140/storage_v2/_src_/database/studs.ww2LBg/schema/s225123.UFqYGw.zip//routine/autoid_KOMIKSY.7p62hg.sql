create function "autoid_КОМИКСЫ"() returns trigger
    language plpgsql
as
$$
DECLARE prevID smallint;
BEGIN
	IF (SELECT count(*) FROM КОМИКСЫ) = 0 THEN
		NEW.ИД_КОМИКСА = 1;	
	ELSE
		prevID = (SELECT ИД_КОМИКСА FROM КОМИКСЫ WHERE ИД_КОМИКСА = (SELECT MAX(ИД_КОМИКСА) FROM КОМИКСЫ));
		NEW.ИД_КОМИКСА = prevID + 1;
	END IF;
	RETURN NEW;
END;
$$;

alter function "autoid_КОМИКСЫ"() owner to s225123;

