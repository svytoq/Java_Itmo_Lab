create function killfighter(fighterid integer) returns integer
    language plpgsql
as
$$
declare begin DELETE FROM "fighter" WHERE "id" = fighterID; return 1;end;
$$;

alter function killfighter(integer) owner to s263884;

