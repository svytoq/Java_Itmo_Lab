create function add_repairs(count integer) returns void
    language plpgsql
as
$$
DECLARE
s_ids integer[];
s_ids_count integer := 0;
s_id integer := 0;
things text[] := '{
стол,
холодильник,
шкаф,
кровать,
розетки,
пол}';
t integer := 0;
e_date timestamp;
BEGIN
SELECT COUNT(*) INTO s_ids_count FROM ПРОЖИВАЮЩИЙ;
s_ids := array(SELECT ИД FROM ПРОЖИВАЮЩИЙ);

FOR i IN 1..count LOOP
s_id := random() * (s_ids_count - 1) + 1;
t := random() * 5 + 1;
SELECT ДАТА_ЗАСЕЛЕНИЯ INTO e_date FROM ПРОЖИВАЮЩИЙ WHERE ИД = s_ids[s_id];

INSERT INTO ЗАЯВКИ_НА_РЕМОНТ VALUES(i, 'Просим починить в нашей комнате ' || things[t], e_date + random() * (current_date - e_date), s_ids[s_id]);
END LOOP;
END;
$$;

alter function add_repairs(integer) owner to s225141;

