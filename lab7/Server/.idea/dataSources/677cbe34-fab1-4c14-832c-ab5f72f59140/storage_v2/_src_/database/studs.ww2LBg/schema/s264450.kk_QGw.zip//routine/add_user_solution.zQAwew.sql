create function add_user_solution(user_login text, solution_location text, solution_language text, comp_id integer) returns void
    language plpgsql
as
$$
BEGIN
insert into solution(participant_id, solution_compiler_id, competition_id, creation_time, file_location, compilation_status) 
values (
(select id from competition_participant where base_user_login like user_login limit 1),
(select id from solution_compiler where language like solution_language limit 1),
comp_id,
current_timestamp,
solution_location,
'Submitted'
);
END;
$$;

alter function add_user_solution(text, text, text, integer) owner to s264450;

