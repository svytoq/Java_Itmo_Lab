create function add_staff(n text, dob date, pl_name text, un text, p text) returns void
    language plpgsql
as
$$
DECLARE
    _id_character int;
BEGIN
    INSERT INTO characters (name, date_of_birth, username, password)
    VALUES (n, dob, un, p)
    RETURNING id INTO _id_character;
    INSERT INTO character_roles (role_id, character_id)
    VALUES (1, _id_character);
    INSERT INTO staff (character_id, place_id)
    VALUES (_id_character, (
        SELECT places.id
        FROM places
                 JOIN locations ON places.location_id = locations.id
        WHERE places.name = pl_name
    ));
END
$$;

alter function add_staff(text, date, text, text, text) owner to s278172;

