create function check_mmr() returns trigger
    language plpgsql
as
$$
BEGIN
   IF (NEW.ММР )
    < (4500) THEN
      RAISE EXCEPTION 'Нельзя добавлять слишком слабых игроков';
   END IF;
   RETURN NEW;
END
$$;

alter function check_mmr() owner to s241870;

