create function trfunccalculatemarketpricecars() returns trigger
    language plpgsql
as
$$
BEGIN
NEW.market_price := NEW.bought_price + POWER((2020 - NEW.year_of_production), 2) * 300 + 20000000 / (SELECT NUMBER_OF_CARS_PRODUCED FROM ABSTR_CARS WHERE ABSTR_CARS.ABSTR_CAR_ID = NEW.abstr_car_id) + 20000000 / NEW.mileage + NEW.bought_price * 65 / 100;
return NEW;
END;
$$;

alter function trfunccalculatemarketpricecars() owner to s265085;

