create function pk_func_type_ex() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_type_ex');
  RETURN new;
END;
$$;

alter function pk_func_type_ex() owner to s223457;

