create function incweapons() returns void
    language plpgsql
as
$$
DECLARE i INTEGER :=0;
BEGIN
  FOR i IN 0..100000 LOOP
    IF i%10=0 THEN
      INSERT INTO WEAPON VALUES (i, 'common', 'M9', 400,25,13.75,'middle',16,1.6);
      INSERT INTO COMMON_WEAPONS VALUES (i,true,i%10000);
    ELSEIF i%10=1 THEN
      INSERT INTO WEAPON VALUES (i, 'common', 'G18',900,20,12.5,'far',20,1.6);
      INSERT INTO COMMON_WEAPONS VALUES (i,true,i%10000);
    ELSEIF i%10=2 THEN
      INSERT INTO WEAPON VALUES (i, 'class', 'M16A3', 800,25,18.4,'very_far',31,2.37);
      INSERT INTO CLASS_WEAPONS VALUES (i, 'Assault',i%10000);
    ELSEIF i%10=3 THEN
      INSERT INTO WEAPON VALUES (i, 'class', 'M416', 750,25,18.4,'far',31,2.5);
      INSERT INTO CLASS_WEAPONS VALUES (i, 'Assault',i%10000);
    ELSEIF i%10=4 THEN
      INSERT INTO WEAPON VALUES (i, 'class', 'M4A1', 800,25,14.3,'middle',31,2.48);
      INSERT INTO CLASS_WEAPONS VALUES (i, 'Engineer',i%10000);
    ELSEIF i%10=5 THEN
      INSERT INTO WEAPON VALUES (i, 'class', 'G36C', 750,25,14.3,'middle',31,2.85);
      INSERT INTO CLASS_WEAPONS VALUES (i, 'Engineer',i%10000);
    ELSEIF i%10=6 THEN
      INSERT INTO WEAPON VALUES (i, 'class', 'M27 IAR', 750,25,18.4,'middle',46,2.5);
      INSERT INTO CLASS_WEAPONS VALUES (i, 'Support',i%10000);
    ELSEIF i%10=7 THEN
      INSERT INTO WEAPON VALUES (i, 'class', 'RPK-74M', 700,25,18.4,'middle',46,4);
      INSERT INTO CLASS_WEAPONS VALUES (i, 'Support',i%10000);
    ELSEIF i%10=8 THEN
      INSERT INTO WEAPON VALUES (i, 'class', 'MK11 MOD 0', 260,50,37.5,'very_far',11,2.4);
      INSERT INTO CLASS_WEAPONS VALUES (i, 'Recon',i%100000);
    ELSE
      INSERT INTO WEAPON VALUES (i, 'class', 'M98B', 46.2,95,59,'very_far',6,4.7);
      INSERT INTO CLASS_WEAPONS VALUES (i, 'Recon',i%10000);
    end if;
    i:=i+1;
  END LOOP;
end;
$$;

alter function incweapons() owner to s225100;

