create function delivery_time_after_order_time() returns trigger
    language plpgsql
as
$$
DECLARE order_time timestamp := (
        SELECT order_time FROM customer_order WHERE id = NEW.order_id
    );

    BEGIN
        IF NEW.delivery_time - order_time >= interval '2 hour' THEN
            RETURN NEW;
        END IF;
        RETURN NULL;
    END;
$$;

alter function delivery_time_after_order_time() owner to s265092;

