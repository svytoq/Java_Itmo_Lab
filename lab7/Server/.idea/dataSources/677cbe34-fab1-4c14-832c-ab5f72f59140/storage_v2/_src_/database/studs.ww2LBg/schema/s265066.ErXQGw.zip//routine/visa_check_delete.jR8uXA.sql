create function visa_check_delete(id integer) returns integer
    language plpgsql
as
$$
declare
    application_id integer;
begin
    select visa_app_id into application_id from Visa_checks where visa_check_id=id;
    update Visa_applications set 
        visa_app_state='awaits_review'
        where visa_app_id=application_id;
    delete from Visa_check_employees where visa_check_id=id;
    delete from Visa_checks where visa_check_id=id;
    return 1;
end;
$$;

alter function visa_check_delete(integer) owner to s265066;

