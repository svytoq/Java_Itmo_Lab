create function check_if_this_worker_exists() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
   IF (EXISTS(SELECT person_id FROM base_worker WHERE person_id = NEW.person_id)) THEN
     RAISE EXCEPTION 'no, this person is already a worker';
   END IF;
   RETURN NEW;
END;
$$;

alter function check_if_this_worker_exists() owner to s270250;

