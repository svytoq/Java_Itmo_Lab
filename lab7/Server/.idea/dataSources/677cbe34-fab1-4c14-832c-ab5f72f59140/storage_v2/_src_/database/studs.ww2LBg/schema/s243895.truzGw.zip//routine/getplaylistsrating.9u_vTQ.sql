create function getplaylistsrating(id bigint) returns bigint[]
    language plpgsql
as
$$
declare
	rating bigint[2];
	likes bigint = 0;
	dislikes bigint = 0;
	begin
	rating[1] = 0;
	rating[2] = 0;
	Select count (rate) into likes from playlist_rate WHERE playlist_id=id AND rate > 0 GROUP BY playlist_id;
	Select count  (rate) into dislikes from playlist_rate WHERE playlist_id=id AND rate < 0 GROUP BY playlist_id;
	if (likes is not NULL) then rating[1]=likes;
	end if;
	if (dislikes is not NULL) then rating[2]=dislikes;
	end if;
	return rating;
	end;
$$;

alter function getplaylistsrating(bigint) owner to s243895;

