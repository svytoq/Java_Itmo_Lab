create function asoiafgetcomparable(t_arr integer[]) returns bigint
    language plpgsql
as
$$
DECLARE
  i int = 1;
  NULLFound bool = false;
  asoiafTmstmp bigint = 0 ;
BEGIN
  IF t_arr[1] IS NULL THEN
    RETURN NULL;
  END IF;

  WHILE (NOT NULLFound = true) AND i < 6 LOOP
    raise notice 'as: %, %', asoiafTmstmp, t_arr[i];
    IF t_arr[i] IS NOT NULL THEN
      asoiafTmstmp = asoiafTmstmp * 10^2 + t_arr[i];
      i = i + 1;
    ELSE
      NULLFound = true;
    END IF;
  END LOOP;

  WHILE i <= 6 LOOP
    asoiafTmstmp = asoiafTmstmp * 10^2;
    i = i +1;
  END LOOP;

  raise notice '%', asoiafTmstmp;
  RETURN asoiafTmstmp;
END
$$;

alter function asoiafgetcomparable(integer[]) owner to s225125;

