create function wondersid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('wonders_id_seq')!=NEW.ID THEN
NEW.ID=nextval('wonders_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function wondersid() owner to s225102;

