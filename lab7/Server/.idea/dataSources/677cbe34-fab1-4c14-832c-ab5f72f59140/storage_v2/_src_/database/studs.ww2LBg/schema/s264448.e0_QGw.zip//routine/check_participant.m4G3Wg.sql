create function check_participant() returns trigger
    language plpgsql
as
$$
BEGIN
    IF people_age(NEW.person_id) > 27 THEN
        RAISE EXCEPTION 'participant should be under 27';
    END IF;

    IF EXISTS(SELECT *
              FROM mentor
              WHERE NEW.person_id = mentor.person_id
                AND NEW.championship_id = mentor.championship_id) THEN
        RAISE EXCEPTION 'participant can not be a mentor in the same championship';
    END IF;

    IF EXISTS(SELECT *
              FROM judge
              WHERE NEW.person_id = judge.person_id
                AND NEW.championship_id = judge.championship_id) THEN
        RAISE EXCEPTION 'participant can not be a judge in the same championship';
    END IF;

    IF NEW.team_id IS NOT NULL AND NEW.championship_id != ANY
                                   (SELECT participant.championship_id
                                    FROM participant
                                    WHERE team_id = NEW.team_id) THEN
        RAISE EXCEPTION 'Participants in one team should be from one championship';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_participant() owner to s264448;

