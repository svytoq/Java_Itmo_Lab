create function season_ins_succ() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO стадии(сезон_ид, типс_ид, начало) VALUES (new.ид, (SELECT ид FROM типы_стадий WHERE название LIKE 'Регулярный сезон'), new.начало);
    IF new.конец IS NOT NULL THEN
        INSERT INTO стадии(сезон_ид, типс_ид, конец) VALUES (new.ид, (SELECT ид FROM типы_стадий WHERE название LIKE 'Плей-офф'), new.конец);
    END IF;
    RETURN NEW;
END;
$$;

alter function season_ins_succ() owner to s242558;

