create function _trigger_check_product() returns trigger
    language plpgsql
as
$$
declare
    tea_id integer := null;
begin
     select super_id from tea where super_id = new.product_id into tea_id;
     if tea_id IS NULL then
         select super_id from tea_composition where super_id = new.product_id into tea_id;
     end if;

     if tea_id is not null then
         return new;
     end if;
     return null;

end;
$$;

alter function _trigger_check_product() owner to s264429;

