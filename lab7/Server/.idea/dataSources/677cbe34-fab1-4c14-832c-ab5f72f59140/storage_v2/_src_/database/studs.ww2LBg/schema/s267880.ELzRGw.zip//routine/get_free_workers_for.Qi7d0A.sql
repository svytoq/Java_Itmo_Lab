create function get_free_workers_for(product_order_id integer) returns SETOF s267880.worker_with_profile
    language sql
as
$$
select * from worker_with_profile
    where worker_id not in (
        select worker_id from product_making
        where product_order_id = $1
    );
$$;

alter function get_free_workers_for(integer) owner to s267880;

