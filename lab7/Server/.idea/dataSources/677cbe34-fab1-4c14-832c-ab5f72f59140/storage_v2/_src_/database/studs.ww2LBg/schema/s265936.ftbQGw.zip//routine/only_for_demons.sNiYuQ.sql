create function only_for_demons() returns trigger
    language plpgsql
as
$$
DECLARE
t_worker int;
worker_world int;
BEGIN
t_worker = (select worker_id from demon_card where id = new.id);
worker_world = (select world_id from worker join demon_card dc on worker.id = dc.worker_id
    where dc.id = new.id);
if (worker_world != 2) then
    raise exception 'Зарплатную карточку можно завести только на работника из Ада';
    else return new;
end if;
END;
$$;

alter function only_for_demons() owner to s265936;

