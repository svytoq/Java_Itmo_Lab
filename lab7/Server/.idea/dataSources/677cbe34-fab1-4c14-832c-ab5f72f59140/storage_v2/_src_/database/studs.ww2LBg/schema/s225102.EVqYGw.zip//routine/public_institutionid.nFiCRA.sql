create function public_institutionid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('public_institution_id_seq')!=NEW.ID THEN
NEW.ID=nextval('public_institution_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function public_institutionid() owner to s225102;

