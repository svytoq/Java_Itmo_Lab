create function mark_to_int(mark text) returns integer
    language plpgsql
as
$$
begin
  if mark = 'освобождение' then return NULL;
  elseif mark = 'диплом с отлиием' then return NULL;
  elseif mark = '2' then return 2;
  elseif mark = 'незач' then return 2;
  elseif mark = 'неявка' then return 2;
  elseif mark = '3' then return 3;
  elseif mark = '4' then return 4;
  elseif mark = '5' then return 5;
  end if;
end
$$;

alter function mark_to_int(text) owner to s225125;

