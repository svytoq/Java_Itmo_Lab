create function bomb() returns trigger
    language plpgsql
as
$$
BEGIN
IF (exists(SELECT "player"."team_id" FROM "player" WHERE "player"."id" = NEW."player_id_bomber") <> exists(SELECT "player"."team_id" FROM "player" WHERE "player"."id" = new."player_id_sapper")) THEN RETURN new;
ELSE RAISE EXCEPTION 'Бомбер и сапёр не могут быть в одной команде';
END IF;
RETURN NULL;
END;
$$;

alter function bomb() owner to s225090;

