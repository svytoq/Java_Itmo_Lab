create function внесение(name1 text, name2 text, otn text) returns void
    language plpgsql
as
$$
DECLARE
chel1 int;
chel2 int;
rel int;
BEGIN
SELECT ИД INTO STRICT chel1 FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=name1 or ИМЯ_ЧЕЛ=name1;
SELECT ИД INTO STRICT chel2 FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=name2 or ИМЯ_ЧЕЛ=name2;
SELECT ИД INTO STRICT rel FROM ОТНОШЕНИЕ WHERE ОТНОШЕНИЕ=otn;
EXCEPTION
	WHEN NO_DATA_FOUND THEN 
		RAISE NOTICE 'You entered incorrect data';
		RETURN;
INSERT INTO СВЯЗЬ_ОТН VALUES(chel1, chel2, rel);
raise notice 'Inserted into СВЯЗЬ_ОТН %, %, %', chel1, chel2, rel;
END;
$$;

alter function внесение(text, text, text) owner to s225106;

