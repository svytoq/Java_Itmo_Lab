create function athlete_cant_be_staff_check() returns trigger
    language plpgsql
as
$$
DECLARE
    person_athlete_id integer := (NEW.id_person);
    person_staff_id   integer := (SELECT ID
                                  FROM Staff_Volunteers
                                  WHERE ID_Person = person_athlete_id);
BEGIN
    IF
        (person_staff_id IS NOT NULL) THEN
        RAISE EXCEPTION 'athlete cant be staff worker';
    END IF;
    RETURN NEW;
END;
$$;

alter function athlete_cant_be_staff_check() owner to s273720;

