create function prid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_ПРОГРАММЫ := nextval('programms_seq');
	return new;
end
$$;

alter function prid() owner to s225120;

