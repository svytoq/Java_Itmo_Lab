create function note_hearts_counter_cache_update() returns trigger
    language plpgsql
as
$$
begin
if tg_op = 'INSERT'
then update notes set heart_count = heart_count + 1 where id = new.note_id;
end if;

if tg_op = 'DELETE'
then update notes set heart_count = heart_count - 1 where id = old.note_id;
end if;

return null;
end;
$$;

alter function note_hearts_counter_cache_update() owner to s243871;

