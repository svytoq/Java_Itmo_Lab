create function "РЕДАКЦИИ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('РЕДАКЦИИ_ИД_РЕДАКЦИИ_seq')!=NEW.ИД_РЕДАКЦИИ 
THEN NEW.ИД_РЕДАКЦИИ=nextval('РЕДАКЦИИ_ИД_РЕДАКЦИИ_seq'); 
  RETURN NEW;
ELSE 
  RETURN NEW;
END IF; 
END;
$$;

alter function "РЕДАКЦИИ_ИД"() owner to s225071;

