create function private_messages("id_ОТПРАВИТЕЛЬ" integer, "id_ПОЛУЧАТЕЛЯ" integer)
    returns TABLE("ИД" bigint, "ДАТА" timestamp without time zone, "СООБЩЕНИЕ" text, "ИД_ПОЛУЧАТЕЛЯ" integer, "ИД_ОТПРАВИТЕЛЬ" integer)
    language sql
as
$$
SELECT * FROM ЛИЧНЫЕ_СООБЩЕНИЯ WHERE ((ИД_ОТПРАВИТЕЛЬ = $1 AND ИД_ПОЛУЧАТЕЛЯ =$2) OR (ИД_ОТПРАВИТЕЛЬ = $2 AND ИД_ПОЛУЧАТЕЛЯ =$1));
$$;

alter function private_messages(integer, integer) owner to s243880;

