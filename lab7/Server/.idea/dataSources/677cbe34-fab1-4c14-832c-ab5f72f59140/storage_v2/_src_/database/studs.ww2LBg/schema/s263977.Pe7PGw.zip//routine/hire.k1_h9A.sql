create function hire(id_isbs integer, worker_id integer) returns void
    language plpgsql
as
$$
BEGIN
    IF ((SELECT count(*) FROM volunteer WHERE on_work = true AND id = worker_id) > 0) THEN
        RAISE NOTICE 'Данный работник уже состоит у нас в организации';
    ELSEIF ((SELECT count(*) FROM volunteer WHERE on_work = false AND id = worker_id) > 0) THEN
        IF ((SELECT count(*) FROM isbs WHERE id = id_isbs) > 0) THEN
            IF ((SELECT oxygen FROM isbs WHERE id = id_isbs) > 0)
                AND ((SELECT food FROM isbs WHERE id = id_isbs) > 0
                    AND (SELECT is_work FROM isbs WHERE id = id_isbs) = true
                    AND (SELECT money FROM total_money) > (SELECT cost FROM volunteer WHERE id = worker_id)) THEN
                UPDATE volunteer SET on_work = true, isbs_id = id_isbs WHERE id = worker_id;
                UPDATE total_money SET money = money - (SELECT cost FROM volunteer WHERE id = worker_id);
                RAISE NOTICE 'Работник нанят';
            ELSE RAISE NOTICE 'Данный купол не пригоден для жизни, либо у вас недостаточно средств';
            END IF;
        ELSE RAISE NOTICE 'Данный купол не найден';
        END IF;
    ELSE RAISE NOTICE 'Данный работник не найден';
    END IF;
END
$$;

alter function hire(integer, integer) owner to s263977;

