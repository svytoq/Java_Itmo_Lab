create function flight_insert() returns trigger
    language plpgsql
as
$$
BEGIN
        NEW.actual_departure := NEW.schedule_departure;
        NEW.actual_arrival := NEW.schedule_arrival;
        RETURN NEW;
    END;
$$;

alter function flight_insert() owner to s265061;

