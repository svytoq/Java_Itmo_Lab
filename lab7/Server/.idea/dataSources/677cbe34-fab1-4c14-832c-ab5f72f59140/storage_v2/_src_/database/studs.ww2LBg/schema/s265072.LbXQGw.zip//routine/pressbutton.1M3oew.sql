create function pressbutton(shortyid integer, buttonid integer) returns boolean
    language plpgsql
as
$$
DECLARE 
	id integer;
	shorty_scene integer;
	button_scene integer;
	subject integer;
	obj integer;
BEGIN
	SELECT changeable_id INTO id FROM Button WHERE button_id = buttonId;
	IF (id is NULL) then RETURN false; END IF;
	SELECT scene_id INTO shorty_scene FROM Shorty WHERE shorty_id = shortyId;
	IF (shorty_scene is NULL) then RETURN false; END IF;
	SELECT scene_id INTO button_scene FROM Button WHERE button_id = buttonid;
	IF (shorty_scene != button_scene) then RETURN false; END IF;
	SELECT subject_id INTO subject FROM Button WHERE button_id = buttonid;
	IF (isDoorToSpace(subject)) THEN RETURN false; END IF;
	UPDATE Changeable SET is_state = NOT is_state WHERE changeable_id = id OR changeable_id = subject;
	UPDATE Shorty SET action_until_feed = (action_until_feed - 1) WHERE shorty_id = shortyId and action_until_feed != 0;
	SELECT object_id INTO obj FROM Changeable WHERE changeable_id = id;
	INSERT INTO Object_to_action (shorty_id, action_id, subject_id, time) VALUES (shortyId, 1, obj, now());
	RETURN true;
END;
$$;

alter function pressbutton(integer, integer) owner to s265072;

