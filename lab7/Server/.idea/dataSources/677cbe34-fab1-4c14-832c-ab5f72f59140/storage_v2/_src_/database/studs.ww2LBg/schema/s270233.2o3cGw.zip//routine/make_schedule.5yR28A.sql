create function make_schedule() returns trigger
    language plpgsql
as
$$
DECLARE
    del_place integer;
    provider  integer;
    weight    integer;

BEGIN
    SELECT delivery_place_id FROM clients WHERE clients.id = NEW._from INTO del_place;
    SELECT id FROM providers WHERE providers.delivery_place_id = del_place INTO provider;
    SELECT storages.sausages_weight
    FROM storages
    WHERE (storages.sausage_id = NEW.sausage_id AND
           storages.factory_id = (SELECT providers.factory_id FROM providers WHERE (providers.id = provider)))
    INTO weight;
    IF (weight > NEW.sausages_weight) THEN
        UPDATE storages
        SET sausages_weight = weight - NEW.sausages_weight
        WHERE (storages.sausage_id = NEW.sausage_id AND
               storages.factory_id =
               (SELECT providers.factory_id FROM providers WHERE (providers.id = provider)));
        IF EXISTS(SELECT *
                  FROM order_schedule
                  WHERE order_schedule.provider_id = provider
                    AND order_schedule.sausage_id =
                        NEW.sausage_id
                    AND order_schedule.del_time =
                        (current_date + 1)) THEN
            UPDATE order_schedule
            SET sausages_weight = sausages_weight + NEW.sausages_weight
            WHERE order_schedule.provider_id = provider
              AND order_schedule.sausage_id =
                  NEW.sausage_id
              AND order_schedule.del_time =
                  current_date + 1;
        ELSE
            INSERT INTO order_schedule(provider_id, sausage_id, sausages_weight, del_time)
            VALUES (provider, NEW.sausage_id, NEW.sausages_weight, current_date + 1);
        END IF;
    ELSE
        RAISE EXCEPTION 'We do not have this product in our storage, it would be soon';
    END IF;
    NEW._to = provider;
    NEW.ord_time = localtimestamp;
    RETURN NEW;
END;
$$;

alter function make_schedule() owner to s270233;

