create function createcoffee(coffee_name text, coffee_type character, author integer, coffee_state text) returns text
    strict
    language plpgsql
as
$$
DECLARE
ret int;
BEGIN
	INSERT INTO товар(название) VALUES(coffee_name) RETURNING id INTO ret;
	INSERT INTO кофе(id, id_товара, тип, id_автора, состояние) VALUES(ret, ret, coffee_type, author, coffee_state);
	RETURN 'Кофе добавлен, id - ' || ret;
END;
$$;

alter function createcoffee(text, char, integer, text) owner to s265082;

