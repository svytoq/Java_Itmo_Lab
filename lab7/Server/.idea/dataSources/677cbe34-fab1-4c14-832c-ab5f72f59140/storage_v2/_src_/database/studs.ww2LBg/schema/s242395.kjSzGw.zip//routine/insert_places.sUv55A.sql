create function insert_places() returns void
    language plpgsql
as
$$
DECLARE
        cinema_room record;
BEGIN
        FOR cinema_room IN (SELECT ид from Залы)
        LOOP
                PERFORM insert_places_for_cinema_room
                (cinema_room.ид,(random()*10+ 1)::int,(random()*20)::int+ 1,(random()*500)::int + 1);
        END LOOP;
END;
$$;

alter function insert_places() owner to s242395;

