create function "ЛЮДИ_ИД_АПДЕЙТ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ИД_ЧЕЛОВЕК!=NEW.ИД_ЧЕЛОВЕК THEN
 NEW.ИД_ЧЕЛОВЕК=OLD.ИД_ЧЕЛОВЕК;
 RETURN NEW;
ELSE
RETURN NEW;
END IF;
 END;
$$;

alter function "ЛЮДИ_ИД_АПДЕЙТ"() owner to s225071;

