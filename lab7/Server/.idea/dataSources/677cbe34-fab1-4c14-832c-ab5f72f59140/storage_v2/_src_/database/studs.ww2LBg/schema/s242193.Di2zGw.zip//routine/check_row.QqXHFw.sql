create function check_row() returns trigger
    language plpgsql
as
$$
BEGIN
RAISE EXCEPTION 'EE';
end;
$$;

alter function check_row() owner to s242193;

