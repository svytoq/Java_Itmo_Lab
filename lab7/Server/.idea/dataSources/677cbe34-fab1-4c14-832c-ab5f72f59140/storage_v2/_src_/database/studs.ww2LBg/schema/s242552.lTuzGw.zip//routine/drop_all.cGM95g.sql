create function drop_all() returns integer
    language plpgsql
as
$$
BEGIN
drop table корабль cascade;
drop table базы;
drop table оружие
 cascade;
drop table раса cascade;
drop table разведка cascade;
drop table исследование cascade;
drop table задание cascade;
drop table битва cascade;
drop table фракция cascade;
drop table планета;
drop table система;
drop table битва_корабль;
drop table корабль_задание;
drop table разведка_раса;
drop table разведка_исследование;
drop table раса_исследование;
drop table оружие_корабль;
drop table раса_фракция;
drop table фракция_битва;
drop type состояние;
drop type тип;
drop type название_расы;
drop type ресурсы;
drop type задание_флоту;
drop type тип_исследования;
drop type погодные_условия_планеты;
return null;
end;
$$;

alter function drop_all() owner to s242552;

