create function titandatatest(i integer) returns void
    language plpgsql
as
$$
DECLARE
j integer;
BEGIN
j = 0;
loop
j = j + 1;
insert into ТИТАНЫ values('type'||'  '||j, 'description'||' '||j, null);
if j = i then exit;
end if;
end loop;
END;
$$;

alter function titandatatest(integer) owner to s223859;

