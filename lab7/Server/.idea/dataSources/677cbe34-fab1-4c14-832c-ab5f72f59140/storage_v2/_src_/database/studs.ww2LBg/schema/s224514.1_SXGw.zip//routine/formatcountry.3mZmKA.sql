create function formatcountry() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.НАИМЕНОВАНИЕ_СТРАНЫ := INITCAP(LOWER(RTRIM(LTRIM(NEW.НАИМЕНОВАНИЕ_СТРАНЫ))));
  return NEW;
  END;
$$;

alter function formatcountry() owner to s224514;

