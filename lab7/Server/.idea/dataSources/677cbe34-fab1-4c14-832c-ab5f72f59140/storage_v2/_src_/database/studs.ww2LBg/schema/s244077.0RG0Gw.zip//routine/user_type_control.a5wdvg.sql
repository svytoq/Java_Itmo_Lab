create function user_type_control() returns trigger
    language plpgsql
as
$$
DECLARE
  user_type user_spec;
  BEGIN
   user_type:=(SELECT spec FROM users WHERE (users.id = NEW.user_id));
   IF (( (user_type = 'ADMIN') OR (user_type = 'SPONSOR')))
     THEN RAISE EXCEPTION 'admins and sponsors are not team members';
     RETURN NULL;
  END IF;
  RETURN NEW;
END;
$$;

alter function user_type_control() owner to s244077;

