create function check_hero_units_amount() returns trigger
    language plpgsql
as
$$
DECLARE
	maxUnits constant smallint = 7;
BEGIN
	IF ((SELECT COUNT(*)
		FROM hero_unit p
		WHERE p.hero = NEW.hero) > maxUnits) THEN
		RAISE EXCEPTION 
			'Units amount cannot be more than %
			hero % unit %',
			maxUnits, NEW.hero, NEW.unit;
	END IF;

	RETURN NEW;
END;
$$;

alter function check_hero_units_amount() owner to s244711;

