create function select_shop_with_id(shop_company_name character varying)
    returns TABLE(shop_id integer, shop_name character varying)
    language plpgsql
as
$$
begin
    if (shop_company_name is null) then
        return query select s.id, s.name from shop s where s.company_name is null;
    end if;
    return query select s.id, s.name from shop s where s.company_name = shop_company_name;
end;
$$;

alter function select_shop_with_id(varchar) owner to s264451;

