create function test_fuel() returns trigger
    language plpgsql
as
$$
declare
    aaa integer;
begin
    if (new.fuel_level <= 1) then
        aaa = (select request_id from booked_car where car_id = new.car_id);
        update client_requests
        set start_a_ride = false
        where request_id = aaa;
    end if;
    return new;
end;
$$;

alter function test_fuel() owner to s263138;

