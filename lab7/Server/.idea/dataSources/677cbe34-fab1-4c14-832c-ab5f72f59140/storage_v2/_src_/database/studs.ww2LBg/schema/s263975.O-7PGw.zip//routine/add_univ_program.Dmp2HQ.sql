create function add_univ_program(uid bigint, progname character varying, lim smallint, subjidsvc character varying, minpointsubjvc character varying) returns bigint
    language plpgsql
as
$$
declare
    uProgId bigint;
    l       integer;
    i       integer;
    subjIds bigint[] = subjIdsVC::bigint[];
    minPointSubj double precision[] = minPointSubjVC::double precision[];
begin
    insert into university_programs(univ_id, name, "limit") values (uId, progName, lim) returning id into uProgId;
    l := array_length(subjIds, 1);
    if l = array_length(minPointSubj, 1) then
        for i in 1..l
            loop
                insert into university_program_subjects values (uProgId, subjIds[i], minPointSubj[i]);
            end loop;
    else
        raise exception 'Not all info about subject and min Point';
    end if;
    return uProgId;
end;
$$;

alter function add_univ_program(bigint, varchar, smallint, varchar, varchar) owner to s263975;

