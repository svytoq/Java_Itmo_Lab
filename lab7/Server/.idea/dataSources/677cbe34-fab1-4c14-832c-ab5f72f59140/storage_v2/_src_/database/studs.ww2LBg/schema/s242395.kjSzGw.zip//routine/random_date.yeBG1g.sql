create function random_date() returns timestamp without time zone
    language plpgsql
as
$$
declare 
        result timestamp;
BEGIN
        result = timestamp '1950-01-10 20:00:00' +
        random() * (now() - '1950-01-10 20:00:00');      
        return result;
end;
$$;

alter function random_date() owner to s242395;

