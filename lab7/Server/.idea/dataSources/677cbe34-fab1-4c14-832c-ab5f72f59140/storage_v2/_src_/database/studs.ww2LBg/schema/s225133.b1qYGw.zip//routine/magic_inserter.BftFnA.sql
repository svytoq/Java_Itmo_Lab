create function magic_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
    N alias for $1;
    i INTEGER DEFAULT 1;
    attack integer;
    armor integer;
    recovery integer;
    length INTEGER;
    count integer default 0;
    chars text[] := '{A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z}';
    name  text := '';
    bonus text := '';
    bane text := '';

BEGIN

    for i in 1..N loop

        length := random()* 1 + 3;
        attack := trunc(random() * 50 + 1);
        armor := trunc(random() * 50 + 1);
        recovery := trunc(random() * 200 + 1);

        while count < length or name = null or bonus=null or bane=null loop
            name := name || chars[1+random()*(array_length(chars, 1)-1)];
            bonus := bonus || chars[1+random()*(array_length(chars, 1)-1)];
            bane := bane || chars[1+random()*(array_length(chars, 1)-1)];
            count:= count + 1;
        end loop;

            insert into "Магия" ("Название", "Атака", "Защита", "Восстановление", "Бонус", "Проклятие", id_героя, id_хронологии) values
              (
                initcap(name),
                attack, 
                armor, 
                recovery, 
                initcap(bonus), 
                initcap(bane), 
                (SELECT "id" FROM "Герой" ORDER BY random() LIMIT 1), (SELECT "id" FROM "Хронология" ORDER BY random() LIMIT 1)
              );

            name := '';
            bonus := '';
            bane := '';
            count:=0;

    end loop;

END;
$$;

alter function magic_inserter(integer) owner to s225133;

