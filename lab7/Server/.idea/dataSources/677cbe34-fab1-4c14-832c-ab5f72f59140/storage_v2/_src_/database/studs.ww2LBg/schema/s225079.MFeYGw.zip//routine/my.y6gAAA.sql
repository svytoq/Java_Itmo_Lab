create function my() returns trigger
    language plpgsql
as
$$
BEGIN
    IF  TG_OP = 'INSERT' THEN
        IF  NEW.ИМЯ IN (SELECT ИМЯ FROM ПЕРСОНАЖ WHERE РАСА=(SELECT НАЗВАНИЕ FROM РАСА WHERE ТИП='НЕ ПОНИ')) THEN
       	    RAISE NOTICE 'СТРОКА НЕ ДОБАВЛЕНА В ПОНИ,ПОПРОБУЙТЕ ДОБАВИТЬ В НЕ_ПОНИ С ИМЕНЕМ%',NEW.ИМЯ;
            RETURN NULL;
	 ELSIF  NEW.ИМЯ IN (SELECT ИМЯ FROM ПЕРСОНАЖ WHERE РАСА=(SELECT НАЗВАНИЕ FROM РАСА WHERE ТИП='ПОНИ')) THEN
            RAISE NOTICE 'СТРОКА ДОБАВЛЕНА В ПОНИ!';
			RETURN NEW;
     ELSIF  NEW.ИМЯ IN (SELECT ИМЯ FROM ПЕРСОНАЖ WHERE РАСА=(SELECT НАЗВАНИЕ FROM РАСА WHERE ТИП='НЕ ОПРЕДЕЛЕНО')) THEN
            RAISE NOTICE 'РАСА ДАННОГО ПЕРСОНЖА БЫЛА ИЗМЕНАНА, ТЕПЕРЬ ТИП РАСЫ -ПОНИ';
		    UPDATE РАСА SET ТИП='ПОНИ' WHERE НАЗВАНИЕ=NEW.РАСА;
		    RETURN NEW;
	     END IF;
    ELSIF TG_OP = 'UPDATE' THEN
        IF  NEW.ИМЯ IN (SELECT ИМЯ FROM ПЕРСОНАЖ WHERE РАСА=(SELECT НАЗВАНИЕ FROM РАСА WHERE ТИП='НЕ ПОНИ')) THEN
			RAISE NOTICE 'ПОНИ НЕ МОЖЕТ ИМЕТЬ ТАКОЕ ИМЯ, СТРОКА НЕ БУДЕТ ИЗМЕНЕНА';
            RETURN OLD;
	  ELSIF NEW.ИМЯ IN (SELECT ИМЯ FROM ПЕРСОНАЖ WHERE РАСА=(SELECT НАЗВАНИЕ FROM РАСА WHERE ТИП='ПОНИ'))THEN
            RAISE NOTICE 'СТРОКА ОБНОВЛЕНА!';
		    RETURN NEW;
		END IF;
    END IF ;
END;
$$;

alter function my() owner to s225079;

