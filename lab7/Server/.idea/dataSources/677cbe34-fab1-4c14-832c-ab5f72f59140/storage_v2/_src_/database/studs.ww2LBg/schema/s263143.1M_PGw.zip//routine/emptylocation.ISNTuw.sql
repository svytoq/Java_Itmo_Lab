create function emptylocation() returns trigger
    language plpgsql
as
$$
begin
    if new.shopid is NULL and new.questgiver is NULL
        then
        new.locationname = concat(text('useless '),new.locationname);
    end if;
    return new;
end;
$$;

alter function emptylocation() owner to s263143;

