create function start_operation(attacker_team_id integer, defense_region_id integer, op_name character varying, operation_equipment_list integer[], should_catch boolean, should_free boolean) returns text
    language plpgsql
as
$$
declare
    attacker_org_id int;
    team_is_not_active boolean;
    defense_org_id int;
    equipment_is_valid boolean;
    operation_equipment int;
    current_operation_id int;
    attacker_org_amount int;
    equipment_transport_price int;
    team_salary int;
    defense_characters_level int;
    attacker_characters_level int;
    attacker_equipment_level int;
    defense_base_id int;
    base_secrecy_level int;
    base_defense_level int;
  begin
    -- достаем данные аттакующей организации
    select organization_id, case when status = 'active' then 'f' else 't' end into attacker_org_id, team_is_not_active from teams where id = attacker_team_id;
    
    if not found or team_is_not_active = 't' then
      raise exception 'Такой команды нет или она не активна';
    end if;
    -- достаем данные защищающейся организации
    select organization_id into defense_org_id from regions where id = defense_region_id;
    
    if not found or attacker_org_id is not distinct from defense_org_id then 
      raise exception 'Вы не можете напасть на данный регион';
    end if;
    
    -- добавляем операцию
      insert into operations (team_id, region_id, name) 
      values (attacker_team_id, defense_region_id, op_name) 
      returning id into current_operation_id;
      
    -- проверяем технику
    foreach operation_equipment in array operation_equipment_list
    loop
      select 't' into equipment_is_valid from organization_has_equipment 
      where organization_id = attacker_org_id and equipment_id = operation_equipment;
      
      if not found then
        raise exception 'Вы не можете использовать данную технику';
      end if;
     
      -- добавляем технику в таблицу equipment_in_operation
      insert into equipment_in_operation (operation_id, equipment_id) 
      values (current_operation_id, operation_equipment);
    end loop;
    
    -- создаем цели
    perform create_goals(current_operation_id, 't', should_catch, should_free);
    
    -- начинаем операцию
    -- 1. Узнаем текущее состояние нападающей организации
    select amount into attacker_org_amount from accounts
    where organization_id = attacker_org_id;
    -- 2. Подсчитываем затраты на технику и зарплаты членов команды
    select coalesce(sum(e.price_for_transport), 0) into equipment_transport_price from equipments e 
    inner join equipment_in_operation eio on (eio.equipment_id = e.id) 
    where eio.operation_id = current_operation_id;
    
    select coalesce(sum(salary), 0) into team_salary from characters
    where team_id = attacker_team_id;
    
    if equipment_transport_price + team_salary > attacker_org_amount then
      raise exception 'У вас недостаточно средств на проведение операции';
    end if;
    
    -- списываем деньги за обслуживание/транспортировку техники
    update accounts set amount = amount - equipment_transport_price - team_salary
    where organization_id = attacker_org_id;
    
    --3. Проводим захват
      -- 3.1. Если регион свободен, то спокойно занимаем его, строим базу, получаем прибыль
      if defense_org_id is null then
        update regions set organization_id = attacker_org_id where id = defense_region_id;
        -- Начисляем деньги за захват и вычитаем за постройку базы 
        update accounts set amount = amount + 100000 - 10000
        where organization_id = attacker_org_id;
        -- Строим новую базу
        insert into bases (region_id) values (defense_region_id);
      else
      -- 3.2. Если регион занят, то расчитываем силы сторон
        select coalesce(sum(level), 0) into attacker_characters_level from characters where team_id = attacker_team_id;
        select coalesce(sum(level), 0) into attacker_equipment_level from equipments where id = any(operation_equipment_list);
        
        select id, secrecy, defense into defense_base_id, base_secrecy_level, base_defense_level 
        from bases where region_id = defense_region_id;
        select coalesce(sum(level), 0) into defense_characters_level from characters where base_id = defense_base_id;
        
        -- 3.3 Если атакующая сторона проигрывает, то теряет команду и технику, операция провалена
        if (attacker_characters_level+attacker_equipment_level) <= (defense_characters_level + base_secrecy_level + base_defense_level) then
          update teams set status = 'failed' where id = attacker_team_id;
          delete from organization_has_equipment where equipment_id=any(operation_equipment_list); 
          update operations set status = 'failed' where id = current_operation_id;
          return 'Вы не смогли захватить базу соперника, операция провалена';
        else
        -- 3.4 Если выигрывает, то занимает регион
          update regions set organization_id = attacker_org_id where id = defense_region_id;
          update accounts set amount = amount - least(amount, 1000) 
          where organization_id = defense_org_id;
        end if;
      end if;
    --4. Захватываем заложников, если нужно
    if should_catch = 't' then
      update characters set jail_id = 
      (select id from jails where region_id = defense_region_id), team_id = null
      where base_id = defense_base_id;
    end if;
    
    --5. Освобождаем заложников, если нужно
    if should_free = 't' then
      -- тратим деньги на взлом тюрьмы
      update accounts set amount = amount - least(amount, 1000) 
      where organization_id = attacker_org_id;
      
      update characters set jail_id = null 
      where base_id = defense_base_id and organization_id = attacker_org_id;
    end if;
    
    update operations set status = 'success' where id = current_operation_id;
    
    return 'Операция успешно завершена';
  end;
$$;

alter function start_operation(integer, integer, varchar, integer[], boolean, boolean) owner to s263148;

