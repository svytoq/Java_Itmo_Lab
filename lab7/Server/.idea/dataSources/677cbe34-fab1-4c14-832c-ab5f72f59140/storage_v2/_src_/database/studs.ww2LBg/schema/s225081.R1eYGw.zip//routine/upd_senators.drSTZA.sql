create function upd_senators() returns trigger
    language plpgsql
as
$$
BEGIN
  IF OLD.ОТДЕЛ != NEW.ОТДЕЛ
  THEN
    UPDATE ОТДЕЛЫ_СЕНАТА
    SET ГЛАВА = NULL
    WHERE ГЛАВА = OLD.ID_ЧЛЕНА;
  ELSEIF OLD.ОТДЕЛ = NEW.ОТДЕЛ AND OLD.ID_ЧЛЕНА != NEW.ID_ЧЛЕНА
    THEN
      UPDATE ОТДЕЛЫ_СЕНАТА
      SET ГЛАВА = NEW.ID_ЧЛЕНА
      WHERE ГЛАВА = OLD.ID_ЧЛЕНА;
  END IF;
  RETURN NULL;
END;
$$;

alter function upd_senators() owner to s225081;

