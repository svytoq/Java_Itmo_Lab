create function culc_rating() returns trigger
    language plpgsql
as
$$
DECLARE
  BEGIN

    UPDATE "Команда" SET "Рейтинг" = 1 +
    (SELECT AVG("Общий рейтинг") FROM "Игровые характеристики" WHERE "ID_Игрока" IN
      (SELECT "ID_Игрока" FROM "Контракты" WHERE "Команда"."ID_Команды" = "Контракты"."ID_Команды"));

    RETURN NEW;
  END;
$$;

alter function culc_rating() owner to s225147;

