create function check_judge_only_update() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.judge_team_id IS NULL OR NEW.judge_team_id != OLD.judge_team_id THEN
        DELETE FROM judge_team
        WHERE judge_team_id = OLD.judge_team_id;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_judge_only_update() owner to s264448;

