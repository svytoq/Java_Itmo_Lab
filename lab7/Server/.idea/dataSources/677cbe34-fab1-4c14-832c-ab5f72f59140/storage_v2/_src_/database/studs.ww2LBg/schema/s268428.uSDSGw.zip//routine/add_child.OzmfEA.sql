create function add_child(name character, birthdate integer, learnability integer, school_id integer, stream_id integer) returns integer
    language plpgsql
as
$$
DECLARE
person_id INTEGER;
role_id INTEGER;
witcher_id INTEGER;
begin
 person_id = add_person(name, birthdate, true);
 role_id = add_role('witcherJr', school_id, NULL, learnability, NULL);
 witcher_id = nextval('witcher_witcher_id_seq'); 
 INSERT INTO witcher VALUES
 (witcher_id, 'witcherJr', person_id, role_id, stream_id);
 INSERT INTO skill_witcher VALUES
 (witcher_id, 1, 0),
 (witcher_id, 2, 0),
 (witcher_id, 3, 0),
 (witcher_id, 5, 0),
 (witcher_id, 6, 0);
 RETURN 0;
 end
$$;

alter function add_child(char, integer, integer, integer, integer) owner to s268428;

