create function characters() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.Имя = OLD."Имя"=concat(upper(left(OLD."Имя",1)),substr(OLD."Имя",2));
RETURN NEW;
  END;
$$;

alter function characters() owner to s223569;

