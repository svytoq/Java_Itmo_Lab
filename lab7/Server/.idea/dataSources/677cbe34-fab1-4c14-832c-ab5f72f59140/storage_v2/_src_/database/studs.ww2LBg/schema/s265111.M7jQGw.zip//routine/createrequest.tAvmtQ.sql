create function createrequest(creator_name text, creator_surname text, linked_request_id integer, startts timestamp without time zone, endts timestamp without time zone, goal text, additional_info text) returns void
    language plpgsql
as
$$
DECLARE
    creator_id     int;
    ts_interval_id int;
    request_id     int;
BEGIN
    select id into creator_id from s265111.employee where name = creator_name and surname = creator_surname;
    select id into ts_interval_id from timestampinterval where starttimestamp = startTS and endtimestamp = endTS;
    if ts_interval_id is NULL then
        select max(id) + 1 into ts_interval_id from timestampinterval;
        insert into timestampinterval values (ts_interval_id, startTS, endTS);
    end if;
    select max(id) + 1 into request_id from researchrequest;
    insert into researchrequest
    values (request_id, creator_id, linked_request_id, ts_interval_id, 'Ready for consideration', goal,
            additional_info);
END;
$$;

alter function createrequest(text, text, integer, timestamp, timestamp, text, text) owner to s265111;

