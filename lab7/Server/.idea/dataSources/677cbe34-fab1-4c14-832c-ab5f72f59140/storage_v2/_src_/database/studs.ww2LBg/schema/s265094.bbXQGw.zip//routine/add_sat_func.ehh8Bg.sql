create function add_sat_func() returns trigger
    language plpgsql
as
$$
DECLARE activeSatAmount INTEGER;
BEGIN
    activeSatAmount = (SELECT count(*) from satellite WHERE group_id = new.group_id AND status = 'online') ;
    IF activeSatAmount + 1 > (SELECT max_satellite_amount FROM groups WHERE groups.group_id = new.group_id)  THEN
        RAISE EXCEPTION 'the maximum number of satellites in the group is executed';
    ELSE RETURN new;
    END IF;
END
$$;

alter function add_sat_func() owner to s265094;

