create function create_h_h(beginning date, ending date, stream integer) returns integer
    language plpgsql
as
$$
DECLARE
id INTEGER;
begin
 
 id = nextval('h_h_h_h_id_seq'); 
 
 INSERT INTO h_h VALUES
 (id, beginning, ending);

UPDATE stream set h_h_id = id WHERE stream_id = stream;
 
 RETURN id;
 end
$$;

alter function create_h_h(date, date, integer) owner to s268428;

