create function patent_date() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Проверить, что указана дата
    IF NEW.start_date IS NULL THEN
        NEW.start_date := now();
    END IF;
    RETURN NEW;
END;
$$;

alter function patent_date() owner to s264475;

