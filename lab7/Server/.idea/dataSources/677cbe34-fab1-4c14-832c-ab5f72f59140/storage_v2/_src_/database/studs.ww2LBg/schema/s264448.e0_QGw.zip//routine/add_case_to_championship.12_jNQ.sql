create function add_case_to_championship(championship_id integer, case_id integer) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO championship_case (championship_id, case_id)
    VALUES (add_case_to_championship.championship_id,
            add_case_to_championship.case_id);
END;
$$;

alter function add_case_to_championship(integer, integer) owner to s264448;

