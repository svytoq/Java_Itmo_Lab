create function race_power(race text) returns bigint
    language sql
as
$$
select sum(power) from army inner join provinces on provinces.garrison_id=army.id where provinces.race_name=$1
$$;

alter function race_power(text) owner to s264430;

