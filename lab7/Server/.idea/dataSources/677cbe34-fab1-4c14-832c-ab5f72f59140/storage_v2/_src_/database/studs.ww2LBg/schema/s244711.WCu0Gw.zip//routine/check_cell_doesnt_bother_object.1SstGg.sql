create function check_cell_doesnt_bother_object() returns trigger
    language plpgsql
as
$$
BEGIN
	IF ((SELECT count(*) > 0
		FROM objects
		WHERE pos = NEW.pos AND map = NEW.map)) THEN
		RAISE EXCEPTION 
			'Cannot make cell not passable 
			cause there`s other object
			[map % at %]',
			NEW.map, NEW.pos;
	END IF;

	RETURN NEW;
END;
$$;

alter function check_cell_doesnt_bother_object() owner to s244711;

