create function make_item(actorid integer, factoryid integer, inputitemid integer) returns void
    language plpgsql
as
$$
declare factoryInputItemId int;
    declare factoryAmount int;
    declare actorItem int;
    declare outputActorItemId int;
    begin
        factoryAmount = (select count(*) from factory_owner where actor_id = actorId and factory_id = factoryId);
        if (factoryAmount is null or factoryAmount <= 0) then
            return;
        end if;
        factoryInputItemId = (select item.id from factory f
            join factory_input_item fii on f.input_items = fii.id
            join item on fii.item_id = item.id
            where f.id = factoryId
            );
        if (inputItemId != factoryInputItemId) then
            return;
        end if;

        actorItem = (select amount from actor_inventory where actor_id = actorId and item_id = inputItemId);
        if (actorItem is null) then
            return;
        end if;
        update actor_inventory set amount = amount - 1 where actor_id = actorId and item_id = inputItemId;

        outputActorItemId = (select amount from actor_inventory where actor_id = actorId
        and item_id = (select output_item from factory where id = factoryId));
        if (outputActorItemId is null) then
            insert into actor_inventory(actor_id, item_id, amount)
            values (actorId, (select output_item from factory where id = factoryId), 1);
        else
            update actor_inventory set amount = amount + 1 where actor_id = actorId
                                                             and item_id =
                                                                 (select output_item from factory where id = factoryId);
        end if;

    end;
$$;

alter function make_item(integer, integer, integer) owner to s263063;

