create function obl() returns trigger
    language plpgsql
as
$$
DECLARE
obl TEXT;
BEGIN
SELECT INTO obl ИМЯ_ГЕРОЯ FROM ГЕРОИ WHERE ГЕРОЙ_ИД=NEW.ГЕРОЙ_ИД;
NEW.ГЕРОЙ_ФИ:=obl;
RETURN NEW;
END
$$;

alter function obl() owner to s243140;

