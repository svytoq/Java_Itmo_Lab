create function add_sorcerer(name character, birthdate integer, h_h integer, lev integer) returns integer
    language plpgsql
as
$$
DECLARE
person_id INTEGER;
sorcerer_id INTEGER;
begin
 person_id = add_person(name, birthdate, true);
 sorcerer_id = nextval('sorcerer_sorcerer_id_seq'); 
 INSERT INTO sorcerer VALUES
 (sorcerer_id, h_h, lev, person_id);

 
 RETURN sorcerer_id;
 end
$$;

alter function add_sorcerer(char, integer, integer, integer) owner to s268428;

