create function most_profitable_place(res_id integer)
    returns TABLE(location_id integer, price double precision)
    language sql
as
$$
SELECT location_id, price FROM location_resources WHERE resource_id = res_id;
$$;

alter function most_profitable_place(integer) owner to s265098;

