create function usefull_func(entrant bigint, OUT "специальность" text, OUT "вуз" text, OUT "город" text) returns SETOF record
    language sql
as
$$
select distinct наименование as "специальность", полное_название as "вуз", substring(адрес, 0, strpos(адрес, ',')) as "город"
from специальность_вуза_описание
natural join (select ид_вуза, код_специальности, count (*) num
from (select ид_вуза, код_специальности, coalesce(exs+id, exs, id) this_summ -- баллы экзамен + ид
from (select ид_абитуриента, ид_вуза, код_специальности, sum(балл) exs
from специальность_абит
natural join специальность_вуза_описание
natural join экзамен 
where балл >= порог
group by (ид_абитуриента, код_специальности, ид_вуза)) as foo -- баллы за экзамен
left join (select ид_абитуриента, ид_вуза, sum(балл) id 
from специальность_абит
natural join дополнительные_документы
natural join индивидуальные_достижения_вуза 
group by (ид_абитуриента, ид_вуза)) as bar -- баллы за ид
using (ид_абитуриента, ид_вуза)
where ид_абитуриента = entrant
group by (ид_абитуриента, код_специальности, ид_вуза, exs, id)) as this_entr
join (select  ид_абитуриента, ид_вуза, код_специальности, coalesce(exs+id, exs, id) others_summ -- баллы экзамен + ид
from (select ид_абитуриента, ид_вуза, код_специальности, sum(балл) exs
from специальность_абит
natural join специальность_вуза_описание
natural join экзамен 
where балл >= порог
group by (ид_абитуриента, код_специальности, ид_вуза)) as foo -- баллы за экзамен
left join (select ид_абитуриента, ид_вуза, sum(балл) id 
from специальность_абит
natural join дополнительные_документы
natural join индивидуальные_достижения_вуза 
group by (ид_абитуриента, ид_вуза)) as bar -- баллы за ид
using (ид_абитуриента, ид_вуза)
where ид_абитуриента in (select a.ид_абитуриента -- для тех, кто на том же направлении (и в том же вузе), что и подопытный
from специальность_абит as a
join специальность_абит as b using (код_специальности, ид_вуза) 
where a.ид_абитуриента != b.ид_абитуриента and b.ид_абитуриента = entrant)
and ид_абитуриента not in (select ид_абитуриента
from специальность_абит
join (select a.ид_абитуриента, код_специальности, ид_вуза
from специальность_абит as a
join специальность_абит as b using (код_специальности, ид_вуза) 
where a.ид_абитуриента != b.ид_абитуриента and b.ид_абитуриента = entrant) as qux
using (ид_абитуриента)
where приоритет = 1 
and статус_абит in ('есть заявление, есть ориг_л', 'нет заявления, есть ориг_л'))
group by (ид_абитуриента, код_специальности, ид_вуза, exs, id)) as others
using (ид_вуза, код_специальности)
where others_summ >= this_summ
group by (ид_вуза, код_специальности)) as baz
natural join специальность
natural join вуз
where количество_мест >= num;
$$;

alter function usefull_func(bigint, out text, out text, out text) owner to s243859;

