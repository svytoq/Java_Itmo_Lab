create function delete_story() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM story_character WHERE story_character.id_fairy_tale = OLD.id_fairy_tale;
    DELETE FROM story_location WHERE story_location.id_fairy_tale = OLD.id_fairy_tale;
    RETURN NULL;
END;
$$;

alter function delete_story() owner to s264912;

