create function check_for_supervising_validity() returns trigger
    language plpgsql
as
$$
DECLARE
    supervisor_id_old INTEGER;
    supervisor_level SMALLINT;
    table_name TEXT;
    BEGIN
    table_name = quote_ident(tg_table_name);
    IF table_name = 'security_profiles' THEN
      supervisor_id_old := (SELECT supervisor_id FROM security_profiles WHERE employee_id = NEW.supervisor_id);
      supervisor_level := (SELECT supervising_level FROM security_profiles where employee_id = NEW.supervisor_id);

    ELSIF table_name = 'scientist_profiles' THEN
      supervisor_id_old := (SELECT supervisor_id FROM scientist_profiles WHERE employee_id = NEW.supervisor_id);
      supervisor_level := (SELECT supervising_level FROM scientist_profiles where employee_id = NEW.supervisor_id);

    ELSIF table_name = 'management_profiles' THEN
      supervisor_id_old := (SELECT supervisor_id FROM management_profiles WHERE employee_id = NEW.supervisor_id);
      supervisor_level := (SELECT supervising_level FROM management_profiles where employee_id = NEW.supervisor_id);

    END IF;

    IF supervisor_id_old = NEW.employee_id THEN
      RAISE EXCEPTION 'Employees cannot supervise each other.';
    ELSE IF supervisor_level <= NEW.supervising_level THEN
        RAISE EXCEPTION 'Supposed supervisor''s level is not sufficient.';
      END IF;
    END IF;
    RETURN NEW;
  END;
$$;

alter function check_for_supervising_validity() owner to s243864;

