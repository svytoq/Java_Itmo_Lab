create function visa_application_autocheck(id integer) returns integer
    language plpgsql
as
$$
declare
    person bigint;
    close_relations relation_types[];
    app Visa_applications;
    check_id integer;
begin
    -- person = (select person_id from Visa_applications where visa_app_id=id);
    select * into app from Visa_applications where visa_app_id=id;
    person = app.person_id;

    if exists(select 1 from Violations
        where person_id=person
        and violation_state != 'done') then
            select visa_check_create(id, -1) into check_id;
            perform visa_check_finish(check_id, 'not_granted', 'has opened violation');
            return 0;
    end if;

    if exists(select 1 from Visas
        where person_id=person
        and exp_date > app.start_date) then
            select visa_check_create(id, -1) into check_id;
            perform visa_check_finish(check_id, 'not_granted', 'has active visa');
            return 0;
    end if;

    if  (select restrict_until from People where person_id = person) > app.start_date
    then
        select visa_check_create(id, -1) into check_id;
        perform visa_check_finish(check_id, 'not_granted', 'has active restriction');
        return 0;
    end if;

    if (select acc_lvl from Employees where person_id = person) != 'max'
        or (select acc_lvl from Employees where person_id = person) is null
    then

        if  extract(month from age(app.exp_date,app.start_date)) > 1 or
            app.trans > 4 or
            (select count(*) from Employees where person_id = person) < 1 or
            (select counterpart from People where person_id = person) is null or
            (select person_state from People where counterpart = person) = 'unknown' or
            (select count(*) from Visas where person_id = person) < 1 or
            (select acc_lvl from Employees where person_id = person) = 'restricted'
        then
            return 0;
        end if;

        close_relations = array['parent', 'sibling', 'child', 'spouse'];
        if  exists(select 1 from Person_relations
            join People on object=person_id where
            subject = person and
            array_position(close_relations, relation_type) < 1 and
            person_state = 'dead' and
            death_date < (
                select exp_date from Visas
                where person_id = person
                order by exp_date desc limit 1
            )) 
        then
            return 0;
        end if;

    end if;

    select visa_check_create(id, -1) into check_id;
    perform visa_check_finish(check_id, 'granted', 'auto granted');
    return 1;
end;
$$;

alter function visa_application_autocheck(integer) owner to s265066;

