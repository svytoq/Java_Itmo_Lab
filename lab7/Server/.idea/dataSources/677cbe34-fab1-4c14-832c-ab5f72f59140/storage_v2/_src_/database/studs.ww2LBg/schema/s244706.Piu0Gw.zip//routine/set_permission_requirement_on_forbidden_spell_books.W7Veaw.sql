create function set_permission_requirement_on_forbidden_spell_books() returns trigger
    language plpgsql
as
$$
declare
  is_forbidden boolean;
begin
  is_forbidden := (select spells.is_forbidden from spells where id = new.spell_id);

  if is_forbidden
  then update books set requires_permission = true where id = new.book_id;
  end if;

  return new;
end;
$$;

alter function set_permission_requirement_on_forbidden_spell_books() owner to s244706;

