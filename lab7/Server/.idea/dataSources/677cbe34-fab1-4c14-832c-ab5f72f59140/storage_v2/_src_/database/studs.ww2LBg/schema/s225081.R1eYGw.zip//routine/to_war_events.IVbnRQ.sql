create function to_war_events(count integer) returns void
    language plpgsql
as
$$
DECLARE
  J      INT;
  nM     VARCHAR(30);
  AVERS  INT;
  REVERS INT;

  STAT   BOOLEAN;
  PLACE  INT;
  DAT    DATE;
BEGIN
  DAT = '0441-01-02 BC';
  PLACE = 0;
  SELECT ID_ВОИНА
  FROM ВОИНЫ
  WHERE ДОЛЖНОСТЬ IN ('ЦЕНТУРИОН', 'ЛЕГИОНЕР')
  INTO REVERS;
  SELECT ID_ВОИНА
  FROM ВОИНЫ
  WHERE ID_ВОИНА != REVERS AND ДОЛЖНОСТЬ IN ('ЦЕНТУРИОН', 'ЛЕГИОНЕР')
  INTO AVERS;
  FOR J IN 1..COUNT LOOP
    DAT = DAT + 1;
    STAT = TRUE;
    NM = 'СРАЖЕНИЕ'||J;
    IF J % 7 = 0
    THEN
    NM = 'БИТВА'||J;

      STAT = FALSE;
      SELECT ID_ВОИНА
      FROM ВОИНЫ
      WHERE ДОЛЖНОСТЬ IN ('ЦЕНТУРИОН', 'ЛЕГИОНЕР') AND ID_ВОИНА > REVERS
      INTO REVERS;
      SELECT ID_ВОИНА
      FROM ВОИНЫ
      WHERE ID_ВОИНА != REVERS AND ДОЛЖНОСТЬ IN ('ЦЕНТУРИОН', 'ЛЕГИОНЕР') AND ID_ВОИНА > AVERS
      INTO AVERS;
    END IF;
    SELECT ID_МЕСТО
    FROM МЕСТОПОЛОЖЕНИЕ
    WHERE ID_МЕСТО != PLACE
    INTO PLACE;
    INSERT INTO ВОЕННЫЕ_МЕРОПРИЯТИЯ VALUES (DEFAULT, nM, AVERS, REVERS, PLACE, STAT, DAT);
  END LOOP;
END;
$$;

alter function to_war_events(integer) owner to s225081;

