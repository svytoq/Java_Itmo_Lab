create function func(i integer, z integer) returns boolean
    language plpgsql
as
$$
begin
end;
$$;

alter function func(integer, integer) owner to s223619;

