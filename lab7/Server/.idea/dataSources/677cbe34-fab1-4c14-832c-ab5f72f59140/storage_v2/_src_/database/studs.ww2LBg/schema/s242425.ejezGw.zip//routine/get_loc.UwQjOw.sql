create function get_loc(integer, double precision)
    returns TABLE("ИД_ЛОКАЦИИ" integer, "ШИРОТА" real, "ДОЛГОТА" real, distance double precision)
    language plpgsql
as
$$
DECLARE
id_loc integer;
BEGIN
RETURN QUERY select  loc.ИД_ЛОКАЦИИ, loc.ШИРОТА, loc.ДОЛГОТА,
(select
SQRT(
(loc2.ШИРОТА - (select КОРАБЛЬ.ШИРОТА from КОРАБЛЬ))*(loc2.ШИРОТА-(select КОРАБЛЬ.ШИРОТА from КОРАБЛЬ) ) + 
(loc2.ДОЛГОТА-(select КОРАБЛЬ.ДОЛГОТА from КОРАБЛЬ))*(loc2.ДОЛГОТА-(select КОРАБЛЬ.ДОЛГОТА from КОРАБЛЬ)))
from ЛОКАЦИЯ as loc2  where loc2.ИД_ЛОКАЦИИ = loc.ИД_ЛОКАЦИИ) as distance 
from ЛОКАЦИЯ as loc join СПРАВОЧНИК_СУЩЕСТВ using(ИД_СУЩЕСТВА)
join ИНГРЕДИЕНТ using(ИД_СУЩЕСТВА) 
where СПРАВОЧНИК_СУЩЕСТВ.ИД_СУЩЕСТВА = ИНГРЕДИЕНТ.ИД_СУЩЕСТВА AND loc.КОЛИЧЕСТВО > 5 * $2 
and ИНГРЕДИЕНТ.ИД_ИНГРЕДИЕНТА= $1  order by 4;
END
$$;

alter function get_loc(integer, double precision) owner to s242425;

