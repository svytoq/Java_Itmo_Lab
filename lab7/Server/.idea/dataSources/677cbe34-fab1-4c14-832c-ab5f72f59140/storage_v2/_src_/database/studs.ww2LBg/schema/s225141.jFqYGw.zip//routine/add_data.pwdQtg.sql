create function add_data() returns trigger
    language plpgsql
as
$$
BEGIN
SELECT CURRENT_DATE INTO NEW.ДАТА;
RETURN NEW;
END
$$;

alter function add_data() owner to s225141;

