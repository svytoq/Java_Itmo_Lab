create function nvl(text, text) returns text
    language plpgsql
as
$$
begin
if $1 is null then return $2;
else return $1;
end if;
end;
$$;

alter function nvl(text, text) owner to s225087;

