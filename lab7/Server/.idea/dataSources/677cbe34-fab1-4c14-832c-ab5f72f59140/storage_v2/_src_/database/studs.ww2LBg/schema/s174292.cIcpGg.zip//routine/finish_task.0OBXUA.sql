create function finish_task() returns trigger
    language plpgsql
as
$$
declare
    t_curs cursor for select *
                      from s174292.task_prize
                      where s174292.task_prize.task_id = NEW.id;
    t_row integer;
BEGIN
    if ((select s174292.task.passed from s174292.task where s174292.task.id = NEW.id) = TRUE) then
        update s174292.witcher
        set xp=xp + 150,
            money=money + NEW.money
        where s174292.witcher.id = NEW.witcher_id;

        for t_row in t_curs
            Loop
                if ((select exists(select *
                                   from s174292.witcher_inventory
                                   where s174292.witcher_inventory.item_id = t_row.item_id
                                     and s174292.witcher_inventory.witcher_id = NEW.witcher_id)) = TRUE)
                then
                    update s174292.witcher_inventory
                    set count=count + t_row.count
                    where s174292.witcher_inventory.witcher_id = NEW.witcher_id
                      and s174292.witcher_inventory.item_id = t_row.item_id;
                else
                    insert into s174292.witcher_inventory(witcher_id, item_id, count)
                    values (NEW.witcher_id, t_row.item_id, t_row.count);
                end if;
            end loop;
    end if;
    return NEW;
end
$$;

alter function finish_task() owner to s174292;

