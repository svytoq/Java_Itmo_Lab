create function random_data(date_after date, disp integer) returns date
    language plpgsql
as
$$
begin
    date_after := (date_after + ( interval '24 hour')*random_intmax(disp))::date;
    return date_after;
end;
$$;

alter function random_data(date, integer) owner to s269380;

