create function create_order(_customer_id integer, _comment text, _address_id integer, _model_id character varying, _model_version character varying) returns boolean
    language plpgsql
as
$$
declare
    _order_id int := 0;
    machines_count int := null;
    _machine_id int := null;
    _machine_speed int := null;
    _truck_id int := null;
    _fulfilled timestamp := null;
begin
    -------------------------------- one circuit board
    select count(*) into machines_count from circuit_board_machine_param_item where board_model_id = _model_id and board_model_version = _model_version;
    if machines_count is null then
        return false;
    end if;
    select machine_id into _machine_id from circuit_board_machine_param_item where board_model_id = _model_id and board_model_version = _model_version limit 1;
    select speed_items_per_hour into _machine_speed from circuit_board_machine_param_item where board_model_id = _model_id and board_model_version = _model_version and machine_id = _machine_id;
    -------------------------------- one circuit board

    _fulfilled = now();
    insert into "order" (customer_id, address_id, accepted ,comment)
    values (_customer_id, _address_id, _fulfilled, _comment) returning id into _order_id;
    insert into order_item(order_id, board_model_id, board_model_version, amount)
    values (_order_id, _model_id, _model_version, 1);

    insert into circuit_board(model_id, model_version, order_id, assembled_by, price)
    values (_model_id, _model_version, _order_id, _machine_id, random() * 900 + 100);


    update "order" set fulfilled = _fulfilled + + interval '1 hour' where id = _order_id;
    select id into _truck_id from delivery_truck where order_id is null /*and capacity*/ limit 1;
    if _truck_id is null then
        return false;
    end if;
    update delivery_truck set order_id = _order_id where id = _truck_id;
    return true;

end;
$$;

alter function create_order(integer, text, integer, varchar, varchar) owner to s264429;

