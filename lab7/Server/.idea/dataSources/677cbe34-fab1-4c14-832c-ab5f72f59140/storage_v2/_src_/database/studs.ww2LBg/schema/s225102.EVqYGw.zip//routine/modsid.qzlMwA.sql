create function modsid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('mods_id_seq')!=NEW.ID THEN
NEW.ID=nextval('mods_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function modsid() owner to s225102;

