create function is_magician_in_hunting(magician integer, hunting integer) returns boolean
    language plpgsql
as
$$
DECLARE
          is_magician_in_hunting boolean;
        BEGIN
          SELECT 1 INTO is_magician_in_hunting FROM Magician_to_hunting mth 
          WHERE mth.magician_id = magician AND mth.hunting_id = hunting;
    IF NOT FOUND THEN
      RAISE EXCEPTION 'Данный маг не принимает участие в данной охоте';
    END IF;
        RETURN 'TRUE';
        END;
$$;

alter function is_magician_in_hunting(integer, integer) owner to s265108;

