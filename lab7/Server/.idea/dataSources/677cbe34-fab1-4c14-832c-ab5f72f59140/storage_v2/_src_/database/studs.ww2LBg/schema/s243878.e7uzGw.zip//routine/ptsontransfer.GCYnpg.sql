create function ptsontransfer() returns trigger
    language plpgsql
as
$$
BEGIN
		UPDATE team SET dpc_points = (SELECT sum(dpc_points) FROM (SELECT dpc_points FROM player
			WHERE team_id = OLD.team_id ORDER BY dpc_points DESC LIMIT 3) AS subq) where id = OLD.team_id;

		UPDATE team SET dpc_points = (SELECT sum(dpc_points) FROM (SELECT dpc_points FROM player
			WHERE team_id = NEW.team_id ORDER BY dpc_points DESC LIMIT 3) AS subq) where id = NEW.team_id;
		RETURN NEW;
	END;
$$;

alter function ptsontransfer() owner to s243878;

