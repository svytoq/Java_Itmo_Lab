create function book(name text, OUT "НАЗВАНИЕ" text, OUT "ИМЯ" text) returns SETOF record
    language sql
as
$$
SELECT ФИЛЬМ.НАЗВАНИЕ, РЕЖИССЕР.ИМЯ 
FROM СЦЕНАРИЙ 
JOIN ФИЛЬМ ON СЦЕНАРИЙ.ИД_Ф=ФИЛЬМ.ИД 
JOIN РЕЖИССЕР ON РЕЖИССЕР.ИД=СЦЕНАРИЙ.ИД_Р 
WHERE СЦЕНАРИЙ.НАЗВАНИЕ_КНИГИ=name;
$$;

alter function book(text, out text, out text) owner to s243886;

