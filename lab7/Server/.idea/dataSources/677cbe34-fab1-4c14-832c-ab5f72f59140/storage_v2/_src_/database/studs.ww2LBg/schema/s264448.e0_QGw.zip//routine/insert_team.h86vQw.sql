create function insert_team(name text, participants integer[], leader_id integer, championship_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    person      integer;
    team_number integer;
BEGIN
    IF (SELECT insert_team.leader_id != ALL (participants)) THEN
        RAISE EXCEPTION 'Leader_id not in participants array';
    END IF;

    INSERT INTO team (name, championship_id) VALUES (insert_team.name, insert_team.championship_id);
    SELECT CURRVAL('team_team_id_seq') INTO team_number;

    FOREACH person IN ARRAY participants
        LOOP
            UPDATE participant
            SET team_id = team_number
            WHERE person_id = person
              AND participant.championship_id = insert_team.championship_id;
        END LOOP;

    UPDATE team
    SET leader_id = insert_team.leader_id
    WHERE team_id = team_number;

    RETURN team_number;
END;
$$;

alter function insert_team(text, integer[], integer, integer) owner to s264448;

