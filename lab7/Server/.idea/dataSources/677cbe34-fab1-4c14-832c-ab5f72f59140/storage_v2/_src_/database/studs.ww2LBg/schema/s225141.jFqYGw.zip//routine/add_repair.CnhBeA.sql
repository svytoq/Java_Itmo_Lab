create function add_repair() returns trigger
    language plpgsql
as
$$
DECLARE
counts integer := 0;
IsExist integer := 1;
BEGIN
SELECT COUNT(*) INTO counts FROM ЗАЯВКИ_НА_РЕМОНТ;
WHILE IsExist != 0 LOOP
counts := counts + 1;
SELECT COUNT(*) INTO IsExist FROM ЗАЯВКИ_НА_РЕМОНТ WHERE ИД = counts;
END LOOP;
NEW.ИД := counts;
RETURN NEW;
END
$$;

alter function add_repair() owner to s225141;

