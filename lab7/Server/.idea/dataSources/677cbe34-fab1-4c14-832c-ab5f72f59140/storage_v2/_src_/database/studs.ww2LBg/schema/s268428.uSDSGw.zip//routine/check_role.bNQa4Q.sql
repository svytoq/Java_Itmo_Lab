create function check_role() returns trigger
    language plpgsql
as
$$
DECLARE
  role CHAR(50);
  st_sword_use BOOLEAN;
  sil_sword_use BOOLEAN;
  sil CHAR(10);
  st CHAR(10);
BEGIN
  SELECT INTO role name
  FROM role
  WHERE role_id = NEW.role_id;

 
  IF (role = 'witcherJr' AND NEW.learnability < 0)
  THEN
    RAISE EXCEPTION 'witcherJr has learnability < 0 or does not have it at all';
  END IF;
  
  IF (role != 'witcherJr')
	THEN
	IF (NEW.st_sword is NULL OR NEW.sil_sword is NULL)
	THEN
	RAISE EXCEPTION 'Witcher does not have set of sword';
	end IF;
	
      SELECT INTO st_sword_use in_use
  FROM sword
  WHERE sword_id = NEW.st_sword;
  
    SELECT INTO sil_sword_use in_use
  FROM sword
  WHERE sword_id = NEW.sil_sword;
  
  IF (NOT st_sword_use OR NOT sil_sword_use)
  THEN 
  RAISE EXCEPTION 'Swords are broken';
  END IF;
  
        SELECT INTO st material
  FROM sword
  WHERE sword_id = NEW.st_sword;
  
    SELECT INTO sil material
  FROM sword
  WHERE sword_id = NEW.sil_sword;
  
  IF (sil != 'silver' OR st != 'steel')
  THEN
  RAISE EXCEPTION 'Materials of swords do not match';
  END IF;
  
   END IF;
   RETURN NEW;
END;
$$;

alter function check_role() owner to s268428;

