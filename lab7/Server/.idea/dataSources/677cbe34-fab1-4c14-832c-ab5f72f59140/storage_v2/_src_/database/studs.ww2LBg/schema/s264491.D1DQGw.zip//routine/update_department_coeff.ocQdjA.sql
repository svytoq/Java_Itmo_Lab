create function update_department_coeff() returns trigger
    language plpgsql
as
$$
DECLARE
    depart_sum RANKING;
BEGIN
    SELECT (get_department_avg_by_worker(NEW.worker_id)).* INTO depart_sum;
    UPDATE DEPARTMENT
    SET workers_rank   = depart_sum.worker_rank,
        corporate_rank = depart_sum.corporate_rank
    WHERE depart_sum.depart_id = DEPARTMENT.id;
    RETURN NEW;
END;
$$;

alter function update_department_coeff() owner to s264491;

