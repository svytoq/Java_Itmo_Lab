create function check_cards() returns trigger
    language plpgsql
as
$$
DECLARE
    vid_lgoti varchar(300);
  BEGIN
  vid_lgoti = (SELECT "Вид_льготы" FROM "Льготники" WHERE "Код_пассажира" = new."Код_пассажира" LIMIT 1);

    CASE new."Код_Тарифа"
      WHEN 18 THEN IF (vid_lgoti != 'Студент очной формы обучения') THEN RAISE EXCEPTION 'Добавление невозможно. Вид льготной карты не соответствует пасажиру'; end if;
      WHEN 13 THEN IF (vid_lgoti != 'Студент очной формы обучения') THEN RAISE EXCEPTION 'Добавление невозможно. Вид льготной карты не соответствует пасажиру'; end if;
      WHEN 12 THEN IF (vid_lgoti != 'Учащийся общеобразовательного учреждения Санкт-Петербурга') THEN RAISE EXCEPTION 'Добавление невозможно. Вид льготной карты не соответствует пасажиру'; end if;
      WHEN 4  THEN IF ((vid_lgoti = 'Студент очной формы обучения') OR (vid_lgoti = 'Учащийся общеобразовательного учреждения Санкт-Петербурга')) THEN RAISE EXCEPTION 'Добавление невозможно. Вид льготной карты не соответствует пасажиру'; end if;
      WHEN 3  THEN IF (vid_lgoti != 'Учащийся общеобразовательного учреждения Санкт-Петербурга') THEN RAISE EXCEPTION 'Добавление невозможно. Вид льготной карты не соответствует пасажиру'; end if;
      WHEN 2  THEN IF (vid_lgoti != 'Студент очной формы обучения') THEN RAISE EXCEPTION 'Добавление невозможно. Вид льготной карты не соответствует пасажиру'; end if;
      ELSE NULL;
    END CASE;
    RETURN new;
  end;
$$;

alter function check_cards() owner to s244710;

