create function check_tributes() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((SELECT СТАНДАРТНАЯ FROM ИГРЫ WHERE ИД_ИГРЫ = NEW.ИД_ИГРЫ)=true) THEN
IF (((SELECT COUNT(ИД_ТРИБУТА) FROM ТРИБУТЫ WHERE ИД_ИГРЫ = NEW.ИД_ИГРЫ GROUP BY ИД_ИГРЫ) + 1) > 24) THEN
RAISE WARNING 'В обычной версии игры не может быть больше 24 трибутов';
RETURN NULL;
ELSEIF (((SELECT COUNT(ТРИБУТЫ.ИД_ТРИБУТА) FROM ТРИБУТЫ 
JOIN ПОЛЬЗОВАТЕЛИ USING(ИД_ПОЛЬЗОВАТЕЛЯ)
WHERE (ТРИБУТЫ.ИД_ИГРЫ = NEW.ИД_ИГРЫ) AND (ПОЛЬЗОВАТЕЛИ.ПОЛ = (SELECT ПОЛ FROM ПОЛЬЗОВАТЕЛИ WHERE ИД_ПОЛЬЗОВАТЕЛЯ=NEW.ИД_ПОЛЬЗОВАТЕЛЯ))
GROUP BY ТРИБУТЫ.ИД_ИГРЫ)  + 1) > 12) THEN
RAISE WARNING 'В обычной версии игры не может быть больше 12 трибутов этого пола';
RETURN NULL;
ELSEIF (((SELECT COUNT(ИД_ТРИБУТА) FROM ТРИБУТЫ
JOIN ПОЛЬЗОВАТЕЛИ ON ((ПОЛЬЗОВАТЕЛИ.ИД_ПОЛЬЗОВАТЕЛЯ = ТРИБУТЫ.ИД_ПОЛЬЗОВАТЕЛЯ) 
AND (ПОЛ = (SELECT ПОЛ FROM ПОЛЬЗОВАТЕЛИ WHERE ПОЛЬЗОВАТЕЛИ.ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛЬЗОВАТЕЛЯ)) 
AND (ДИСТРИКТ = (SELECT ДИСТРИКТ FROM ПОЛЬЗОВАТЕЛИ WHERE ПОЛЬЗОВАТЕЛИ.ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛЬЗОВАТЕЛЯ)))
WHERE ИД_ИГРЫ = NEW.ИД_ИГРЫ
GROUP BY ИД_ИГРЫ) + 1) >= 2) THEN
RAISE WARNING 'Для обычной версии игры уже добавлен трибут этого пола из этого дистрикта';
RETURN NULL;
ELSE
RETURN NEW;
END IF;
ELSEIF ((SELECT COUNT(ИД_ТРИБУТА) FROM ТРИБУТЫ WHERE ИД_ИГРЫ = NEW.ИД_ИГРЫ GROUP BY ИД_ИГРЫ) 
>= (SELECT КОЛИЧЕСТВО_ТРИБУТОВ FROM ИГРЫ WHERE ИД_ИГРЫ = NEW.ИД_ИГРЫ)) THEN
RAISE WARNING 'В этой версии игры не можеть быть больше трибутов';
RETURN NULL;
ELSE
RETURN NEW;

END IF;
END;
$$;

alter function check_tributes() owner to s242361;

