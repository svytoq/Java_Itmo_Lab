create function get_screenwriter_info(screenwriter_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text, films_number integer, genres character varying[])
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT sw.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH, sw.FILMS_NUMBER, sw.GENRES FROM screenwriters AS sw 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE sw.WORKER_ID = screenwriter_id;
END
$$;

alter function get_screenwriter_info(integer) owner to s263229;

