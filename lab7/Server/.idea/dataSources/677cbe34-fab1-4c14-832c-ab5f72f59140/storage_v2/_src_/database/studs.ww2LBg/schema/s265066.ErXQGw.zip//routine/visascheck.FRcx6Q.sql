create function visascheck() returns trigger
    language plpgsql
as
$$
begin
    if (select verdict from Visa_checks where visa_app_id = NEW.visa_application)
        != 'granted' then return NULL; end if;
    
    if NEW.visa_state = 'issued' then
        if  NEW.issue_empl_id is null or
            NEW.issue_date is null then
                return NULL;
        end if;
    end if;

    if NEW.exp_date < current_date or 
        NEW.cur_trans >= NEW.max_trans then
        NEW.visa_state = 'expired';
    end if;

    return NEW;
end;
$$;

alter function visascheck() owner to s265066;

