create function check_object_placed_on_passable_cell() returns trigger
    language plpgsql
as
$$
BEGIN
	IF ((SELECT (is_passable = false) 
		FROM cells
		WHERE pos = NEW.pos AND map = NEW.map)) THEN
		RAISE EXCEPTION 
			'Cannot place object 
			in not passable cell 
			[map % at %]',
			NEW.map, NEW.pos;
	END IF;

	RETURN NEW;
END;
$$;

alter function check_object_placed_on_passable_cell() owner to s244711;

