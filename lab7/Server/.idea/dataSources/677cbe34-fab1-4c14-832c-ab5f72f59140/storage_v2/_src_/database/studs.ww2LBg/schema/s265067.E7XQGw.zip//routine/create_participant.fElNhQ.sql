create function create_participant(vfcs text) returns bigint
    language plpgsql
as
$$
DECLARE
  ret bigint;
BEGIN
  INSERT INTO participants(FCs) VALUES (vFCs) returning id into ret;
  RETURN ret;
END;
$$;

alter function create_participant(text) owner to s265067;

