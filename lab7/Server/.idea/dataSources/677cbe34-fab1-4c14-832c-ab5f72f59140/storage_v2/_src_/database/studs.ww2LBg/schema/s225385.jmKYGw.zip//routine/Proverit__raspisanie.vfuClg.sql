create function "Проверить_расписание"() returns trigger
    language plpgsql
as
$$
declare
Уже_в_наряде integer;
Всего_в_наряде integer;
Всего_на_корабле integer;
begin
select count(*) into Уже_в_наряде from Расписание_нарядов where 
ИД_Военнослужащего = new.ИД_Военнослужащего and 
Начало <= new.Начало and
Конец >= new.Начало;

select count(*) into Всего_в_наряде from Расписание_нарядов where 
Начало <= new.Начало and
Конец >= new.Начало;

select count(*) into Всего_на_корабле from Экипаж;

if (Уже_в_наряде <> 0) then raise notice 'Ошибка в расписании %. Военнослужащий №% уже в наряде.', new.ИД, new.ИД_Военнослужащего;
return null;
end if;

if (Всего_в_наряде * 3 > Всего_на_корабле) then raise notice 'Ошибка в расписании %.Нельзя, чтобы больше трети военнослужащих были в наряде. % %', new.ИД, Всего_в_наряде, Всего_на_корабле;
return null;
end if;

return new;
end
$$;

alter function "Проверить_расписание"() owner to s225385;

