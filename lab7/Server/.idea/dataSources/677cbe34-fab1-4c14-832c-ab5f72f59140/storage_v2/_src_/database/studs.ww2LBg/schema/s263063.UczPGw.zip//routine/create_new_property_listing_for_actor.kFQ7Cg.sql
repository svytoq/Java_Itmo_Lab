create function create_new_property_listing_for_actor(actorid integer, propertyid integer, listingdescription character varying, currencyid integer, propertyprice integer) returns void
    language plpgsql
as
$$
declare propertyAmount int;
begin
    propertyAmount = (select count(*) from property where owner_id = actorId and id = propertyId);
    if (propertyAmount is null or propertyAmount <= 0) then
        return;
    end if;
    with insertListing as (
        insert into listing (seller, author_id, description) values ('Actor', actorId, listingDescription)
            returning listing_id as listingId
    )
    insert
    into property_listing (listing_id, property_id, price, currency_id)
    values ((select listingId from insertListing), propertyId, propertyPrice, currencyId);
end;
$$;

alter function create_new_property_listing_for_actor(integer, integer, varchar, integer, integer) owner to s263063;

