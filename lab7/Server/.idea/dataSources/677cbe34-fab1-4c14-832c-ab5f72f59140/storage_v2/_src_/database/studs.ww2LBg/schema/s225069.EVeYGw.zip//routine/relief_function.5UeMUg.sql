create function relief_function() returns trigger
    language plpgsql
as
$$
begin
new.Relief_ID=nextval('Relief_Relief_ID_seq');
return new;
end;
$$;

alter function relief_function() owner to s225069;

