create function create_places(count integer) returns void
    language plpgsql
as
$$
DECLARE
        cinema record;
BEGIN
        FOR cinema IN (SELECT ид from Кинотеатры)
        LOOP
                PERFORM create_places_for_cinema_room
                (cinema.ид,(random()*10)::int,(random()*20)::int,(random()*500)::int);
        END LOOP;
END;
$$;

alter function create_places(integer) owner to s242395;

