create function create_in_message(msg_text text) returns integer
    language plpgsql
as
$$
declare
    new_id integer;
begin
    if (msg_text = '') is not false then return NULL; end if;

    insert into Messages(enc_content, creation_time, msg_type, msg_state)
    values(msg_text, now()::timestamp, 'in','received')
    returning msg_id into new_id;
    return new_id;
end;
$$;

alter function create_in_message(text) owner to s265066;

