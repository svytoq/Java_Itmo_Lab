create function auditfunc() returns trigger
    language plpgsql
as
$$
BEGIN
INSERT INTO AUDIT (EMP_ID, ENTRY_DATE)
VALUES (NEW.ID, current_timestamp);
RETURN NEW;
END;
$$;

alter function auditfunc() owner to s225086;

