create function visa_check_finish(check_id integer, verd s265066.visa_verdicts, com text) returns integer
    language plpgsql
as
$$
declare
    app_id integer;
begin
raise notice '%', check_id;
    if (select is_finished from Visa_checks where visa_check_id=check_id) = true then
        raise exception 'is finished';
        return 0;
    end if;

    select visa_app_id into app_id from Visa_checks where visa_check_id=check_id;

    if (select visa_app_state from Visa_applications 
            where visa_app_id=app_id)
        != 'reviewing' then
        raise exception 'not reviewing';
        return 0;
    end if;

    if not exists(
            select 1 from Visa_check_employees
            where visa_check_id=check_id
        ) then
        raise exception 'no employees';
        return 0;
    end if;

    update Visa_checks set 
        verdict_comment=com, 
        is_finished=true,
        verdict=verd,
        verdict_date=current_date
        where visa_check_id=check_id;

    if verd = 'granted' then
        update Visa_applications set 
            visa_app_state='ready'
            where visa_app_id=app_id;
    else
        update Visa_applications set 
        visa_app_state='done'
        where visa_app_id=app_id;
    end if;
    return 1;
end;
$$;

alter function visa_check_finish(integer, s265066.visa_verdicts, text) owner to s265066;

