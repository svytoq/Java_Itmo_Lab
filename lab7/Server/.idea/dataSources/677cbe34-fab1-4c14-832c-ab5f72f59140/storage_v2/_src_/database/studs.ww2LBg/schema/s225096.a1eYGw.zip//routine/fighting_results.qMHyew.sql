create function fighting_results() returns trigger
    language plpgsql
as
$$
DECLARE
	kind_of INTEGER;
	one_speed_of INTEGER;
	second_life_of INTEGER;
	second_count_of_life_of INTEGER;
	second_speed_of INTEGER;
	situation INTEGER;
	available_food_of INTEGER;
	name_food_of type_of_food;
BEGIN
	SELECT /*(p.level_of_life), ss.life,*/ss.speed INTO /*one_count_of_life_of, one_life_of,*/one_speed_of FROM passenger p LEFT JOIN skills ss ON (ss.id = p.id_of_kind) WHERE new.id_of_aggressor = p.passport_document;
	SELECT (p.level_of_life), ss.life, ss.speed, p.id_of_kind INTO second_count_of_life_of, second_life_of, second_speed_of, kind_of FROM passenger p LEFT JOIN skills ss ON (ss.id = p.id_of_kind) WHERE new.id_of_defender = p.passport_document;
	--проверка на скорость
	IF one_speed_of >= second_speed_of
		THEN
				UPDATE passenger SET level_of_life = level_of_life - new.damage  WHERE new.id_of_defender = passenger.passport_document;
				situation := check_health(second_life_of, second_count_of_life_of, new.damage, new.id_of_defender, kind_of);
				if situation = 1
					THEN
						RAISE NOTICE 'We try to help him';
							SELECT type_of_food INTO name_food_of FROM kind WHERE id_of_kind = (SELECT id_of_kind FROM passenger WHERE passport_document = NEW.id_of_defender);
						available_food_of := get_reserved_food((second_life_of - second_count_of_life_of + new.damage), name_food_of, kind_of, new.id_of_defender);
						UPDATE passenger SET level_of_life = level_of_life+available_food_of WHERE new.id_of_defender = passenger.passport_document;
			END IF;
		ELSE
		NEW.successfully = FALSE;
	END IF;
  RETURN NEW;
END;
$$;

alter function fighting_results() owner to s225096;

