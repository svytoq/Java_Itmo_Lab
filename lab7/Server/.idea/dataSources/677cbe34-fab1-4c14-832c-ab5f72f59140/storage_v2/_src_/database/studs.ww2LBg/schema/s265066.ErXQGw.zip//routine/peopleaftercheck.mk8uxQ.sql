create function peopleaftercheck() returns trigger
    language plpgsql
as
$$
begin
    -- if NEW.counterpart is not null then 
    --     if (select counterpart from People where person_id=NEW.counterpart)
    --     is null then
    --         update People set counterpart=NEW.person_id where person_id = NEW.counterpart;
    --     end if;
    -- end if;
    return NULL;
end;
$$;

alter function peopleaftercheck() owner to s265066;

