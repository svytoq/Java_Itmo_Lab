create function inc_workernum() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE factories
    SET worker_num = worker_num + 1
    WHERE factories.id = NEW.factory_id;
    RETURN NEW;
END;
$$;

alter function inc_workernum() owner to s270233;

