create function comparetable(searchtime character varying) returns boolean
    language plpgsql
as
$$
BEGIN
RETURN (SELECT COUNT(*) == 2 FROM
(SELECT time, activity FROM Truman_schedule
UNION
SELECT time, activity FROM show_schedule) AS compare_table WHERE time = to_char(searchTime,'HH24:MI:SS'));
END
$$;

alter function comparetable(varchar) owner to s277686;

