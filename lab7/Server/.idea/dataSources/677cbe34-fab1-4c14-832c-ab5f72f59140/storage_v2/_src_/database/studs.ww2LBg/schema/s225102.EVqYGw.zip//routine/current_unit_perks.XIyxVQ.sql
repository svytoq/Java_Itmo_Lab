create function current_unit_perks(name text)
    returns TABLE(perks text, bonus text)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT perks_for_units.parameter, perks_for_units.bonus FROM perks_for_units WHERE perks_for_units.id IN (SELECT unit_perks.perk_id FROM unit_perks JOIN units ON units.id = unit_perks.unit_id WHERE units.id = (SELECT units.id FROM units WHERE units.unit_name = name) );
END;
$$;

alter function current_unit_perks(text) owner to s225102;

