create function insert_business() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
  BEGIN
    LOOP
      INSERT INTO business VALUES (DEFAULT, trunc(random()*20)+1, trunc(random()*10000)+1, trunc(random()*100)+1, random()*100000::money);
      count = count + 1;
      EXIT WHEN count = 5000;
    END LOOP;
  END;
$$;

alter function insert_business() owner to s225107;

