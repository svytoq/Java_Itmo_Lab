create function check_reference(tblname text) returns void
    language plpgsql
as
$fun$
DECLARE
  row RECORD;
BEGIN
  IF tblname NOT IN ('Дома', 'Организации') THEN
    RAISE EXCEPTION $$Значение поля tblname должно быть 'Дома', 'Организации',                       'Действ_лица', 'Типы_действ_лиц'$$;
  END IF;
  FOR row IN EXECUTE 'SELECT id FROM ' || NEW.tblname LOOP
    IF NEW.id = row.id THEN
--      RETURN NEW;
    END IF;
  END LOOP;
  RAISE EXCEPTION 'Не существует записи с ИД % в таблице %', NEW.id, NEW.tbl;
END
$fun$;

alter function check_reference(text) owner to s225125;

