create function "КОЛИЧЕСТВО_РАС"("ид_государства" integer) returns integer
    language plpgsql
as
$$
BEGIN 
RETURN (SELECT COUNT(*) FROM ГОСУДАРСТВА_РАСЫ WHERE ИД_ГОСУДАРСТВА = ид_государства); 
END
$$;

alter function "КОЛИЧЕСТВО_РАС"(integer) owner to s243853;

