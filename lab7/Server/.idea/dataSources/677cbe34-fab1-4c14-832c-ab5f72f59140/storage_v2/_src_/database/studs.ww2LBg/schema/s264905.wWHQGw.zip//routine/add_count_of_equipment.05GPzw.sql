create function add_count_of_equipment() returns trigger
    language plpgsql
as
$$
DECLARE
	count_of_equip integer;
BEGIN
	IF (SELECT EXISTS(SELECT 1 FROM Counter WHERE Counter.name = NEW.name)) THEN
		UPDATE Counter SET count = count + 1 WHERE Counter.name = NEW.name;
	ELSE
		INSERT INTO Counter VALUES (NEW.name, 1);
	END IF;
    RETURN NEW;
END;
$$;

alter function add_count_of_equipment() owner to s264905;

