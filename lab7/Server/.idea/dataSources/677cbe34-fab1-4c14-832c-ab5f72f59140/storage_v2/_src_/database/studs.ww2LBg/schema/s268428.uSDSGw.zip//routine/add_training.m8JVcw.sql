create function add_training(type character, beg_date date, stream_id integer, end_date date DEFAULT NULL::date) returns integer
    language plpgsql
as
$$
DECLARE
training_id INTEGER;
begin
 training_id = nextval('training_training_id_seq ');
 
 INSERT INTO training VALUES
 (training_id, type, beg_date, stream_id, end_date);

 RETURN training_id;
 end
$$;

alter function add_training(char, date, integer, date) owner to s268428;

