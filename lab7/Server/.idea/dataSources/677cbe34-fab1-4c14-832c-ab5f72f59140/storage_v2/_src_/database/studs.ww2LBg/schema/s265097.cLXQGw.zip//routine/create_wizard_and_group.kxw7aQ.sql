create function create_wizard_and_group(wid integer, gid integer, s_name text, age integer, g_name text) returns integer
    language plpgsql
as
$$
declare 
myid integer;
begin
Insert into "Wizard"("Id", "Name", "Age") values(wid, s_name, age);
select "Id" into myid from "Wizard" where "Name" = s_name;
insert into "Group"("Id", "Name", "AdminId") values(gid, g_name, myid);
update "Wizard" set "GroupId" = gid where "Id" = myid;
return myid;
end;
$$;

alter function create_wizard_and_group(integer, integer, text, integer, text) owner to s265097;

