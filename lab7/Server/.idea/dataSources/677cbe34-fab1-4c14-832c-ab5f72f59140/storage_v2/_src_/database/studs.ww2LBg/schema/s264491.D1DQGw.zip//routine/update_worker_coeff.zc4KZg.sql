create function update_worker_coeff() returns trigger
    language plpgsql
as
$$
DECLARE
    lin_cache LIN_APPLY;
BEGIN
    SELECT (get_linear(NEW.atype_id)).* INTO lin_cache;
    UPDATE WORKER
    SET workers_rank   = (workers_rank * lin_cache.worker_coeff + lin_cache.worker_delta),
        corporate_rank = (corporate_rank * lin_cache.corp_coeff + lin_cache.corp_delta)
    WHERE NEW.worker_id = WORKER.id;
    RETURN NEW;
END;
$$;

alter function update_worker_coeff() owner to s264491;

