create function check_platforms(championship_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS(SELECT platform_id
                  FROM championship_platform
                  WHERE championship_platform.championship_id = check_platforms.championship_id) THEN
        RAISE EXCEPTION 'Championship should contains at least one platform';
    END IF;

    RETURN true;
END;
$$;

alter function check_platforms(integer) owner to s264448;

