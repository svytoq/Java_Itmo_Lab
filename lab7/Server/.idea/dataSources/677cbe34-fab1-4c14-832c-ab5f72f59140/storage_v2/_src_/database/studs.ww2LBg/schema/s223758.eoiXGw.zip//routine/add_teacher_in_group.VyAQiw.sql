create function add_teacher_in_group(integer, integer, integer, date) returns void
    language plpgsql
as
$$
DECLARE
	ид_преподавателя integer := $1;
	ид_человека integer := $2;
	ид_учебной_группы integer := $3;
	год_обучения date := $4;
BEGIN
	START TRANSACTION;
		INSERT INTO преподаватель
		VALUES (ид_преподавателя, ид_человека)
		;
		INSERT INTO учебная_группа
		VALUES (ид_учебной_группы, ид_преподавателя, год_обучения)
		;
	COMMIT;
END;
$$;

alter function add_teacher_in_group(integer, integer, integer, date) owner to s223758;

