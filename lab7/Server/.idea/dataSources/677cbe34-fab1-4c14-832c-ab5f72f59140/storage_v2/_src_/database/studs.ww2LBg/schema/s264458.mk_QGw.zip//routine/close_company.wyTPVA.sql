create function close_company(id_company integer) returns void
    language plpgsql
as
$$
BEGIN

  IF EXISTS(SELECT * FROM company WHERE company.id = close_company.id_company AND company.close_date NOTNULL) THEN
    RAISE EXCEPTION 'Company is already closed';
  ELSE
    UPDATE company
    SET company.close_date = CURRENT_DATE
    WHERE company.id = close_company.id_company;

    IF EXISTS(SELECT * FROM team WHERE team.id = close_company.id_company AND team.close_date NOTNULL) THEN
      RAISE EXCEPTION 'Company is already closed';
    ELSE
      UPDATE team
      SET team.close_date = CURRENT_DATE
      WHERE team.id = close_company.id_company;
    END IF;

  END IF;

END;

$$;

alter function close_company(integer) owner to s264458;

