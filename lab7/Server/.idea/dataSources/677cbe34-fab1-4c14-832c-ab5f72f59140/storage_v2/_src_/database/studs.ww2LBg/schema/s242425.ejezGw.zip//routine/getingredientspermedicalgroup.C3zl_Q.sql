create function getingredientspermedicalgroup(name text)
    returns TABLE("ИД_ИНГРЕДИЕНТА" integer, "НАЗВАНИЕ" text, "СТОИМОСТЬ" integer, "МАССА" double precision)
    language sql
as
$$
select * from getMedicineConsist(
    ( 
        select ИД_ЛЕКАРСТВА
        from ЛЕКАРСТВО
            join ЗАКАЗ using(ИД_ЛЕКАРСТВА)
        where ЗАКАЗ.НАЗВАНИЕ_АПТЕЧНОЙ_СЕТИ = 'ABC')
    )
$$;

alter function getingredientspermedicalgroup(text) owner to s242425;

