create function commit_delivery_auto() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (SELECT EXISTS(SELECT 1 FROM Delivery_Auto WHERE Delivery_Auto.miner_id = NEW.miner_id)) THEN
		RAISE 'Этот шахтер уже получил авто';
	ELSEIF (((SELECT count FROM Counter WHERE Counter.name = 'АВТО') = 0) OR (SELECT NOT EXISTS (SELECT 1 FROM Counter WHERE Counter.name = 'АВТО' ))) THEN
		RAISE 'Нет авто';
	ELSEIF (SELECT EXISTS(SELECT 1 FROM Delivery_Auto WHERE Delivery_Auto.auto_id = NEW.auto_id)) THEN
		RAISE 'Авто уже выдано';
	ELSEIF (NOT(SELECT EXISTS(SELECT 1 FROM Miner WHERE NEW.miner_id IN (SELECT miner_id FROM Brigade_record)))) THEN
		RAISE 'Шахтер не относится ни к какой бригаде';
	ELSEIF (NEW.delivery_date != current_date) THEN
		RAISE 'Выдача может быть только в сегодняшний день';
	ELSE
		IF ((SELECT part FROM Brigade_record INNER JOIN Miner ON Brigade_record.miner_id = Miner.miner_id WHERE Miner.miner_id = NEW.miner_id) <> 'ВОДИТЕЛЬ') THEN
			RAISE 'Только водитель может брать авто';
		END IF;
		UPDATE Counter SET count = count - 1 WHERE Counter.name = 'АВТО';
	END IF;
    RETURN NEW;
END;
$$;

alter function commit_delivery_auto() owner to s264905;

