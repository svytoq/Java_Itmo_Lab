create function store_navigation_unique_pair() returns trigger
    language plpgsql
as
$$
BEGIN
        IF EXISTS(
            SELECT from_id, to_id FROM store_navigation WHERE
                (from_id = NEW.from_id AND to_id = NEW.to_id) OR
                (from_id = NEW.to_id AND to_id = NEW.from_id)
        ) THEN
            RETURN NULL;
        END IF;
        RETURN NEW;
    END
$$;

alter function store_navigation_unique_pair() owner to s265092;

