create function trigger_army_before_del() returns trigger
    language plpgsql
as
$$
BEGIN

    if (select count(*) from "Существо" a
    where a."Войско"=OLD."id")>0
        then delete from "Существо" where "Существо"."Войско"=OLD."id";
    end if;

    return OLD;
END;
$$;

alter function trigger_army_before_del() owner to s225133;

