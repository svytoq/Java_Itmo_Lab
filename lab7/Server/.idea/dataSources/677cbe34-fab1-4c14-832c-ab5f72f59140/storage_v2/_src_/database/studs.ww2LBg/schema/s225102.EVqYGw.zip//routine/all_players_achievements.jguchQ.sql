create function all_players_achievements()
    returns TABLE(player_name text, achievement text, achievement_date date, condition text)
    language plpgsql
as
$$
BEGIN
		RETURN QUERY SELECT player.name, achievements.name, achievements.achieving_date, achievements.conditions FROM player JOIN achievements ON player.id = achievements.player_id ORDER BY achievements.player_id;
	END;
$$;

alter function all_players_achievements() owner to s225102;

