create function is_unit_instance_claimed(_unit integer) returns boolean
    language plpgsql
as
$$
DECLARE
	amount int;
	sum int = 0;
BEGIN
	SELECT count(*) INTO amount 
		FROM map_units
		WHERE unit = _unit;

	sum = sum + amount;

	SELECT count(*) INTO amount 
		FROM building_unit
		WHERE unit = _unit;

	sum = sum + amount;

	SELECT count(*) INTO amount 
		FROM hero_unit
		WHERE unit = _unit;

	sum = sum + amount;
	
	RETURN sum > 0;
END;
$$;

alter function is_unit_instance_claimed(integer) owner to s244711;

