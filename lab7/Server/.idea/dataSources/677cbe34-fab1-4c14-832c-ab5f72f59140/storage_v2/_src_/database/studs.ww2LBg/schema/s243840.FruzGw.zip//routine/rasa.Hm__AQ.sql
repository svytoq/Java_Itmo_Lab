create function раса() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.название IN (select название from раса) THEN
UPDATE раса SET умения = NEW.умения, k_дружелюбности = NEW.k_дружелюбности WHERE название = NEW.название;
RETURN null;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function раса() owner to s243840;

