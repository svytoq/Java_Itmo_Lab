create function check_judge_teams(championship_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    cur_judge_team judge_team%rowtype;
BEGIN
    IF NOT EXISTS(SELECT judge.judge_team_id
                  FROM judge_team
                           JOIN judge ON judge_team.judge_team_id = judge.judge_team_id
                  WHERE judge.championship_id = check_judge_teams.championship_id) THEN
        RAISE EXCEPTION 'Championship should contains at least one platform';
    END IF;

    FOR cur_judge_team IN
        (SELECT *
         FROM judge_team
         WHERE EXISTS(SELECT * FROM judge WHERE judge.judge_team_id = judge_team.judge_team_id
                                            AND judge.championship_id = check_judge_teams.championship_id))
        LOOP
            IF ((SELECT COUNT(*) FROM judge WHERE judge.judge_team_id = cur_judge_team.judge_team_id) != 3) THEN
                RAISE EXCEPTION 'Judge teams should contains 3 judges.';
            END IF;
        END LOOP;

    RETURN true;
END;
$$;

alter function check_judge_teams(integer) owner to s264448;

