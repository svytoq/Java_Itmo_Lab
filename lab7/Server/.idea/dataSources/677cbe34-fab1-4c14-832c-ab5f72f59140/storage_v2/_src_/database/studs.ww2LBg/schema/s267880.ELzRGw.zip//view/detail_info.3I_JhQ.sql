create view detail_info(detail_type_id, name, unit, quantity_remain) as
SELECT detail_type.detail_type_id,
       detail_type.name,
       detail_type.unit,
       detail_remain.quantity_remain
FROM s267880.detail_type
         JOIN s267880.detail_remain USING (detail_type_id);

alter table detail_info
    owner to s267880;

