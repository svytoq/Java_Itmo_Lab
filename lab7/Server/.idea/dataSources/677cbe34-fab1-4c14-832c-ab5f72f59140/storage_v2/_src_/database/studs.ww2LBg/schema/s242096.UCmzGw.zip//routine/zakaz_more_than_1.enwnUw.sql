create function zakaz_more_than_1() returns SETOF integer
    language sql
as
$$
SELECT Код_клиента from Заказ where (Дата_оформления between '01/01/2017'::date and '01/02/2017'::date);

$$;

alter function zakaz_more_than_1() owner to s242096;

