create function get_user_data(requester_id integer)
    returns TABLE(user_id integer, name character varying, email character varying, card_level integer, card_points integer, card_release_time timestamp without time zone)
    language plpgsql
as
$$
BEGIN
        RETURN QUERY
            SELECT u.id AS user_id, u.name, u.email, card.level, card.points, card.release_time
            FROM user_account u
            LEFT JOIN family_card card
            ON card.id = u.family_card_id
            WHERE u.id = requester_id;
    END;
$$;

alter function get_user_data(integer) owner to s264443;

