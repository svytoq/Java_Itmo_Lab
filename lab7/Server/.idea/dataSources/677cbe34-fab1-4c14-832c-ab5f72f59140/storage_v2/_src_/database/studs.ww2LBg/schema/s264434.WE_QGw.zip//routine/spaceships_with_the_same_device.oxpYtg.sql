create function spaceships_with_the_same_device(_device_id integer)
    returns TABLE(spaceship_id integer, spaceship_name character varying, id_home_planet integer, id_current_planet integer, id_manufacture integer)
    language plpgsql
as
$$
begin
return query SELECT * from "Spaceships"
    where id = (select id_spaceship from "Spaceships_Devices" where id_device=_device_id);
end;
$$;

alter function spaceships_with_the_same_device(integer) owner to s264434;

