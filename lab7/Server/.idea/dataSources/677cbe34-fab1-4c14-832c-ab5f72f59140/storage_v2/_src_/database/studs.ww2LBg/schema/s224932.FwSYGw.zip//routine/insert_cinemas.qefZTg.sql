create function insert_cinemas(count integer) returns void
    language plpgsql
as
$$
DECLARE
        circuit record;
BEGIN
        FOR circuit IN (SELECT ид, название from Сети)
        LOOP
                FOR i in 1 .. count LOOP
                insert into Кинотеатры(ид_сети, название, город, адрес) 
                        values(circuit.ид,circuit.название, 'Санкт-Петербург', random_string(8));
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_cinemas(integer) owner to s224932;

