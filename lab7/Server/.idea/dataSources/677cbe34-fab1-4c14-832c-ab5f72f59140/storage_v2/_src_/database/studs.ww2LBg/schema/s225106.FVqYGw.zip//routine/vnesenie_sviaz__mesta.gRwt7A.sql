create function внесение_связь_места(number integer, place text) returns void
    language plpgsql
as
$$
DECLARE
chislo int;
place_epiz int;
BEGIN
SELECT ИД INTO STRICT chislo FROM ЭПИЗОД WHERE ИД=number;
SELECT ИД INTO STRICT place_epiz FROM МЕСТО WHERE МЕСТО=place;
INSERT INTO СВЯЗЬ_МЕСТА VALUES(chislo, place_epiz);
raise notice 'Inserted into СВЯЗЬ_МЕСТА %, %', chislo, place_epiz;
EXCEPTION
WHEN NO_DATA_FOUND THEN 
RAISE NOTICE 'You entered incorrect data';
RETURN;
END;
$$;

alter function внесение_связь_места(integer, text) owner to s225106;

