create function reborn_leader() returns trigger
    language plpgsql
as
$$
BEGIN
		IF NEW.name is null then
			raise exception 'not leader';
		END IF;
		IF NEW.char_id IS NULL THEN
			RAISE EXCEPTION 'leader dont have characteristics';
		END IF;
		if new.isalive = false then 
		update characteristics set intellect = 10, agillity = 10, strength = 10, armor = 50 where id = old.char_id;
		new.isalive = true;
		new.char_id = old.char_id;
		new.name = old.name;
		new.experience = 0;
		end if;
		return new;
	END;
$$;

alter function reborn_leader() owner to s264430;

