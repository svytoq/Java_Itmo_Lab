create function "РЕДАКЦИИ_ИД_АПДЕЙТ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ИД_РЕДАКЦИИ!=NEW.ИД_РЕДАКЦИИ
THEN NEW.ИД_РЕДАКЦИИ=OLD.ИД_РЕДАКЦИИ; 
	RETURN NEW;
ELSE RETURN NEW; 
END IF; 
END;
$$;

alter function "РЕДАКЦИИ_ИД_АПДЕЙТ"() owner to s225071;

