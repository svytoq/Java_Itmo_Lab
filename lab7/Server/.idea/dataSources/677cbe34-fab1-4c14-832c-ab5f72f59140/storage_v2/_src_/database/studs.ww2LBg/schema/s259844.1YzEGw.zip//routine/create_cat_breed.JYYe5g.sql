create function create_cat_breed(breed_name text, breed_price double precision) returns s259844.cat_breed
    strict
    language plpgsql
as
$$
DECLARE
    ret cat_breed;
BEGIN
    INSERT INTO cat_breed(name, price) VALUES (breed_name, breed_price)
        ON CONFLICT (name) DO UPDATE SET price = breed_price
        RETURNING * INTO ret;

    RETURN ret;
END;
$$;

alter function create_cat_breed(text, double precision) owner to s259844;

