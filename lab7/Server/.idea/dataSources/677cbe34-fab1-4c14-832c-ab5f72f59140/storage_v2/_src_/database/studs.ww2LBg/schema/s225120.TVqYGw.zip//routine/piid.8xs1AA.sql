create function piid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_КАРТИНЫ := nextval('pictures_seq');
	return new;
end
$$;

alter function piid() owner to s225120;

