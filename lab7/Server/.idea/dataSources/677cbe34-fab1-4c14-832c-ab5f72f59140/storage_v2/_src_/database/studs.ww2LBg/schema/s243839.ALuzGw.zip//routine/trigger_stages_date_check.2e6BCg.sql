create function trigger_stages_date_check() returns trigger
    language plpgsql
as
$$
BEGIN
IF NOT (EXISTS (SELECT ИД_МУЛЬТФИЛЬМА FROM ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА WHERE ИД_МУЛЬТФИЛЬМА=NEW.ИД_МУЛЬТФИЛЬМА)) THEN RETURN NEW;
END IF;
IF NEW.ДАТА_СДАЧИ > (SELECT ДАТА_ВЫХОДА FROM МУЛЬТФИЛЬМ WHERE ИД_МУЛЬТФИЛЬМА=NEW.ИД_МУЛЬТФИЛЬМА) THEN RETURN NULL;
END IF;
  RETURN NEW;
END;
$$;

alter function trigger_stages_date_check() owner to s243839;

