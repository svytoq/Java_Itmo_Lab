create function get_star(army integer)
    returns TABLE(star_name character varying, difficulty smallint, resources numeric, distance double precision)
    language plpgsql
as
$$
declare
    army_current_planet int;
    current_planet_x bigint;
    current_planet_y bigint;
    current_planet_z bigint;
    current_planet_r bigint;
  begin
    select planet.object_id INTO army_current_planet from planet 
    where planet.army_id = army;
    
    if not found then
      raise exception 'No such planet with provided army';
    end if;
    
    select x_coordinate, y_coordinate, z_coordinate, radius
    into current_planet_x, current_planet_y, current_planet_z, current_planet_r
    from space_object where id = army_current_planet;
    
    return query select s_o.name, s.difficulty, 
    (select sum(quantity) from resource_space_object where object_id = s_o.id),
    sqrt(
      power(current_planet_x - s_o.x_coordinate, 2) + 
      power(current_planet_y - s_o.y_coordinate, 2) + 
      power(current_planet_z - s_o.z_coordinate, 2)
    )-current_planet_r-s_o.radius as distance from space_object as s_o
    inner join star as s on (s.object_id = s_o.id)
    order by distance;
  end;
$$;

alter function get_star(integer) owner to s264482;

