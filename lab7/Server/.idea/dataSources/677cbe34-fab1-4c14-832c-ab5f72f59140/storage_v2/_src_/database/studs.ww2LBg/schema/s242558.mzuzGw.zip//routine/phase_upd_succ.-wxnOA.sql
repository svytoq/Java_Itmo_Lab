create function phase_upd_succ() returns trigger
    language plpgsql
as
$$
BEGIN
    IF new.типс_ид=(SELECT ид FROM типы_стадий WHERE название LIKE 'Регулярный сезон') THEN
        IF (new.конец IS NOT NULL) THEN
            IF EXISTS (SELECT 1 FROM стадии WHERE (ид<>old.ид) AND (сезон_ид=old.сезон_ид)) THEN
                IF (SELECT начало FROM стадии WHERE (ид<>old.ид) AND (сезон_ид=old.сезон_ид)) IS NULL THEN
                    UPDATE стадии SET начало=new.конец+1 WHERE (ид<>old.ид) AND (сезон_ид=old.сезон_ид);
                END IF;
            END IF;
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function phase_upd_succ() owner to s242558;

