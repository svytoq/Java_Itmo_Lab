create function oncreatingcharacter() returns trigger
    language plpgsql
as
$$
BEGIN
IF (NEW.ОРГАНИЗАЦИИ IS NOT NULL) 
THEN
UPDATE ОРГАНИЗАЦИИ SET КОЛИЧЕСТВО_УЧАСТНИКОВ = КОЛИЧЕСТВО_УЧАСТНИКОВ + 1 WHERE НАИМЕНОВАНИЕ IN( SELECT НАИМЕНОВАНИЕ FROM NEW);
RETURN NEW;
        END IF;
RETURN NEW;
END;
$$;

alter function oncreatingcharacter() owner to s225054;

