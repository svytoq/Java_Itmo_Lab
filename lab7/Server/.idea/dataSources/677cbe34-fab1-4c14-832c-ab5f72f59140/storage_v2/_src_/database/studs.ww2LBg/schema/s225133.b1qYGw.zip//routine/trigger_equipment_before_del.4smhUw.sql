create function trigger_equipment_before_del() returns trigger
    language plpgsql
as
$$
BEGIN

    if (select count(*) from "Артефакт" a
    where a."id_экипировки"=OLD."id")>0
        then delete from "Артефакт" where "Артефакт"."id_экипировки"=OLD."id";
    end if;

    return OLD;
END;
$$;

alter function trigger_equipment_before_del() owner to s225133;

