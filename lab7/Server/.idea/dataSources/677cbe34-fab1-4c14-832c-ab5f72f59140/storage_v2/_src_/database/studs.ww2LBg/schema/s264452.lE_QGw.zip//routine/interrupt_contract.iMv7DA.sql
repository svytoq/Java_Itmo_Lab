create function interrupt_contract(id_arg uuid) returns void
    language plpgsql
as
$$
BEGIN
    update contract
    set interrupted     = true,
        interrupted_date=CURRENT_TIMESTAMP
    where id = id_arg;
END;
$$;

alter function interrupt_contract(uuid) owner to s264452;

