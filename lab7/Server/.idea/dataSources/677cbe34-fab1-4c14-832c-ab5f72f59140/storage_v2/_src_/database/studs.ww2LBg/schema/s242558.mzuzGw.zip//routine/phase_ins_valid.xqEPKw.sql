create function phase_ins_valid() returns trigger
    language plpgsql
as
$$
BEGIN
    IF EXISTS (SELECT 1 FROM стадии WHERE (сезон_ид=new.сезон_ид) AND (типс_ид=new.типс_ид)) THEN
        RAISE EXCEPTION 'Все стадии автоматически создаются при добавлении или изменении сезонов!';
    END IF;
    RETURN NEW;
END;
$$;

alter function phase_ins_valid() owner to s242558;

