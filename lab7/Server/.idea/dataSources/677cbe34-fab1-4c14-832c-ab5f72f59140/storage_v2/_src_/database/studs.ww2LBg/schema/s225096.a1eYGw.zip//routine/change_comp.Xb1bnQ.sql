create function change_comp() returns trigger
    language plpgsql
as
$$
DECLARE
	old_hab_of INTEGER;
	new_hab_of INTEGER;
BEGIN
	SELECT id_habitat INTO old_hab_of FROM compartment WHERE id_comparatment = ANY (SELECT id_of_compartment FROM passenger where new.pass_id = passport_document);
	SELECT id_habitat INTO new_hab_of FROM compartment WHERE id_comparatment = NEW.comp_id;
	IF (old_hab_of = new_hab_of)
		THEN
				UPDATE passenger SET passenger.id_of_compartment = new.comp_id;
		ELSE
			RAISE NOTICE 'THE ANIMAL CANT LIVE IN THIS HABITAT';
			RETURN NULL;
	END IF;
  RETURN NEW;
END;
$$;

alter function change_comp() owner to s225096;

