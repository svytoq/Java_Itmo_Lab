create function asoiaffindmaxcomparablepartindex(t1_arr integer[], t2_arr integer[]) returns integer
    language plpgsql
as
$$
DECLARE
  min1 int = 0; min2 int = 0;
  NULLFound bool = false;
  asoiafTmstmp bigint = 0;
BEGIN
  WHILE (NOT NULLFound) AND min1 < 6 LOOP
    min1 = min1 + 1;
    IF t1_arr[min1] IS NULL THEN
      NULLFound = true;
    END IF;
  END LOOP;

  NULLFound = false;
  WHILE (NOT NULLFound) AND min2 < 6 LOOP
    min2 = min2 + 1;
    IF t2_arr[min2] IS NULL THEN
      NULLFound = true;
    END IF;
  END LOOP;

  IF min1 < min2 THEN
    RETURN min1-1;
  ELSE
    RETURN min2-1;
  END IF;
END
$$;

alter function asoiaffindmaxcomparablepartindex(integer[], integer[]) owner to s225125;

