create function get_object_suggestions_in_dormitory(dormitory_id integer)
    returns TABLE(id integer, name character varying, description character varying, status s265087."STATUS", creation_date timestamp with time zone, author integer, object integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT SUGGESTION.ID          as ID,
                        SUGGESTION.NAME        as SUGGESTION_NAME,
                        SUGGESTION.DESCRIPTION as SUGGESTION_DESCRIPTION,
                        SUGGESTION.STATUS,
                        SUGGESTION.CREATION_DATE,
                        SUGGESTION.AUTHOR,
                        OBJECT.ID              as OBJECT
                 FROM USERS
                          JOIN DORMITORY ON USERS.DORMITORY = DORMITORY.ID
                          JOIN SUGGESTION ON SUGGESTION.AUTHOR = USERS.ID
                          JOIN OBJECT_SUGGESTION ON OBJECT_SUGGESTION.ID = SUGGESTION.ID
                          JOIN OBJECT ON OBJECT_SUGGESTION.OBJECT = OBJECT.ID
                 WHERE DORMITORY.ID = DORMITORY_ID;
END;
$$;

alter function get_object_suggestions_in_dormitory(integer) owner to s265087;

