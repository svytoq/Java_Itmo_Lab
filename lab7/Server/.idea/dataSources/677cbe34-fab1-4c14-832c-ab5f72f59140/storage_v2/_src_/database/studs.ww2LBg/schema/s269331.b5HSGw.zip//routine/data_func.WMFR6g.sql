create function data_func() returns trigger
    language plpgsql
as
$$
BEGIN
NEW.ДАТА = CURRENT_DATE;
RETURN NEW;
END;
$$;

alter function data_func() owner to s269331;

