create function tech_to_wonder(wname text)
    returns TABLE(tech_name text, points integer, features text)
    language plpgsql
as
$$
BEGIN
		RETURN QUERY SELECT technologies.tech_name, technologies.points, technologies.features FROM  (technologies JOIN tech_wonder ON technologies.id = tech_wonder.technology) JOIN wonders ON tech_wonder.wonder = wonders.id WHERE wonders.name = wname; 
	END;
$$;

alter function tech_to_wonder(text) owner to s225102;

