create function check_order() returns trigger
    language plpgsql
as
$$
BEGIN
  IF (SELECT ОТПРАВИТЕЛЬ_ИД FROM ЕДА WHERE ЕДА_ИД = NEW.ЕДА_ИД) != (SELECT ОТПРАВИТЕЛЬ_ИД FROM ЗАКАЗ WHERE  ЗАКАЗ_ИД=NEW.ЗАКАЗ_ИД)
    THEN
      RAISE EXCEPTION 'Error in completing order';
  end if;
  RETURN NEW;
END;
$$;

alter function check_order() owner to s242456;

