create function set_police_priority() returns trigger
    language plpgsql
as
$$
declare max_pr integer;
    begin
        select max(priority) into max_pr from time_police_officers;
        NEW.priority = max_pr + 1;
        return NEW;
    end;
$$;

alter function set_police_priority() owner to s265103;

