create function "НАЙТИ_СВОБОДНУЮ_АУДИТОРИЮ"(start_time timestamp without time zone, finish_time timestamp without time zone) returns SETOF smallint
    language sql
as
$$
select НОМЕР FROM АУДИТОРИЯ WHERE NOT EXISTS
(SELECT ЗАНЯТИЕ_ИД FROM ЗАНЯТИЕ WHERE (ЗАНЯТИЕ.АУД_ИД=АУДИТОРИЯ.НОМЕР AND NOT(start_time>=ЗАНЯТИЕ.ВРЕМЯ_КОНЦА) AND NOT(finish_time<=ЗАНЯТИЕ.ВРЕМЯ_НАЧАЛА)))
AND NOT EXISTS
(SELECT ЭКЗАМЕН_ИД FROM ЭКЗАМЕН WHERE (ЭКЗАМЕН.АУД_ИД=АУДИТОРИЯ.НОМЕР AND NOT(start_time>=ЭКЗАМЕН.ВРЕМЯ_КОНЦА) AND NOT(finish_time<=ЭКЗАМЕН.ВРЕМЯ_НАЧАЛА)))
$$;

alter function "НАЙТИ_СВОБОДНУЮ_АУДИТОРИЮ"(timestamp, timestamp) owner to s265057;

