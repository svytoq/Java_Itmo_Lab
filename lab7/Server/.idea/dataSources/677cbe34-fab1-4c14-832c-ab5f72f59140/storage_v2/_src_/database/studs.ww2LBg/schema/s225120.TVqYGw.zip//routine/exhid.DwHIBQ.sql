create function exhid() returns trigger
    language plpgsql
as
$$
begin
	if ((select count(ИД) from addition) > 0) then
	new.ИД_ВЫСТАВКИ := (select min(ИД) from addition);
	delete from addition where ИД = (select min(ИД) from addition);
	else new.ИД_ВЫСТАВКИ := nextval('exhibitions_seq');
	end if;
	return new;
end
$$;

alter function exhid() owner to s225120;

