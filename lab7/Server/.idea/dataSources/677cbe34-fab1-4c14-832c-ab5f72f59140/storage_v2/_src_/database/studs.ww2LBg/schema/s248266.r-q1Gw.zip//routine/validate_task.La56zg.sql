create function validate_task() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Убедимся, что задача не слишком стара
    IF NEW.Дата < ANY(
            SELECT Дата_рождения FROM К_Пользователь
            WHERE ИД = NEW.ИД_Пользователя)
    THEN
        RAISE EXCEPTION 'Задача % старше пользователя', NEW.ИД;
    END IF;
    RETURN NEW;
  END
$$;

alter function validate_task() owner to s248266;

