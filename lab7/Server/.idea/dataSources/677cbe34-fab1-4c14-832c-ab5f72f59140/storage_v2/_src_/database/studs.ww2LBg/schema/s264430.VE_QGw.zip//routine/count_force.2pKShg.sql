create function count_force() returns trigger
    language plpgsql
as
$$
BEGIN
		IF NEW.ID_АРМИИ is null then
			raise exception 'отряд не принадлежит армии';
		END IF;
		IF NEW.РОДНОЙ_ДОМ IS NULL THEN
			RAISE EXCEPTION 'отряд не принадлежит Дому';
		END IF;
		IF NEW.ТИП_ОТРЯДА IS NULL THEN
			RAISE EXCEPTION 'У отряда не прописан тип';
		END IF;
		IF NEW.ЧИСЛЕННОСТЬ IS NULL AND NEW.ЧИСЛЕННОСТЬ < 0 THEN
			RAISE EXCEPTION 'Неверное значение численности';
		END IF;
		IF NEW.БОЕВАЯ_МОЩЬ_ЕДИНИЦЫ IS NULL AND NEW.БОЕВАЯ_МОЩЬ_ЕДИНИЦЫ < 0 THEN
			RAISE EXCEPTION 'Неверное значение для боевой мощи единицы';
		END IF;
		NEW.БОЕВАЯ_МОЩЬ := NEW.БОЕВАЯ_МОЩЬ_ЕДИНИЦЫ * NEW.ЧИСЛЕННОСТЬ;
		RETURN NEW;
	END;
$$;

alter function count_force() owner to s264430;

