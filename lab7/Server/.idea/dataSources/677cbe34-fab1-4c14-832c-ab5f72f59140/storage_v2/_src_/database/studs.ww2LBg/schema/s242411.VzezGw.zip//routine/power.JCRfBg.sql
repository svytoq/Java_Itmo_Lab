create function power() returns trigger
    language plpgsql
as
$$
BEGIN
CASE WHEN (NEW.ВЛИЯНИЕ + (SELECT SUM (ВЛИЯНИЕ) FROM ГРУППИРОВКА)) > 100 THEN
NEW.ВЛИЯНИЕ := 0;
ELSE NEW.ВЛИЯНИЕ := NEW.ВЛИЯНИЕ + 0;
END CASE;
RETURN NEW;
END;
$$;

alter function power() owner to s242411;

