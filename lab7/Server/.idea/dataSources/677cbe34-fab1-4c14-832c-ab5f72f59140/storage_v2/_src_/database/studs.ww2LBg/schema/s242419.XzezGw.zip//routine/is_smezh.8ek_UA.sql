create function is_smezh(stop_id integer) returns integer
    language plpgsql
as
$$
declare kolOst integer;
current_num integer;
x_curr integer;
y_curr integer;
x_ost integer;
y_ost integer;
num integer;
smezh integer;
i record;
BEGIN

smezh := 0;
select count(*) into kolOst from ОСТАНОВКА;
select номер into current_num from ОСТАНОВКА inner join МАРШРУТ on (ОСТАНОВКА.ид_маршрута=МАРШРУТ.ид) where ОСТАНОВКА.ид=stop_id;
select х_коор into x_curr from ОСТАНОВКА where ОСТАНОВКА.ид=stop_id;
select у_коор into y_curr from ОСТАНОВКА where ОСТАНОВКА.ид=stop_id;
<<karl>>
for i in 1..kolOst loop
select х_коор into x_ost from ОСТАНОВКА inner join МАРШРУТ on (ОСТАНОВКА.ид_маршрута=МАРШРУТ.ид) where ОСТАНОВКА.ид=i;
select у_коор into y_ost from ОСТАНОВКА inner join МАРШРУТ on (ОСТАНОВКА.ид_маршрута=МАРШРУТ.ид) where ОСТАНОВКА.ид=i;
select номер into num from ОСТАНОВКА inner join МАРШРУТ on (ОСТАНОВКА.ид_маршрута=МАРШРУТ.ид) where ОСТАНОВКА.ид=i;
if (x_curr=x_ost) and (y_curr=y_ost) and (current_num <> num) then
smezh := 1;
exit karl;
else
end if;
end loop;
return smezh;
END;
$$;

alter function is_smezh(integer) owner to s242419;

