create function check_building_strength(strength integer, building_type integer) returns boolean
    stable
    language sql
as
$$
select (building_type.max_strength > $1) as boolean 
from building_type 
inner join building on building.building_type = $2
limit 1;

$$;

alter function check_building_strength(integer, integer) owner to s264479;

