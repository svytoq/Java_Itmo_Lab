create function moneyexcursionsdel() returns trigger
    language plpgsql
as
$$
declare money integer;
begin
	money:= 5000;
	update СОТРУДНИКИ set ОКЛАД = (ОКЛАД - money) where ИД_СОТРУДНИКА = new.ИД_СОТРУДНИКА;
	return new;
end;
$$;

alter function moneyexcursionsdel() owner to s225120;

