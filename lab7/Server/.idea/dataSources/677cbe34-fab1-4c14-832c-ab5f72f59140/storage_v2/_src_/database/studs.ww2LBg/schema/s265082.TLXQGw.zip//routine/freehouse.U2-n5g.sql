create function freehouse() returns text
    language plpgsql
as
$$
BEGIN 
EXECUTE DELETE FROM "Житель" WHERE "Кол-во лет в партии" > 0.66 AND "Кол-во лет в партии" < 0.67;
RETURN 'removed';
END
$$;

alter function freehouse() owner to s265082;

