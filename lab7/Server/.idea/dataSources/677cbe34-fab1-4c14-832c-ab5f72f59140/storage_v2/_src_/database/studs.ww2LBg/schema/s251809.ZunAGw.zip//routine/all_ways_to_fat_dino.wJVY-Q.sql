create function all_ways_to_fat_dino(tourist_id integer)
    returns TABLE(path integer[], distanatce_to_go double precision)
    language sql
as
$$
WITH RECURSIVE p(last_vertex, hops, iteration, full_dist) AS ( --p первая итерация
SELECT id, 
 ARRAY[id], 
 1::int,
 0::float
FROM sections
WHERE id=(SELECT section_id FROM tourist WHERE id=tourist_id)
UNION ALL -- рекурсивная часть
SELECT e.second_vertex_id AS last_vertex, --вершина в которую идём становится последней
 p.hops || ARRAY[e.second_vertex_id] AS hops, --конкатинируем массивы (путь)
 p.iteration + 1 AS iteration, 
 p.full_dist + e.distance AS full_dist
FROM edge e, p
WHERE e.first_vertex_id=p.last_vertex 
 AND NOT e.second_vertex_id = ANY(p.hops) --проверяем, что ещё не посещали эту вершину
  --AND p.iteration < 4 --те строчки, где первая вершина равна последней пройденой на прошлой иттерации

) 
SELECT hops, full_dist FROM p WHERE p.last_vertex=(
SELECT sections.id AS section_id FROM dinosaurs
JOIN sections ON dinosaurs.sectionid=sections.id
--JOIN species ON dinosaurs.speciesid=species.id
JOIN dinosaur_state ON dinosaurs.stateid=dinosaur_state.id 
WHERE 
weight=(SELECT MAX(dinosaurs.weight) FROM dinosaurs WHERE dinosaurs.stateid=3)
LIMIT 1
);
$$;

alter function all_ways_to_fat_dino(integer) owner to s251809;

