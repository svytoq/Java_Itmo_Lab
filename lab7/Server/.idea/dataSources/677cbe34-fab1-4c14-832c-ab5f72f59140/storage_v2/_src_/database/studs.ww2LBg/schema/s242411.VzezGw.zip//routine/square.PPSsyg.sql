create function square() returns trigger
    language plpgsql
as
$$
BEGIN
CASE WHEN NEW.ПЛОЩАДЬ < 0 THEN
NEW.ПЛОЩАДЬ := -NEW.ПЛОЩАДЬ;
ELSE NEW.ПЛОЩАДЬ := NEW.ПЛОЩАДЬ + 0;
END CASE;
RETURN NEW;
END;
$$;

alter function square() owner to s242411;

