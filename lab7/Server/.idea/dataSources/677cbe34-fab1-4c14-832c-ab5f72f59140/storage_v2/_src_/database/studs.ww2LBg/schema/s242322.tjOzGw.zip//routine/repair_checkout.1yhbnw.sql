create function repair_checkout() returns void
    language plpgsql
as
$$
declare
rep_table record;
r_c integer;
begin
        select count(*) into r_c from РЕМОНТ_ТРАНСПОРТА where date(ГОТОВНОСТЬ_К) = current_date;
        if r_c > 0 then
            raise notice 'Отремотировано % единиц транспорта', r_c;
            select count(ИД) as CNT, ТРАНСПОРТ into rep_table from РЕМОНТ_ТРАНСПОРТА where date(ГОТОВНОСТЬ_К) = current_date group by ТРАНСПОРТ;
            update ТРАНСПОРТ set ГОТОВО_ЕДИНИЦ = ГОТОВО_ЕДИНИЦ + rep_table.CNT where ИД in (select ТРАНСПОРТ from rep_table);
        end if;
        
        select count(*) into r_c from РЕМОНТ_ОРУЖИЯ where date(ГОТОВНОСТЬ_К) = current_date;
        if r_c > 0 then
            raise notice 'Отремотировано % единиц оружия', r_c;
            select count(ИД) as CNT, ОРУЖИЕ into rep_table from РЕМОНТ_ОРУЖИЯ where date(ГОТОВНОСТЬ_К) = current_date group by ОРУЖИЕ;
            update ОРУЖИЕ set ГОТОВО_ЕДИНИЦ = ГОТОВО_ЕДИНИЦ + rep_table.CNT where ИД in (select ОРУЖИЕ from rep_table);
        end if;
end;
$$;

alter function repair_checkout() owner to s242322;

