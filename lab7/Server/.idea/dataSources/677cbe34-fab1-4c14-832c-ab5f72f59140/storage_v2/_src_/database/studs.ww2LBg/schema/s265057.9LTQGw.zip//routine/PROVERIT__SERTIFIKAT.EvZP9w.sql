create function "ПРОВЕРИТЬ_СЕРТИФИКАТ"() returns trigger
    language plpgsql
as
$$
DECLARE
	stud_id integer;
	result_ex boolean;
	ex_type ТИП_ЭКЗАМЕНА;
BEGIN
	SELECT INTO stud_id,ex_type,result_ex УЧЕНИК_ИД,ТИП,РЕЗУЛЬТАТ FROM ЭКЗАМЕН WHERE ЭКЗАМЕН_ИД=NEW.ЭКЗАМЕН_ИД;
	IF (stud_id!=NEW.УЧЕНИК_ИД) THEN 
		RAISE NOTICE 'Экзамен с id=% сдавал другой ученик',NEW.ЭКЗАМЕН_ИД;
		RETURN NULL;
	ELSIF (ex_type!='СЕРТИФИКАТ') THEN
		RAISE NOTICE 'Экзамен имеет тип %',ex_type;
		RETURN NULL;
	ELSIF (result_ex=false OR result_ex IS NULL) THEN
		RAISE NOTICE 'Экзамен не был сдан, нельзя выдать сертификат';
		RETURN NULL;
	END IF;
	RETURN NEW;
END;
$$;

alter function "ПРОВЕРИТЬ_СЕРТИФИКАТ"() owner to s265057;

