create function "ТРАССЫ_stamp"() returns trigger
    language plpgsql
as
$$
BEGIN 
    IF NEW.ИД IS NULL THEN
            RAISE EXCEPTION 'ИД cannot be null';
        END IF;
IF NEW.НАЗВАНИЕ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ДЛИНА_МАРШРУТА IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.СЛОЖНОСТЬ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.МЕСТО_ПРОВЕДЕНИЯ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
    IF (NEW.ТИП IN (SELECT НАЗВАНИЕ FROM ТИП_ТРАССЫ)) = FALSE THEN 
RAISE EXCEPTION '% cannot have THIS TYPE', NEW.ИД;
        END IF;
RETURN NEW;
  END;
$$;

alter function "ТРАССЫ_stamp"() owner to s243880;

