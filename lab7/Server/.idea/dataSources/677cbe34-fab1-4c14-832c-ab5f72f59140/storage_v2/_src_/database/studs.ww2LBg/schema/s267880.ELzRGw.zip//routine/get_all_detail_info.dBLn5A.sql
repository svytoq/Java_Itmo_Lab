create function get_all_detail_info() returns SETOF s267880.detail_info
    language sql
as
$$
select * from detail_info;
$$;

alter function get_all_detail_info() owner to s267880;

