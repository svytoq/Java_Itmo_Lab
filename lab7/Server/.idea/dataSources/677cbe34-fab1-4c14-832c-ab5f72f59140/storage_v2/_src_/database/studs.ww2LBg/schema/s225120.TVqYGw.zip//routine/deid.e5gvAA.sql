create function deid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_ОТДЕЛА := nextval('departments_seq');
	return new;
end
$$;

alter function deid() owner to s225120;

