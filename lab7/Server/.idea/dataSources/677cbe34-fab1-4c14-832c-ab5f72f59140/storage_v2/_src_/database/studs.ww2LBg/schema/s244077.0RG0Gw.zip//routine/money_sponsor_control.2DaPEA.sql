create function money_sponsor_control() returns trigger
    language plpgsql
as
$$
DECLARE
  money BIGINT;
  BEGIN
   money:=(SELECT budget FROM sponsors WHERE (sponsors.user_id = NEW.sponsor_id));
   IF (money < (SELECT SUM(sponsoring.sp_money) FROM sponsoring WHERE sponsoring.sponsor_id = NEW.sponsor_id))
     THEN RAISE EXCEPTION 'Sponsor does not have enough money for this';
     RETURN NULL;
  END IF;
  RETURN NEW;
END;
$$;

alter function money_sponsor_control() owner to s244077;

