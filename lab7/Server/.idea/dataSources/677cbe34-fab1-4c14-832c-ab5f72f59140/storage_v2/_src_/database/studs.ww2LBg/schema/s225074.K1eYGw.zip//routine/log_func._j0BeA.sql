create function log_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.log_id:= NEXTVAL('log_seq');
RETURN new;
END;
$$;

alter function log_func() owner to s225074;

