create function rate_performance(performance_id integer, points real) returns void
    language plpgsql
as
$$
BEGIN
    IF (SELECT count(*) FROM performance WHERE performance.performance_id = rate_performance.performance_id) = 0 THEN
        RAISE EXCEPTION 'That performance does not exist!';
    END IF;
    IF (SELECT championship.begin_date FROM performance
        JOIN project ON performance.project_id = project.project_id
        JOIN team ON team.team_id = project.team_id
        JOIN championship ON championship.championship_id = team.championship_id
        WHERE performance.performance_id = rate_performance.performance_id) IS NULL THEN
        RAISE EXCEPTION 'Championship is not started!';
    END IF;

    IF points > (SELECT SUM(complexity) FROM "case"
        JOIN project_case ON "case".case_id = project_case.case_id
        JOIN performance ON performance.performance_id = rate_performance.performance_id
                AND project_case.project_id = performance.project_id) THEN
        RAISE EXCEPTION 'Too much points for this performance';
    END IF;

    UPDATE performance
    SET points = rate_performance.points
    WHERE performance.performance_id = rate_performance.performance_id;
END;
$$;

alter function rate_performance(integer, real) owner to s264448;

