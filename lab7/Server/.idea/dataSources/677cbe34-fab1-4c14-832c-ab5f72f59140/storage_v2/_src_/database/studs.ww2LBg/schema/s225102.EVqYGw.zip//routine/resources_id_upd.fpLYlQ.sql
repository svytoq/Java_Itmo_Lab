create function resources_id_upd() returns trigger
    language plpgsql
as
$$
BEGIN
		IF OLD.id!=NEW.id THEN
			NEW.id=OLD.id;
			RETURN NEW;	
		ELSE
			RETURN NEW;
		END IF;
	END;
$$;

alter function resources_id_upd() owner to s225102;

