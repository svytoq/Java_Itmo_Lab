create function next_day() returns void
    language plpgsql
as
$$
BEGIN
    UPDATE total_time SET day = day + 1 WHERE id = 1;
End
$$;

alter function next_day() owner to s263977;

