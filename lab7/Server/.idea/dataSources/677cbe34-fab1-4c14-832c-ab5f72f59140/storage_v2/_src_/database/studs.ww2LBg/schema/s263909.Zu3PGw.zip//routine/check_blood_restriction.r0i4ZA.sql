create function check_blood_restriction() returns trigger
    language plpgsql
as
$$
declare
    clan          integer;
    blood         integer;
    blood_of_clan integer;
begin
    blood = (select blood_restriction from technic where technic.technic_id = new.technic_id);
    if (blood = true) then
        clan = (select clan from ninja where ninja.ninja_id = old.ninja_id);
        blood_of_clan = (select count() from blood_restriction_of_clan where clan_id = clan);
        if (blood_of_clan > 0) then
            blood_of_clan = (select count()
                             from blood_restriction_of_clan
                             where clan_id = clan
                               and blood_restriction_of_clan.technic_id = new.technic_id);
            if (blood_of_clan = 0) then
                raise exception 'techniс cannot be added';
            end if;
        end if;
    end if;
    return new;
end;
$$;

alter function check_blood_restriction() owner to s263909;

