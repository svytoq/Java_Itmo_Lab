create function сгенерировать_медиа(count integer) returns void
    language plpgsql
as
$$
DECLARE
        film record;
BEGIN
        FOR film IN (SELECT ид from Фильмы)
        LOOP
            FOR i IN 1..COUNT LOOP
                insert into Медиа(название, ид_фильма, тип, url) 
                        values(random_string(20),
                         film.ид, random_string(5), random_string(30));
            END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_медиа(integer) owner to s242395;

