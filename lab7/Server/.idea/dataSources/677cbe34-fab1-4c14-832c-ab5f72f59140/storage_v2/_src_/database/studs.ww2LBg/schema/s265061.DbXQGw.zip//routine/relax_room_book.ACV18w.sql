create function relax_room_book(integer, s265061.room_class) returns void
    language plpgsql
as
$$
begin
  insert into relax_room_booking(ticket_id, class) VALUES ($1,$2);
  if $2='comfort' then
 update ticket set amount=amount + 2000 where id=$1;
 else if $2='comfort+' then 
 update ticket set amount=amount + 2500 where id=$1;
 end if;end if;
end;
$$;

alter function relax_room_book(integer, s265061.room_class) owner to s265061;

