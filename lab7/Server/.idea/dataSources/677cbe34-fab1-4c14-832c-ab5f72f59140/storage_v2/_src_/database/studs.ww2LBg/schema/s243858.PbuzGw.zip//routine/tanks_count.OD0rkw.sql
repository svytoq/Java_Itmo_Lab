create function tanks_count(OUT result integer) returns integer
    language plpgsql
as
$$
BEGIN
  EXECUTE format('SELECT count(ID) FROM tank')
  INTO result;
END
$$;

alter function tanks_count(out integer) owner to s243858;

