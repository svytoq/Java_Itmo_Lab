create function get_req_info()
    returns TABLE(type_of_req s265109.tyreq, active boolean, who_surname character varying, who_name character varying, who_patronymic character varying, whom_surname character varying, whom_name character varying, whom_patronymic character varying, equipment text)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT c.kind,
                        c.active,
                        e2.surname,
                        e2.name,
                        e2.patronymic,
                        e3.surname,
                        e3.name,
                        e3.patronymic,
                        e.name
                 FROM equipment AS e
                          JOIN clientrequests c on e.id = c.equipment_id
                          join employee e2 on e2.id = c.who_id
                          join employee e3 on e3.id = c.worker_id;
end;
$$;

alter function get_req_info() owner to s265109;

