create function components_changing_check() returns trigger
    language plpgsql
as
$$
DECLARE
  team INT;
  BEGIN
  team := (SELECT team_id FROM cars WHERE (cars.id = NEW.car_id));
  IF ((NEW.current_carcase_old IS NOT NULL) AND (NEW.current_carcase_new IS NOT NULL)) THEN
   IF (NOT(team = (SELECT team_id FROM carcase_storage WHERE (carcase_storage.id = NEW.current_carcase_old))))
     THEN RAISE EXCEPTION 'old carcase and car must belong to one team';
     RETURN NULL;
   END IF;
   IF (NOT(team = (SELECT team_id FROM carcase_storage WHERE (carcase_storage.id = NEW.current_carcase_new))))
     THEN RAISE EXCEPTION 'new carcase and car must belong to one team';
     RETURN NULL;
   END IF;
  END IF;

   IF ((NEW.current_engine_old IS NOT NULL) AND (NEW.current_engine_new IS NOT NULL)) THEN
   IF (NOT(team = (SELECT team_id FROM engine_storage WHERE (engine_storage.id = NEW.current_engine_old))))
     THEN RAISE EXCEPTION 'old engine and car must belong to one team';
     RETURN NULL;
   END IF;
   IF (NOT(team = (SELECT team_id FROM engine_storage WHERE (engine_storage.id = NEW.current_engine_new))))
     THEN RAISE EXCEPTION 'new engine and car must belong to one team';
     RETURN NULL;
   END IF;
  END IF;

   IF ((NEW.current_chassis_old IS NOT NULL) AND (NEW.current_chassis_new IS NOT NULL)) THEN
   IF (NOT(team = (SELECT team_id FROM chassis_storage WHERE (chassis_storage.id = NEW.current_chassis_old))))
     THEN RAISE EXCEPTION 'old chassis and car must belong to one team';
     RETURN NULL;
   END IF;
   IF (NOT(team = (SELECT team_id FROM chassis_storage WHERE (chassis_storage.id = NEW.current_chassis_new))))
     THEN RAISE EXCEPTION 'new chassis and car must belong to one team';
     RETURN NULL;
   END IF;
  END IF;

   IF ((NEW.current_electronics_old IS NOT NULL) AND (NEW.current_electronics_new IS NOT NULL)) THEN
   IF (NOT(team = (SELECT team_id FROM electronics_storage WHERE (electronics_storage.id = NEW.current_electronics_old))))
     THEN RAISE EXCEPTION 'old electronics and car must belong to one team';
     RETURN NULL;
   END IF;
   IF (NOT(team = (SELECT team_id FROM electronics_storage WHERE (electronics_storage.id = NEW.current_electronics_new))))
     THEN RAISE EXCEPTION 'new electronics and car must belong to one team';
     RETURN NULL;
   END IF;
  END IF;


  RETURN NEW;
END;
$$;

alter function components_changing_check() owner to s244077;

