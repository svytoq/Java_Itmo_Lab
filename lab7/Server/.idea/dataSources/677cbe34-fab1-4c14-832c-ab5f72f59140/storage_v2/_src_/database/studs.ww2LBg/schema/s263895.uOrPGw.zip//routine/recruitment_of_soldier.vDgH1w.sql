create function recruitment_of_soldier() returns trigger
    language plpgsql
as
$$
begin
	select * from family where don = donID;
	end

$$;

alter function recruitment_of_soldier() owner to s263895;

