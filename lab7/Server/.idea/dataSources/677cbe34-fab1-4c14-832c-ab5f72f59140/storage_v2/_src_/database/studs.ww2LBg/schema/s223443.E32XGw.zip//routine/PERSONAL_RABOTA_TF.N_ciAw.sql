create function "ПЕРСОНАЛ_РАБОТА_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF (exists(SELECT FROM "ПЕРСОНАЛ_РАБОТА" WHERE "ПЕРСОНАЛ_РАБОТА"."ИД_ПЕРСОНАЛ" = NEW."ИД_ПЕРСОНАЛ"))
AND
(exists(SELECT FROM "ПЕРСОНАЛ_РАБОТА" WHERE "ПЕРСОНАЛ_РАБОТА"."ИД_НРАБОТЫ" = NEW."ИД_РАБОТЫ"))
THEN
RAISE 'Такое отношение уже записано в БД.';
END IF;
IF NOT (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."ИД_ПЕРСОНАЛ" = NEW."ИД_ПЕРСОНАЛ"))
THEN
RAISE 'Такого персонала нет в БД.';
END IF;
IF NOT (exists(SELECT FROM "РАБОТА" WHERE "РАБОТА"."ИД_РАБОТЫ" = NEW."ИД_РАБОТЫ"))
THEN
RAISE 'Такоой работы нет в БД.';
END IF;
return NEW;
END;
$$;

alter function "ПЕРСОНАЛ_РАБОТА_ТФ"() owner to s223443;

