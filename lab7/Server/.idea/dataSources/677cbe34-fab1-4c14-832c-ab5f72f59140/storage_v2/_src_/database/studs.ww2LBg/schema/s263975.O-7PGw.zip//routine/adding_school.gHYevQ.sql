create function adding_school(org_name character varying, org_address character varying, dir character varying) returns bigint
    language plpgsql
as
$$
declare
    o_id integer;
begin
    insert into organization(name, address) values (org_name, org_address) returning id into o_id;
    insert into school values (o_id, dir);
    return o_id;
end;
$$;

alter function adding_school(varchar, varchar, varchar) owner to s263975;

