create function createwizard(charactername text, wward integer, wmagic integer) returns text
    language plpgsql
as
$$
declare
    id_ch int;
begin
    insert into character(name) values (characterName) returning id_character into id_ch;
    insert into wizard(id_character, ward, magic_level) values (id_ch, wWard, wMagic);
    return 'Волшебник создан! id - ' || id_ch;
end;
$$;

alter function createwizard(text, integer, integer) owner to s264912;

