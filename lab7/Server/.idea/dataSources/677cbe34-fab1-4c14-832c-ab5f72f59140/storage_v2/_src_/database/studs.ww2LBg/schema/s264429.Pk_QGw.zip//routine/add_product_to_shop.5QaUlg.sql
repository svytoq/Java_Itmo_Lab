create function add_product_to_shop(_product_id integer, _store_id integer, _amount real) returns void
    language plpgsql
as
$$
declare
    product_amount real := null;
begin
    select amount into product_amount from store_item where product_id = _product_id and store_id = _store_id;
    if _amount is null then
        insert into store_item(store_id, product_id, amount) values (_store_id, _product_id, _amount);
    else
        update store_item set amount = _amount + product_amount where product_id = _product_id and store_id = _store_id;
    end if;
end
$$;

alter function add_product_to_shop(integer, integer, real) owner to s264429;

