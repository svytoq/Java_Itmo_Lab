create function deleteakkum() returns trigger
    language plpgsql
as
$$
begin
 delete from УСТРОЙСТВА where  УСТРОЙСТВА.ИД_АККУМУЛЯТОРА = АККУМУЛЯТОР.ИД;
 end;
$$;

alter function deleteakkum() owner to s243855;

