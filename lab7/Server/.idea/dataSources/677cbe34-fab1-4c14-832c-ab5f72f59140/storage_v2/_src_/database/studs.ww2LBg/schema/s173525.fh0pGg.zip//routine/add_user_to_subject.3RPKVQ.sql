create function add_user_to_subject() returns trigger
    language plpgsql
as
$$
DECLARE
	result real;
BEGIN 
	SELECT user_id,subject_id,end_date INTO result FROM user_subjects WHERE user_id=NEW.user_id AND subject_id=NEW.subject_id AND end_date IS NULL;
	IF NOT FOUND THEN 
		RETURN NEW;
	ELSE
		RAISE EXCEPTION 'Пользователь уже преподает данный предмет.';
	END IF;
END;
$$;

alter function add_user_to_subject() owner to s173525;

