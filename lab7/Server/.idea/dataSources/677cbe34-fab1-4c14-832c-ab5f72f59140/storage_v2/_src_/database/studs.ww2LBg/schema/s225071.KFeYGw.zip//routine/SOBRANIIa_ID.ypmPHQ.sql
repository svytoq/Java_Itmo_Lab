create function "СОБРАНИЯ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('СОБРАНИЯ_ИД_СОБРАНИЯ_seq')!=NEW.ИД_СОБРАНИЯ THEN NEW.ИД_СОБРАНИЯ=nextval('СОБРАНИЯ_ИД_СОБРАНИЯ_seq');
  RETURN NEW;
ELSE
  RETURN NEW;
END IF;
END;
$$;

alter function "СОБРАНИЯ_ИД"() owner to s225071;

