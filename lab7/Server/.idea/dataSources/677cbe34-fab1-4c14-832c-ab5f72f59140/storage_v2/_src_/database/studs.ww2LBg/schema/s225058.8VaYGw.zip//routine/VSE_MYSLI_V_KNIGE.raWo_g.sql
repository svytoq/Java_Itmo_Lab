create function "ВСЕ_МЫСЛИ_В_КНИГЕ"(name character varying)
    returns TABLE("СУТЬ" text, "РОЛЬ_В_КНИГЕ" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT МЫСЛИ.СУТЬ,МЫСЛИ.РОЛЬ_В_КНИГЕ FROM (КНИГИ JOIN КНИГА_И_МЫСЛЬ ON КНИГИ.ИД=КНИГА_И_МЫСЛЬ.ИД_КНИГИ) AS A JOIN МЫСЛИ ON МЫСЛИ.ИД=A.ИД_МЫСЛИ WHERE НАЗВАНИЕ = name;
END;
$$;

alter function "ВСЕ_МЫСЛИ_В_КНИГЕ"(varchar) owner to s225058;

