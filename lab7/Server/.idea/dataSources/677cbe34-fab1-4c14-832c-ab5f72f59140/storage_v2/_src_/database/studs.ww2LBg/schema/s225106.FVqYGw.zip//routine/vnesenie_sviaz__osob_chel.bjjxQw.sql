create function внесение_связь_особ_чел(name text, charact text) returns void
    language plpgsql
as
$$
DECLARE
chel int;
osob int;
BEGIN
SELECT ИД INTO STRICT chel FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=name;
SELECT ИД INTO STRICT osob FROM ОСОБЕННОСТЬ WHERE ОПИСАНИЕ_ОСОБ=charact;
INSERT INTO СВЯЗЬ_ОСОБ_ЧЕЛ VALUES(chel, osob);
raise notice 'Inserted into СВЯЗЬ_ОСОБ_ЧЕЛ %, %', chel, osob;
EXCEPTION
WHEN NO_DATA_FOUND THEN 
RAISE NOTICE 'You entered incorrect data';
RETURN;
END;
$$;

alter function внесение_связь_особ_чел(text, text) owner to s225106;

