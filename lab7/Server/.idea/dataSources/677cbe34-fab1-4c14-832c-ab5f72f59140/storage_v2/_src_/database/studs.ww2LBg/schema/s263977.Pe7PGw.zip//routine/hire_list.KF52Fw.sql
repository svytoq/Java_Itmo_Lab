create function hire_list()
    returns TABLE(worker_name character varying, worker_id integer, worker_speciality character varying, worker_bio character varying, worker_cost integer)
    language plpgsql
as
$$
BEGIN
    If ((SELECT count(*) FROM volunteer WHERE on_work = false) > 0) THEN
        RETURN QUERY (SELECT name, id, speciality, bio, cost FROM volunteer WHERE on_work = false);
    ELSE RAISE NOTICE 'Людей в спивке нет';
    END IF;
END
$$;

alter function hire_list() owner to s263977;

