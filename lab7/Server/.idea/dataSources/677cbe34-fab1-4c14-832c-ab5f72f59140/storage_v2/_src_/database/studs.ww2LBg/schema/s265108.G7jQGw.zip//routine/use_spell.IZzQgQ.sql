create function use_spell(spell integer, magician integer, hunting integer) returns text
    language plpgsql
as
$$
DECLARE
  magician_exists boolean;
  hunting_exists boolean;
  is_not_dead boolean;
  does_know_spell boolean;
  is_enough_energy boolean;
  creature int;
BEGIN

  IF is_magician_in_hunting(magician, hunting) AND spell_exists(spell) THEN

  SELECT c.id INTO creature FROM Huntings h 
  JOIN Creatures c ON (h.creature_id = c.id)
  WHERE h.id = hunting;
  
  SELECT 1 INTO is_not_dead FROM Creatures c
  WHERE c.id = creature AND c.hp_level != 0;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ваш монстр уже мертв, вы не можете атаковать его';
  END IF;
  
  SELECT 1 INTO does_know_spell FROM Spell_to_magician stm 
  WHERE stm.magician_id = magician AND stm.spell_id = spell;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Вы пока не знаете это заклинание, идите учиться';
  END IF;
  
  SELECT 1 INTO is_enough_energy FROM Magicians m, Spells s
  WHERE s.id = spell AND m.person_id = magician AND m.energy >= s.energy;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'У вас недостаточно энергии';
  END IF;
  
  INSERT INTO Spells_on_hunting (magician_id, hunting_id, spell_id)
  VALUES (magician, hunting, spell);
  
  RETURN 'Вы успешно применили заклинание';
  
  END IF;
END;
$$;

alter function use_spell(integer, integer, integer) owner to s265108;

