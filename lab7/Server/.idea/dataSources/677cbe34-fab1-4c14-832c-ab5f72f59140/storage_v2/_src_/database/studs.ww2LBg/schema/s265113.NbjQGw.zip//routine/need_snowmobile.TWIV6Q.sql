create function need_snowmobile() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO request_position(type) VALUES (order_type('snowmobile'));
    RETURN NEW;
END;
$$;

alter function need_snowmobile() owner to s265113;

