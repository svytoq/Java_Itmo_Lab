create function visaapplaftercheck() returns trigger
    language plpgsql
as
$$
begin
    if NEW.visa_app_state = 'awaits_review' then
        perform visa_application_autocheck(NEW.visa_app_id);
    end if;
    return NEW;
end;
$$;

alter function visaapplaftercheck() owner to s265066;

