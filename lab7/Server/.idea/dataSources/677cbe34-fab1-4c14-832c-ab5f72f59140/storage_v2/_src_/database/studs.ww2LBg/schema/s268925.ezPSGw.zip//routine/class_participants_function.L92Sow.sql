create function class_participants_function() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE DEBUG 'Trigger function class_participants_function() fired';
    IF EXISTS(
            SELECT 1
            FROM classes
                     INNER JOIN teachers ON classes.creator_id = teachers.id
                     INNER JOIN students_teachers ON teachers.id = students_teachers.teacher_id
                     INNER JOIN students ON students_teachers.student_id = students.id
            WHERE classes.id = new.class_id
              AND students.id = new.student_id
        )
    THEN
        RETURN new;
    ELSE
        RAISE WARNING 'Creator of the class with id % is not teacher of student with id %',
            new.class_id, new.student_id;
        RETURN NULL;
    END IF;
END;
$$;

alter function class_participants_function() owner to s268925;

