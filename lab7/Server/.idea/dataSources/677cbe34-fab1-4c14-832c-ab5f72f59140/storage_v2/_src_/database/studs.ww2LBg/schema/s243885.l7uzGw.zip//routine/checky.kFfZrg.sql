create function checky() returns trigger
    language plpgsql
as
$$
BEGIN
	CASE WHEN NEW.beginning = 0 THEN
		NEW.beginning := 1;
	ELSE NEW.beginning := NEW.beginning + 0;
	END CASE;
	CASE WHEN NEW.ending = 0 THEN
		NEW.ending :=1;
	ELSE NEW.beginning := NEW.beginning + 0;
	END CASE;
	RETURN NEW;
END;
$$;

alter function checky() owner to s243885;

