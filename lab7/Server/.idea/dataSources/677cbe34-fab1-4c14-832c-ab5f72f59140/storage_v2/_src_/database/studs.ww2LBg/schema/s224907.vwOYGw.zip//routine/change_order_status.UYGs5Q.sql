create function change_order_status() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE "order" set status = "Курьер найден" where id = new.id;
    RETURN NULL;
END
$$;

alter function change_order_status() owner to s224907;

