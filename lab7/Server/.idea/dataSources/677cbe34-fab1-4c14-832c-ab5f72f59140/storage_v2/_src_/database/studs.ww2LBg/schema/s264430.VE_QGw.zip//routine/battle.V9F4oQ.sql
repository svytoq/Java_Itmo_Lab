create function battle(first_id_army integer, second_id_army integer) returns void
    language plpgsql
as
$$
DECLARE
	first_row АРМИЯ%ROWTYPE;
	first_house text;
	second_row АРМИЯ%ROWTYPE;
	second_house text;
	first_power_hero integer;
	second_power_hero integer;
	castle_power integer;
BEGIN
	select * into first_row from getArmy($1);
	select * into second_row from getArmy($2);
	select getHouse(first_row.ЛИДЕР) into first_house;
	select getHouse(second_row.ЛИДЕР) into second_house;
	select getPowerHero(0, first_row.ЛИДЕР) into first_power_hero;
	select getPowerHero(1, second_row.ЛИДЕР) into second_power_hero;
	select getCastlePower(second_row.ЗЕМЛЯ) into castle_power;
	if castle_power is null then
		castle_power := 0;
	end if;
	if (first_row.БОЕВАЯ_МОЩЬ + first_power_hero >= second_row.БОЕВАЯ_МОЩЬ + second_power_hero + castle_power) then
		perform goPriston(second_row.ЛИДЕР, first_house);
		delete from ОТРЯД where id_АРМИИ = second_row.id;
		perform recount_force_army(second_row.id);
		insert into СРАЖЕНИЕ(НАЗВАНИЕ, ЗЕМЛЯ, ИТОГ) values (first_house || '-' || second_house, second_row.ЗЕМЛЯ, 'Победитель - ' || first_house);
		delete from ПИТОМЕЦ where КЛИЧКА = (select ПИТОМЕЦ from ЛИДЕР where ИМЯ = second_row.ЛИДЕР);
	else
		perform goPriston(first_row.ЛИДЕР, second_house);
		delete from ОТРЯД where id_АРМИИ = first_row.id;
		perform recount_force_army(first_row.id);
		insert into СРАЖЕНИЕ(НАЗВАНИЕ, ЗЕМЛЯ, ИТОГ) values (first_house || '-' || second_house, second_row.ЗЕМЛЯ, 'Победитель - ' || second_house);
		delete from ПИТОМЕЦ where КЛИЧКА = (select ПИТОМЕЦ from ЛИДЕР where ИМЯ = first_row.ЛИДЕР);
	end if;
	end;
$$;

alter function battle(integer, integer) owner to s264430;

