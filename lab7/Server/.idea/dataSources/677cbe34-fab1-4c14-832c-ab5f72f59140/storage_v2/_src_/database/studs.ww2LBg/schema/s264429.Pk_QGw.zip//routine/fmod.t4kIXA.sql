create function fmod(dividend double precision, divisor double precision) returns double precision
    immutable
    language sql
as
$$
SELECT dividend - floor(dividend / divisor) * divisor
$$;

alter function fmod(double precision, double precision) owner to s264429;

