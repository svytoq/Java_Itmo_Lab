create function getclimateandforecastdata(observatory_name text, startts timestamp without time zone, endts timestamp without time zone)
    returns TABLE(film_title text)
    language plpgsql
as
$$
BEGIN
    return query
    select name from observatory;
END;
$$;

alter function getclimateandforecastdata(text, timestamp, timestamp) owner to s265111;

