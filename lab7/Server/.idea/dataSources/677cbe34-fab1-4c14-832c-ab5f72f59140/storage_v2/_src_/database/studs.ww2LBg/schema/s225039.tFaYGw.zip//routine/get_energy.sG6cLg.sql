create function get_energy() returns trigger
    language plpgsql
as
$$
BEGIN 
 NEW. Энер_ц = 9 * NEW.Жиры  + 4 * NEW.Белки + 3.75 * NEW.Углеводы;
RETURN NEW;
END;
$$;

alter function get_energy() owner to s225039;

