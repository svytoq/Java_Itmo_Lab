create function insert_clans() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
    clanName text = insert_random();
  BEGIN
    LOOP
      IF NOT EXISTS(SELECT * FROM clans WHERE name = clanName)
        THEN
          INSERT INTO clans VALUES (DEFAULT, clanName, '5/12/1998', trunc(random()*1000)+1);
          count = count + 1;
        ELSE clanName = insert_random();
      END IF;
      EXIT WHEN count = 20;
    END LOOP;
  END;
$$;

alter function insert_clans() owner to s225107;

