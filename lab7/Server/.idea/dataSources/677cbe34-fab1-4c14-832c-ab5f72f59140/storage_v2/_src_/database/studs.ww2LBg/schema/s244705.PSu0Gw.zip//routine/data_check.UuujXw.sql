create function data_check() returns trigger
    language plpgsql
as
$$
DECLARE
ДАТА_СОЗДАНИЯ_ТЕМЫ TIMESTAMP;

ДАТА_НАПИСАНИЯ_СООБЩЕНИЯ TIMESTAMP;
BEGIN
ДАТА_СОЗДАНИЯ_ТЕМЫ:=(SELECT ДАТА_ПОЯВЛЕНИЯ FROM БАНК_ТЕМ_ФОРУМ WHERE (БАНК_ТЕМ_ФОРУМ.N_ТЕМЫ = NEW.N_ТЕМЫ));
ДАТА_НАПИСАНИЯ_СООБЩЕНИЯ:=(SELECT ДАТА_СООБЩЕНИЯ FROM СООБЩЕНИЕ_ФОРУМ WHERE (СООБЩЕНИЕ_ФОРУМ.N_СООБЩЕНИЯ = NEW.N_СООБЩЕНИЯ) AND (СООБЩЕНИЕ_ФОРУМ.N_ТЕМЫ = NEW.N_ТЕМЫ));
IF ДАТА_СОЗДАНИЯ_ТЕМЫ < ДАТА_НАПИСАНИЯ_СООБЩЕНИЯ THEN
RAISE EXCEPTION 'Сообщение не может быть написано раньше создания темы';
END IF;
RETURN NEW;
END;
$$;

alter function data_check() owner to s244705;

