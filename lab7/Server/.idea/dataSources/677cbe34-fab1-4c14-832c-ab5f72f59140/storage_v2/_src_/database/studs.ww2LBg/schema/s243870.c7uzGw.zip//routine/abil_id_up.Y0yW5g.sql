create function abil_id_up() returns trigger
    language plpgsql
as
$$
BEGIN
NEW.Id := OLD.Id;
RETURN NEW;
END;
$$;

alter function abil_id_up() owner to s243870;

