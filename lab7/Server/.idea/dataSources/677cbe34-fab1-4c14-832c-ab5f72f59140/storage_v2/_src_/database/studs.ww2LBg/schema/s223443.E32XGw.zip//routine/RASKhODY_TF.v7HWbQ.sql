create function "РАСХОДЫ_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW."ИД_РАСХОДОВ" IS NULL THEN
   NEW."ИД_РАСХОДОВ" = generate_UUID();
END IF;
IF (exists(SELECT FROM "РАСХОДЫ" WHERE "РАСХОДЫ"."ИД_РАСХОДОВ" = NEW."ИД_РАСХОДОВ")) THEN
RAISE 'Расходы с указаным ИД уже есть в базе.';
END IF;
IF NEW."АРЕНДА" IS NULL THEN
RAISE 'Графа "АРЕНДА" не может быть пустой.';
END IF;
return NEW;
END;
$$;

alter function "РАСХОДЫ_ТФ"() owner to s223443;

