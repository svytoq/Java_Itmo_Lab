create function find_better_weapon(hunter integer)
    returns TABLE(planet_name character varying, weapon character varying, price bigint, level smallint)
    language plpgsql
as
$$
DECLARE
    hunter_weapon_level int;
  BEGIN
    SELECT MAX(w.level) INTO hunter_weapon_level FROM Hunter as h 
    INNER JOIN Inventory as i ON (i.id = h.inventory_id)
    INNER JOIN Weapon as w ON (w.inventory_id = i.id) WHERE h.id = hunter;
    
    IF NOT FOUND THEN
      hunter_weapon_level = 0;
    END IF;
    
    RETURN QUERY SELECT p.name, w.name, w.price, w.level FROM Weapon as w
    INNER JOIN Store as s ON (w.store_id = s.id)
    INNER JOIN Planet as p ON (p.store_id = s.id)
    WHERE w.level > hunter_weapon_level;
  END;
$$;

alter function find_better_weapon(integer) owner to s263081;

