create function "ПУБЛИКАЦИИ_ПРОИЗВЕДЕНИЯ"(name character varying)
    returns TABLE("НАЗВАНИЕ_ЖУРНАЛА" character varying, "ИД_ЖУРНАЛА" smallint, "ДАТА" date, "ФОРМАТ" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"ЛИТ_ЖУРНАЛ"."НАЗВАНИЕ_ЖУРНАЛА", "ПУБЛИКАЦИИ"."ИД_ЖУРНАЛА", "ПУБЛИКАЦИИ"."ДАТА", "ПУБЛИКАЦИИ"."ФОРМАТ"
FROM "ЛИТ_ЖУРНАЛ" NATURAL JOIN "ПУБЛИКАЦИИ" WHERE "ПУБЛИКАЦИИ"."НАЗВАНИЕ_ПРОИЗВЕДЕНИЯ" = name;
END;
$$;

alter function "ПУБЛИКАЦИИ_ПРОИЗВЕДЕНИЯ"(varchar) owner to s225071;

