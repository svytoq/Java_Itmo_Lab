create function formatjudge() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.СТРАНА_СУДЬИ := INITCAP(LOWER(RTRIM(LTRIM(NEW.СТРАНА_СУДЬИ))));
  return NEW;
  END;
$$;

alter function formatjudge() owner to s224514;

