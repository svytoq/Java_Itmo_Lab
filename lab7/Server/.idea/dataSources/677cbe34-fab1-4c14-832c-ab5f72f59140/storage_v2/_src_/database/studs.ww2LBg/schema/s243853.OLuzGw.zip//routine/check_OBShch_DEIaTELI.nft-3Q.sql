create function "check_ОБЩ_ДЕЯТЕЛИ"() returns trigger
    language plpgsql
as
$$
BEGIN 
IF NOT EXISTS(SELECT ИД_РАСЫ, ИД_ГОСУДАРСТВА FROM ГОСУДАРСТВА_РАСЫ 
WHERE (NEW.ИД_РАСЫ = ИД_РАСЫ) AND (NEW.ИД_ГОСУДАРСТВА = ИД_ГОСУДАРСТВА)) 
THEN RAISE EXCEPTION 'РАСА и ГОСУДАРСТВО ОБЩ_ДЕЯТЕЛЯ должны СУЩЕСТВОВАТЬ'; 
END IF; 
RETURN NEW; 
END
$$;

alter function "check_ОБЩ_ДЕЯТЕЛИ"() owner to s243853;

