create function validate_note() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.Дата < ANY(
SELECT Дата_рождения FROM 
Г_Пользователь
WHERE ИД = NEW.ИД_Пользователя) THEN
RAISE EXCEPTION 'Заметка % старше пользователя', NEW.ИД;
END IF; RETURN NEW; END
$$;

alter function validate_note() owner to s243879;

