create function checkunique() returns trigger
    language plpgsql
as
$$
BEGIN
IF isunique(NEW.ЛОГИН) = FALSE
THEN RAISE EXCEPTION 'Логин уже занят';
END IF;
RETURN NEW;
END
$$;

alter function checkunique() owner to s243854;

