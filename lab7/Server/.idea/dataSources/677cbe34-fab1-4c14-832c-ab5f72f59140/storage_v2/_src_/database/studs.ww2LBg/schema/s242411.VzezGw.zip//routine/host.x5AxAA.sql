create function host() returns trigger
    language plpgsql
as
$$
BEGIN
CASE WHEN NEW.ПРИНАДЛЕЖИТ < 0 THEN
NEW.ПРИНАДЛЕЖИТ := NULL;
ELSE NEW.ПРИНАДЛЕЖИТ := NEW.ПРИНАДЛЕЖИТ + 0;
END CASE;
RETURN NEW;
END;
$$;

alter function host() owner to s242411;

