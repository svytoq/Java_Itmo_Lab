create function create_rule() returns trigger
    language plpgsql
as
$$
BEGIN
  create rule deny_update as on update to refill do instead select raisea();
  return new;
end;
$$;

alter function create_rule() owner to s243872;

