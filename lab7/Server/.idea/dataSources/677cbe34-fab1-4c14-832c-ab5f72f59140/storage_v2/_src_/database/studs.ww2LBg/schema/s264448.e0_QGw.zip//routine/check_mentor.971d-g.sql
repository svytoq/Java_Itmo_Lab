create function check_mentor() returns trigger
    language plpgsql
as
$$
BEGIN
    IF people_age(NEW.person_id) < 21 THEN
        RAISE EXCEPTION 'mentor should be older then 21';
    END IF;

    IF NOT EXISTS(SELECT NEW.person_id
                  FROM people_publication
                  WHERE NEW.person_id = people_publication.person_id) THEN
        RAISE EXCEPTION 'mentor should have one or more publications';
    END IF;

    IF EXISTS(SELECT *
              FROM judge
              WHERE NEW.person_id = judge.person_id
                AND NEW.championship_id = judge.championship_id) THEN
        RAISE EXCEPTION 'mentor can not be a jude in the same championship';
    END IF;

    IF EXISTS(SELECT *
              FROM participant
              WHERE NEW.person_id = participant.person_id
                AND NEW.championship_id = participant.championship_id) THEN
        RAISE EXCEPTION 'mentor can not be a participant in the same championship';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_mentor() owner to s264448;

