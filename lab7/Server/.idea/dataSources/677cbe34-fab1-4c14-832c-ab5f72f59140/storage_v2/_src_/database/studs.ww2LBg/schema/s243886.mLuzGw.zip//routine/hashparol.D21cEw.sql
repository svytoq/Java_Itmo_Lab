create function hashparol() returns trigger
    language plpgsql
as
$$
begin
UPDATE ЧЕЛОВЕК set ПАРОЛЬ=HASHBYTES(SHA1,CONVERT(nvarchar(4000),ПАРОЛЬ)); 
RETURN NEW; 
END;
$$;

alter function hashparol() owner to s243886;

