create function "Смерш"(id integer, "id_базы" integer, "название" character varying) returns void
    language plpgsql
as
$$
BEGIN
insert into корабль values(ID, 600, название, '[25, 30]' , 2500, 'создается',1100, ID_базы, now(), null);
insert into оружие_корабль values(8, ID);
END;
$$;

alter function "Смерш"(integer, integer, varchar) owner to s242552;

