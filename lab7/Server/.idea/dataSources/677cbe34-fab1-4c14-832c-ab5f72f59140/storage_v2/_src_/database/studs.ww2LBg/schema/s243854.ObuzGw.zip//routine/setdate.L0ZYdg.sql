create function setdate() returns trigger
    language plpgsql
as
$$
BEGIN
NEW.ДАТА_СМЕНЫ := current_date;
RETURN NEW;
END
$$;

alter function setdate() owner to s243854;

