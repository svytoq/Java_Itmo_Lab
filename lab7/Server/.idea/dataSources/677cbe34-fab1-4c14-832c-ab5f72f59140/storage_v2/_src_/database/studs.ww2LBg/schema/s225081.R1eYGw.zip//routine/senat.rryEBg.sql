create function senat() returns trigger
    language plpgsql
as
$$
DECLARE
  SOSL SOSL;
BEGIN
  SELECT СОСЛОВИЕ
  FROM ЛЮДИ
  WHERE ID_ЧЕЛ = NEW.ID_ЧЛЕНА
  INTO SOSL;
  IF SOSL = 'ПАТРИЦИЙ'
  THEN RETURN NEW;
  ELSE
    RAISE NOTICE '% НЕ МОЖЕТ БЫТЬ ЧЛЕНОМ СЕНАТА. ТОЛЬКО ПАТРИЦИИ', SOSL;
    RETURN NULL;
  END IF;

END;
$$;

alter function senat() owner to s225081;

