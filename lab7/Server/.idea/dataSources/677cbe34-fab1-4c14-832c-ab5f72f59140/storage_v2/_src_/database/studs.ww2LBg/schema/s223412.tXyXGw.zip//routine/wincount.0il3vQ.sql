create function wincount()
    returns TABLE(name text, count bigint)
    language sql
as
$$
SELECT
  "Клан"."Название",
  Count(*)
FROM "Клан"
  JOIN "Клан_Сторона" ON "Клан"."Название" = "Клан_Сторона"."Название_клана"
  JOIN "Сторона" ON "Клан_Сторона".id_стороны = "Сторона".id_сторона
  JOIN "Сторона_Битва" ON "Сторона".id_сторона = "Сторона_Битва".id_стороны
  JOIN "Битва" ON "Сторона_Битва".id_битва = "Битва".id
WHERE "Победившая_сторона" = "Сторона".id_сторона
GROUP BY "Клан"."Название";
$$;

alter function wincount() owner to s223412;

