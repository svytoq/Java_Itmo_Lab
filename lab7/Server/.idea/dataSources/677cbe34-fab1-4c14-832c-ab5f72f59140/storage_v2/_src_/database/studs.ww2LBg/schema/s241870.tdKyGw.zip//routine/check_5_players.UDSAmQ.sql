create function check_5_players() returns trigger
    language plpgsql
as
$$
BEGIN
   IF (SELECT COUNT (Игроки.ID_Игрока) FROM Игроки WHERE Игроки.ID_Команды = NEW."ID_Команды")
    < (5) THEN
      RAISE EXCEPTION 'Должно быть минимум 5 игроков';
   END IF;
   RETURN NEW;
END
$$;

alter function check_5_players() owner to s241870;

