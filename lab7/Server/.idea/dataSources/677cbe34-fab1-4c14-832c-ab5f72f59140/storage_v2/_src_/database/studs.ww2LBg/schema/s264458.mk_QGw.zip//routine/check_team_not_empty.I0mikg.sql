create function check_team_not_empty(team_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS(SELECT developer_id FROM developer_team WHERE team_id = check_team_not_empty.team_id) THEN
        RAISE EXCEPTION 'team is empty';
    END IF;
    RETURN TRUE;
END;
$$;

alter function check_team_not_empty(integer) owner to s264458;

