create function check_if_this_engine_exists() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
   IF (EXISTS(SELECT device_id FROM engine WHERE device_id = NEW.device_id)) THEN
     RAISE EXCEPTION 'no, this device is already an engine';
   END IF;
   RETURN NEW;
END;
$$;

alter function check_if_this_engine_exists() owner to s270250;

