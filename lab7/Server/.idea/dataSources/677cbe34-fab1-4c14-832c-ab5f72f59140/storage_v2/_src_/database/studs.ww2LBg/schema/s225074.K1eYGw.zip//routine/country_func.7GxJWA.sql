create function country_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.country_id:= NEXTVAL('country_seq');
RETURN new;
END;
$$;

alter function country_func() owner to s225074;

