create function buy_item_time() returns trigger
    language plpgsql
as
$$
DECLARE
	item_time interval;
	BEGIN
		SELECT "Время_Получения" INTO item_time FROM "К_Предметы" where Id = NEW.Предмет_ИД;
 		UPDATE "К_Инвентарь" SET "Момент_Получения" = ("К_Инвентарь".Момент_Получения + item_time)
 		WHERE "К_Инвентарь".Персонаж_ИД = NEW.Персонаж_ИД AND "К_Инвентарь".Предмет_ИД = NEW.Предмет_ИД;
 		RETURN NEW;
		END;
$$;

alter function buy_item_time() owner to s242193;

