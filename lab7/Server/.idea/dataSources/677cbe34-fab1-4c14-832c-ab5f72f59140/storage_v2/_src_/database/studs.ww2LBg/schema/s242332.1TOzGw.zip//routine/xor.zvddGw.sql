create function xor(boolean, boolean) returns boolean
    language sql
as
$$
SELECT ($1 AND NOT $2) OR (NOT $1 AND $2);
$$;

alter function xor(boolean, boolean) owner to s242332;

