create function add_book(book_isbn character, book_title text, author_first_name character varying, author_last_name character varying, author_patronymic character varying, book_publication_year integer, book_genre character varying, book_amount integer DEFAULT 1, department character varying DEFAULT 'Взрослый'::character varying) returns boolean
    language plpgsql
as
$$
declare
    isBookExists        boolean;
    author_id           int;
    found_department_id int;
    added_book_id       int;
begin
    if book_amount < 1 then
        RAISE EXCEPTION 'Amount = % is less than 1', book_amount
            USING HINT = 'Provide amount >= 1';
    end if;

    select (case when count(*) > 0 then d.department_id else 0 end)
    into found_department_id
    from departments d
    where d.name = department;
    if found_department_id = 0 then
        RAISE EXCEPTION 'No such department = %', department
            USING HINT = 'Check spelling or add new department';
    end if;

    select (case when count(*) > 0 then true else false end) into isBookExists from books where books.isbn = book_ISBN;
    if isBookExists then
        RAISE EXCEPTION 'ISBN % already exists', book_ISBN
            USING HINT = 'Check book ISBN or update existing book record';
    end if;

    select (case when count(*) > 0 then a.author_id else 0 end)
    into author_id
    from authors a
    where a.first_name = author_first_name
      and a.last_name = author_last_name
      and a.patronymic = author_patronymic;
    if author_id = 0 then
        RAISE EXCEPTION 'No such author'
            USING HINT = 'First add information about author';
    end if;

    insert into books (isbn, title, publication_year, genre, amount, department_id)
    VALUES (book_ISBN, book_title, book_publication_year, book_genre, book_amount, found_department_id)
    returning book_id into added_book_id;

    insert into books_authors values (added_book_id, author_id);
    return true;
end
$$;

alter function add_book(char, text, varchar, varchar, varchar, integer, varchar, integer, varchar) owner to s265089;

