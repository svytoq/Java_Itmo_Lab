create function producer(name text, OUT "НАЗВАНИЕ" text, OUT "ИМЯ" text) returns SETOF record
    language sql
as
$$
SELECT ФИЛЬМ.НАЗВАНИЕ, АКТЕР.ИМЯ 
FROM РЕЖИССЕР 
JOIN СЦЕНАРИЙ ON СЦЕНАРИЙ.ИД_Р=РЕЖИССЕР.ИД 
JOIN ФИЛЬМ ON СЦЕНАРИЙ.ИД_Ф=ФИЛЬМ.ИД 
JOIN АКТЕРСКИЙ_СОСТАВ ON АКТЕРСКИЙ_СОСТАВ.ИД_Ф=ФИЛЬМ.ИД 
JOIN АКТЕР ON АКТЕР.ИД=АКТЕРСКИЙ_СОСТАВ.ИД_А 
WHERE РЕЖИССЕР.ИМЯ=name;
$$;

alter function producer(text, out text, out text) owner to s243886;

