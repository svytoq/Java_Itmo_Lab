create function ид_религии_деятеля("ид_деятеля" integer) returns integer
    language plpgsql
as
$$
BEGIN
RETURN (SELECT ИД_РЕЛИГИИ FROM ОРГАНИЗАЦИИ WHERE ИД = (SELECT ИД_ОРГАНИЗАЦИИ FROM ОБЩ_ДЕЯТЕЛИ WHERE ИД = ид_деятеля));
END
$$;

alter function ид_религии_деятеля(integer) owner to s243853;

