create function add_olymp_event(event_name character varying, favsubj bigint[], orgid bigint) returns bigint
    language plpgsql
as
$$
declare
    evId bigint;
    s     bigint;
begin
    insert into event(name) values (event_name) returning id into evId;
    foreach s in array favSubj
        loop
            insert into event_subjects(ev_id, subj_id) values (evId, s);
        end loop;
    insert into competition(ev_id, org_id) values (evId, orgId);
    return evId;
end;
$$;

alter function add_olymp_event(varchar, bigint[], bigint) owner to s263975;

