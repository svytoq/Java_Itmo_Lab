create function trigger_fight_before_del() returns trigger
    language plpgsql
as
$$
BEGIN

    if (select count(*) from "Хронология" a
    where a."Битва"=OLD."id")>0
        then delete from "Хронология" where "Хронология"."Битва"=OLD."id";
    end if;

    return OLD;
END;
$$;

alter function trigger_fight_before_del() owner to s225133;

