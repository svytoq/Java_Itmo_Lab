create function "ПЕРСОНАЛ_НАРУШЕНИЯ_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "ПЕРСОНАЛ_НАРУШЕНИЯ" ("ИД_ПЕРСОНАЛА","ИД_НАРУШЕНИЕ")
VALUES ((SELECT "ИД_ПЕРСОНАЛА" FROM "ПЕРСОНАЛ" OFFSET floor(random()* 100) LIMIT 1),(SELECT "ИД_НАРУШЕНИЕ" FROM "НАРУШЕНИЯ" OFFSET floor(random()*200) LIMIT 1));
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END LOOP;
END;
$$;

alter function "ПЕРСОНАЛ_НАРУШЕНИЯ_ТЕСТ"(integer) owner to s223443;

