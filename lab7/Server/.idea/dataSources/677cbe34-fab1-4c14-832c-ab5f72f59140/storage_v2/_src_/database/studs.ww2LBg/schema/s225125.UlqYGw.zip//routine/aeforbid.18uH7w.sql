create function aeforbid() returns trigger
    language plpgsql
as
$$
BEGIN
  RAISE EXCEPTION 'Нельзя добавлять новые строки, изменять старые, или удалять строки из таблицы %', TG_TABLE_NAME;
END
$$;

alter function aeforbid() owner to s225125;

