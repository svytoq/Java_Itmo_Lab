create function test_free_places_amount() returns trigger
    language plpgsql
as
$$
DECLARE
    max_amount int;
    current_amount int;
BEGIN
    SELECT COUNT(*) FROM room_occupation
        WHERE room_occupation.room_number = NEW.room_number
        INTO current_amount;

    SELECT room.amount_of_places FROM room
        WHERE room.room_number = NEW.room_number
        INTO max_amount;

    ASSERT current_amount < max_amount;
    RETURN NEW;
END;
$$;

alter function test_free_places_amount() owner to s259844;

