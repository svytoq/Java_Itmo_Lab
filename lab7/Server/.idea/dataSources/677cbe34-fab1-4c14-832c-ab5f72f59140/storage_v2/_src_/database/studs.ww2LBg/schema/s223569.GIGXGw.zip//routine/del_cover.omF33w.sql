create function del_cover() returns trigger
    language plpgsql
as
$$
BEGIN
  IF (Select Count(*) from Композиция Where Old.ИД = Кавер_ИД)>0 THEN
    UPDATE "Композиция" SET "Кавер_ИД" = 0 WHERE "Кавер_ИД" = old.ИД;
    RETURN OLD;
  END IF;
  RETURN OLD;
  END;
$$;

alter function del_cover() owner to s223569;

