create function checks() returns void
    language plpgsql
as
$$
DECLARE
  id_player1 integer;
  id_player2 integer;
  mas integer[1000][1000];
  i integer default 1;
  j integer default 1;
BEGIN
  mas[1][1] = NULL;
  for i in 2..1000 loop
    for j in 2..1000 loop
  SELECT ИД_ИГРОКА INTO mas[i][j]
  FROM ИГРОК
  JOIN СТРАНА_УЧАСТНИЦА USING (ИД_СТРАНЫ)
  JOIN ЗАСЕЛЕНИЕ A USING (ИД_СТРАНЫ)
  JOIN ОТЕЛЬ USING (ИД_ОТЕЛЯ)
  WHERE ИД_ОТЕЛЯ = j AND ИД_ИГРОКА IN (SELECT ИД_ИГРОКА
                                       FROM КАРТОЧКА
                                       WHERE ДАТА_ПОЛУЧЕНИЯ_КАРТОЧКИ < A.ДАТА_ЗАСЕЛЕНИЯ);

  end loop;
  end loop;
END;
$$;

alter function checks() owner to s224514;

