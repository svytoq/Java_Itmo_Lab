create function to_chel_greazhd(count integer, start integer, gst integer) returns void
    language plpgsql
as
$$
DECLARE
  J INT;
  I INT;
  K INT;
BEGIN
  K=0;
  FOR J IN SELECT ID_ЧЕЛ FROM ЛЮДИ WHERE ID_ЧЕЛ%5=0 AND ID_ЧЕЛ>=START  LOOP
    IF K=count THEN EXIT ; END IF ;
   FOR I IN SELECT ID_ГРАЖД FROM ГРАЖДАНСКИЕ_МЕРОПРИЯТИЯ WHERE ID_ГРАЖД >=GST AND ID_ГРАЖД%3=0 LOOP
    IF K=count THEN EXIT ; END IF ;
      INSERT INTO ЧЕЛ_НА_ГРАЖД_МЕРОПРИЯТИИ VALUES (DEFAULT ,J,I);
     K= K+1;
   END LOOP;
  END LOOP;
END;
$$;

alter function to_chel_greazhd(integer, integer, integer) owner to s225081;

