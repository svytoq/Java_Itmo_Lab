create function durationbiggerthanage() returns trigger
    language plpgsql
as
$$
BEGIN
  if (SELECT age from character  where id = NEW.id_characters1)< NEW.duration OR (SELECT age from character  where id = NEW.id_characters2)< NEW.duration THEN
    RAISE NOTICE 'Чет ты гонишь... ';
    ROLLBACK TRANSACTION;
    RETURN new;
  end if;
  RETURN new;
END;
$$;

alter function durationbiggerthanage() owner to s225099;

