create function check_building_strength() returns trigger
    language plpgsql
as
$$
begin
if new.strength is null then
raise exception 'strngth cannot be null';
end if;
if new.strength < 0 then
raise exception 'strngth cannot be less than zero';
end if;
if (select (building_type.max_strength >= new.strength) 
	from building_type 
	where building_type.id = new.building_type
	limit 1) then
return new;
else
return null;
end if;
end;
$$;

alter function check_building_strength() owner to s264479;

