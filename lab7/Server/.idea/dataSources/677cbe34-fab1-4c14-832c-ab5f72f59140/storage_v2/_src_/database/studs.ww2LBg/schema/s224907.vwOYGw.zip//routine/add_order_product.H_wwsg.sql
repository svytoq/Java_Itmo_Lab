create function add_order_product(product_id_in integer, count integer, price_in integer, need_confirm_in boolean, order_id_in integer) returns text
    language plpgsql
as
$$
begin
    insert into order_product(order_id, product_id, price, product_count, need_confirm)
    values (order_id_in, product_id_in, price_in, count, need_confirm_in);
    return 'Added product to order';
end
$$;

alter function add_order_product(integer, integer, integer, boolean, integer) owner to s224907;

