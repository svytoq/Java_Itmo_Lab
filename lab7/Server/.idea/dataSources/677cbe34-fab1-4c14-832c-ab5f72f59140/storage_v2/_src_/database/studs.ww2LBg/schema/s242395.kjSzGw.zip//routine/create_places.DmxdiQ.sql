create function create_places() returns void
    language plpgsql
as
$$
DECLARE
        cinema_room record;
BEGIN
        FOR cinema_room IN (SELECT ид from Залы)
        LOOP
                PERFORM create_places_for_cinema_room
                (cinema_room.ид,(random()*10+ 1)::int,(random()*20)::int+ 1,(random()*500)::int + 1);
        END LOOP;
END;
$$;

alter function create_places() owner to s242395;

