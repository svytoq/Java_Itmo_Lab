create function dangerousmeds()
    returns TABLE(med character varying, avghealthimpact numeric, avgiqimpact numeric)
    language plpgsql
as
$$
BEGIN
return query select research.Реагент,avg(result.Изменение_IQ), avg(result.Изменение_здоровья) from Исследование research inner join Результаты_исследований result on research.ИД=result.ИД_исследования where (result.Влияние_на_IQ OR result.Влияние_на_здоровье)=true AND ((result.Изменение_IQ<0) OR (result.Изменение_здоровья <0)) group by Реагент order by (avg(result.Изменение_IQ), avg(result.Изменение_здоровья)) desc;
END;
$$;

alter function dangerousmeds() owner to s185017;

