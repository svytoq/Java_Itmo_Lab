create function "ЧЕЛОВЕК_ИД_ОБН"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ЧЕЛОВЕК_ИД!=NEW.ЧЕЛОВЕК_ИД THEN
NEW.ЧЕЛОВЕК_ИД=OLD.ЧЕЛОВЕК_ИД;
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function "ЧЕЛОВЕК_ИД_ОБН"() owner to s242456;

