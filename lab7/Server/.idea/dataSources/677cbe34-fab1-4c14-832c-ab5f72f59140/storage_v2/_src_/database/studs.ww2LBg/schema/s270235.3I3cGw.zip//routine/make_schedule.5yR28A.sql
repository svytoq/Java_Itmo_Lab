create function make_schedule() returns trigger
    language plpgsql
as
$$
DECLARE
    del_place integer;
    provider  integer;
    weight    integer;

BEGIN
    SELECT id_delivery_place FROM clients WHERE clients.id_client = NEW._from INTO del_place;
    SELECT id_provider FROM providers WHERE providers.id_delivery_place = del_place INTO provider;
    SELECT storages.sausages_weight
    FROM storages
    WHERE (storages.id_sausage = NEW.id_sausage AND
           storages.id_factory = (SELECT providers.id_factory FROM providers WHERE (providers.id_provider = provider)))
    INTO weight;
    IF (weight > NEW.sausages_weight) THEN
        UPDATE storages
        SET sausages_weight = weight - NEW.sausages_weight
        WHERE (storages.id_sausage = NEW.id_sausage AND
               storages.id_factory =
               (SELECT providers.id_factory FROM providers WHERE (providers.id_provider = provider)));
        IF EXISTS(SELECT *
                  FROM order_schedule
                  WHERE order_schedule.id_provider = provider
                    AND order_schedule.id_sausage =
                        NEW.id_sausage
                    AND order_schedule.del_time =
                        (current_date + 1)) THEN
            UPDATE order_schedule
            SET sausages_weight = sausages_weight + NEW.sausages_weight
            WHERE order_schedule.id_provider = provider
              AND order_schedule.id_sausage =
                  NEW.id_sausage
              AND order_schedule.del_time =
                  current_date + 1;
        ELSE
            INSERT INTO order_schedule(id_provider, id_sausage, sausages_weight, del_time)
            VALUES (provider, NEW.id_sausage, NEW.sausages_weight, current_date + 1);
        END IF;
    ELSE
        RAISE EXCEPTION 'We do not have this product in our storage, it would be soon';
    END IF;
    NEW._to = provider;
    NEW.ord_time = localtimestamp;
    RETURN NEW;
END;
$$;

alter function make_schedule() owner to s270235;

