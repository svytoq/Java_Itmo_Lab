create function user_name_change(id_user integer, new_first_name character varying, new_surname character varying) returns void
    language plpgsql
as
$$
BEGIN

  IF NOT EXISTS(SELECT * FROM users WHERE id = user_name_change.id_user) THEN
    RAISE EXCEPTION 'Cannot find user for update';
  ELSE
    UPDATE users
    SET first_name = user_name_change.new_first_name, surname = user_name_change.new_surname
    WHERE id = user_name_change.id_user;
  END IF;

END;

$$;

alter function user_name_change(integer, varchar, varchar) owner to s264458;

