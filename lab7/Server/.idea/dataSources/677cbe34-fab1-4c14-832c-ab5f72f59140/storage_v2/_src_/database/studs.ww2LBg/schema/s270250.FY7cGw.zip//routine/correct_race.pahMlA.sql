create function correct_race() returns trigger
    language plpgsql
as
$$
DECLARE
        count_horses integer;
        ready_to_action boolean;
    BEGIN
        SELECT count(horse_id) INTO count_horses FROM Horse_in_race hr WHERE hr.race_id = NEW.race_id;
        IF NOT FOUND THEN
            RETURN NEW;
        ELSIF (count_horses < 6 OR count_horses > 10) THEN
            UPDATE Races SET is_ready_to_start = FALSE WHERE id = NEW.race_id;
        ELSIF (count_horses >= 6 AND count_horses <= 10) THEN
            UPDATE Races SET is_ready_to_start = TRUE WHERE id = NEW.race_id;
        END IF;
        RETURN NULL;
    END;
$$;

alter function correct_race() owner to s270250;

