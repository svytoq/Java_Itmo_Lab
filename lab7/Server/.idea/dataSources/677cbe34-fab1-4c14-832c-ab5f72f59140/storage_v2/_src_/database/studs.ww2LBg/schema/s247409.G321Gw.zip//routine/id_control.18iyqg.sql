create function id_control(i integer, tabl character varying) returns integer
    language plpgsql
as
$$
BEGIN
        RETURN 10 + (select infoo.maxEl from infoo where infoo.Name = tabl );
    END;
$$;

alter function id_control(integer, varchar) owner to s247409;

