create function last_spaceship_flight(_spaceship_id integer)
    returns TABLE(id_planet_from integer, name_planet_from character varying, id_planet_to integer, name_planet_to character varying, date_start timestamp with time zone, date_end timestamp with time zone)
    language plpgsql
as
$$
begin
return query SELECT
                    P_FROM.id,
                    P_FROM.name,
                    P_TO.id, P_TO.name,
                    "Flights".date_start,
                    CASE WHEN duration is null THEN null else "Flights".date_start + duration end
    from "Flights"
    left join "Planets" P_FROM on P_FROM.id = "Flights".id_planet_from
    left join "Planets" P_TO on P_TO.id = "Flights".id_planet_to
    where id_spaceship = _spaceship_id order by "Flights".date_start desc limit 1;
end;
$$;

alter function last_spaceship_flight(integer) owner to s264434;

