create function insert_random() returns text
    language plpgsql
as
$$
DECLARE length integer = trunc(random()*9)+1::int;
  BEGIN
    return array_to_string(ARRAY(
      SELECT substr('abcdefghijklmnopqrstuvwxuz',trunc(random()*25+1)::int,1)
        FROM generate_series(1, length)),'');
  END;
$$;

alter function insert_random() owner to s225107;

