create function to_senators(count integer, start integer) returns void
    language plpgsql
as
$$
DECLARE
  J     INT;
  TIT   TITUL;
  K     INT;
  datas DATE;
BEGIN
  K = 0;
  datas = '0481-01-01 BC';
  FOR J IN SELECT ID_ЧЕЛ
           FROM ЛЮДИ
           WHERE ID_ЧЕЛ >= start AND СОСЛОВИЕ = 'ПАТРИЦИЙ' LOOP
    IF K = count
    THEN EXIT; END IF;
    IF J % 8 = 0
    THEN datas = datas + 1; END IF;
    CASE
      WHEN J % 120 = 0
      THEN TIT = 'ПРИНЦИПС';
      WHEN J % 55 = 0
      THEN TIT = 'ТРИБУН';

      WHEN J % 28 = 0
      THEN TIT = 'ЦЕНЗОР';

      WHEN J % 16 = 0
      THEN TIT = 'КОНСУЛ';
      WHEN J % 11 = 0
      THEN TIT = 'СОВЕТНИК';
      WHEN J % 7 = 0
      THEN TIT = 'МАГИСТРАТ';
    ELSE TIT = 'РЯДОВОЙ СЕНАТОР';
    END CASE;

    INSERT INTO ЧЛЕНЫ_СЕНАТА VALUES (J, TIT, DATAS, NULL );
    K = K + 1;
  END LOOP;
END;
$$;

alter function to_senators(integer, integer) owner to s225081;

