create function check_house_student_value_alignment() returns trigger
    language plpgsql
as
$$
declare
  house_values personal_value [];
  student_value personal_value;
begin
  house_values := (select values from houses
    inner join study_plans s on s.id = new.study_plan_id and s.house_id = houses.id);
  student_value := (select personal_value from people
    where id = new.person_id);

  if not (student_value = any (house_values))
  then raise exception 'Student''s personal value does not align with those of the house';
  end if;

  return new;
end;
$$;

alter function check_house_student_value_alignment() owner to s244706;

