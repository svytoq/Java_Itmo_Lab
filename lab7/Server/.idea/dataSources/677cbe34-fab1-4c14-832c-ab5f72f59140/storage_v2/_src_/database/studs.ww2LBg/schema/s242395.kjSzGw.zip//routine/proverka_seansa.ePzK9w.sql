create function проверка_сеанса() returns trigger
    language plpgsql
as
$$
DECLARE
        премьера timestamp;
BEGIN
SELECT Фильмы.премьера INTO премьера FROM "Фильмы" WHERE ид = NEW.ид_фильма;
IF NEW.начало < премьера THEN
        RAISE EXCEPTION 'Дата премьеры фильма (%) не может быть позже, чем дата начала показа (%)', премьера, NEW.начало;
END IF;

-- IF EXISTS (SELECT 1 FROM Сеансы WHERE ид != NEW.ид AND ид_зала = NEW.ид_зала AND
--      (
--              (NEW.конец >= Сеансы.начало AND NEW.конец <= Сеансы.конец) OR
--              (NEW.начало >= Сеансы.начало AND NEW.начало <= Сеансы.конец)
--      )
-- ) THEN
--      RAISE EXCEPTION 'В одном зале не могут одновременно проходить два сеанса';
-- END IF;

RETURN NEW;
END;
$$;

alter function проверка_сеанса() owner to s242395;

