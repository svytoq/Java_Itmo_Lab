create function check_if_battle() returns trigger
    language plpgsql
as
$$
DECLARE 
    is_for_battle BOOLEAN;
BEGIN
    SELECT l.FOR_BATTLE INTO is_for_battle FROM locations AS l WHERE l.LOCATION_ID = NEW.LOCATION_ID;
    IF is_for_battle IS TRUE THEN
        INSERT INTO trigger_info(TG_OP, TG_RELNAME, TG_NAME, CREATION_TIME) VALUES(TG_OP, TG_RELNAME, TG_NAME, NOW());
        RETURN NEW;
    ELSE
        RETURN NULL;
    END IF;
END
$$;

alter function check_if_battle() owner to s264449;

