create function add_herb(name character, id integer, h_h integer) returns integer
    language plpgsql
as
$$
DECLARE
quality INTEGER;
intelligence INTEGER;
experience INTEGER;
begin
SELECT INTO intelligence lev from skill_witcher where witcher_id = id AND skill_id = 5;
SELECT INTO experience lev from skill_witcher where witcher_id = id AND skill_id = 6;
 quality = (intelligence + experience)/ 2.8 * 10;
 
 INSERT INTO ingridient VALUES
 (DEFAULT, h_h, name, quality);
 
 RETURN 0;
 end
$$;

alter function add_herb(char, integer, integer) owner to s268428;

