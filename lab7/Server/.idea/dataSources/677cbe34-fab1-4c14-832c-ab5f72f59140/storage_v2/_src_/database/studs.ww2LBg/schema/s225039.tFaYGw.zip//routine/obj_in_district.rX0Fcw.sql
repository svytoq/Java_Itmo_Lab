create function obj_in_district(id integer) returns SETOF s225039."Объект"
    language sql
as
$$
SELECT * FROM Объект WHERE ИД_район = id
$$;

alter function obj_in_district(integer) owner to s225039;

