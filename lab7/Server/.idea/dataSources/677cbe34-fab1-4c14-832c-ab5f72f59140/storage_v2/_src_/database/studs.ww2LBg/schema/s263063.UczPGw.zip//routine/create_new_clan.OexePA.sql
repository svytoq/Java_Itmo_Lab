create function create_new_clan(creatorid integer, clanname character varying, regionid integer, clantype character varying) returns void
    language plpgsql
as
$$
declare actorClanId int;
    begin
        actorClanId = (select clan_id from actor where id = creatorId);
        if actorClanId is null then
            with new_clan as (
                insert into clan (name, region_id, type) values (clanName, regionId, clanType::clan_type)
                returning id as clanId
            )
            update actor set clan_id = (select clanId from new_clan), clan_role = 'Leader' where id = creatorId;
        else
            raise notice 'Actor already in clan!';
        end if;
    end;
$$;

alter function create_new_clan(integer, varchar, integer, varchar) owner to s263063;

