create function add_products_to_shop(_product_ids integer[], _store_id integer, _amounts real[]) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
begin
    for i in 1 .. array_length(_product_ids, 1) loop
        select add_product_to_shop(_product_ids[i], _store_id, _amounts[i]);
    end loop;
end
$$;

alter function add_products_to_shop(integer[], integer, real[]) owner to s264429;

