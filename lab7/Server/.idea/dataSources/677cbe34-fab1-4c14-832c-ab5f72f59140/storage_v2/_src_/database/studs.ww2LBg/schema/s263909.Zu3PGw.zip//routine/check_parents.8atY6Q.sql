create function check_parents() returns trigger
    language plpgsql
as
$$
declare
    count_of_parent integer;
    first_parent integer;
begin
    count_of_parent = (select count(parent_id) from parents where children_id = new.children_id);
    if (count_of_parent > 1) then
        raise exception 'more 2 parent';
    else
        if (count_of_parent = 1) then
            first_parent = (select parent_id from parents where children_id = new.children_id);
            if (new.parent_id = first_parent) then
                raise exception 'Double parent';
            end if;
        end if;
    end if;
    return new;
end;
$$;

alter function check_parents() owner to s263909;

