create view worker_with_profile
            (worker_id, description, user_profile_id, name, date_of_birth, email, telephone_number, password_hash,
             privilege) as
SELECT worker.worker_id,
       worker.description,
       user_profile.user_profile_id,
       user_profile.name,
       user_profile.date_of_birth,
       user_profile.email,
       user_profile.telephone_number,
       user_profile.password_hash,
       user_profile.privilege
FROM s267880.worker
         LEFT JOIN s267880.user_profile ON worker.worker_id = user_profile.user_profile_id;

alter table worker_with_profile
    owner to s267880;

