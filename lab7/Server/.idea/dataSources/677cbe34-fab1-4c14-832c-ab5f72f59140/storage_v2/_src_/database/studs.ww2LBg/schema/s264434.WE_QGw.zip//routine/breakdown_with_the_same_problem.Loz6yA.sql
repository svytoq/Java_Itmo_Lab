create function breakdown_with_the_same_problem(_id_detector integer, _id_device integer)
    returns TABLE(id_device_with_breakdown integer, id_detector_with_breakdown integer, description_breakdown text, description_solution text, id_spaceship_with_breakdown integer, spaceship_name character varying, date timestamp with time zone)
    language plpgsql
as
$$
begin
    return query select id_device, id_detector, B.description, "BreakdownSolutions".description, id_spaceship, S.name, B.date from "BreakdownSolutions"
    left join "Breakdowns" B on B.id = "BreakdownSolutions".id_breakdown
    left join "Spaceships" S on S.id = B.id_spaceship
    where (id_detector is not null and id_detector=_id_detector)
       or (id_device is not null and id_device=_id_device);
end;
$$;

alter function breakdown_with_the_same_problem(integer, integer) owner to s264434;

