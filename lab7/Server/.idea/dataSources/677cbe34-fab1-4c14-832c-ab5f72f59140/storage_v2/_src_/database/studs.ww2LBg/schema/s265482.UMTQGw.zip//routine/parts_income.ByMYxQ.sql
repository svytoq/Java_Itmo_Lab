create function parts_income() returns void
    language plpgsql
as
$$
begin
    update shipments
    set count_left    = count_left + delivery_size,
        delivery_date = delivery_date + delivery_interval
    where delivery_date = current_date;
    end
$$;

alter function parts_income() owner to s265482;

