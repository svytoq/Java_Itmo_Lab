create function "ЗАПОЛНИТЬ_ВАЖНЫЕ_СОБЫТИЯ"(count integer) returns void
    language plpgsql
as
$$
BEGIN
FOR i IN 1..count LOOP
INSERT INTO ПЕРСОНАЖИ VALUES(DEFAULT, 'Гарри' || i, 'Поттер', NULL, NULL, 'Карий', 'Черный', NULL, NULL, NULL, NULL);
END LOOP;
RETURN;
END;
$$;

alter function "ЗАПОЛНИТЬ_ВАЖНЫЕ_СОБЫТИЯ"(integer) owner to s225054;

