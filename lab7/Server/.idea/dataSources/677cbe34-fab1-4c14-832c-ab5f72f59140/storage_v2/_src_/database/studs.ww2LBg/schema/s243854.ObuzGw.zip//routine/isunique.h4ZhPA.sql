create function isunique(login text) returns boolean
    language plpgsql
as
$$
BEGIN
IF EXISTS (SELECT ЛОГИН FROM ПОЛЬЗОВАТЕЛЬ WHERE ЛОГИН = login)
THEN RETURN FALSE;
END IF;
RETURN TRUE;
END
$$;

alter function isunique(text) owner to s243854;

