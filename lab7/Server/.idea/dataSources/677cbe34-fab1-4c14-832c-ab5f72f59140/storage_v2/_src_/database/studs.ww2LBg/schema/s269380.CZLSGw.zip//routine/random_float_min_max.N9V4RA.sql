create function random_float_min_max(val_min integer, val_max integer) returns double precision
    language sql
as
$$
select (random() *(val_max - val_min) + val_min)
$$;

alter function random_float_min_max(integer, integer) owner to s269380;

