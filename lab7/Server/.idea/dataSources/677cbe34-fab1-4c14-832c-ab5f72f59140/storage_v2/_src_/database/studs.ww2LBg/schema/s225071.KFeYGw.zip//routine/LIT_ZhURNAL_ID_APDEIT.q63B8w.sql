create function "ЛИТ_ЖУРНАЛ_ИД_АПДЕЙТ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ИД_ЖУРНАЛА!=NEW.ИД_ЖУРНАЛА
THEN NEW.ИД_ЖУРНАЛА=OLD.ИД_ЖУРНАЛА; 
	RETURN NEW;
ELSE RETURN NEW; 
END IF; 
END;
$$;

alter function "ЛИТ_ЖУРНАЛ_ИД_АПДЕЙТ"() owner to s225071;

