create function return_weapon_after_using() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW.weapon_id IS NULL AND OLD.weapon_id IS NOT NULL) OR (NEW.weapon_id <> OLD.weapon_id) THEN
      UPDATE weaponry SET quantity = quantity+1 WHERE id = OLD.weapon_id;
    END IF;
      RETURN NEW;
  END;
$$;

alter function return_weapon_after_using() owner to s243867;

