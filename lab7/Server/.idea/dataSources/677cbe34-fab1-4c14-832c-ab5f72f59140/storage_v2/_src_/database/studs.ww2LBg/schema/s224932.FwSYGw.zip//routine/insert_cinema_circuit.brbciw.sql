create function insert_cinema_circuit(count integer) returns void
    language plpgsql
as
$$
BEGIN
        FOR i in 1 .. count LOOP
                insert into Сети(название) values(random_string(10));
        END LOOP;
END;
$$;

alter function insert_cinema_circuit(integer) owner to s224932;

