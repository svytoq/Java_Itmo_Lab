create function brigade_record_add() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (SELECT EXISTS(SELECT 1 FROM Brigade INNER JOIN Brigade_record ON Brigade.foreman_id = Brigade_record.miner_id)) THEN
		RAISE 'Вы пытаетесь добавить бригадира в бригаду';
	ELSE
		RETURN NEW;
	END IF;
END;
$$;

alter function brigade_record_add() owner to s264905;

