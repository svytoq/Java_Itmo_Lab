create function add_baggage(integer, real) returns void
    language plpgsql
as
$$
begin
  insert into baggage(ticket_id, max_weight) values ($1,$2);
  update ticket set amount=amount + $2*100 where id=$1;
end;
$$;

alter function add_baggage(integer, real) owner to s265061;

