create view last_prices(id, value, item_id) as
SELECT DISTINCT ON (price_history.item_id) price_history.id,
                                           price_history.value,
                                           price_history.item_id
FROM s251437.price_history
ORDER BY price_history.item_id, price_history.id DESC;

alter table last_prices
    owner to s251437;

