create function managing_add() returns trigger
    language plpgsql
as
$$
DECLARE
counts integer := 0;
BEGIN
SELECT COUNT(*) FROM УПРАВЛЯЮЩИЙ WHERE КОРПУС_НОМЕР = NEW.КОРПУС_НОМЕР INTO counts;
IF counts > 8 THEN
RAISE EXCEPTION 'НЕДОПУСТИМОЕ КОЛЛИЧЕСТВО';
ELSE
NEW.ИД := NEW.КОРПУС_НОМЕР * 10 + counts;
END IF;

RETURN NEW;
END
$$;

alter function managing_add() owner to s225141;

