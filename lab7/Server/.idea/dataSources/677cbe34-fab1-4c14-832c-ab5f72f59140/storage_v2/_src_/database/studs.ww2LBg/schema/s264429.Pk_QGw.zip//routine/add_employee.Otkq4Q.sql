create function add_employee(_fname character varying, _mname character varying, _lname character varying) returns integer
    language plpgsql
as
$$
declare
    i integer := 0;
    employee_id integer := 0;
    machines_count integer := 0;
begin
    select count(*) into machines_count from circuit_board_machine where state = 'ok';
    insert into factory_employee(fname, mname, lname) values (_fname, _mname, _lname) returning id into employee_id;
    for i in 1 .. ((random() * 3 + 1)::int) loop
        insert into employee_machine_xref(employee_id, machine_id)
        values (employee_id, random() * (machines_count - 1) + 1) on conflict do nothing;
    end loop;
    insert into tea_cupboard (owner_id, color, capacity) values (employee_id, hsv_to_rgb(random(), 1, 1), floor(random() * (40 - 10) + 10)::int);
    return employee_id;
end;
$$;

alter function add_employee(varchar, varchar, varchar) owner to s264429;

