create function check_banned_deck() returns trigger
    language plpgsql
as
$$
BEGIN
		--проверяем поля забаненной колоды
		IF ((SELECT COUNT(*) FROM PLAYER WHERE (NICKNAME = NEW.NICKNAME_BANNED_BY)) = 0) THEN
			RAISE EXCEPTION 'No such player';
		END IF;
		IF ((SELECT COUNT(*) FROM MATCH WHERE (MATCH_ID = NEW.MATCH_ID)) = 0) THEN
			RAISE EXCEPTION 'No such match';
		END IF;
		IF ((SELECT COUNT(*) FROM DECK WHERE (DECK_ID = NEW.DECK_ID)) = 0) THEN
			RAISE EXCEPTION 'No such deck';
		END IF;
	END;

$$;

alter function check_banned_deck() owner to s225111;

