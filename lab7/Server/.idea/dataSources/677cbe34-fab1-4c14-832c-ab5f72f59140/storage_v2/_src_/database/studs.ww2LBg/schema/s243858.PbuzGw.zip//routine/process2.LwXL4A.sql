create function process2(tbl character varying) returns SETOF character varying
    language plpgsql
as
$$
BEGIN
RETURN QUERY EXECUTE 'SELECT * FROM ' || tbl;
END
$$;

alter function process2(varchar) owner to s243858;

