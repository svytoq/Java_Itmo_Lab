create function visa_check_create(app_id integer, employee integer) returns integer
    language plpgsql
as
$$
declare
    check_id integer;
begin
    if employee=-1 then
        select visa_check_id into check_id from Visa_checks where visa_app_id=app_id;
        if check_id is not null then
            perform visa_check_assign(check_id, employee);
            return check_id;
        end if;
    end if;

    insert into Visa_checks(visa_app_id)
        values(app_id)
        returning visa_check_id into check_id;
    insert into Visa_check_employees(employee_id, visa_check_id)
        values(employee, check_id);
    update Visa_applications set 
        visa_app_state='reviewing'
        where visa_app_id=app_id;
    return check_id;
end;
$$;

alter function visa_check_create(integer, integer) owner to s265066;

