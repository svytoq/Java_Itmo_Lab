create function order_type(type_string character varying) returns integer
    language plpgsql
as
$$
DECLARE
    res integer;
BEGIN
    SELECT order_type_id INTO res FROM order_type WHERE name = type_string;
    RETURN res;
END;
$$;

alter function order_type(varchar) owner to s265113;

