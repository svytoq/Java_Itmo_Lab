create function check_service_offer_status() returns trigger
    language plpgsql
as
$$
DECLARE
    STATUS "STATUS" := (SELECT STATUS
                       FROM OFFER
                       WHERE ID = NEW.OFFER);
BEGIN
    IF STATUS != 'OPEN' THEN
        RETURN NULL;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_service_offer_status() owner to s265090;

