create function "МЕСТА_В_СТРАНЕ"(country character varying)
    returns TABLE("НАЗВАНИЕ_МЕСТА" character varying, "СТРАНА" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"МЕСТА"."НАЗВАНИЕ_МЕСТА", "МЕСТА"."СТРАНА"
from "МЕСТА" WHERE "МЕСТА"."СТРАНА" = country;
END;
$$;

alter function "МЕСТА_В_СТРАНЕ"(varchar) owner to s225071;

