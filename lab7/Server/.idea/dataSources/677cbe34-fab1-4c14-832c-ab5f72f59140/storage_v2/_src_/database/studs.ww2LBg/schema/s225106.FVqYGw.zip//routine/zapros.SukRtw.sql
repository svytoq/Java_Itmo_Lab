create function запрос(index integer) returns SETOF record
    language sql
as
$$
SELECT ЧЕЛОВЕК.ИД, ИМЯ_ЧЕЛ, КОРОТКОЕ_ИМЯ, ПОЛ_ЧЕЛ, ВОЗРАСТ_ЧЕЛ, НАЗВАНИЕ, МЕСТО FROM ЧЕЛОВЕК, ДОЛЖНОСТЬ, ИНФА_ЧЕЛ, МЕСТО 
WHERE ИНФА_ЧЕЛ.ИД_ЧЕЛ=index AND ЧЕЛОВЕК.ИД = index AND ИНФА_ЧЕЛ.ИД_ДОЛЖН=ДОЛЖНОСТЬ.ИД AND ИНФА_ЧЕЛ.ИД_МЕСТА=МЕСТО.ИД;
$$;

alter function запрос(integer) owner to s225106;

