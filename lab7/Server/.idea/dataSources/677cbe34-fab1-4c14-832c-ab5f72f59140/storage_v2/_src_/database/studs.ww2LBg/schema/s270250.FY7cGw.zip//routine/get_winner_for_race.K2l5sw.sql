create function get_winner_for_race(race integer, OUT winner_id integer) returns integer
    language plpgsql
as
$$
BEGIN
        SELECT h.id INTO winner_id FROM Horse_in_race JOIN Horses h ON (Horse_in_race.horse_id = h.id) WHERE race_id = race ORDER BY (h.power*0.6+h.luck*4) DESC LIMIT 1;
    END;
$$;

alter function get_winner_for_race(integer, out integer) owner to s270250;

