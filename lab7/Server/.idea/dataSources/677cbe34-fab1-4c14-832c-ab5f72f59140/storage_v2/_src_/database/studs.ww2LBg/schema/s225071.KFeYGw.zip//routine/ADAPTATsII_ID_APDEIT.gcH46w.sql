create function "АДАПТАЦИИ_ИД_АПДЕЙТ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ИД_АДАПТАЦИИ!=NEW.ИД_АДАПТАЦИИ THEN
 NEW.ИД_АДАПТАЦИИ=OLD.ИД_АДАПТАЦИИ;
 RETURN NEW;
ELSE
RETURN NEW;
END IF;
 END;
$$;

alter function "АДАПТАЦИИ_ИД_АПДЕЙТ"() owner to s225071;

