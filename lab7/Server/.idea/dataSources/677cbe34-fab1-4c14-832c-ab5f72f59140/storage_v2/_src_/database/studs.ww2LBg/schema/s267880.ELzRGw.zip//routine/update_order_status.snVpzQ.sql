create function update_order_status(product_order_id integer, order_status s267880.order_status_type) returns void
    language plpgsql
as
$$
begin
    update product_order set order_status = $2 where product_order.product_order_id = $1;
    if not found then
        raise exception 'Order not found';
    end if;
end
$$;

alter function update_order_status(integer, s267880.order_status_type) owner to s267880;

