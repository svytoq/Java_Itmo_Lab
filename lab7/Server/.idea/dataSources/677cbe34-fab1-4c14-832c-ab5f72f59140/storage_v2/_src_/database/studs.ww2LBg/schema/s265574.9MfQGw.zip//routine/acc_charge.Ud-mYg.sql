create function acc_charge() returns trigger
    language plpgsql
as
$$
declare
    needEnergy integer := new.maxvalue - new.currentvalue;
    reactor modul;
begin
    if((cast(NEW.CurrentValue as decimal) / NEW.MaxValue * 100) > 80) then
        reactor = (select m from accumulator as a
            INNER JOIN ucw as u on a.id = u.moduleaccumid
            inner join modul m on u.moduleid = m.id and m.name = 'Реактор');

        if(reactor.e_buffer > needEnergy) then
            Update modul 
            set e_buffer = reactor.e_buffer - needEnergy 
            where id = reactor.id;
        else
            raise notice 'Not enought energy!';
        end if;
    end if;
    
    return new;
end;
$$;

alter function acc_charge() owner to s265574;

