create function correct_time_for_product_owner() returns trigger
    language plpgsql
as
$$
DECLARE
  r TIME[2];
  flag BOOLEAN;
BEGIN
  flag = false;
  FOREACH r SLICE 1 IN ARRAY (SELECT ЧАСЫ_РАБОТЫ FROM "ОТПРАВИТЕЛЬ" WHERE NEW.ОТПРАВИТЕЛЬ_ИД = "ОТПРАВИТЕЛЬ_ИД")
  LOOP
    IF NEW.ВРЕМЯ_ЗАКАЗА::time BETWEEN r[1] AND r[2] THEN
      flag = true;
    end if;
  END LOOP;

  IF not flag THEN
    RAISE EXCEPTION 'Нерабочие время';
  END IF;

RETURN NEW;
END;
$$;

alter function correct_time_for_product_owner() owner to s242456;

