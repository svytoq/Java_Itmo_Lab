create function calculate_recipe_total_volume(coffee integer) returns double precision
    language plpgsql
as
$$
DECLARE
    sum float;
BEGIN
    SELECT SUM(компонент_кофе.количество * ингредиент.количество_мл) as whole_volume
                 FROM компонент_кофе
                          JOIN ингредиент ON компонент_кофе.id_ингредиента = ингредиент.id
                 WHERE компонент_кофе.id_кофе = coffee INTO sum;
    RETURN sum;
END;
$$;

alter function calculate_recipe_total_volume(integer) owner to s265082;

