create function mover(intormented integer, insubcircle integer) returns text
    language plpgsql
as
$$
declare

begin
update Tormented set idsubcircle=insubcircle where idtormented=intormented;
delete from Tormented_has_SpecificSin where Tormented_idTormented=intormented and
SpecificSin_idSpecificSin=(select idspecificsin from SubCircle where idSubCircle=insubcircle);
return 'updated!';
end;
$$;

alter function mover(integer, integer) owner to s242430;

