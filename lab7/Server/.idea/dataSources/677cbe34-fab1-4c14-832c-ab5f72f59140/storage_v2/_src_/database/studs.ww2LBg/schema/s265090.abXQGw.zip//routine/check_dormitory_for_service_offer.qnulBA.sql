create function check_dormitory_for_service_offer() returns trigger
    language plpgsql
as
$$
DECLARE
    REQUEST_AUTHOR    INTEGER := (SELECT AUTHOR
                                  FROM REQUEST
                                  WHERE ID = NEW.REQUEST);
    OFFER_AUTHOR      INTEGER := (SELECT AUTHOR
                                  FROM OFFER
                                  WHERE ID = NEW.OFFER);
    REQUEST_DORMITORY INTEGER := (SELECT DORMITORY
                                  FROM "USER"
                                  WHERE ID = REQUEST_AUTHOR);
    OFFER_DORMITORY   INTEGER := (SELECT DORMITORY
                                  FROM "USER"
                                  WHERE ID = OFFER_AUTHOR);
BEGIN
    IF REQUEST_DORMITORY != OFFER_DORMITORY THEN
        RETURN NULL;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_dormitory_for_service_offer() owner to s265090;

