create function add_person(name character, birthdate date, alive boolean) returns integer
    language plpgsql
as
$$
DECLARE
id INTEGER;
begin
 id = nextval('person_person_id_seq'); 
 INSERT INTO person VALUES
 (id, name, birthdate, alive);
 RETURN id;
 end;
$$;

alter function add_person(char, date, boolean) owner to s268428;

