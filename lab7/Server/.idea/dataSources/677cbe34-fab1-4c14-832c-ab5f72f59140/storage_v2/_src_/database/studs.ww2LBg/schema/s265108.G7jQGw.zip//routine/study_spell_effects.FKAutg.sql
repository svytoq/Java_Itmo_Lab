create function study_spell_effects() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.is_success = 'TRUE' THEN
    INSERT INTO Spell_to_magician (magician_id, spell_id)
    VALUES (NEW.magician_id, NEW.spell_id);
  END IF;
  RETURN NEW;
END;
$$;

alter function study_spell_effects() owner to s265108;

