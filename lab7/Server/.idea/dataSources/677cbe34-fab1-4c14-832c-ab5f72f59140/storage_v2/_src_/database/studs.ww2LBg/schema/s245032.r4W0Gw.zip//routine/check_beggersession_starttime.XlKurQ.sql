
BEGIN
IF (NEW.StartTime >= CURRENT_TIMESTAMP) THEN
RAISE EXCEPTION 'BeggerSession: StartTime is bigger then the current date and time!';
END IF;
RETURN NEW;
END;
