create function check_for_reserve() returns trigger
    language plpgsql
as
$$
begin
        if old.Ticket_is_in_queue = true
            then
                raise exception 'Ticket has been reserved already!';
            else
                return NEW;
        end if;
    end;
$$;

alter function check_for_reserve() owner to s265103;

