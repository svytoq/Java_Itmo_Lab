create function random_string(length integer) returns text
    language plpgsql
as
$$
declare
chars text[] := '{Б, В, Г, Д, Ж, З, Й, К, Л, М, Н, П, Р, С, Т, Ф, Х, Ч, Ц, Ш, Щ, А, Е, Ё, И, О, У, Ы, Э, Ю, Я}';
result text := '';
i integer := 0;
begin
if length < 0 then
raise exception 'Длинна не может быть меньше 0';
end if;
for i in 1..length loop
result := result || chars[1+random()*(array_length(chars, 1)-1)];
end loop;
return result;
end;
$$;

alter function random_string(integer) owner to s223443;

