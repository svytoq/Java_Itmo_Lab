create function tr() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN

IF NOT EXISTS(SELECT Группа_ИД FROM Тренировки_групп WHERE Группа_ИД = NEW.Группа_ИД AND Время_проведения = NEW.Время_проведения and День_недели=NEW.День_недели)THEN
RETURN NEW;
ELSE
RAISE EXCEPTION 'В это время у группы % уже есть занятия',NEW.Группа_ИД;
END IF;


IF NOT EXISTS(SELECT Тренировка_ИД FROM Тренировки_групп WHERE Время_проведения=NEW.Время_проведения AND День_недели=NEW.День_недели AND Тренировка_ИД=NEW.Тренировка_ИД) THEN
RETURN NEW;
ELSE 
RAISE EXCEPTION 'Невозможно выбрать данное время'
USING HINT ='попробуйте выбрать другое занятие или другое время';
END IF;
END;
$$;

alter function tr() owner to s242243;

