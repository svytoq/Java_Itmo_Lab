create function человек(name text) returns SETOF record
    language sql
as
$$
SELECT ЧЕЛОВЕК.КОРОТКОЕ_ИМЯ, МЕСТО.МЕСТО, ДОЛЖНОСТЬ.НАЗВАНИЕ from ЧЕЛОВЕК inner join ИНФА_ЧЕЛ on (ЧЕЛОВЕК.ИД=ИНФА_ЧЕЛ.ИД_ЧЕЛ) 
inner join МЕСТО on (МЕСТО.ИД=ИНФА_ЧЕЛ.ИД_МЕСТА) inner join ДОЛЖНОСТЬ on ( ДОЛЖНОСТЬ.ИД=ИНФА_ЧЕЛ.ИД_ДОЛЖН) where ЧЕЛОВЕК.КОРОТКОЕ_ИМЯ=name;
$$;

alter function человек(text) owner to s225106;

