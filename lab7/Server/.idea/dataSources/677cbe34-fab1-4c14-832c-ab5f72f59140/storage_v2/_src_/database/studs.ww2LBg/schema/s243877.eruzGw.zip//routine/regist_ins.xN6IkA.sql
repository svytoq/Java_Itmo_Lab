create function regist_ins() returns trigger
    language plpgsql
as
$$
declare
B MEETING%ROWTYPE;
begin
select * into B from MEETING where ID = NEW.MEETING_ID;
if B.PEOPLE_LEFT = 0
then delete from REGISTRATION where PERSON_ID = NEW.PERSON_ID;
raise notice 'No more people are allowed at this meeting';
end if;
if B.PEOPLE_LEFT <> 0
then update MEETING set PEOPLE_LEFT = B.PEOPLE_LEFT-1 where ID = NEW.MEETING_ID;
end if;
return NEW;
end
$$;

alter function regist_ins() owner to s243877;

