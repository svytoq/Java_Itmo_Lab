create function get_character_ablilities(char_id integer)
    returns TABLE(character_name character varying, ability_name character varying, ability_description text, ability_type s263229.ability_types, complexity_level integer)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT c.CHARACTER_NAME, a.ABILITY_NAME, a.DESCRIPTION, a.ABILITY_TYPE, a.COMPLEXITY_LEVEL FROM character AS c 
    JOIN characters_abilities USING(CHARACTER_ID) JOIN abilities AS a USING(ABILITY_ID) WHERE c.CHARACTER_ID = char_id;
END
$$;

alter function get_character_ablilities(integer) owner to s263229;

