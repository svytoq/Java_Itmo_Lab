create function "АРТЕФАКТ_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "АРТ_ИД" FROM "АРТЕФАКТ");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."АРТ_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''АРТЕФАКТ_АРТ_ИД_seq'', max("АРТ_ИД") + 1) FROM "АРТЕФАКТ"';
                        NEW."АРТ_ИД" := max_id + 1;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "АРТЕФАКТ_PK_seq_func"() owner to s245094;

