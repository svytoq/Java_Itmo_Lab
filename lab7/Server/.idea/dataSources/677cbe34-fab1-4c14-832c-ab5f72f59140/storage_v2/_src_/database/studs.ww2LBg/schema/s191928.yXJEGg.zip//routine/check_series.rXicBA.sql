create function check_series() returns trigger
    language plpgsql
as
$$
declare
series_length integer;
iterator integer;
err_length character(70);
err_first_char character(50);
err_fourth_char character(50);
err_last_char character(50);
err_not_digit character(50);
begin
series_length := length(new.series);
err_length := 'Series must be of 7 characters. Format is s00e00a (last char can be b)';
err_first_char := 'First character must be s!';
err_fourth_char := 'Fourth character must be e!';
err_last_char := 'Last character can be either a or b!';
err_not_digit := 'There should be 2 digits after s or e!';
if series_length <> 7 then raise notice '%', err_length;
return null;
end if;
for i in 1..series_length loop
 if substr(new.series, i, 1) <> 's' and i = 1 then raise notice '%', err_first_char;
  return null;
  end if;
  if i = 2 or i = 3 or i = 5 or i = 6 then
   if position(substr(new.series, i, 1) in '0123456789') = 0 then raise notice '%', err_not_digit;
   return null;
   end if;
  end if;
  if substr(new.series, i, 1) <> 'e' and i = 4 then raise notice '%', err_fourth_char;
  return null;
  end if;
  if position(substr(new.series, i, 1) in 'ab') = 0 and i = 7 then raise notice '%', err_last_char;
  return null;
  end if;
 end loop;
return new;
end
$$;

alter function check_series() owner to s191928;

