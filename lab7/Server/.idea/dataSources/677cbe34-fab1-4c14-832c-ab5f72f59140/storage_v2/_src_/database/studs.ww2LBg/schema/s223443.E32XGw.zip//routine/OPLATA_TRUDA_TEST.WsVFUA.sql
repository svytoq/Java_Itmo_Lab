create function "ОПЛАТА_ТРУДА_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  tel uuid;
  telq uuid;
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
tel = (SELECT "ИД_РАСХОДОВ" FROM "РАСХОДЫ" OFFSET floor(random()*200) LIMIT 1);
telq = (SELECT "ИД_ПЕРСОНАЛА" FROM "ПЕРСОНАЛ" OFFSET floor(random()*500) LIMIT 1);
IF NOT (exists(SELECT FROM "ОПЛАТА_ТРУДА" WHERE "ОПЛАТА_ТРУДА"."ИД_РАСХОДОВ" = tel)) THEN
IF exists(SELECT FROM "РАСХОДЫ" WHERE "РАСХОДЫ"."ИД_РАСХОДОВ" = tel) THEN
IF NOT (exists(SELECT FROM "ОПЛАТА_ТРУДА" WHERE "ОПЛАТА_ТРУДА"."ИД_ПЕРСОНАЛА" = telq)) THEN
IF (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."ИД_ПЕРСОНАЛА" = telq)) THEN
INSERT INTO "ОПЛАТА_ТРУДА" ("ИД_РАСХОДОВ","ИД_ПЕРСОНАЛА", "ДАТА","ВЫПЛАЧЕННАЯ_СУММА")
VALUES (tel,telq,date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)),s);
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END IF;
  END IF;
  END IF;
  END IF;
END LOOP;
END;
$$;

alter function "ОПЛАТА_ТРУДА_ТЕСТ"(integer) owner to s223443;

