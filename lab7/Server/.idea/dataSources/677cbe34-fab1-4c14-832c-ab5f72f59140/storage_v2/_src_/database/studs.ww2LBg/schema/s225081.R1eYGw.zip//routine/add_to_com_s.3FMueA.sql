create function add_to_com_s(n integer) returns void
    language plpgsql
as
$$
DECLARE
 SER INTEGER;
  AUTH INTEGER;
  CONT TEXT;
  DAT TIMESTAMP;
  ONCOM INTEGER;
  I INTEGER;
BEGIN
 FOR I IN 1..N LOOP
    SER = 18+I;
   AUTH = 18+I;
   CONT = 'COMMENT_TO_NEWS'||I;
   SELECT NOW() INTO DAT;
   INSERT INTO comment_on_series VALUES (DEFAULT ,AUTH, CONT, DAT,NULL);
   ONCOM=I;
    INSERT INTO comment_on_series VALUES (DEFAULT,AUTH, CONT, DAT,ONCOM);
 END LOOP;
END;

$$;

alter function add_to_com_s(integer) owner to s225081;

