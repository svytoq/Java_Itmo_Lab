create function add_child(name character, birthdate date, learnability integer, school_id integer, stream_id integer) returns integer
    language plpgsql
as
$$
DECLARE
person_id INTEGER;
role_id INTEGER;
witcher_id INTEGER;
begin
 person_id = add_person(name, birthdate, true);
 SELECT into role_id from add_role('witcherJr', school_id, NULL, learnability, NULL);
 witcher_id = nextval('witcher_witcher_id_seq'); 
 INSERT INTO witcher VALUES
 (witcher_id, 'witcherJr', person_id, role_id, stream_id);
 RETURN 0;
 end
$$;

alter function add_child(char, date, integer, integer, integer) owner to s268428;

