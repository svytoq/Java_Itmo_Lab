create function create_building() returns trigger
    language plpgsql
as
$$
DECLARE
buildings integer=0;
BEGIN
SELECT COUNT(*) INTO buildings FROM КОРПУС;
NEW.НОМЕР:=buildings;
FOR i IN 1..10 LOOP
PERFORM create_floor(buildings);
END LOOP;
RETURN NEW;
END;
$$;

alter function create_building() owner to s225141;

