create function create_rooms(count integer) returns void
    language plpgsql
as
$$
DECLARE
        cinema record;
BEGIN
        FOR cinema IN (SELECT ид from Кинотеатры)
        LOOP
                FOR i in 1 .. count LOOP
                insert into Залы(ид_кинотеатра, номер_зала) 
                        values(cinema.ид,i);
                END LOOP;
        END LOOP;
END;
$$;

alter function create_rooms(integer) owner to s242395;

