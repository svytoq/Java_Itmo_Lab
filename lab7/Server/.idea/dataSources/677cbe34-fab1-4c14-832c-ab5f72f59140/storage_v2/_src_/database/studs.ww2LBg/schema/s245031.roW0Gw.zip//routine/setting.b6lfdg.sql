create function setting() returns trigger
    language plpgsql
as
$$
begin
NEW.уровень := NEW.ОО/100+1;
NEW.Макс_ОД := 5+NEW.ЛВК/2;
if (NEW.ОД is null) then NEW.ОД:= NEW.Макс_ОД;
end if;
NEW.Шанс_крита := NEW.УДЧ;
NEW.Меткость := NEW.ВСП * 9;
NEW.Грузоподъёмность := 10 + NEW.СИЛ * 10;
NEW.Базовая_защита := (NEW.ЛВК+NEW.ВНС+NEW.СИЛ+NEW.УДЧ) / 4;
NEW.Макс_ОЗ := 15+NEW.СИЛ+NEW.ВНС*2+NEW.уровень*2;
if (NEW.ОЗ is null) then NEW.ОЗ:= NEW.Макс_ОЗ;
end if;
return NEW;
end;
$$;

alter function setting() owner to s245031;

