create function add_children(count integer, start_date date) returns void
    language plpgsql
as
$$
DECLARE
                weight_v numeric;
                day      date;
                age      interval;
            BEGIN
                day = start_date;

                FOR i IN 1..count / 2
                LOOP
                    day = day + interval '1 day';
                    age = age(now(), day);

                    IF age >= interval '15 year' then
                        weight_v = 50.4;
                    ELSEIF age >= interval '14 year' then
                        weight_v = 45.4;
                    ELSEIF age >= interval '13 year' then
                        weight_v = 39.3;
                    ELSEIF age >= interval '12 year' then
                        weight_v = 36.7;
                    ELSEIF age >= interval '11 year' then
                        weight_v = 32.1;
                    ELSEIF age >= interval '10 year' then
                        weight_v = 30.0;
                    ELSEIF age >= interval '9 year' then
                        weight_v = 26.1;
                    ELSEIF age >= interval '8 year' then
                        weight_v = 24.1;
                    ELSEIF age >= interval '7 year' then
                        weight_v = 21.6;
                    ELSEIF age >= interval '6 year' then
                        weight_v = 19.7;
                    ELSEIF age >= interval '5 year' then
                        weight_v = 17.4;
                    ELSEIF age >= interval '4 year' then
                        weight_v = 15.5;
                    ELSEIF age >= interval '3 year' then
                        weight_v = 13.7;
                    ELSEIF age >= interval '2 year' then
                        weight_v = 12.4;
                    ELSEIF age >= interval '1 year' then
                        weight_v = 10;
                    ELSE
                        weight_v = 5;
                    END IF;
                    INSERT into children (birthday, sex, weight, iq)
                    VALUES (day, true, weight_v, weight_v + 60),
                    (day, false, weight_v, weight_v + 60);
                END LOOP;
            END;
$$;

alter function add_children(integer, date) owner to s223791;

