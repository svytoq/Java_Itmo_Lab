create function check_mentor_team_dependency() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS(SELECT * FROM team WHERE NEW.championship_id = team.championship_id AND NEW.team_id = team.team_id) THEN
        RAISE EXCEPTION 'Mentor and team should be in one championship';
    END IF;
RETURN NEW;
END;
$$;

alter function check_mentor_team_dependency() owner to s264448;

