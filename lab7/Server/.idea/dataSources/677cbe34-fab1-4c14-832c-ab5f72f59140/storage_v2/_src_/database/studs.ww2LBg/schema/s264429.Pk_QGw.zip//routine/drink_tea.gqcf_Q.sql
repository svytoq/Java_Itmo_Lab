create function drink_tea(_cupboard_id integer, _tea_id integer, _amount real) returns boolean
    language plpgsql
as
$$
declare
    i integer := 0;
    tea_amount real := null;
begin
    select amount into tea_amount from cupboard_item where cupboard_id = _cupboard_id and product_id = _tea_id;
    if tea_amount is null or tea_amount - _amount < 0 then
        return false;
    else
        update cupboard_item set amount = tea_amount - _amount  where cupboard_id = _cupboard_id and product_id = _tea_id;
        return true;
    end if;

end
$$;

alter function drink_tea(integer, integer, real) owner to s264429;

