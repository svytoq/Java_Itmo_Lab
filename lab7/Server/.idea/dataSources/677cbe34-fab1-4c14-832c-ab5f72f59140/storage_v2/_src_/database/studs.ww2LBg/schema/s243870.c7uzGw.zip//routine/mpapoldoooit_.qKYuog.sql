create function мпаполдоооить() returns trigger
    language plpgsql
as
$$
DECLARE
	   _is_busy integer;
	BEGIN
		SELECT count(*) INTO _is_busy FROM "К_Партии" WHERE ГМ_ИД = NEW.ГМ_ИД AND Время_Удаления > current_timestamp;
		IF (_is_busy != 0) THEN
			RETURN NULL;
		END IF;
		RETURN NEW;
	END;
$$;

alter function мпаполдоооить() owner to s243870;

