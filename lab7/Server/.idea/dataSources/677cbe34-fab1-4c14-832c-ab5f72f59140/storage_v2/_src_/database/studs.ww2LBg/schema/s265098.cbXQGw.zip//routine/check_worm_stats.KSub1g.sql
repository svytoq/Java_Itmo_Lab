create function check_worm_stats() returns trigger
    language plpgsql
as
$$
DECLARE
        req_strf int;
        req_aglf int;
        req_intf int;
        strf int;
        aglf int;
        intelf int;
        costume_idf int;
    BEGIN
        SELECT req_str, req_agl, req_int INTO req_strf, req_aglf, req_intf
            FROM occupations WHERE name = NEW.occupation;
        SELECT costume_id INTO costume_idf FROM worms
            WHERE id = NEW.worm_id;
        SELECT str, agl, int INTO strf, aglf, intelf
            FROM costumes WHERE id = costume_idf;
        IF (strf < req_strf) OR (aglf < req_aglf) OR (intelf < req_intf) THEN
            RAISE EXCEPTION 'Worm % does not have required stats for ocuppation %', NEW.worm_id, NEW.occupation;
        END IF;
        RETURN NEW;
    END;
$$;

alter function check_worm_stats() owner to s265098;

