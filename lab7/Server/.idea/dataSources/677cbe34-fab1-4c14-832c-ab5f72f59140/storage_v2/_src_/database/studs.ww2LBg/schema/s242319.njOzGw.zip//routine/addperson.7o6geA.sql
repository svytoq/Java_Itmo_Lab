create function addperson(text, character, date, money) returns void
    language plpgsql
as
$$
DECLARE
ФИО alias for $1; 
ПОЛ alias for $2; 
ГОД_РОЖДЕНИЯ alias for $3;
БЮДЖЕТ alias for $4;
out_p integer;
BEGIN
INSERT INTO ВЛАДЕЛЕЦ (ФИО, ПОЛ, ГОД_РОЖДЕНИЯ, БЮДЖЕТ, СПОРТИВНЫЙ_РАЗРЯД, КОЛИЧЕСТВО_ОЧКОВ) VALUES (
ФИО, ПОЛ, ГОД_РОЖДЕНИЯ, БЮДЖЕТ, 0, 0);
out_p = currval('ВЛАДЕЛЕЦ_ИД_seq'); 
INSERT INTO ГАРАЖ (ИД_ВЛАДЕЛЬЦА) VALUES (out_p);
END;
$$;

alter function addperson(text, char, date, money) owner to s242319;

