create function copycoffee(coffee integer, author integer) returns integer
    strict
    language plpgsql
as
$$
DECLARE
newCoffeeId int;
BEGIN
    INSERT INTO товар(название, стоимость, фото) SELECT название, стоимость, фото FROM товар WHERE id = coffee RETURNING id INTO newCoffeeId;
    INSERT INTO кофе(id, id_товара, тип, id_автора, состояние) VALUES (newCoffeeId, newCoffeeId, 'u', author, 'e');
	INSERT INTO компонент_кофе(id_кофе, id_ингредиента, количество, порядок_добавления) SELECT newCoffeeId, id_ингредиента, количество, порядок_добавления FROM компонент_кофе WHERE id_кофе = coffee;
	RETURN newCoffeeId;
END;
$$;

alter function copycoffee(integer, integer) owner to s265082;

