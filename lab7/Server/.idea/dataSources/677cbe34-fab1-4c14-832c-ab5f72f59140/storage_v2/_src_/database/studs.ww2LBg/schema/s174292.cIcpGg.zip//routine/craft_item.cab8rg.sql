create function craft_item(witcher_id integer, receipt_id integer) returns void
    language plpgsql
as
$$
declare
    t_curs scroll cursor for select *
                             from s174292.receipt_items
                             where s174292.receipt_items.receipt_id = s174292.craft_item.receipt_id;
    t_row integer;
    item  integer;
begin
    if ((select exists(select * from s174292.witcher where s174292.witcher.id = witcher_id)) = TRUE
        and (select exists(select * from s174292.receipt where s174292.receipt.id = receipt_id)) = TRUE) then
        select s174292.receipt.item_id into item from s174292.receipt where s174292.receipt.id = receipt_id;
        for t_row in t_curs
            Loop
                if ((select exists(select *
                                   from s174292.witcher_inventory
                                   where s174292.witcher_inventory.witcher_id = s174292.craft_item.witcher_id
                                     and s174292.witcher_inventory.item_id = t_row.item_id)) = TRUE) then
                    if ((select s174292.witcher_inventory.count
                         from s174292.witcher_inventory
                         where s174292.witcher_inventory.witcher_id = s174292.craft_item.witcher_id
                           and s174292.witcher_inventory.item_id = t_row.item_id) < t_row.count) then
                        raise NOTICE 'not enough items';
                    end if;
                else
                    raise NOTICE 'Not found item in inventory';
                end if;
            end loop;
        for t_row in t_curs
            Loop
                if ((select s174292.witcher_inventory.count
                     from s174292.witcher_inventory
                     where s174292.witcher_inventory.witcher_id = s174292.craft_item.witcher_id
                       and s174292.witcher_inventory.item_id = t_row.item_id) >
                    t_row.count) then
                    update s174292.witcher_inventory
                    set count=count - t_row.count
                    where s174292.witcher_inventory.witcher_id = s174292.craft_item.witcher_id
                      and s174292.witcher_inventory.item_id = t_row.item_id;
                else
                    delete
                    from s174292.witcher_inventory
                    where s174292.witcher_inventory.witcher_id = s174292.craft_item.witcher_id
                      and s174292.witcher_inventory.item_id = t_row.item_id;
                end if;
            end loop;

        if ((select exists(select *
                           from s174292.witcher_inventory
                           where s174292.witcher_inventory.witcher_id = s174292.craft_item.witcher_id
                             and s174292.witcher_inventory.item_id = item)) = TRUE) then
            update s174292.witcher_inventory
            set count=count + 1
            where s174292.witcher_inventory.witcher_id = s174292.craft_item.witcher_id
              and s174292.witcher_inventory.item_id = item;
        else
            insert into s174292.witcher_inventory(witcher_id, item_id, count)
            values (s174292.craft_item.witcher_id, item, 1);
        end if;
    else
        raise NOTICE 'Not found witcher_id';
    end if;
end;
$$;

alter function craft_item(integer, integer) owner to s174292;

