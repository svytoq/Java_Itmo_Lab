create function create_new_factory_listing_for_clan(clanid integer, factoryid integer, currencyid integer, factoryprice integer, listingdescription character varying) returns void
    language plpgsql
as
$$
declare factoryAmount int;
begin
    factoryAmount = (select count(*) from factory_owner where clan_id = clanId and factory_id = factoryId);
    if (factoryAmount is null or factoryAmount <= 0) then
        return;
    end if;
    with insertListing as (
        insert into listing (seller, clan_id, description) values ('Clan', clanId, listingDescription)
            returning listing_id as listingId
    )
    insert
    into factory_listing (listing_id, factory_id, currency_id, price)
    values ((select listingId from insertListing), factoryId, currencyId, factoryPrice);
end;
$$;

alter function create_new_factory_listing_for_clan(integer, integer, integer, integer, varchar) owner to s263063;

