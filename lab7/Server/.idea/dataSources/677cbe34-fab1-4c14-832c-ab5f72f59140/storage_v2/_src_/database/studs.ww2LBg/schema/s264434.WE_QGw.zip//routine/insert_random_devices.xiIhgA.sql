create function insert_random_devices() returns void
    language plpgsql
as
$$
BEGIN
    FOR i IN 1..1000 LOOP
            perform insert_random_device_and_detectors();
        END LOOP;
END;
$$;

alter function insert_random_devices() owner to s264434;

