create function f1() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE БЛАГОРОДНЫЙ_ДОМ SET ДОМ_КОЛИЧЕСТВО_ТИТАНОВ = ДОМ_КОЛИЧЕСТВО_ТИТАНОВ+1
WHERE ДОМ_ИД = NEW.ТИТАН_БЛАГОРОДНЫЙ_ДОМ;
RETURN NEW;
END;
$$;

alter function f1() owner to s242534;

