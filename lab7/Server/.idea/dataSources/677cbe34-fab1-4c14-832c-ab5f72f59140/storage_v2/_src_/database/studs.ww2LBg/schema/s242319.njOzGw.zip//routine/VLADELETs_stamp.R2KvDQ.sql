create function "ВЛАДЕЛЕЦ_stamp"() returns trigger
    language plpgsql
as
$$
BEGIN 
    IF NEW.ИД IS NULL THEN
            RAISE EXCEPTION 'ИД cannot be null';
        END IF;
   IF NEW.ФИО IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ПОЛ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ГОД_РОЖДЕНИЯ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.БЮДЖЕТ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.СПОРТИВНЫЙ_РАЗРЯД IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.КОЛИЧЕСТВО_ОЧКОВ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF (NEW.mail IS NULL) OR (NEW.mail !~* '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+[.][A-Za-z]+$') THEN
            RAISE EXCEPTION '% cannot be this format of EMAIL', NEW.ИД;
        END IF;
IF NEW.pasword IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
RETURN NEW;
  END;
$$;

alter function "ВЛАДЕЛЕЦ_stamp"() owner to s242319;

