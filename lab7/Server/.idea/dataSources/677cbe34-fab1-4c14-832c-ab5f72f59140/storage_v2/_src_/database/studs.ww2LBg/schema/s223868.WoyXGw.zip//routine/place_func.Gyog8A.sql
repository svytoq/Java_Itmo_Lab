create function place_func() returns trigger
    language plpgsql
as
$$
BEGIN
		IF (NEW.Занятое_место > (SELECT count(*) FROM Человек)) THEN
			RAISE EXCEPTION 'Ошибка. Проверьте правильность занятого участником места.';
		END IF;
	RETURN NEW;
	END;
$$;

alter function place_func() owner to s223868;

