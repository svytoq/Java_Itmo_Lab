create function gettreatmentcost(smoker integer) returns integer
    language plpgsql
as
$$
declare
        sum integer;
        doctorCost integer;
    begin
        select sum(cost) into sum from punishment P where P.smokerid = smoker;
        select cost into doctorCost from doctor D inner join
                         (SELECT doctorId from smoker S where S.id = smoker) DC on D.id = DC.doctorid;
        return sum + doctorCost;
    end;
$$;

alter function gettreatmentcost(integer) owner to s207704;

