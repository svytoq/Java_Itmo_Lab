create function data_checking() returns trigger
    language plpgsql
as
$$
DECLARE
ДАТА_ТЕМЫ TIMESTAMP;

ДАТА_ПАРАГРАФА TIMESTAMP;
BEGIN
ДАТА_ТЕМЫ:=(SELECT ДАТА_СОЗДАНИЯ FROM БАНК_ТЕМА WHERE (БАНК_ТЕМА.ИД_ТЕМ = NEW.ИД_ТЕМ));
ДАТА_ПАРАГРАФА:=(SELECT ДАТА_СОЗДАНИЯ FROM БАНК_ПАРАГРАФ WHERE (БАНК_ПАРАГРАФ.ИД_ПАРАГРАФ = NEW.ИД_ПАРАГРАФ));
IF ДАТА_ТЕМЫ < ДАТА_ПАРАГРАФА THEN
RAISE EXCEPTION 'Параграф не может быть создан раньше темы.';
END IF;
RETURN NEW;
END;
$$;

alter function data_checking() owner to s244705;

