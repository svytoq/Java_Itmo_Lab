create function gettimeclaimed() returns trigger
    language plpgsql
as
$$
begin
new.ДАТА_РАССМОТРЕНИЯ := current_timestamp;
return new;
end;
$$;

alter function gettimeclaimed() owner to s242274;

