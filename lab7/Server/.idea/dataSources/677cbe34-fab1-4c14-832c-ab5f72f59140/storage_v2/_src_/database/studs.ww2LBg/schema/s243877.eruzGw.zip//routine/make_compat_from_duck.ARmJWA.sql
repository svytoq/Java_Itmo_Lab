create function make_compat_from_duck() returns trigger
    language plpgsql
as
$$
declare
RFS feature_set%rowtype;
begin
select * into RFS from feature_set where (feature_set.id = new.feature_set_id);
create temp table requestFS(
request_id int,
ID serial,
BIRTHDAY date,
GENDER gender,
COLOUR int[3],
SHADE text,
SHAPE text,
SIZE size,
WEIGHT real,
SWIMMING_SKILL int,
MODEL varchar(30),
PRODUCER varchar(30),
BEAK_ID int,
ACCESSABILITY boolean,
CHARACTER character,
STYLE varchar(20),
ACCESSORIES text);
insert into requestFS
select request.id as request_id, feature_set.*
from request
join feature_set on (request.requested_feature_set_id = feature_set.id);
insert into compatibility
select NEW.id, request_id
from requestfs
where ((requestfs.birthday = rfs.birthday)or(rfs.birthday isnull))and
((requestfs.gender = rfs.gender)or(rfs.gender isnull))and
((requestfs.colour = rfs.colour)or(rfs.colour isnull))and
((requestfs.size = rfs.size)or(rfs.size isnull))and
((requestfs.weight = rfs.weight)or(rfs.weight isnull))and
((requestfs.swimming_skill = rfs.swimming_skill)or(rfs.swimming_skill isnull))and
((requestfs.model = rfs.model)or(rfs.model isnull))and
((requestfs.producer = rfs.producer)or(rfs.producer isnull))and
((requestfs.beak_id = rfs.beak_id)or(rfs.beak_id isnull))and
((requestfs.character = rfs.character)or(rfs.character isnull))and
((requestfs.style = rfs.style)or(rfs.style isnull));
drop table requestFS;
return NEW;
end
$$;

alter function make_compat_from_duck() owner to s243877;

