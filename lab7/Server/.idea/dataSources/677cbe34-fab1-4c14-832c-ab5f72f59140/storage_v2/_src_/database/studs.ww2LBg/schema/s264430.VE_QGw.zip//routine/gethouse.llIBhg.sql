create function gethouse(name text) returns text
    language sql
as
$$
select НАЗВАНИЕ_ДОМА from ЛИДЕР inner join АРМИЯ on ЛИДЕР.ИМЯ = $1
$$;

alter function gethouse(text) owner to s264430;

