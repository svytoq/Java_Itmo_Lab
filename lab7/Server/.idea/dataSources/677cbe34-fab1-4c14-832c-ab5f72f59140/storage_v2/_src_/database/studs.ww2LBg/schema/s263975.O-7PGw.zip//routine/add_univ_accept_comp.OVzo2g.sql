create function add_univ_accept_comp(uid bigint, comid bigint, p double precision) returns bigint
    language plpgsql
as
$$
begin
    insert into university_acceptable_competitions values (uId, comId, p);
return uId;
end;
$$;

alter function add_univ_accept_comp(bigint, bigint, double precision) owner to s263975;

