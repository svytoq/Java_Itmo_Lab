create function find_transport_with_stress_level_less_than(stress_level_arg integer)
    returns TABLE(id integer, additional_price numeric, additional_stress integer, name character varying, speed integer, transport_type_id integer)
    language plpgsql
as
$$
begin
    RETURN QUERY select transport.id,
                        transport.additional_price,
                        transport.additional_stress,
                        transport.name,
                        transport.speed,
                        transport.transport_type_id
                 from transport
                          join transport_type t
                               on t.id = transport.transport_type_id
                 where transport.additional_stress + t.stress < stress_level_arg;
end;
$$;

alter function find_transport_with_stress_level_less_than(integer) owner to s264465;

