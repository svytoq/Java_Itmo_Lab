create function msgexchangescheck() returns trigger
    language plpgsql
as
$$
declare
    hour double precision;
    minutes double precision;
    m_state msg_states;
    time_ok bool;
begin
    if NEW.room < 1 or NEW.room > 10 then return NULL; end if;
    select date_trunc('minute', NEW.exc_time) into NEW.exc_time; 

    select check_time(NEW.exc_time) into time_ok;
    if not time_ok then return NULL; end if;

    select msg_state into m_state from Messages where msg_id = NEW.out_msg;

    if NEW.msg_ex_state = 'scheduled' and NEW.out_msg is not NULL and m_state != 'planned'
    then return NULL; end if;

    if NEW.msg_ex_state = 'ok' and 
    (NEW.out_msg is NULL and NEW.in_msg is NULL)
    then return NULL; end if;

    if exists(select 1 from Msg_exchanges where
        room=NEW.room and exc_time=NEW.exc_time and msg_exc_id!=NEW.msg_exc_id)
    then return NULL; end if;

    if exists(select 1 from Msg_exchanges where
        employee_id=NEW.employee_id and exc_time=NEW.exc_time and msg_exc_id!=NEW.msg_exc_id)
    then return NULL; end if;

    return NEW;
end;
$$;

alter function msgexchangescheck() owner to s265066;

