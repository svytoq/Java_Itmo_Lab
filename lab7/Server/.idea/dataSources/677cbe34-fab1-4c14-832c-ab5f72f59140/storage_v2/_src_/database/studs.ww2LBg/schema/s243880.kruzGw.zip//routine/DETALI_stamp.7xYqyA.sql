create function "ДЕТАЛИ_stamp"() returns trigger
    language plpgsql
as
$$
BEGIN 
    IF NEW.ИД IS NULL THEN
            RAISE EXCEPTION 'ИД cannot be null';
        END IF;
    IF (NEW.ТИП IN (SELECT НАЗВАНИЕ FROM ТИП_ДЕТАЛИ)) = FALSE THEN 
RAISE EXCEPTION '% cannot have THIS TYPE', NEW.ИД;
        END IF;
IF NEW.ВЕС IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ВЛИЯНИЕ_НА_СКОРОСТЬ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ВЛИЯНИЕ_НА_УПРАВЛЯЕМОСТЬ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ВЛИЯНИЕ_НА_УСКОРЕНИЕ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
RETURN NEW;
  END;
$$;

alter function "ДЕТАЛИ_stamp"() owner to s243880;

