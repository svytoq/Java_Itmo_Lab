create function _trigger_check_tea_cupboard_capacity() returns trigger
    language plpgsql
as
$$
declare
    sum real := 0;
    cupboard_amount real := 0;
    repeated_id integer := null;
    repeated_amount real := null;
begin
    select sum(amount) from cupboard_item where cupboard_id = new.cupboard_id into sum;
    select capacity from tea_cupboard where id = new.cupboard_id into cupboard_amount;
    if sum + new.amount >= cupboard_amount then
        return NULL;
    end if;
    select product_id from cupboard_item
    where product_id = new.product_id and cupboard_id = new.cupboard_id into repeated_id;
    if repeated_id is not null then
        select amount from cupboard_item
    where product_id = new.product_id and cupboard_id = new.cupboard_id into repeated_amount;
        delete from cupboard_item where product_id = new.product_id and cupboard_id = new.cupboard_id;
        new.amount := new.amount + repeated_amount;
    end if;

    return new;
end;
$$;

alter function _trigger_check_tea_cupboard_capacity() owner to s264429;

