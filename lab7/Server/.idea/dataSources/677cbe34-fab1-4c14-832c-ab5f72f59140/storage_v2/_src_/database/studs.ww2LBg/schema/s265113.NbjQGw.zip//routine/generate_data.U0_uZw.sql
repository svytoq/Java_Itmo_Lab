create function generate_data() returns void
    language plpgsql
as
$$
BEGIN
    FOR counter IN 1..100
        LOOP
            INSERT INTO person (name, station, on_station) VALUES ('Test Person', 1, true);
            INSERT INTO snowmobile (speed, fuel_consumption, fuel_tank_capacity, station, on_station)  VALUES (10, 10, 10, 1, true);
        END LOOP;
    FOR counter IN 1..3000
        LOOP
            INSERT INTO person (name, station, on_station) VALUES ('Test Person', 1, false);
            INSERT INTO snowmobile (speed, fuel_consumption, fuel_tank_capacity, station, on_station)  VALUES (10, 10, 10, 1, false);
        END LOOP;
END;
$$;

alter function generate_data() owner to s265113;

