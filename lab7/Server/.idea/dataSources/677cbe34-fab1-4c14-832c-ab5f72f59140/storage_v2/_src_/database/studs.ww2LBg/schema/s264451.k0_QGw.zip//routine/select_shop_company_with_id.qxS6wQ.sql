create function select_shop_company_with_id()
    returns TABLE(shop_company_name character varying)
    language plpgsql
as
$$
begin
    return query select * from shop_company;
end;
$$;

alter function select_shop_company_with_id() owner to s264451;

