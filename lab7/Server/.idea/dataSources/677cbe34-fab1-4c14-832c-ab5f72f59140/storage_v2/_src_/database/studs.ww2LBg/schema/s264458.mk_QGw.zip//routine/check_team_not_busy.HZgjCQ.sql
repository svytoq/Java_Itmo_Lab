create function check_team_not_busy(team_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    IF EXISTS(SELECT project_id
              FROM team_project
                       INNER JOIN project ON project_id = project.id
              WHERE team_id = check_team_not_busy.team_id
                AND date_end IS NULL) THEN
        RAISE EXCEPTION 'team did not finish previous project';
    END IF;
    RETURN TRUE;
END;
$$;

alter function check_team_not_busy(integer) owner to s264458;

