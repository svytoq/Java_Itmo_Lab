create function calculatevotes(idvote integer) returns text
    language plpgsql
as
$$
declare
    yesCnt int;
    noCnt int;
begin
    select count(*) from participating where id_vote = idVote and user_status = 'За' into yesCnt;
    select count(*) from participating where id_vote = idVote and user_status = 'Против' into noCnt;
    return 'Результаты: За - ' || yesCnt || ', Против - ' || noCnt;
end;
$$;

alter function calculatevotes(integer) owner to s264912;

