create function get_stages(mult_name text)
    returns TABLE("id_ЭТАПА" integer, "id_СЛЕД_ЭТАПА" integer, "ИМЯ_ЭТАПА" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY WITH RECURSIVE r AS (
  SELECT "ИД_ЭТАПА","ИД_СЛЕД_ЭТАПА","НАЗВАНИЕ_ЭТАПА", 5 AS Порядок
        from  МУЛЬТФИЛЬМ join "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА" using (ИД_МУЛЬТФИЛЬМА)
              WHERE НАЗВАНИЕ_МУЛЬТФИЛЬМА=mult_name AND "ИД_СЛЕД_ЭТАПА" IS NULL

    UNION ALL

    -- рекурсивная часть
    SELECT
         "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА"."ИД_ЭТАПА","ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА"."ИД_СЛЕД_ЭТАПА","ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА"."НАЗВАНИЕ_ЭТАПА", r.Порядок - 1 AS Порядок
   FROM "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА"
      JOIN r
          ON "ЭТАПЫ_СОЗДАНИЯ_МУЛЬТФИЛЬМА"."ИД_СЛЕД_ЭТАПА" = r."ИД_ЭТАПА"
)
SELECT "ИД_ЭТАПА", "ИД_СЛЕД_ЭТАПА", "НАЗВАНИЕ_ЭТАПА" FROM r order by Порядок;
END;
$$;

alter function get_stages(text) owner to s243839;

