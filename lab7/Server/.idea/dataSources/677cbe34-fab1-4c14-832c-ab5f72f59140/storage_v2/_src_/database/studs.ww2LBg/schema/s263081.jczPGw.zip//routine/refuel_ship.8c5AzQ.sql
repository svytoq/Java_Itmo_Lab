create function refuel_ship(ship integer, litres integer) returns text
    language plpgsql
as
$$
DECLARE
    planet_yard_id int;
  BEGIN
    IF litres <=0 THEN
      RAISE EXCEPTION 'Invalid litres number';
    END IF;
    
    SELECT p.yard_id INTO planet_yard_id FROM Planet as p 
    INNER JOIN Space_ship as ss ON (ss.planet_id = p.id) 
    WHERE ss.id = ship;
    
    INSERT INTO Refueling (ship_id, yard_id, litres_num) VALUES (ship, planet_yard_id, litres);
    
    RETURN 'Success, check your ship fuel level';
  END;
$$;

alter function refuel_ship(integer, integer) owner to s263081;

