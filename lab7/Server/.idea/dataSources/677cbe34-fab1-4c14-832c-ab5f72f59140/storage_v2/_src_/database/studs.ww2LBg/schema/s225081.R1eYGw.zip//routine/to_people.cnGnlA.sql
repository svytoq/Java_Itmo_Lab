create function to_people(count integer, start integer) returns void
    language plpgsql
as
$$
DECLARE
  nam   VARCHAR(25);
  sirname VARCHAR(25);
  pol     VARCHAR(3);
  pos     SOSL;
  J       INT;
  MALE    INT;
  FEM INT;
  SIRNAMEid INT;
  ref int;
BEGIN
  FEM =0;
  MALE=0;
  SIRNAMEid =0;
  ref =1;
  FOR J IN 1..COUNT LOOP
    SELECT ID FROM russian_surnames WHERE ID>SIRNAMEid INTO SIRNAMEid;
    IF SIRNAMEid ISNULL THEN SIRNAMEid =2; END IF ;
        SELECT surname FROM russian_surnames WHERE ID=SIRNAMEid INTO sirname;
    IF sirname LIKE '%а' OR sirname LIKE '%А' then
   SELECT ID FROM russian_names WHERE ID>FEM and sex='Ж' INTO FEM;
    IF FEM ISNULL THEN FEM =24961; END IF ;
        SELECT name FROM russian_names WHERE ID=FEM and sex = 'Ж' INTO nam;
      pol ='жен';
      ELSE
      SELECT ID FROM russian_names WHERE ID>MALE and sex='М' INTO MALE;
    IF MALE ISNULL THEN MALE =43888; END IF ;
        SELECT name FROM russian_names WHERE ID=MALE and sex='М' INTO nam;
     pol ='муж';

END IF ;
    IF J % 3 = 0
    THEN
      POS = 'РЕМЕСЛЕННИК';
    ELSEIF J % 5 = 0
      THEN
        SELECT ID_МЕСТО from МЕСТОПОЛОЖЕНИЕ where ID_МЕСТО>ref into ref;
        POS = 'ТОРГОВЕЦ';
    ELSEIF J % 23 = 0
      THEN
        POS = 'ПАТРИЦИЙ';
    ELSE POS = 'КРЕСТЬЯНИН';
    END IF;

    INSERT INTO ЛЮДИ VALUES (DEFAULT, nam, sirname, pos, ref, pol);
  END LOOP;
END;
$$;

alter function to_people(integer, integer) owner to s225081;

