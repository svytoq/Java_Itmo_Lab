create function weight() returns trigger
    language plpgsql
as
$$
DECLARE
   _character_weight integer;
   _max_weight integer;
BEGIN
SELECT sum(Вес) INTO _character_weight FROM "К_Предметы" WHERE ИД IN (SELECT Предмет_ИД FROM "К_Инвентарь" WHERE Персонаж_ИД = NEW.Персонаж_ИД);
SELECT Максимальный_Вес INTO _max_weight FROM "К_Персонажи" WHERE Id = NEW.Персонаж_ИД;
IF (_character_weight + NEW.Вес > _max_weight) THEN
RETURN NULL;
END IF;
RETURN NEW;
END;
$$;

alter function weight() owner to s243870;

