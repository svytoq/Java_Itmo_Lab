create function add_kira_in_tied() returns trigger
    language plpgsql
as
$$
declare status_of_kira_id integer;
declare god_count_id integer;
declare person_kira_id integer;
begin
  if (tg_op = 'INSERT') then
    select into god_count_id count(*) from god_of_death where god_of_death.killer_id = new.killer_id;
    if(god_count_id !=0) then
      raise exception 'No man can be god';
    end if;
    select into status_of_kira_id status_id from note_killer where id = new.killer_id;
    if (status_of_kira_id !=2) then
        select into person_kira_id person_id from note_killer where id = new.killer_id;
        insert into man_who_tied values (person_kira_id,status_of_kira_id);
        return new;
      else if (status_of_kira_id =2) then
        new.have_gods_eyes = 'n';
        return new;
      end if;
    end if;
    return new;
  end if ;
  if (tg_op = 'DELETE') then
    raise exception 'You can not delete killer';
    return old;
  end if;
  if (tg_op = 'UPDATE') then
    if (old.killer_id != new.killer_id) then
      raise exception 'You can not change killer id';
      return old;
    else return new;
    end if;
  end if;
  return null;
end;
$$;

alter function add_kira_in_tied() owner to s249007;

