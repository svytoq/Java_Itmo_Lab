create function showaliveforclan(clan text)
    returns TABLE(id integer, name text)
    language sql
as
$$
SELECT
  id,
  Имя
FROM Самурай
WHERE Название_клана = clan AND Самурай.Жив = TRUE;
$$;

alter function showaliveforclan(text) owner to s223412;

