create function set_team_on_start() returns trigger
    language plpgsql
as
$$
DECLARE
busy_team boolean = FALSE;
max_p integer = 0;
current_p integer = 0;
BEGIN
SELECT in_race INTO busy_team FROM teams WHERE team_id = NEW.team_id;
SELECT max_participants INTO max_p FROM races WHERE race_id = NEW.race_id;
SELECT current_participants INTO current_p FROM races WHERE race_id = NEW.race_id;
IF ( current_p >= max_p ) THEN
RAISE EXCEPTION 'В этой гонке уже максимальное количество команд';
END IF;
IF (  busy_team = TRUE ) THEN
RAISE EXCEPTION 'Команда уже в гонке';
END IF;
UPDATE race_team SET x_coordinate = x_start_coordinate, y_coordinate = y_start_coordinate, z_coordinate = z_start_coordinate, active = TRUE, finished = FALSE FROM tracks WHERE tracks.track_id IN ( SELECT races.track_id FROM races WHERE races.race_id = NEW.race_id) AND team_id = NEW.team_id;
UPDATE teams SET in_race = TRUE WHERE teams.team_id = NEW.team_id; 
UPDATE races SET current_participants = ( current_p + 1 ) WHERE races.race_id = NEW.race_id; 
RETURN NEW;
END;
$$;

alter function set_team_on_start() owner to s265078;

