create function insert_property() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
    hum integer;
    clan integer;
  BEGIN
    LOOP
      IF random()>0.5
        THEN hum = null;
        ELSE hum = trunc(random()*10000)+1;
      END IF;
      IF random()>0.5
        THEN clan = null;
        ELSE clan = trunc(random()*20)+1;
      END IF;
      INSERT INTO property VALUES (DEFAULT, insert_random(),clan, hum);
      count = count + 1;
      EXIT WHEN count = 2000;
    END LOOP;
  END;
$$;

alter function insert_property() owner to s225107;

