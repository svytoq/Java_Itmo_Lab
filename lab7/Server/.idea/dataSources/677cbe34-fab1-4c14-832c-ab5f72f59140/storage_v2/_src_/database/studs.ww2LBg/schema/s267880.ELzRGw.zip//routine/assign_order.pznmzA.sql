create function assign_order(product_order_id integer, worker_id integer, deadline date) returns void
    language sql
as
$$
insert into product_making (product_order_id, worker_id, deadline, is_finished)
    values ($1, $2, $3, false);
$$;

alter function assign_order(integer, integer, date) owner to s267880;

