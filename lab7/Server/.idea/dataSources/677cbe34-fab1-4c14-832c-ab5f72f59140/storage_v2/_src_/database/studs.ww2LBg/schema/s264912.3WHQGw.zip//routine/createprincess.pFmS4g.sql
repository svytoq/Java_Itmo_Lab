create function createprincess(charactername text, psobrequet text, pbeuty integer, pmind integer) returns text
    language plpgsql
as
$$
declare
    id_ch int;
begin
    insert into character(name) values (characterName) returning id_character into id_ch;
    insert into princess(id_character, sobriquet, beauty_level, mind_level) values (id_ch, pSobrequet, pBeuty, pMind);
    return 'Принцесса создана! id - ' || id_ch;
end;
$$;

alter function createprincess(text, text, integer, integer) owner to s264912;

