create function correction_data_game() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.status<>4 then
        IF NEW.profit IS not NULL then
            RAISE EXCEPTION 'Invalid record' ;
        end if;
        IF NEW.number  IS not  NULL then
            RAISE EXCEPTION 'Invalid record' ;
        end if;
        IF NEW.endtime IS not  NULL then
            RAISE EXCEPTION 'Invalid record' ;
        end if;
    end if;
    RETURN NEW;
END;
$$;

alter function correction_data_game() owner to s264431;

