create function get_object_suggestions_in_dormitory(dormitory_id integer)
    returns TABLE(suggestion_id integer, suggestion_name character varying, suggestion_description character varying, status s265090."STATUS", creation_date timestamp with time zone, author integer, object_id integer, object_name character varying, object_description character varying, object_state s265090."OBJECT_STATE")
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT 
    SUGGESTION.ID as SUGGESTION_ID, SUGGESTION.NAME as SUGGESTION_NAME, SUGGESTION.DESCRIPTION as SUGGESTION_DESCRIPTION, SUGGESTION.STATUS, SUGGESTION.CREATION_DATE, 
SUGGESTION.AUTHOR, OBJECT.ID as OBJECT_ID, OBJECT.NAME as OBJECT_NAME, OBJECT.DESCRIPTION as OBJECT_DESCRIPTION, OBJECT.OBJECT_STATE as OBJECT_STATE
    FROM "USER"
JOIN DORMITORY ON "USER".DORMITORY = DORMITORY.ID
JOIN SUGGESTION ON SUGGESTION.AUTHOR = "USER".ID
JOIN OBJECT_SUGGESTION ON OBJECT_SUGGESTION.SUGGESTION = SUGGESTION.ID
JOIN OBJECT ON OBJECT_SUGGESTION.OBJECT = OBJECT.ID WHERE DORMITORY.ID = DORMITORY_ID;
END;
$$;

alter function get_object_suggestions_in_dormitory(integer) owner to s265090;

