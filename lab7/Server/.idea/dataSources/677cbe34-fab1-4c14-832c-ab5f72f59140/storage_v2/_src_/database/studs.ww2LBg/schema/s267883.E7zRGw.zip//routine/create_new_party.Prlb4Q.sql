create function create_new_party(creatorid integer, partyname text) returns void
    language plpgsql
as
$$
declare comradepartyId int;
begin
    comradepartyId = (select party_id from comrade where id = creatorId);
    if comradepartyId is null then
        with new_party as (
            insert into party (name) values (partyName)
                returning id as partyId
        )
        update comrade set party_id = (select partyId from new_party) where id = creatorId;
    else
        raise notice 'comrade already in party!';
    end if;
end;
$$;

alter function create_new_party(integer, text) owner to s267883;

