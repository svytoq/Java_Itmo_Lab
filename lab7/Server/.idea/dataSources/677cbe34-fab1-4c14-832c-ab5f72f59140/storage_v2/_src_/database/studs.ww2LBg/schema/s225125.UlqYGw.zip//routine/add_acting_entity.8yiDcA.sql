create function add_acting_entity() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO Действ_сущности (ИД, tblname) values (NEW.ИД, TG_TABLE_NAME);
  PERFORM * FROM Действ_сущности WHERE ИД = NEW.ИД;
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Что-то пошло не так';
  END IF;
  RETURN NEW;
END
$$;

alter function add_acting_entity() owner to s225125;

