create function sell_of_item_del() returns trigger
    language plpgsql
as
$$
declare
	price real;
	BEGIN
		IF (OLD.Статус = 'в инвентаре') THEN
			Select Цена into price from К_Предметы where Id = OLD.Предмет_ИД;
			UPDATE "К_Инвентарь" SET "Статус" = 'продан' WHERE
			"К_Инвентарь".Предмет_ИД = OLD.Предмет_ИД AND "К_Инвентарь".Персонаж_ИД = OLD.Персонаж_ИД;
		END IF;
		RETURN NULL;
		END;
$$;

alter function sell_of_item_del() owner to s242193;

