create function isreligionsame() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((SELECT БОГ.КОД_РЕЛИГИИ FROM БОГ WHERE БОГ.КОД_БОГА = NEW.КОД_БОГА)
= (SELECT БОГ.КОД_РЕЛИГИИ FROM БОГ WHERE БОГ.КОД_БОГА = NEW.КОД_БОГА_2))
THEN NEW.ОТНОШЕНИЕ = 'сотрудничество';
END IF;
RETURN NEW;
END
$$;

alter function isreligionsame() owner to s243854;

