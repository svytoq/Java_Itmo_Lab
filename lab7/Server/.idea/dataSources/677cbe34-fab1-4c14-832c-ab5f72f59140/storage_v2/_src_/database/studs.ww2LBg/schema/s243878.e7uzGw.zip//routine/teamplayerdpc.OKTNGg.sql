create function teamplayerdpc() returns trigger
    language plpgsql
as
$$
DECLARE
		totalpts integer;
	BEGIN
		SELECT dpc_points INTO totalpts FROM tournament WHERE id = NEW.tournament_id;
		UPDATE player SET dpc_points = dpc_points + totalpts * 0.5 WHERE team_id = NEW.first_id;
		UPDATE player SET dpc_points = dpc_points + totalpts * 0.3 WHERE team_id = NEW.second_id;
		UPDATE player SET dpc_points = dpc_points + totalpts * 0.15 WHERE team_id = NEW.third_id;
		UPDATE player SET dpc_points = dpc_points + totalpts * 0.05 WHERE team_id = NEW.fourth_id;

		UPDATE team SET dpc_points = (SELECT sum(dpc_points) FROM (SELECT dpc_points FROM player
			WHERE team_id = NEW.first_id ORDER BY dpc_points DESC LIMIT 3) AS subq) where id = NEW.first_id;
		UPDATE team SET dpc_points = (SELECT sum(dpc_points) FROM (SELECT dpc_points FROM player
			WHERE team_id = NEW.second_id ORDER BY dpc_points DESC LIMIT 3) AS subq) where id = NEW.second_id;
		UPDATE team SET dpc_points = (SELECT sum(dpc_points) FROM (SELECT dpc_points FROM player
			WHERE team_id = NEW.third_id ORDER BY dpc_points DESC LIMIT 3) AS subq) where id = NEW.third_id;
		UPDATE team SET dpc_points = (SELECT sum(dpc_points) FROM (SELECT dpc_points FROM player
			WHERE team_id = NEW.fourth_id ORDER BY dpc_points DESC LIMIT 3) AS subq) where id = NEW.fourth_id;

		RETURN NEW;
	END;
$$;

alter function teamplayerdpc() owner to s243878;

