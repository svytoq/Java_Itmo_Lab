create function check_examinator_death_and_enlistment() returns trigger
    language plpgsql
as
$$
DECLARE
    examinator_enlistment date;
    examinator_death date;
    BEGIN
    examinator_enlistment := (SELECT date_of_employment FROM employees WHERE id = NEW.examinator_id);
    examinator_death := (SELECT date_of_death FROM employees WHERE id = NEW.examinator_id);
    IF NEW.date > examinator_death THEN
      RAISE EXCEPTION 'Scientist is already dead by the time of the experiment.';
      ELSE IF NEW.date < examinator_enlistment THEN
        RAISE EXCEPTION 'Scientist has not been enlisted yet by the time of the experiment.';
      END IF;
    END IF;
    RETURN NEW;
  END;
$$;

alter function check_examinator_death_and_enlistment() owner to s243867;

