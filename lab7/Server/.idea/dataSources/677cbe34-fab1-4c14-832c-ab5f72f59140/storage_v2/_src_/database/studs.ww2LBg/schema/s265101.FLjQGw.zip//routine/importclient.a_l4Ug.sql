create function importclient("Клиент" text, "Пароль" text, "Электронная_почта" text, "Соль" text) returns void
    language plpgsql
as
$$
begin
  INSERT INTO clientpassword values (Клиент, Пароль, Электронная_почта, Соль);
end;
$$;

alter function importclient(text, text, text, text) owner to s265101;

