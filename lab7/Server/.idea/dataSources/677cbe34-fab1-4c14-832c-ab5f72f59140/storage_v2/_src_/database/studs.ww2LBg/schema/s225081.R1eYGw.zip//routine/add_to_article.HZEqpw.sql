create function add_to_article(n integer) returns void
    language plpgsql
as
$$
DECLARE
  NM VARCHAR ;
  AUTHOR INTEGER;
  BODY TEXT;
 DATE TIMESTAMP;
  I INTEGER;
BEGIN
  NM = 'ARTICLE';
 BODY = 'ABRACADABRA';

 FOR I IN 1..N LOOP
   SELECT NOW() INTO DATE;
   AUTHOR=18+I;
   INSERT INTO article VALUES (DEFAULT , BODY, NM, AUTHOR,DATE);
   NM=NM||I;
     BODY=BODY||I;

 END LOOP;
END;

$$;

alter function add_to_article(integer) owner to s225081;

