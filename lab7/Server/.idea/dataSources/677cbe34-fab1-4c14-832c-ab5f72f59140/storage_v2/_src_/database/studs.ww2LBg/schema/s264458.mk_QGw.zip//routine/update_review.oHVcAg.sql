create function update_review(review_id integer, stars integer, description text, time_value timestamp without time zone) returns void
    language plpgsql
as
$$
BEGIN

  IF NOT EXISTS(SELECT * FROM review WHERE id = update_review.review_id) THEN
    RAISE EXCEPTION 'Cannot find review for update';
  END IF;

  UPDATE review
  SET stars       = update_review.stars,
    description = update_review.description,
    time_value  = update_review.time_value
  WHERE review_id = update_review.review_id;

  RAISE NOTICE 'Отзыв обновлен';

END;

$$;

alter function update_review(integer, integer, text, timestamp) owner to s264458;

