create function random_between(low bigint, high bigint) returns bigint
    strict
    language plpgsql
as
$$
begin
  return floor(random()* (high-low + 1) + low);
end;
$$;

alter function random_between(bigint, bigint) owner to s264482;

