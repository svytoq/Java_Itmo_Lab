create function get_info(magician integer, creature integer) returns text
    language plpgsql
as
$$
DECLARE
    person int;
  BEGIN

    IF magician_exists(magician) AND creature_exists(creature) THEN
    
      SELECT p.id INTO person FROM Creatures c 
      INNER JOIN Locations l ON (l.id = c.location_id)
      INNER JOIN Regions r ON (r.id = l.nearest_region_id)
      INNER JOIN People p ON (p.region_id = r.id)
      WHERE c.id = creature AND c.hp_level != 0 AND p.id != magician LIMIT 1;
    
      IF NOT FOUND THEN
      RETURN 'Монстр мертв, либо информация недоступна';
      ELSE
      INSERT INTO Infos (person_id, magician_id, creature_id, info) 
      VALUES (person, magician, creature, 'Монстр еще жив, убейте его, пожалуйста');
      END IF;
    END IF;
    RETURN 'Монстр еще жив, убейте его, пожалуйста';
  END;
$$;

alter function get_info(integer, integer) owner to s265108;

