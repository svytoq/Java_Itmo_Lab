create function calc_financial(user_id integer, type s265099.finance_type_enum, from_date date DEFAULT NULL::date, to_date date DEFAULT NULL::date) returns real
    language plpgsql
as
$$
BEGIN

		IF (from_date IS null AND to_date IS null) THEN
			RETURN (SELECT sum(сумма) from финансы where id_пользователя = user_id AND тип = type);
		ELSIF (from_date IS null AND to_date IS NOT null) THEN
			RETURN (SELECT sum(сумма) from финансы where id_пользователя = user_id AND тип = type AND дата_совершения <= to_date);
		ELSIF (from_date IS NOT null AND to_date IS null) THEN
			RETURN (SELECT sum(сумма) from финансы where id_пользователя = user_id AND тип = type AND дата_совершения >= from_date);
		ELSE
			RETURN (SELECT sum(сумма) from финансы where id_пользователя = user_id AND тип = type AND дата_совершения >= from_date AND дата_совершения <= to_date);
		END IF;


	END
$$;

alter function calc_financial(integer, s265099.finance_type_enum, date, date) owner to s265099;

