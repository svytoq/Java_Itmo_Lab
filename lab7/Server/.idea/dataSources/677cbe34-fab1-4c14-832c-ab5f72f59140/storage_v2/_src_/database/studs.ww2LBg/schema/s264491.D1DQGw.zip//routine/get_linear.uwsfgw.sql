create function get_linear(action_type_id integer) returns s264491.lin_apply
    language plpgsql
as
$$
DECLARE
    res LIN_APPLY;
BEGIN
    SELECT L.worker_coeff, L.corp_coeff, L.worker_delta, L.corp_delta
    INTO res
    FROM ACTION_TYPE AT
             INNER JOIN LINEAR L on AT.linear_id = L.id
    WHERE AT.id = action_type_id;
    RETURN res;
END;
$$;

alter function get_linear(integer) owner to s264491;

