create function add_delivery_order(requester_address character varying, requester_assembly boolean, requester_delivery_time timestamp without time zone, main_order_id integer) returns integer
    language plpgsql
as
$$
DECLARE ord_id integer := nextval('delivery_order_id_seq');

    BEGIN
        INSERT INTO delivery_order
            (id, address, assembly_ordered, delivery_time, responsible_id, order_id) VALUES
            (
                ord_id,
                requester_address,
                requester_assembly,
                requester_delivery_time,
                find_delivery_responsible(),
                main_order_id
            );
        RETURN ord_id;
    END;
$$;

alter function add_delivery_order(varchar, boolean, timestamp, integer) owner to s265092;

