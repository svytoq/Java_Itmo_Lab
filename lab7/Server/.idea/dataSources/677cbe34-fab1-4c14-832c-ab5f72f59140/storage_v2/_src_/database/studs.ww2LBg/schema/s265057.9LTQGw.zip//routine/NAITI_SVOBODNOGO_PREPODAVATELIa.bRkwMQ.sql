create function "НАЙТИ_СВОБОДНОГО_ПРЕПОДАВАТЕЛЯ"(start_time timestamp without time zone, finish_time timestamp without time zone) returns SETOF s265057."ПРЕПОДАВАТЕЛЬ"
    language sql
as
$$
select * FROM ПРЕПОДАВАТЕЛЬ WHERE NOT EXISTS
(SELECT ЗАНЯТИЕ_ИД FROM ЗАНЯТИЕ WHERE (ЗАНЯТИЕ.ПРЕП_ИД=ПРЕПОДАВАТЕЛЬ.ПРЕП_ИД AND NOT(start_time>=ЗАНЯТИЕ.ВРЕМЯ_КОНЦА) AND NOT(finish_time<=ЗАНЯТИЕ.ВРЕМЯ_НАЧАЛА)))
AND NOT EXISTS
(SELECT ЭКЗАМЕН_ИД FROM ЭКЗАМЕН WHERE (ЭКЗАМЕН.ПРЕП_ИД=ПРЕПОДАВАТЕЛЬ.ПРЕП_ИД AND NOT(start_time>=ЭКЗАМЕН.ВРЕМЯ_КОНЦА) AND NOT(finish_time<=ЭКЗАМЕН.ВРЕМЯ_НАЧАЛА)))
$$;

alter function "НАЙТИ_СВОБОДНОГО_ПРЕПОДАВАТЕЛЯ"(timestamp, timestamp) owner to s265057;

