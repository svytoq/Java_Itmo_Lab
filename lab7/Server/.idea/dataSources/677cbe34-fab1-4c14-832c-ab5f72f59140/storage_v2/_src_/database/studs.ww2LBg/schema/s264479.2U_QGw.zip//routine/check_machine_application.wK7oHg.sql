create function check_machine_application() returns trigger
    language plpgsql
as
$$
begin
if new.machine_type is null then
raise exception 'machine_type cannot be null';
end if;
if new.army_id is null then
raise exception 'army_id cannot be null';
end if;
if (select (army.army_type = machine_type.application_area) 
	from machine_type, army
	where machine_type.id = new.machine_type and army.id = new.army_id
	limit 1) then
return new;
else
return null;
end if;
end;
$$;

alter function check_machine_application() owner to s264479;

