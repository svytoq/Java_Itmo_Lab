create function test_task() returns void
    language plpgsql
as
$$
declare
    res text ;
    res1 int;
    flag bool := true;
    user_id int;
begin
    select id from user_table limit 1 into user_id;
    raise notice 'Creating task priority';
    insert into task_priority values (111, 111, 'test');

    raise notice 'Creating task';
    insert into task values (111, NOW()::timestamp, 'desc', NOW()::timestamp, 'name', 'status', 'task_type', user_id, user_id, user_id, 111, user_id);

    raise notice 'Check that created';
    select name from task where id=111 into res;
    if res='name' then
        raise notice 'TASK CREATED OK';
    else
        raise notice 'NOT CREATED';
        flag := false;
    end if;
    begin     -- try
        raise notice 'Inserting with same ID';
    insert into task values (111, NOW()::timestamp, 'desc', NOW()::timestamp, 'name1', 'status', 'task_type', user_id, user_id, user_id, 111, user_id);
    flag := false;
    exception -- catch
        when sqlstate '23505' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Id should be unique';
    end ;
    begin     -- try
        raise notice 'Inserting with same name';
        insert into task values (1111, NOW()::timestamp, 'desc', NOW()::timestamp, 'name', 'status', 'task_type', user_id, user_id, user_id, 111, user_id);
        flag := false;
    exception -- catch
        when sqlstate '23505' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Name should be unique';
    end ;
    begin     -- try
        raise notice 'Inserting with not existing users';
        insert into task values (1111, NOW()::timestamp, 'desc', NOW()::timestamp, 'name1', 'status', 'task_type', 1111, 1111, 1111, 111, 1111);
        flag := false;
    exception -- catch
        when sqlstate '23503' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! User should exist';
    end ;
    begin     -- try
        raise notice 'Inserting with not existing task priority';
        insert into task values (1111, NOW()::timestamp, 'desc', NOW()::timestamp, 'name1', 'status', 'task_type', user_id, user_id, user_id, 1111, user_id);
        flag := false;
    exception -- catch
        when sqlstate '23503' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Task priority should exist';
    end ;
    begin     -- try
        raise notice 'Deleting task priority before task';
        delete from task_priority where id=111;
        flag := false;
    exception -- catch
        when sqlstate '23503' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Task related to priority still exists';
    end ;

    raise notice 'Deleting rows';
    delete from task where id=111;
    select count(*) from task where id=111 into res1;
    if res1=0 then
        raise notice 'TASK DELETED OK';
    else
        raise notice 'TASK NOT DELETED';
        flag := false;
    end if;
    delete from task_priority where id=111;
    select count(*) from task_priority where id=111 into res1;
    if res1=0 then
        raise notice 'TASK PRIORITY DELETED OK';
    else
        raise notice 'TASK PRIORITY NOT DELETED';
        flag := false;
    end if;

    raise notice 'Test accomplished: %', flag;
end;
$$;

alter function test_task() owner to s225102;

