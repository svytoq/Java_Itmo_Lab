create function del_character(n text, dob date) returns void
    language plpgsql
as
$$
BEGIN
    DELETE FROM characters WHERE (name, date_of_birth) = (n, dob);
END
$$;

alter function del_character(text, date) owner to s278172;

