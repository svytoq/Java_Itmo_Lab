create function croom() returns trigger
    language plpgsql
as
$$
begin
  update rooms SET number_of_prisoners = number_of_prisoners+1
  where id = new.room;
  return new;
end;
$$;

alter function croom() owner to s209617;

