create function spell_effects() returns trigger
    language plpgsql
as
$$
DECLARE
  is_dark boolean := 'FALSE';
  creature int;
  creature_hp int;
  magician_order int;
  spell_power int;
  spell_energy int;
  thing_power int;
  can_hit_hp int := 0;
BEGIN

-- сначала отлучаем от ордера, если было применено темное заклинание и колдун состоял в ордере
  SELECT CASE WHEN s.spell_type = 'd' THEN 'TRUE' ELSE 'FALSE' END INTO is_dark FROM Spells s
  WHERE s.id = NEW.spell_id;
  
  SELECT m.order_id INTO magician_order FROM Magicians m WHERE m.person_id = NEW.magician_id;
  
  IF is_dark = 'TRUE' AND magician_order != null THEN
    INSERT INTO Exiles (order_id, magician_id, date_exiled) 
    VALUES (magician_order, NEW.magician_id, CURRENT_DATE);
  END IF;
  
-- Отнимаем hp у существа
  SELECT h.creature_id, c.hp_level INTO creature, creature_hp
  FROM Huntings h JOIN Creatures c ON (c.id = h.creature_id)
  WHERE h.id = NEW.hunting_id;
  
  SELECT s.power, s.energy INTO spell_power, spell_energy FROM Spells s WHERE s.id = NEW.spell_id;
  
  SELECT mt.power INTO thing_power FROM Magicians m 
  INNER JOIN Magic_things mt ON (m.thing_id = mt.id)
  WHERE m.person_id = NEW.magician_id;
  
  IF creature_hp >= (spell_power + thing_power) THEN
    can_hit_hp = spell_power + thing_power;
  ELSE
    can_hit_hp = creature_hp;
  END IF;
  
  UPDATE Creatures SET hp_level = hp_level - can_hit_hp
  WHERE id = creature;
  
  IF creature_hp - can_hit_hp = 0 THEN
    UPDATE Huntings SET is_success = 'TRUE' WHERE id = NEW.hunting_id;
  END IF;

-- Отнимаем энергию у колдуна
  UPDATE Magicians SET energy = energy - spell_energy
  WHERE person_id = NEW.magician_id;
  
  RETURN NEW;
END;
$$;

alter function spell_effects() owner to s265108;

