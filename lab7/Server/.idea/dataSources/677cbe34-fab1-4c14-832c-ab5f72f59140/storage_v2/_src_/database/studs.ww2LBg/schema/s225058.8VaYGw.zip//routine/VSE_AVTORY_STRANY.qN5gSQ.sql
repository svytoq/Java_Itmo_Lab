create function "ВСЕ_АВТОРЫ_СТРАНЫ"(strana character varying)
    returns TABLE("ИМЯ" character varying, "ФАМИЛИЯ" character varying, "ОТЧЕСТВО" character varying, "ПОЛ" character varying, "ДАТА_РОЖДЕНИЯ" date, "ДАТА_СМЕРТИ" date)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT АВТОРЫ.ИМЯ, АВТОРЫ.ФАМИЛИЯ, АВТОРЫ.ОТЧЕСТВО, АВТОРЫ.ПОЛ, АВТОРЫ.ДАТА_РОЖДЕНИЯ, АВТОРЫ.ДАТА_СМЕРТИ 
FROM АВТОРЫ WHERE СТРАНА=strana;
END;
$$;

alter function "ВСЕ_АВТОРЫ_СТРАНЫ"(varchar) owner to s225058;

