create function get_producer_info(producer_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text, role s263229.producer_roles)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT p.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH, p.ROLE FROM producers AS p 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE p.WORKER_ID = producer_id;
END
$$;

alter function get_producer_info(integer) owner to s263229;

