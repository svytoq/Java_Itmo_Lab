create function onvoland() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((LOWER(NEW.ИМЯ) = 'Воланд-де-Морт') OR ((LOWER(NEW.ИМЯ) = 'Том') AND (LOWER(NEW.ФАМИЛИЯ) = 'Реддл')))
THEN
RAISE NOTICE 'То, чьё имя нельзя называть';
NEW.ИМЯ = '***';
NEW.ФАМИЛИЯ = '*****';
END IF;
RETURN NEW;
END;
$$;

alter function onvoland() owner to s225054;

