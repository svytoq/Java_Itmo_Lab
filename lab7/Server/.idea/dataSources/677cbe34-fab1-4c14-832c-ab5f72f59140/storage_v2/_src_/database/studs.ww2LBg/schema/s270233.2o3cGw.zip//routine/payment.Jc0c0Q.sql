create function payment() returns trigger
    language plpgsql
as
$$
DECLARE
    client_payment   integer;
    price            integer;
    factory          integer;
    provider_payment integer;
BEGIN
    SELECT client_id
    FROM clients_payments
    WHERE (client_id = NEW._from AND provider_id = NEW._to AND dept_time::date = current_date AND
           paying = FALSE)
    INTO client_payment;
    SELECT sausages.price FROM sausages WHERE (sausages.id = NEW.sausage_id) INTO price;
    IF (client_payment IS NOT NULL AND client_payment <> 0) THEN
        UPDATE clients_payments
        SET sum = sum + price * NEW.sausages_weight
        WHERE client_id = client_payment;
    ELSE
        INSERT INTO clients_payments(client_id, provider_id, sum, dept_time, paying, payment_date)
        VALUES (NEW._from, NEW._to, price * NEW.sausages_weight, current_date, FALSE, NULL);
    END IF;

    SELECT factory_id FROM providers WHERE providers.id = NEW._to INTO factory;
    SELECT provider_id
    FROM providers_payments
    WHERE (provider_id = NEW._to AND factory_id = factory AND dept_time = current_date AND paying = FALSE)
    INTO provider_payment;
    IF (provider_payment IS NOT NULL AND provider_payment <> 0) THEN
        UPDATE providers_payments
        SET sum = sum + price * NEW.sausages_weight
        WHERE provider_id = provider_payment;
    ELSE
        INSERT INTO providers_payments(provider_id, factory_id, sum, dept_time, paying, payment_date)
        VALUES (NEW._to, factory, price * NEW.sausages_weight, current_date, FALSE, NULL);
    END IF;
    RETURN NEW;
END
$$;

alter function payment() owner to s270233;

