create function add_insert_suitability() returns trigger
    language plpgsql
as
$$
declare
       id integer;
       sex text;
       r integer;
       sexuality integer;
      person_id integer;
      float_days integer;
   BEGIN
       id = NEW.person_id;
       sex = NEW.sex;
       if sex = 'male' then
           for person_id, sexuality in (select lodger.person_id, lodger.sexuality from lodger WHERE lodger.sex ilike 'female')
           loop
                   insert into suitability values (id, person_id, new.sexuality - sexuality,floor(0.05*power(new.sexuality - sexuality,2) + 2));
            end loop;
       elseif sex = 'female' then
           for person_id, sexuality in (select lodger.person_id, lodger.sexuality from lodger WHERE lodger.sex ilike 'male')
               loop
                   insert into suitability values (person_id, id, new.sexuality - sexuality,floor(0.05*power(new.sexuality - sexuality,2) + 2));
               end loop;
       end if;
       return NULL;
   end;
$$;

alter function add_insert_suitability() owner to s265492;

