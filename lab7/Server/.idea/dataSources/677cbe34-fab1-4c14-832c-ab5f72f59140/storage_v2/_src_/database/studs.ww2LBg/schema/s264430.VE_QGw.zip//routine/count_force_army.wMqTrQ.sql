create function count_force_army() returns trigger
    language plpgsql
as
$$
DECLARE
	powerPet integer;
	BEGIN
		select getPowerPet(NEW.ID_АРМИИ) into powerPet;
		IF powerPet is null then
			powerPet := 0;
		END IF;
		UPDATE АРМИЯ SET БОЕВАЯ_МОЩЬ = ((select sum(БОЕВАЯ_МОЩЬ) from ОТРЯД
									   WHERE ОТРЯД.ID_АРМИИ = NEW.ID_АРМИИ ) + powerPet)
									   where АРМИЯ.ID = NEW.ID_АРМИИ;
	return null;
	END;
$$;

alter function count_force_army() owner to s264430;

