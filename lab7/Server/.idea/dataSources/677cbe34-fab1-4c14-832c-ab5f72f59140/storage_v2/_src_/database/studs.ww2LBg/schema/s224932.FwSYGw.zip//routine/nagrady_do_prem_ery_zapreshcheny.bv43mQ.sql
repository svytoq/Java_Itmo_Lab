create function награды_до_премьеры_запрещены() returns trigger
    language plpgsql
as
$$
DECLARE 
	премьера timestamp;
BEGIN
SELECT Фильмы.премьера INTO премьера FROM "Фильмы" WHERE ид = NEW.ид_фильма;
IF now() < премьера THEN
	RAISE EXCEPTION 'Награда не может вручаться до выхода фильма (премьера %)', премьера;
END IF;
RETURN NEW;
END;
$$;

alter function награды_до_премьеры_запрещены() owner to s224932;

