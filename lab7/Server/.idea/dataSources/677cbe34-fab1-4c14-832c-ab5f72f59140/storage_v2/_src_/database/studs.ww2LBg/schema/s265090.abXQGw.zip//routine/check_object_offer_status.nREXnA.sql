create function check_object_offer_status() returns trigger
    language plpgsql
as
$$
DECLARE
    STATE  "OBJECT_STATE" := (SELECT OBJECT_STATE
                       FROM OBJECT
                       WHERE ID = NEW.OBJECT);
    STATUS "STATUS" := (SELECT STATUS
                       FROM OFFER
                       WHERE ID = NEW.OFFER);
BEGIN
    IF STATE = 'SHARED' OR STATUS != 'OPEN' THEN
        RETURN NULL;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_object_offer_status() owner to s265090;

