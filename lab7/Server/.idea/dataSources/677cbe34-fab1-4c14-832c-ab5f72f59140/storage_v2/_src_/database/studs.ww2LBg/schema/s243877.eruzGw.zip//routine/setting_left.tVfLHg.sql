create function setting_left() returns trigger
    language plpgsql
as
$$
declare
B MEETING%ROWTYPE;
begin
if NEW.PEOPLE_LEFT isnull
then NEW.PEOPLE_LEFT = NEW.MAX_PARTICIPANTS;
end if;
return NEW;
end
$$;

alter function setting_left() owner to s243877;

