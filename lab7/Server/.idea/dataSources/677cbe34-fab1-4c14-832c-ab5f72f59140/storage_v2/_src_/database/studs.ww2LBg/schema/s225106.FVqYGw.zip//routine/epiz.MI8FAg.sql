create function эпиз() returns trigger
    language plpgsql
as
$$
BEGIN
IF MOD(NEW.ИД,3)=0 THEN
NEW.ПРИЧИНА='FAIL';
raise notice 'Hello';
END IF;
RETURN NEW;
END;
$$;

alter function эпиз() owner to s225106;

