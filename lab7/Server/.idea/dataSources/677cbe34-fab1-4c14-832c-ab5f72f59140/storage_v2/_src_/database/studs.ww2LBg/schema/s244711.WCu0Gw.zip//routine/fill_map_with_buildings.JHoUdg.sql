create function fill_map_with_buildings(_map integer, amount integer) returns void
    language plpgsql
as
$$
DECLARE
BEGIN
	FOR i IN 1 .. amount LOOP
		INSERT INTO map_buildings
			(object, building) 
			VALUES
			(get_first_not_claimed_object(_map), 
			get_first_not_claimed_building());
	END LOOP;
END;
$$;

alter function fill_map_with_buildings(integer, integer) owner to s244711;

