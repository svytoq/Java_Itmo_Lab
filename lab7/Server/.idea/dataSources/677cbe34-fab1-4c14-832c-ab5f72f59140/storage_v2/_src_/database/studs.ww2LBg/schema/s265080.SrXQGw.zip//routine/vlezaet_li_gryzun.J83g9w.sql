create function влезает_ли_грызун() returns trigger
    language plpgsql
as
$$
BEGIN

        -- Проверить, что указаны имя сотрудника и зарплата
        IF  (select count(*) from "ГРЫЗУНЫ" where "ИД_КЛЕТКИ" = new."ИД_КЛЕТКИ" group by "ИД_КЛЕТКИ") > (select "ВМЕСТИМОСТЬ" from "КЛЕТКИ" where "ИД" = new."ИД_КЛЕТКИ") THEN
            insert into "ГРЫЗУНЫ" ("ВИД_ГРЫЗУНА","ПОЛ","ИД_КЛЕТКИ","ДАТА_РОЖДЕНИЯ","ИМЯ") values
                                                         (new."ВИД_ГРЫЗУНА", new."ПОЛ",new."ИД_КЛЕТКИ" + 1,new."ДАТА_РОЖДЕНИЯ",new."ИМЯ");
        END IF;

        RETURN NEW;
    END;
$$;

alter function влезает_ли_грызун() owner to s265080;

