create function updategad(id integer, model character varying, man integer, type character varying, frequency numeric) returns void
    language sql
as
$$
update "Устройства_передатчики" set "Модель"=model,"Человек_установщик"=id,"Тип"=type,"Частота"=frequency where "ID_Устройства"=id;
$$;

alter function updategad(integer, varchar, integer, varchar, numeric) owner to s265102;

