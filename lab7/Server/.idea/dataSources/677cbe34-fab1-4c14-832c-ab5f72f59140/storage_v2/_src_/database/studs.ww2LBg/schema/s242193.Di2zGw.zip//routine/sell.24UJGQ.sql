create function sell(character_id integer, item_id integer, time_id timestamp without time zone) returns void
    language plpgsql
as
$$
BEGIN
		UPDATE К_Инвентарь SET Статус = 'продан' where Персонаж_ИД = character_id and Предмет_ИД = item_id and Момент_Получения = time_id;		
	END;

$$;

alter function sell(integer, integer, timestamp) owner to s242193;

