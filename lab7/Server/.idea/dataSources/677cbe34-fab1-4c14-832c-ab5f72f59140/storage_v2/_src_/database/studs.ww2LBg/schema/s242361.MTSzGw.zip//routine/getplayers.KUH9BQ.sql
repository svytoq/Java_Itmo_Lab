create function getplayers(number integer, OUT "ИГРЫ" integer, OUT "ИД_ТРИБУТА" bigint, OUT "ИД_ПОЛЬЗОВАТЕЛЯ" integer, OUT "СТАТУС" character varying, OUT "ПРИЧИНА_СМЕРТИ" character varying, OUT "ИД_УБИЙЦЫ" bigint, OUT "ИД_ОРУЖИЯ" integer, OUT "ЗДОРОВЬЕ" smallint, OUT "ФАМИЛИЯ" character varying, OUT "ИМЯ" character varying, OUT "ПОЛ" s242361.gender, OUT "ДИСТРИКТ" smallint) returns SETOF record
    language sql
as
$$
SELECT ТРИБУТЫ.ИД_ИГРЫ, ТРИБУТЫ.ИД_ТРИБУТА, ТРИБУТЫ.ИД_ПОЛЬЗОВАТЕЛЯ, ТРИБУТЫ.СТАТУС, ТРИБУТЫ.ПРИЧИНА_СМЕРТИ, ТРИБУТЫ.ИД_УБИЙЦЫ, 
ТРИБУТЫ.ИД_ОРУЖИЯ, ТРИБУТЫ.ЗДОРОВЬЕ, ПОЛЬЗОВАТЕЛИ.ФАМИЛИЯ, ПОЛЬЗОВАТЕЛИ.ИМЯ, ПОЛЬЗОВАТЕЛИ.ПОЛ, ПОЛЬЗОВАТЕЛИ.ДИСТРИКТ FROM ТРИБУТЫ 
JOIN ПОЛЬЗОВАТЕЛИ USING (ИД_ПОЛЬЗОВАТЕЛЯ)
WHERE ИД_ИГРЫ = number;
$$;

alter function getplayers(integer, out integer, out bigint, out integer, out varchar, out varchar, out bigint, out integer, out smallint, out varchar, out varchar, out s242361.gender, out smallint) owner to s242361;

