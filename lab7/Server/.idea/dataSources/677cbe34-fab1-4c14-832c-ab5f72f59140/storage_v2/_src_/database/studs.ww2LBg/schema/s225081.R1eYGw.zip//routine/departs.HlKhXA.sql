create function departs() returns trigger
    language plpgsql
as
$$
BEGIN
  IF TG_OP IN ('UPDATE', 'INSERT') AND NEW.ГЛАВА NOTNULL
  THEN
    UPDATE ЧЛЕНЫ_СЕНАТА
    SET ОТДЕЛ = NEW.ID_ОТДЕЛА
    WHERE ID_ЧЛЕНА = NEW.ГЛАВА;
  END IF;

  IF TG_OP = 'DELETE'
  THEN
    UPDATE ЧЛЕНЫ_СЕНАТА
    SET ОТДЕЛ = NULL
    WHERE ОТДЕЛ = OLD.ID_ОТДЕЛА;
  END IF;
  RETURN NULL;
END;
$$;

alter function departs() owner to s225081;

