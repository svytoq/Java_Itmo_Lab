create function is_valid_email(user_email text, is_student boolean) returns boolean
    language plpgsql
as
$$
declare
  student_row student%rowtype;
  worker_row worker%rowtype;
begin
  if is_student then
    for worker_row in select * from worker loop
      if worker_row.email = user_email then
        return false;
      end if;
    end loop;
  else
    for student_row in select * from student loop
      if student_row.email = user_email then
        return false;
      end if;
    end loop;
  end if;
  return true;
end;
$$;

alter function is_valid_email(text, boolean) owner to s243856;

