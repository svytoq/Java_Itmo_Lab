create function update_users_distributor() returns trigger
    language plpgsql
as
$$
BEGIN
        update participant set name = new.main_person_name where id = new.main_person_id;
    return null;
    end;
$$;

alter function update_users_distributor() owner to s264957;

