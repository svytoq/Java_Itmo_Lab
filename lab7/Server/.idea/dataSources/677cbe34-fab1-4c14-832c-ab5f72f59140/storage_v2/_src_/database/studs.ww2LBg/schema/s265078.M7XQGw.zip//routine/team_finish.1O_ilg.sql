create function team_finish() returns trigger
    language plpgsql
as
$$
DECLARE
x_finish numeric(10, 2) = 0;
y_finish numeric(10, 2) = 0;
z_finish numeric(10, 2) = 0;
x_curr numeric(10, 2) = 0;
y_curr numeric(10, 2) = 0;
z_curr numeric(10, 2) = 0;
max_fin integer = 0;
curr_fin integer = 0;
BEGIN
SELECT x_finish_coordinate INTO x_finish FROM tracks WHERE track_id IN ( SELECT track_id FROM races WHERE race_id = NEW.race_id );
SELECT y_finish_coordinate INTO y_finish FROM tracks WHERE track_id IN ( SELECT track_id FROM races WHERE race_id = NEW.race_id );
SELECT z_finish_coordinate INTO z_finish FROM tracks WHERE track_id IN ( SELECT track_id FROM races WHERE race_id = NEW.race_id );
SELECT x_coordinate INTO x_curr FROM race_team WHERE race_id = NEW.race_id AND team_id = NEW.team_id AND active = TRUE;
SELECT y_coordinate INTO y_curr FROM race_team WHERE race_id = NEW.race_id AND team_id = NEW.team_id AND active = TRUE;
SELECT z_coordinate INTO z_curr FROM race_team WHERE race_id = NEW.race_id AND team_id = NEW.team_id AND active = TRUE;
SELECT max_finishers INTO max_fin FROM races WHERE race_id = NEW.race_id;
SELECT current_finishers INTO curr_fin FROM races WHERE race_id = NEW.race_id;

IF ( x_curr = x_finish AND y_curr = y_finish AND z_curr = z_finish ) THEN
UPDATE teams SET in_race = FALSE WHERE team_id = NEW.team_id;
IF ( curr_fin < max_fin ) THEN
UPDATE races SET current_finishers = ( curr_fin + 1 ) WHERE race_id = NEW.race_id;
ELSE
UPDATE teams SET in_championship = FALSE WHERE team_id = NEW.team_id;
END IF; 
END IF;
RETURN NEW;
END;
$$;

alter function team_finish() owner to s265078;

