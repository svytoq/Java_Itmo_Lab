create function delete_acting_entity() returns trigger
    language plpgsql
as
$$
BEGIN
  DELETE FROM Действ_сущности WHERE ИД = OLD.ИД;
  PERFORM * FROM Действ_сущности WHERE ИД = OLD.ИД;
  IF FOUND THEN
    RAISE EXCEPTION 'Что-то пошло не так';
  END IF;
  RETURN NULL;
END
$$;

alter function delete_acting_entity() owner to s225125;

