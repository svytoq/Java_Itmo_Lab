create function check_clan(ninja_to_check integer, clan_to_check integer) returns boolean
    language plpgsql
as
$$
declare
    checker integer;
begin
    checker = (select count() from ninja where ninja_id = ninja_to_check and clan = clan_to_check);
    if (checker = 1) then
        return true;
    else
        return false;
    end if;
end;
$$;

alter function check_clan(integer, integer) owner to s263909;

