create function create_actions() returns void
    language plpgsql
as
$$
DECLARE
    rating int = 0;
begin
    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (1, 'Пожрать на помойке', 0, 'Еда');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating", "Bottles")
    VALUES (1, 10, -5, -5, 10, 2);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (2, 'Съесть хотдог', -100, 'Еда');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (2, 20, -2, -2, 20);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (3, 'Сходить в кафе', -500, 'Еда');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (3, 30, 0, 2, 30);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (4, 'Закупиться в магазине', -3000, 'Еда');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (4, 40, 0, 5, 40);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (5, 'Выпить пива', -50, 'Настроение');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (5, 1, -3, 10, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (6, 'Выпить водки', -200, 'Настроение');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (6, 2, -6, 20, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (7, 'Выпить виски', -500, 'Настроение');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (7, 3, -9, 30, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (8, 'Выпить коньяк XO', -1500, 'Настроение');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (8, 4, -12, 40, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (9, 'Полечиться на помойке', 0, 'Поднять здоровье');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (9, -3, 5, -3, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (10, 'Полечиться у бабки', -100, 'Поднять здоровье');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (10, -3, 10, -1, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (11, 'Сходить к доктору', -500, 'Поднять здоровье');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (11, -3, 20, 3, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (12, 'Сходить в клинику', -3000, 'Поднять здоровье');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (12, -3, 30, 5, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (13, 'Лечиться за границей', -50000, 'Поднять здоровье');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (13, -3, 40, 10, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (14, 'Совершить пробежку', 0, 'Занятие спортом');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (14, -5, 10, 10, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (15, 'Бомжатничать во дворе', 0, 'Бомжатничать');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating", "Bottles")
    VALUES (15, -2, -2, -1, 5, 2);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (16, 'Бомжатничать в переходе', 0, 'Бомжатничать');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating", "Bottles")
    VALUES (16, -4, -4, -2, 10, 4);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (17, 'Бомжатничать у магазина', 0, 'Бомжатничать');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating", "Bottles")
    VALUES (17, -6, -6, -3, 15, 6);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (18, 'Бомжатничать в центре', 0, 'Бомжатничать');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating", "Bottles")
    VALUES (18, -8, -8, -4, 20, 8);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (19, 'Искать монеты на улице', 15, 'Поборы');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (19, null, null, 500);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (20, 'Наехать на собутыльника', 50, 'Поборы');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (20, null, null, 5000);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (21, 'Таксовать на авто', 150, 'Поборы');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (21, 19, null, 10000);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (22, 'Ограбить прохожего', 1000, 'Поборы');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (22, 20, null, 100000);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (23, 'Ограбить банк', 100000, 'Поборы');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (23, 15, 21, 500000);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (24, 'Мыть машины', 150, 'Работа');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (24, 5, 10, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (25, 'Мести дворы', 250, 'Работа');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (25, 5, 10, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (26, 'Работать сантехником', 600, 'Работа');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (26, 6, 11, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (27, 'Работать на заводе', 1000, 'Работа');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (27, 6, 11, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (28, 'Работать в офисе', 5000, 'Работа');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (28, 7, 13, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (29, 'Управлять компанией', 15000, 'Работа');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (29, 8, 13, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (30, 'Заработать на бирже', 50000, 'Работа');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (30, 8, 14, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (31, 'Махинации с акциями', 100000, 'Работа');
    SELECT "Rating" FROM "Status" WHERE "Name" = 'Депутат' INTO rating;
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (31, 8, 24, rating);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (32, 'Заседать в правительстве', 350000, 'Работа');
    SELECT "Rating" FROM "Status" WHERE "Name" = 'Депутат' INTO rating;
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (32, 8, 24, rating);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (33, 'Торговать оружием', 500000, 'Работа');
    SELECT "Rating" FROM "Status" WHERE "Name" = 'Министр' INTO rating;
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (33, 8, 25, rating);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (34, 'Распределять бюджет', 500000, 'Работа');
    SELECT "Rating" FROM "Status" WHERE "Name" = 'Министр' INTO rating;
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (34, 8, 26, rating);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (35, 'Управлять страной', 1000000, 'Работа');
    SELECT "Rating" FROM "Status" WHERE "Name" = 'Президент' INTO rating;
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (35, 8, 27, rating);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (36, 'Затусить в клубе', -1000, 'Рейтинг');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (36, 5, -5, 20, 350);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (37, 'Засветиться на тв', -150000, 'Рейтинг');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (37, 0, -3, 30, 10000);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (38, 'Снять рекламу', -12000000, 'Рейтинг');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (38, -5, -3, 10, 10000);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (39, 'Купить конкурентов', -150000000, 'Рейтинг');
    INSERT INTO "Live_action"("Action_ID", "Satiety", "Health", "Mood", "Rating")
    VALUES (39, 0, 0, 0, 30000);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (42, 'Оформить пенсию', 1500, 'Социальные услуги');
    INSERT INTO "Money_action"("Action_ID", "Access_obj1_ID", "Access_obj2_ID", "Access_rating")
    VALUES (42, 23, null, 2000);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (43, 'Поцеловать жену', 0, 'Семья');
    INSERT INTO "Family_action"("Action_ID", "Loyalty")
    VALUES (43, 5);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (44, 'Подарить жене цветы', -3000, 'Семья');
    INSERT INTO "Family_action"("Action_ID", "Loyalty")
    VALUES (44, 10);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (45, 'Подарить жене платье', -15000, 'Семья');
    INSERT INTO "Family_action"("Action_ID", "Loyalty")
    VALUES (45, 20);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (46, 'Подарить жене телефон', -50000, 'Семья');
    INSERT INTO "Family_action"("Action_ID", "Loyalty")
    VALUES (46, 30);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (47, 'Купить жене брилианты', -150000, 'Семья');
    INSERT INTO "Family_action"("Action_ID", "Loyalty")
    VALUES (47, 40);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (48, 'Путешествовать с женой', -300000, 'Семья');
    INSERT INTO "Family_action"("Action_ID", "Loyalty")
    VALUES (48, 50);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (49, 'Завести ребенка', 0, 'Семья');
    INSERT INTO "Family_action"("Action_ID", "Loyalty")
    VALUES (49, 0);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (50, 'Подарить игрушку', -1000, 'Дети');
    INSERT INTO "Family_action"("Action_ID", "Care", "Education")
    VALUES (50, 15, 5);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (51, 'Дать карманные деньги', -2000, 'Дети');
    INSERT INTO "Family_action"("Action_ID", "Care", "Education")
    VALUES (51, 25, 12);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (52, 'Подарить ребенку планшет', -20000, 'Дети');
    INSERT INTO "Family_action"("Action_ID", "Care", "Education")
    VALUES (52, 30, 40);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (53, 'Оплатить обучение', -500000, 'Дети');
    INSERT INTO "Family_action"("Action_ID", "Care", "Education")
    VALUES (53, 40, 50);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (54, 'Пристроить на работу', -1000000, 'Дети');
    INSERT INTO "Family_action"("Action_ID", "Care", "Education")
    VALUES (54, 50, 40);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (55, 'Подарить ребенку машину', -700000, 'Дети');
    INSERT INTO "Family_action"("Action_ID", "Care", "Education")
    VALUES (55, 60, 20);

    INSERT INTO "Action"(ID, "Name", "Money", "Type")
    VALUES (56, 'Подарить ребенку квартиру', -6000000, 'Дети');
    INSERT INTO "Family_action"("Action_ID", "Care", "Education")
    VALUES (56, 70, 20);

    RETURN;
end
$$;

alter function create_actions() owner to s264425;

