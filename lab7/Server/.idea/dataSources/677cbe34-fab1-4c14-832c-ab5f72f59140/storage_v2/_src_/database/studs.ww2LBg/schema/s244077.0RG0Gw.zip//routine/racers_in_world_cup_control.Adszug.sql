create function racers_in_world_cup_control() returns trigger
    language plpgsql
as
$$
DECLARE
  person_id INT;
  us_spec user_spec;
  BEGIN
   person_id:=(SELECT racer_id FROM world_cup_result WHERE (world_cup_result.racer_id = NEW.racer_id));
   us_spec:=(SELECT spec FROM users WHERE (users.id = person_id));
   IF (NOT(us_spec = 'RACER'))
     THEN RAISE EXCEPTION 'Only racers can be in world cup results';
     RETURN NULL;
  END IF;
  RETURN NEW;
END;
$$;

alter function racers_in_world_cup_control() owner to s244077;

