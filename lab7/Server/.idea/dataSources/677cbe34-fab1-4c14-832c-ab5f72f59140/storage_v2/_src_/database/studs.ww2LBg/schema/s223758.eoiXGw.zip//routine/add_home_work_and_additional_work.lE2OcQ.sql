create function add_home_work_and_additional_work(integer, integer, integer, date, date, text, integer, text) returns void
    language sql
as
$$
START TRANSACTION;
	INSERT INTO домашнее_задание
	VALUES ($1, $2, $3, 
			$4, $5, $6)
	;
	INSERT INTO дополнительное_задание
	VALUES ($1, $7, 
			$8)
	;
COMMIT;
$$;

alter function add_home_work_and_additional_work(integer, integer, integer, date, date, text, integer, text) owner to s223758;

