create view empty_spot as
SELECT "Очередь_дверь"."Занято_с" + '00:01:00'::interval
FROM s267650."Очередь_дверь"
WHERE "Очередь_дверь"."Занято_с" IS NOT NULL
  AND ((date_part('day'::text, "Очередь_дверь"."Занято_с"::timestamp with time zone - now()) * 24::double precision +
        date_part('hour'::text, "Очередь_дверь"."Занято_с"::timestamp with time zone - now())) * 60::double precision +
       date_part('minute'::text, "Очередь_дверь"."Занято_с"::timestamp with time zone - now())) >= 30::double precision
  AND ((SELECT "Очередь_дверь_1"."Занято_с"
        FROM s267650."Очередь_дверь" "Очередь_дверь_1"
        WHERE "Очередь_дверь_1"."Занято_с" >= ("Очередь_дверь_1"."Занято_с" + '00:01:00'::interval)
          AND "Очередь_дверь_1"."Занято_с" <=
              ("Очередь_дверь_1"."Занято_с" + 2::double precision * '00:01:00'::interval))) IS NULL
ORDER BY "Очередь_дверь"."Занято_с"
LIMIT 1;

alter table empty_spot
    owner to s267650;

