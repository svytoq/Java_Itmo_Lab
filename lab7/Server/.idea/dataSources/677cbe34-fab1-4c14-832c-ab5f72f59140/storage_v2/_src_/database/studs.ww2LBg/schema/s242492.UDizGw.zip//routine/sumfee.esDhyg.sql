create function sumfee() returns trigger
    language plpgsql
as
$$
declare
b timestamp;
e timestamp;
raznost integer;
tarif integer;
rub integer;
begin
b:=(select начало from посещения where id=new.id_посещения);
e:=(select конец from посещения where id=new.id_посещения);
raznost:=cast(extract(epoch from (e-b)) as integer);
tarif:=(select стопчек from тарифы where id=new.id_тарифа);
rub:=(select поминутно from тарифы where id=new.id_тарифа);
raznost:=raznost*rub;
if (raznost>tarif) then
new.сумма:=tarif;
else new.сумма:=raznost;
end if;
return new;
end
$$;

alter function sumfee() owner to s242492;

