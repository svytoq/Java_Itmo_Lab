create function сеансы_до_премьеры_запрещены() returns trigger
    language plpgsql
as
$$
DECLARE 
	премьера timestamp;
BEGIN
SELECT Фильмы.премьера INTO премьера FROM "Фильмы" WHERE ид = NEW.ид_фильма;
IF NEW.дата_начала < премьера THEN
	RAISE EXCEPTION 'Дата премьеры фильма (%) не может быть позже, чем дата начала показа (%)', премьера, NEW.дата_начала;
END IF;

RETURN NEW;
END;
$$;

alter function сеансы_до_премьеры_запрещены() owner to s224932;

