create function calculatemarketprice(integer, integer) returns void
    language sql
as
$$
UPDATE FOR_SALE_CARS
SET MARKET_PRICE = $2 WHERE CAR_ID = $1;
$$;

alter function calculatemarketprice(integer, integer) owner to s265085;

