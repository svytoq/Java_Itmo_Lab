create function player_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	rand INTEGER;
	length integer;
	i INTEGER DEFAULT 1;
	count integer default 0;
	chars text[] = '{a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z}';
	func text[] = '{ГК, СЗ, ПЗ, ЛЗ, ЦЗ, ЗПФ, ЗЛФ, ЦОПЗ, ППЗ, ЦПЗ, ЛПЗ, ПЗПФ, ПЗЛФ, ЦАПЗ, ПН, СН, ЛН, ПФ, ЛФ, ЦФ}';
	name text;
	familiya text;
	otchestvo text;
	id_strany integer default 1;
	function text;
  maxN integer;
BEGIN
  Select count(ИД_СТРАНЫ) from СТРАНА_УЧАСТНИЦА into maxN;
  if (N % 3)-1 > maxN THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "СТРАНА_УЧАСТНИЦА"';
	END if;

	for i in 1..N loop

		rand = random();
		length = random() * 10 + 1;

		while count<length or name=null or familiya=null or otchestvo=null loop
			name = concat(chars[1+random()*(array_length(chars, 1)-1)], name);
			familiya = concat(chars[1+random()*(array_length(chars, 1)-1)], familiya);
			otchestvo = concat(chars[1+random()*(array_length(chars, 1)-1)], otchestvo);
			count = count+1;
		end loop;

		function = func[i % 21 + 1];
		if i % 20 = 0 THEN
			id_strany = id_strany + 1;
		End if;

		insert into "ИГРОК" values(DEFAULT, familiya, name, otchestvo, id_strany, CAST(function AS position_of_player));
		name = NULL;
		familiya = NULL;
		otchestvo = NULL;
		count = 0;
	end loop;
END;
$$;

alter function player_inserter(integer) owner to s224514;

