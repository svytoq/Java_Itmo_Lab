create function check_on_delete_jinchuriki() returns trigger
    language plpgsql
as
$$
begin
    if (tg_op = 'delete') then
        raise exception 'Jinchuriki cannot be removed';
    end if;
    return new;
end;
$$;

alter function check_on_delete_jinchuriki() owner to s263909;

