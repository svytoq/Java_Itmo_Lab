create function make_tour(namet character varying, prizepool integer, startdate date, enddate date, team1 character varying, team2 character varying, team3 character varying, team4 character varying) returns void
    language plpgsql
as
$$
declare
team1_id integer;
team2_id integer;
team3_id integer;
team4_id integer;
tid integer;
begin
IF(startdate <= CURRENT_DATE )
THEN
select Команды.ID_Команды into team1_id from Команды t where t.Тег = team1;
select Команды.ID_Команды into team2_id from Команды t where t.Тег = team2;
select Команды.ID_Команды into team3_id from Команды t where t.Тег = team3;
select Команды.ID_Команды into team4_id from Команды t where t.Тег = team4;
select MAX(Турниры.ID_Турнира) into tid from Турниры;
tid = tid + 1;
insert into Турниры_Команды(ID_Турнира, ID_Команды) values (tid, team1_id);
insert into Турниры_Команды(ID_Турнира, ID_Команды) values (tid, team2_id);
insert into Турниры_Команды(ID_Турнира, ID_Команды) values (tid, team3_id);
insert into Турниры_Команды(ID_Турнира, ID_Команды) values (tid, team4_id);

insert into Матчи(ID_Турнира, ID_Команды1, ID_Команды2, Наименование, Статус) values(tid, team1_id, team2_id, 'Semifinal',  'Не начался');
insert into Матчи(ID_Турнира, ID_Команды1, ID_Команды2, Наименование, Статус) values(tid, team3_id, team4_id, 'Semifinal',  'Не начался');
END IF;

IF(startdate > CURRENT_DATE )
THEN
 RAISE EXCEPTION 'Турнир нельзя зарегестрировать в день начала';
END IF;
end
$$;

alter function make_tour(varchar, integer, date, date, varchar, varchar, varchar, varchar) owner to s241870;

