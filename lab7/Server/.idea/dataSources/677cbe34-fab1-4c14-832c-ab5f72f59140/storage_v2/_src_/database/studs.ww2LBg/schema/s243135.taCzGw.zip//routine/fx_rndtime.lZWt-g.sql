create function fx_rndtime(n integer) returns timestamp with time zone
    language plpgsql
as
$$
begin
return to_timestamp(1000000+n*3650000+random()*10000000);
end
$$;

alter function fx_rndtime(integer) owner to s243135;

