create function a(table_name text, scheme_name text) returns void
    language plpgsql
as
$$
declare
    column_limit integer = 0;
    table_oid integer = -1;
    current_row record;
    max_attname_length integer = -1;
begin
    if table_name is null or scheme_name is null then
        raise info 'Имя таблицы или название схемы не задано';
    else
        raise info 'Таблица: %', table_name;

        select oid into table_oid from pg_class where relname = table_name;

        select max(length(pg_attribute.attname)) into max_attname_length from pg_attribute
        where pg_attribute.attrelid = table_oid and pg_attribute.attnum > 0;

        column_limit = max_attname_length + 15;

        raise info '% % % % %','No.',repeat(' ',3),'Имя столбца',repeat(' ',column_limit - 17),'Атрибуты';
        raise info '% % % % %','---',repeat(' ',3),'-----------',repeat(' ',column_limit - 17),'------------------------------------------------------';

        for current_row in
            select
                pg_attribute.attname,
                pg_attribute.attnum,
                pg_attribute.atttypid,
                pg_attribute.attnotnull,
                pg_type.typname,
                pg_constraint.conname,
                pg_constraint.contype,
                pg_constraint.confkey,
                pg_constraint.confrelid
            from pg_attribute
                     left join pg_type on pg_attribute.atttypid = pg_type.oid
                     left join pg_constraint on pg_attribute.attnum = pg_constraint.conkey[1] and pg_constraint.conrelid = table_oid
            where pg_attribute.attrelid = table_oid and pg_attribute.attnum > 0
            order by pg_attribute.attnum
            loop
                declare
                    attname_length integer = length(current_row.attname);
                begin
                    raise info '% % % % Type: %',current_row.attnum,repeat(' ',5),current_row.attname,repeat(' ',column_limit - 1 - 5 - attname_length),current_row.typname;

                    if current_row.conname is not null then
                        declare
                            ref_table text;
                            ref_column text;
                        begin
                            select pg_class.relname into ref_table
                            from pg_class
                            where pg_class.oid = current_row.confrelid;

                            select pg_attribute.attname into ref_column
                            from pg_attribute
                            where pg_attribute.attrelid = current_row.confrelid and pg_attribute.attnum = current_row.confkey[1];

                            raise info  '% Constr : % References %(%)',repeat(' ',column_limit+3) ,current_row.conname,ref_table,ref_column;
                        end;

                    end if;
                end;
            end loop;
    end if;
end
$$;

alter function a(text, text) owner to s273610;

