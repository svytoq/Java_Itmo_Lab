create function count_earningss() returns trigger
    language plpgsql
as
$$
declare
earnings integer;
gain_earn integer;

BEGIN
Gain_earn = (select earnings from gain where new.gain_id = gain_gain_id);
earnings = new.count * new.ticket_price + gain_earn;
Insert into gain(gain_id, earnings) values(new.gain_id, earnings);
Return NULL;
end;
$$;

alter function count_earningss() owner to s265447;

