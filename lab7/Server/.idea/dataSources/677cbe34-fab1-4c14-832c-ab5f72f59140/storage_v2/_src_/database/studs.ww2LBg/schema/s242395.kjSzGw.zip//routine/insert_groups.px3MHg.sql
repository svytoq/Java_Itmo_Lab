create function insert_groups(count integer) returns void
    language plpgsql
as
$$
BEGIN
        FOR i in 1 .. count LOOP
                insert into Группы(название) values(random_string(10));
        END LOOP;
END;
$$;

alter function insert_groups(integer) owner to s242395;

