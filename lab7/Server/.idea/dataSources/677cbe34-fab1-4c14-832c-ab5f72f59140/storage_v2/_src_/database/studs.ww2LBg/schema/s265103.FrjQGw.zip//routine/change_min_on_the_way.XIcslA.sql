create function change_min_on_the_way() returns trigger
    language plpgsql
as
$$
begin
    if DATE_PART('year', CURRENT_TIMESTAMP) - NEW.Arrival_year  > 5
    then UPDATE  Tickets SET Min_on_the_way = (DATE_PART('year', CURRENT_TIMESTAMP) - NEW.Arrival_year) where Passenger_id = NEW.Passenger_id;
    else UPDATE Tickets set Arrival_year = (DATE_PART('year', CURRENT_TIMESTAMP)) where id = NEW.id;
    end if;
    return NEW;
end;
$$;

alter function change_min_on_the_way() owner to s265103;

