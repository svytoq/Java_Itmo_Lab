create function order_responsible_sales() returns trigger
    language plpgsql
as
$$
DECLARE responsible_dpt department := (
        SELECT department FROM employee WHERE id = NEW.responsible_id
    );

    BEGIN
        IF responsible_dpt = 'sales' THEN
            RETURN NEW;
        END IF;
        RETURN NULL;
    END;
$$;

alter function order_responsible_sales() owner to s265092;

