create function violation_check_delete(id integer) returns integer
    language plpgsql
as
$$
declare
    violation integer;
begin
    select violation_id into violation from Violation_checks where violation_check_id=id;
    update Violations set 
        violation_state='awaits_review'
        where violation_id=violation;
    delete from Violation_check_employees where violation_check_id=id;
    delete from Violation_checks where violation_check_id=id;
    return 1;
end;
$$;

alter function violation_check_delete(integer) owner to s265066;

