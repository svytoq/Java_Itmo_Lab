create function "Менок"(id integer, "id_базы" integer, "название" character varying) returns void
    language plpgsql
as
$$
BEGIN
insert into корабль values(ID, 800, название, '[20, 25]' , 1300, 'создается',700, ID_базы, now(), null);
insert into оружие_корабль values(7, ID);
END;
$$;

alter function "Менок"(integer, integer, varchar) owner to s243840;

