create function update_position(our_employee_id integer, new_position_id integer) returns text
    language plpgsql
as
$$
begin
        update employee
            set position_id = new_position_id
            where employee_id = our_employee_id;
        return 'Успешно';
    end;
$$;

alter function update_position(integer, integer) owner to s265058;

