create function correct_officer() returns trigger
    language plpgsql
as
$$
DECLARE
        person_job varchar(20);
    BEGIN
        SELECT job INTO person_job FROM Persons p WHERE p.id = NEW.person;
        IF (person_job != 'officer') THEN
            RAISE EXCEPTION 'Этот человек не офицер';
        END IF;
        RETURN NEW;
    END;
$$;

alter function correct_officer() owner to s270250;

