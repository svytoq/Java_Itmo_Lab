create function create_contract(new_contract_uuid uuid, new_company_id uuid, new_employee_id uuid, new_created_date timestamp without time zone, new_end_date timestamp without time zone, new_name character varying, new_description character varying, new_doc_url character varying) returns text
    language plpgsql
as
$$
declare
    id_contract uuid;
begin
    if exists(select c.id from company c where c.id = new_company_id) then
        if exists(select e.id from employee e where e.id = new_employee_id) then
            insert into contract(id, created_date, description, doc_url, end_date, interrupted, interrupted_date, name,
                                 printed, company_id, employee_id)
            values (new_contract_uuid,
                    new_created_date,
                    new_description,
                    new_doc_url,
                    new_end_date,
                    false,
                    null,
                    new_name, false,
                    new_company_id,
                    new_employee_id)
            returning contract.id into id_contract;

            return 'Contract created. Id: ' || id_contract;
        else
            return 'No such employee_id: ' || new_employee_id;
        end if;
    else
        return 'No such company_id: ' || new_company_id;

    end if;
end;
$$;

alter function create_contract(uuid, uuid, uuid, timestamp, timestamp, varchar, varchar, varchar) owner to s264452;

