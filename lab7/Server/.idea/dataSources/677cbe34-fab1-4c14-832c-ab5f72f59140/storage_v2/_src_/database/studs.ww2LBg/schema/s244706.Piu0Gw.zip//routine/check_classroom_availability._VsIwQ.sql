create function check_classroom_availability() returns trigger
    language plpgsql
as
$$
declare
  is_occupied boolean;
begin
  is_occupied := (select exists(
    select from classroom_bookings
    where room_number = new.room_number and week_day = new.week_day
      and (occupied_from, occupied_to) overlaps (new.occupied_from, new.occupied_to)
  ));

  if is_occupied
  then raise exception 'The requested classroom is already booked for this time.';
  end if;

  return new;
end;
$$;

alter function check_classroom_availability() owner to s244706;

