create function win_via_bribe() returns trigger
    language plpgsql
as
$$
DECLARE
        bribe_race_id integer;
        race_district_id integer;
        officer_district_id integer;
        officer_person_id integer;
        bribe_horse_id integer;
        mafia_id integer;
        mafia_wealth bigint;
        need_money integer;
        addressee_relationship integer;
        officer_rank varchar;
        rank_coef integer;
    BEGIN
        SELECT Hippodromes.district INTO race_district_id FROM Races JOIN Hippodromes ON (Races.hippodrome = Hippodromes.id);
        SELECT person INTO officer_person_id FROM Officers WHERE id = NEW.addressee;
        SELECT Persons.live_in INTO officer_district_id FROM Officers JOIN Persons ON (officer_person_id = Persons.id);

        IF (race_district_id != officer_district_id) THEN
            RAISE EXCEPTION 'Вы подкупаете не того офицера';
        END IF;

        SELECT race_id INTO bribe_race_id FROM Horse_in_race hir WHERE hir.id = NEW.horse_in_race;
        SELECT horse_id INTO bribe_horse_id FROM Horse_in_race hir WHERE hir.id = NEW.horse_in_race;
        SELECT mafia_family INTO mafia_id FROM Persons p WHERE p.id = NEW.sender;
        SELECT relationship INTO addressee_relationship FROM Mafia_officer mo WHERE mo.officer = NEW.addressee AND
                                                                                    mo.mafia_family = mafia_id;


        IF NOT FOUND THEN
            INSERT INTO Mafia_officer (officer, mafia_family) VALUES (NEW.addressee, mafia_id) RETURNING relationship INTO addressee_relationship;
        END IF;

        SELECT rank INTO officer_rank FROM Officers of WHERE of.id = NEW.addressee;
        case officer_rank
            when 'general' then
                rank_coef = 4;
            when 'captain' then
                rank_coef = 3;
            when 'major' then
                rank_coef = 2;
            else
                rank_coef = 1;
        end case;

        need_money := (11 - addressee_relationship) * rank_coef * 150;

        SELECT wealth INTO mafia_wealth FROM Mafies WHERE id = mafia_id;
        IF (NEW.amount > mafia_wealth) THEN
            RAISE EXCEPTION 'Недостаточно денег, чтобы дать взятку';
        ELSIF (need_money <= NEW.amount) THEN
            UPDATE Races r SET fake_winner = bribe_horse_id WHERE r.id = bribe_race_id;
            UPDATE Mafies m SET wealth = wealth - NEW.amount WHERE m.id = mafia_id;
            RETURN NEW;
        END IF;
        RETURN NULL;
    END;
$$;

alter function win_via_bribe() owner to s270250;

