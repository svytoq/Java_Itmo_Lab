create function techid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('technologies_id_seq')!=NEW.ID THEN
NEW.ID=nextval('technologies_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function techid() owner to s225102;

