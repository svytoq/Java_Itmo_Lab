create function kill_mob() returns trigger
    language plpgsql
as
$$
declare
    t_curs cursor for select *
                      from s174292.mob_inventory
                      where s174292.mob_inventory.mob_id = NEW.mob_id;
    t_row integer;
begin
    if ((select s174292.mob_witcher_fight.success from s174292.mob_witcher_fight where id = NEW.id) = TRUE) then
        update s174292.witcher
        set xp=xp + 50
        where s174292.witcher.id = NEW.witcher_id;

        for t_row in t_curs
            Loop
                if ((select exists(select *
                                   from s174292.witcher_inventory
                                   where s174292.witcher_inventory.item_id = t_row.item_id
                                     and s174292.witcher_inventory.witcher_id = NEW.witcher_id)) = TRUE)
                then
                    update s174292.witcher_inventory
                    set count=count + t_row.count
                    where s174292.witcher_inventory.witcher_id = NEW.witcher_id
                      and s174292.witcher_inventory.item_id = t_row.item_id;
                else
                    insert into s174292.witcher_inventory(witcher_id, item_id, count)
                    values (NEW.witcher_id, t_row.item_id, t_row.count);
                end if;
            end loop;
    end if;
    return NEW;
end;
$$;

alter function kill_mob() owner to s174292;

