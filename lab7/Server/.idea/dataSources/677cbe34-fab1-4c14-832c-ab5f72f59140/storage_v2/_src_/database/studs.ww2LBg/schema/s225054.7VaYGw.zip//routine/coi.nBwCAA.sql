create function coi() returns void
    language plpgsql
as
$$
BEGIN
CREATE INDEX index1 ON ПЕРСОНАЖИ USING btree(ФАКУЛЬТЕТ);
CREATE INDEX index2 ON ПЕРСОНАЖИ USING btree(ПРОФЕССИЯ);
CREATE INDEX index3 ON ПЕРСОНАЖИ USING btree(ЛЮБИМАЯ_ИГРА);
CREATE INDEX index4 ON ПЕРСОНАЖИ USING btree(ИМЯ, ФАМИЛИЯ);
CREATE INDEX index5 ON ЗАКЛИНАНИЯ USING btree(УРОВЕНЬ_УРОНА);
CREATE INDEX index6 ON ВОЛШЕБНЫЕ_ИГРЫ USING btree(MIN_ИГРОКОВ);
CREATE INDEX index7 ON ВОЛШЕБНЫЕ_ИГРЫ USING btree(MAX_ИГРОКОВ);
CREATE INDEX index8 ON УЧЕБНЫЕ_ПРЕДМЕТЫ USING btree(ФАКУЛЬТЕТ);
CREATE INDEX index9 ON УЧЕБНЫЕ_ПРЕДМЕТЫ USING btree(ID_ПРЕПОДАВАТЕЛЯ);
CREATE INDEX index10 ON ОРГАНИЗАЦИИ USING btree(ID_ГЛАВЫ);
CREATE INDEX index11 ON ОРГАНИЗАЦИИ USING btree(КОЛИЧЕСТВО_УЧАСТНИКОВ);
CREATE INDEX index12 ON ВОЛШЕБНЫЕ_ЖИВОТНЫЕ USING btree(ID_ХОЗЯИНА);
CREATE INDEX index13 ON ВОЛШЕБНЫЕ_ЖИВОТНЫЕ USING btree(ЛОКАЦИЯ);
CREATE INDEX index14 ON ВОЛШЕБНЫЕ_ЖИВОТНЫЕ USING btree(ТИП);
CREATE INDEX index15 ON ШКОЛЫ_МАГИИ USING btree(ЛОКАЦИЯ);
CREATE INDEX index16 ON ШКОЛЫ_МАГИИ USING btree(УРОВЕНЬ_ПРЕСТИЖНОСТИ);
CREATE INDEX index17 ON ГОДЫ_ОБУЧЕНИЯ USING btree(НАЧАЛО);
CREATE INDEX index18 ON КРЕСТРАЖИ USING btree(КОГДА_УНИЧТОЖЕН);
CREATE INDEX index19 ON ЛОКАЦИИ USING btree(СТЕПЕНЬ_ЗАЩИЩЕННОСТИ);
CREATE INDEX index20 ON ВАЖНЫЕ_СОБЫТИЯ USING btree(ЛОКАЦИЯ);
CREATE INDEX index21 ON ВАЖНЫЕ_СОБЫТИЯ USING btree(ГОД_ОБУЧЕНИЯ);
RETURN;
END;
$$;

alter function coi() owner to s225054;

