create function trigger_data_before_ins() returns trigger
    language plpgsql
as
$$
begin
new.data=nvl(new.data,current_date);
return new;
end;
$$;

alter function trigger_data_before_ins() owner to s225087;

