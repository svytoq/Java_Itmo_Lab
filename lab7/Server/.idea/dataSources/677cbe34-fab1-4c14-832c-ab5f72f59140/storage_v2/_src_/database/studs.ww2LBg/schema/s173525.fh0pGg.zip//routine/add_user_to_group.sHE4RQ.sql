create function add_user_to_group() returns trigger
    language plpgsql
as
$$
DECLARE
	result real;
BEGIN 
	SELECT user_id,group_id,end_date INTO result FROM user_groups WHERE user_id=NEW.user_id AND group_id=NEW.group_id AND end_date IS NULL;
	IF NOT FOUND THEN 
		RETURN NEW;
	ELSE
		RAISE EXCEPTION 'Пользователь уже числится в данной группе.';
	END IF;
END;
$$;

alter function add_user_to_group() owner to s173525;

