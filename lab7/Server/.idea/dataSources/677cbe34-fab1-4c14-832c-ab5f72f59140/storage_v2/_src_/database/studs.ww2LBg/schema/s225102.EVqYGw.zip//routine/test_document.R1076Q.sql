create function test_document() returns void
    language plpgsql
as
$$
declare
    res text ;
    res1 int;
    flag bool := true;
    creator_id int;
begin
    select id from user_table limit 1 into creator_id;
    raise notice 'Creating test document';
    insert into document values (111, NOW()::timestamp, 'desc', NOW()::timestamp, 'name', 'type', creator_id, creator_id);

    raise notice 'Check that created';
    select name from document where id=111 into res;
    if res='name' then
        raise notice 'CREATED OK';
    else
        raise notice 'NOT CREATED';
        flag := false;
    end if;
    begin     -- try
        raise notice 'Inserting with same ID';
        insert into document values (111, NOW()::timestamp, 'desc', NOW()::timestamp, 'name', 'type', 12, 12);
        flag := false;
    exception -- catch
        when sqlstate '23505' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! Id should be unique';
    end ;
    begin     -- try
        raise notice 'Inserting with not existing users';
        insert into document values (1111, NOW()::timestamp, 'desc', NOW()::timestamp, 'name', 'type', 1211, 1211);
        flag := false;
    exception -- catch
        when sqlstate '23503' then -- error that can be handeled
            raise notice 'NOT POSSIBLE! User should exist';
    end ;

    raise notice 'Deleting row';
    delete from document where id=111;
    select count(*) from document where id=111 into res1;

    if res1=0 then
        raise notice 'DELETED OK';
    else
        raise notice 'NOT DELETED';
        flag := false;
    end if;
    raise notice 'Test accomplished: %', flag;
end;
$$;

alter function test_document() owner to s225102;

