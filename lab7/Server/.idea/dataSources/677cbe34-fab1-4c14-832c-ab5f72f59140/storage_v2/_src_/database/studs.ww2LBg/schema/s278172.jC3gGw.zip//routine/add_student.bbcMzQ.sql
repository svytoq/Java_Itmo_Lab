create function add_student(n text, un text, dob date, y integer, f character varying) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO characters (name, username, date_of_birth, password) VALUES (n, un, dob, 'password');
    INSERT INTO character_roles (role_id, character_id)
    VALUES (2, (
        SELECT id
        FROM characters
        WHERE name = n
          AND date_of_birth = dob));
    INSERT INTO students (character_id, year, faculty_id)
    VALUES ((
                SELECT id
                FROM characters
                WHERE name = n
                  AND date_of_birth = dob
            ),
            y,
            (SELECT id FROM faculties WHERE name = f));
END
$$;

alter function add_student(text, text, date, integer, varchar) owner to s278172;

