create function get_resources(active_fraction integer) returns text
    language plpgsql
as
$$
declare
    profit              int;
    using_army_fraction int;
begin

    select sum(income)
    into profit
    from space_objects
             inner join stellar_systems
                        on space_objects.system = stellar_systems.id
    where stellar_systems.fraction = active_fraction;

    update fraction set (resources) = (resources + profit) where id = active_fraction;
    return 'ok';

end;
$$;

alter function get_resources(integer) owner to s265106;

