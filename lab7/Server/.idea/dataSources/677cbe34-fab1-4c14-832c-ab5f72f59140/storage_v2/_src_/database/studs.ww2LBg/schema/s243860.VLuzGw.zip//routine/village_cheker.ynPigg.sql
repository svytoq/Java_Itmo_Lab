create function village_cheker() returns trigger
    language plpgsql
as
$$
DECLARE
    temprow persons_belonging%ROWTYPE;
BEGIN
    FOR temprow IN 
        SELECT * FROM persons_belonging WHERE person_id = NEW.person_id
    LOOP
        IF ((NEW.date_of_beginning, NEW.date_of_ending)
         OVERLAPS 
         (temprow.date_of_beginning, temprow.date_of_ending))
        THEN 
            RAISE EXCEPTION 'Person cannot belong to two villages simultaneously';
        END IF;
    END LOOP;
    RETURN NEW;
END;
$$;

alter function village_cheker() owner to s243860;

