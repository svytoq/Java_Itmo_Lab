create function is_building_claimed(_building integer) returns boolean
    language plpgsql
as
$$
DECLARE
	amount int;
	sum int = 0;
BEGIN
	SELECT count(*) INTO amount
		FROM map_buildings
		WHERE building = _building;

	sum = sum + amount;

	SELECT count(*) INTO amount
		FROM town_buildings
		WHERE building = _building;

	sum = sum + amount;

	RETURN sum > 0;
END;
$$;

alter function is_building_claimed(integer) owner to s244711;

