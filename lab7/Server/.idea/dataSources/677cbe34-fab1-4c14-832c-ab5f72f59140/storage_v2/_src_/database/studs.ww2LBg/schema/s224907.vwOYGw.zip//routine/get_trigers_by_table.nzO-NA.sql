create function get_trigers_by_table(schema text, table_name text)
    returns TABLE("COLUMN NAME" name, "TRIGGER NAME" name)
    language sql
as
$$
select attname, tgname
from studs.pg_catalog.pg_trigger
         join pg_class pc on pc.oid = pg_trigger.tgrelid
         left join pg_catalog.pg_attribute pa
                   on pa.attnum = ANY (tgattr) and pa.attrelid = pg_trigger.tgrelid
         join pg_namespace pn on pc.relnamespace = pn.oid
WHERE relname = table_name
  and tgisinternal = false
  and nspname = schema
$$;

alter function get_trigers_by_table(text, text) owner to s224907;

