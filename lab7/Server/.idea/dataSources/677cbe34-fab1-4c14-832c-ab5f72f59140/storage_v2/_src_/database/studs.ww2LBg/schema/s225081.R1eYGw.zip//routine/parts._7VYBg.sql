create function parts() returns trigger
    language plpgsql
as
$$
BEGIN
  IF  NEW.КОМАНДИР NOTNULL THEN
    UPDATE ВОИНЫ
    SET ПОДРАЗДЕЛЕНИЕ = NEW.ID_ПОДРАЗДЕЛЕНИЯ
    WHERE ID_ВОИНА = NEW.КОМАНДИР;
END IF ;
  RETURN  NULL;
END;
$$;

alter function parts() owner to s225081;

