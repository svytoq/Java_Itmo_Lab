create function "АДАПТАЦИИ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('АДАПТАЦИИ_ИД_АДАПТАЦИИ_seq')!=NEW.ИД_АДАПТАЦИИ THEN NEW.ИД_АДАПТАЦИИ=nextval('АДАПТАЦИИ_ИД_АДАПТАЦИИ_seq');
  RETURN NEW;
ELSE
  RETURN NEW; 
END IF; 
END;
$$;

alter function "АДАПТАЦИИ_ИД"() owner to s225071;

