create function insert_review(id integer, project_id integer, user_id integer, stars integer, description text, time_value timestamp without time zone) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO review (id,
            project_id,
            user_id,
            stars,
            description,
            time_value)

  VALUES (insert_review.id,
      insert_review.project_id,
      insert_review.user_id,
      insert_review.stars,
      insert_review.description,
      insert_review.time_value);
END;

$$;

alter function insert_review(integer, integer, integer, integer, text, timestamp) owner to s264458;

