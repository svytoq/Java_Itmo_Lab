create function messagescheck() returns trigger
    language plpgsql
as
$$
declare
    in_states msg_states[];
    out_states msg_states[];
    pos int;
    dec_empl_departments departments[];
    department_array_pos int;
begin
    in_states = array['received', 'decrypting', 'decrypted', 'delivered'];
    out_states = array['formed', 'encrypting', 'encrypted', 'planned', 'sent'];

    if NEW.msg_type = 'in' then
        pos = array_position(in_states, NEW.msg_state);
        if pos is NULL then raise exception 'wrong state'; end if;

        if (pos >= array_position(in_states, 'received')
           and (NEW.enc_content is NULL or NEW.creation_time is NULL))
        then return NULL; end if;

        if (pos >= array_position(in_states, 'decrypting')
           and NEW.dec_empl is NULL)
        then return NULL; end if;

        if (pos >= array_position(in_states, 'decrypted')
           and (NEW.content is NULL OR
                NEW.sender is NULL OR
                NEW.recipient is NULL))
        then return NULL; end if;
    else
        pos = array_position(out_states, NEW.msg_state);
        if pos is NULL then raise exception 'wrong state'; end if;

        if (pos >= array_position(out_states, 'formed')
           and (NEW.content is NULL OR
                NEW.sender is NULL OR
                NEW.recipient is NULL OR
                NEW.creation_time is NULL))
        then return NULL; end if;
        
        if (pos >= array_position(out_states, 'encrypting')
           and NEW.dec_empl is NULL)
        then return NULL; end if;

        if (pos >= array_position(out_states, 'encrypted')
           and NEW.enc_content is NULL)
        then return NULL; end if;
    end if;

    if NEW.dec_empl is not NULL then
        dec_empl_departments = array(select department from Positions
        join Employee_Positions using(position_id)
        join Employees e using(employee_id)
        where e.employee_id=NEW.dec_empl);

        select array_position(dec_empl_departments, 'decryption') into department_array_pos;

        if department_array_pos is NULL or department_array_pos < 1 then
            return NULL;
        end if;
    end if;

    return NEW;
end;
$$;

alter function messagescheck() owner to s265066;

