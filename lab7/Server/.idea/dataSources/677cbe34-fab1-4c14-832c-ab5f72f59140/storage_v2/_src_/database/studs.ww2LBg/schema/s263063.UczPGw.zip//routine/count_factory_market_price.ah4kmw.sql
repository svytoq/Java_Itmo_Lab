create function count_factory_market_price(factoryid integer, currencyid integer) returns double precision
    language plpgsql
as
$$
declare avgFactoryPrice float;
    begin
        avgFactoryPrice = (select avg(price) from factory_listing where factory_id = factoryId
                                                                                        and currency_id = currencyId);
        return avgFactoryPrice;
    end;
$$;

alter function count_factory_market_price(integer, integer) owner to s263063;

