create function trigger_artifact_before_del() returns trigger
    language plpgsql
as
$$
BEGIN

    if (select count(*) from "Битва" a
    where a."Артефакт"=OLD."id")>0
        then delete from "Битва" where "Битва"."Артефакт"=OLD."id";
    end if;

    return OLD;
END;
$$;

alter function trigger_artifact_before_del() owner to s225133;

