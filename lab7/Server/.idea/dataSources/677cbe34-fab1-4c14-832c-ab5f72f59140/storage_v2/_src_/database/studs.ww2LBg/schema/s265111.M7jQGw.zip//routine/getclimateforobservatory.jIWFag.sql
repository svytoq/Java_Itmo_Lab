create function getclimateforobservatory(observatory_name text)
    returns TABLE(startts timestamp without time zone, endts timestamp without time zone, transparency_ real, homogeneity_ real, temperaturedrop_ real)
    language plpgsql
as
$$
DECLARE
    location_id_local int;
BEGIN
    select locationid into location_id_local from observatory where name = observatory_name;
    return query
        select starttimestamp, endtimestamp, transparency, homogeneity, temperaturedrop
        from astroclimate
                 inner join astroclimatetolocation on astroclimate.id = astroclimatetolocation.astroclimateid
                 inner join timestampinterval on timestampinterval.id = astroclimate.timestampintervalid
        where astroclimatetolocation.locationid = location_id_local;
END;
$$;

alter function getclimateforobservatory(text) owner to s265111;

