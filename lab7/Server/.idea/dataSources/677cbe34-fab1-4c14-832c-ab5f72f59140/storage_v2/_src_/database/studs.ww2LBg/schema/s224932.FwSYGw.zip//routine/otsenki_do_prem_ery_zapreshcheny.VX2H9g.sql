create function оценки_до_премьеры_запрещены() returns trigger
    language plpgsql
as
$$
DECLARE 
	премьера timestamp;
BEGIN
SELECT Фильмы.премьера INTO премьера FROM "Фильмы" WHERE ид = NEW.ид_фильма;
IF NEW.дата_время < премьера THEN
	RAISE EXCEPTION 'Оценка не может быть поставлена до премьеры фильма (премьера %)', премьера;
END IF;
RETURN NEW;
END;
$$;

alter function оценки_до_премьеры_запрещены() owner to s224932;

