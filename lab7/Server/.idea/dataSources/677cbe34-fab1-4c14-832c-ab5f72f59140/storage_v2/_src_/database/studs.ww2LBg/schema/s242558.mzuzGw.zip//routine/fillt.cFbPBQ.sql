create function fillt() returns void
    language sql
as
$$
    CREATE TRIGGER сезоны_BIR
    BEFORE INSERT ON сезоны
    FOR EACH ROW
    EXECUTE PROCEDURE season_ins_valid();
    
CREATE TRIGGER сезоны_BUP
    BEFORE UPDATE ON сезоны
    FOR EACH ROW
    EXECUTE PROCEDURE season_upd_valid();    

CREATE TRIGGER сезоны_AIR
    AFTER INSERT ON сезоны
    FOR EACH ROW
    EXECUTE PROCEDURE season_ins_succ();
    
CREATE TRIGGER сезоны_AUP
    AFTER UPDATE ON сезоны
    FOR EACH ROW
    EXECUTE PROCEDURE season_upd_succ();

CREATE TRIGGER стадии_BIR
    BEFORE INSERT ON стадии
    FOR EACH ROW
    EXECUTE PROCEDURE phase_ins_valid();    
    
CREATE TRIGGER стадии_BUP
    BEFORE UPDATE ON стадии
    FOR EACH ROW
    EXECUTE PROCEDURE phase_upd_valid();  

CREATE TRIGGER стадии_AUP
    AFTER UPDATE ON стадии
    FOR EACH ROW
    EXECUTE PROCEDURE phase_upd_succ();  
    
CREATE TRIGGER матчи_BIR
    BEFORE INSERT ON матчи
    FOR EACH ROW
    EXECUTE PROCEDURE game_ins_valid();  
    
CREATE TRIGGER матчи_AIR
    AFTER INSERT ON матчи
    FOR EACH ROW
    EXECUTE PROCEDURE game_ins_succ();

    $$;

alter function fillt() owner to s242558;

