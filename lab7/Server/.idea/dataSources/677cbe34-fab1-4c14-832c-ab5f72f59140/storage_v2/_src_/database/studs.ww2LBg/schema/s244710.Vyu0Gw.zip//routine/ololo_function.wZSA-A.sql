create function ololo_function() returns trigger
    language plpgsql
as
$$
BEGIN
  new."Код_места_оплаты_проезда" :=setval('Место_оплаты_пр_Код_места_оплат_seq',new."Код_места_оплаты_проезда");
  RETURN new;
end;
$$;

alter function ololo_function() owner to s244710;

