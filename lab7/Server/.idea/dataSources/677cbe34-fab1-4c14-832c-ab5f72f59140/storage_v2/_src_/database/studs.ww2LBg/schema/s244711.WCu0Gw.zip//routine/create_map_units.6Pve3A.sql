create function create_map_units(_map integer, amount integer) returns void
    language plpgsql
as
$$
DECLARE
BEGIN
	FOR i IN 1 .. amount LOOP
		INSERT INTO map_units
			(object, unit)
			VALUES
			(get_first_not_claimed_object(_map), get_first_not_claimed_unit());
	END LOOP;
END;
$$;

alter function create_map_units(integer, integer) owner to s244711;

