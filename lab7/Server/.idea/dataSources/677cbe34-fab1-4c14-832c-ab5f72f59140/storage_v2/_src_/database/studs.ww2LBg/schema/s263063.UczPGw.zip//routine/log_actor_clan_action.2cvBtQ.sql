create function log_actor_clan_action() returns trigger
    language plpgsql
as
$$
begin
        if old.clan_id is null and new.clan_id is not null then
            insert into actor_clan_log(actor_id, clan_id, action_type) values (new.id, new.clan_id, 'Join');
            return new;
        end if;

        if old.clan_id != new.clan_id then
            insert into actor_clan_log(actor_id, clan_id, action_type) values (new.id, new.clan_id, 'Join');
            insert into actor_clan_log(actor_id, clan_id, action_type) values (new.id, old.clan_id, 'Leave');
            return new;
        end if;

        if old.clan_id is not null and new.clan_id is null then
            insert into actor_clan_log(actor_id, clan_id, action_type) values (new.id, old.clan_id, 'Leave');
        end if;
        return new;
    end;
$$;

alter function log_actor_clan_action() owner to s263063;

