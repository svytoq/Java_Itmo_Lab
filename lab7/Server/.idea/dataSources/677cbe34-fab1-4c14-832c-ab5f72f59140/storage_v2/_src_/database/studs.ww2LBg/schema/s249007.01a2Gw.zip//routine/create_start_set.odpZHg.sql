create function create_start_set() returns trigger
    language plpgsql
as
$$
begin
    insert into page values (default,new.id,1,0);
    insert into page values (default,new.id,2,0);
    insert into page values (default,new.id,3,0);
    insert into page values (default,new.id,4,0);
    insert into page values (default,new.id,5,0);
    insert into rule_to_note values (new.id,1);
    insert into rule_to_note values (new.id,2);
    insert into rule_to_note values (new.id,3);
    new.count_of_pages := 5;
  return new;
  end;

$$;

alter function create_start_set() owner to s249007;

