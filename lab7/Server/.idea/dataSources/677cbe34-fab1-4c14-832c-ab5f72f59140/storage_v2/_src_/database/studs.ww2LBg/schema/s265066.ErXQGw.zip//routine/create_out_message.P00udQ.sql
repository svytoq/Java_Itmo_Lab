create function create_out_message(msg_text text, sender_id bigint, recipient_id bigint) returns s265066.messages
    language plpgsql
as
$$
declare
    new_id integer;
    dims dimensions[];
    msg Messages;
begin
    -- if not exists (select 1 from People where person_id=sender_id) or
    --    not exists (select 1 from People where person_id=recipient_id)
    -- then return NULL; end if;

    dims = array(select current_dim from People where person_id=sender_id or person_id=recipient_id);
    if array_length(dims, 1) = 2 then
        if dims[1] = dims[2] then 
        raise exception 'same dimension'; 
    end if;
    else 
        raise exception 'wrong sender or/and recipient id';
    end if;

    insert into Messages(sender, recipient, content, creation_time, msg_type, msg_state)
    values(sender_id, recipient_id, msg_text, now()::timestamp, 'out','formed')
    returning * into msg;
    return msg;
end;
$$;

alter function create_out_message(text, bigint, bigint) owner to s265066;

