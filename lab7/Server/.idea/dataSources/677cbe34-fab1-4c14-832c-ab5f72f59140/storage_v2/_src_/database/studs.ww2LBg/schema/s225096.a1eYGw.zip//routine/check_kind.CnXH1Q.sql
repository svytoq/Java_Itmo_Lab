create function check_kind(father_of integer, mother_of integer) returns integer
    language plpgsql
as
$$
DECLARE
	kind_father_of INTEGER;
	detachment_father_of INTEGER;
	father_is_alive BOOLEAN;
	kind_mother_of INTEGER;
	detachment_mother_of INTEGER;
	mother_is_alive BOOLEAN;
  kind_of INTEGER;
	habitat_of INTEGER;
	avg_speed INTEGER;
	avg_life INTEGER;
	tof type_of_food;
	one_of INTEGER;
BEGIN
	CREATE TEMP TABLE parents AS SELECT p.id_of_kind, p.gender, k.id_of_detachment, p.is_alive, k.type_of_food, p.passport_document
	FROM passenger p LEFT JOIN kind k USING (id_of_kind)
	WHERE father_of = p.passport_document OR mother_of = p.passport_document;
	SELECT id_of_kind, id_of_detachment, is_alive, type_of_food, passport_document INTO kind_father_of, detachment_father_of, father_is_alive, tof, one_of FROM parents WHERE gender = 'M';
	SELECT id_of_kind, id_of_detachment, is_alive INTO kind_mother_of, detachment_mother_of, mother_is_alive FROM parents WHERE gender = 'F';
	DROP TABLE parents;
  SELECT id_of_kind INTO kind_of FROM kind WHERE (kind_father_of = kind_of_father) AND (kind_mother_of = kind_of_mother);
	--checking to difference and existence in DB of kind
  IF (kind_father_of != kind_mother_of AND kind_father_of NOTNULL AND kind_mother_of NOTNULL AND detachment_father_of = detachment_mother_of AND father_is_alive AND mother_is_alive)
  THEN
			IF  (kind_of IS NULL)
				THEN
					CREATE TEMP TABLE avg_skills AS SELECT id, speed, life FROM skills WHERE kind_father_of = id OR kind_mother_of = id;
      		SELECT id_of_habitat INTO habitat_of FROM kind WHERE kind_father_of = id_of_kind;
					if father_of != one_of
					THEN
						mother_of := father_of;
						father_of := one_of;
					END IF;
    	  	INSERT INTO kind (name, id_of_detachment, kind_of_father, kind_of_mother, id_of_habitat, type_of_food)
        		VALUES (kind_father_of||'-'||kind_mother_of, detachment_father_of, kind_father_of, kind_mother_of, habitat_of, tof);
					INSERT INTO number_of_species (id_of_kind) VALUES ((SELECT id_of_kind FROM kind ORDER BY id_of_kind DESC LIMIT 1));
					SELECT ROUND(AVG(speed)), ROUND(AVG(life)) INTO avg_speed, avg_life FROM avg_skills GROUP BY id;
  	    	INSERT INTO skills (speed, life) VALUES (avg_speed, avg_life);
					DROP TABLE avg_skills;
					SELECT id_of_kind INTO kind_of FROM kind WHERE (kind_father_of = kind_of_father) AND (kind_mother_of = kind_of_mother);
  		END IF;
      ELSE
		kind_of := kind_father_of;
	END IF;
	IF kind_mother_of IS NULL OR kind_father_of IS NULL
		THEN
		RETURN -1;
	END IF;
	IF detachment_father_of != detachment_mother_of
		THEN
		RETURN -2;
	END IF;
	IF NOT father_is_alive OR NOT mother_is_alive
		THEN
			RETURN -3;
		END IF;
  RETURN kind_of;
END;
$$;

alter function check_kind(integer, integer) owner to s225096;

