create function show_available_captains()
    returns TABLE(cap_id integer, cap_name character varying, cap_exp integer, cap_company character varying, ship_id integer, ship_type character varying, ship_reqexp integer)
    language plpgsql
as
$$
BEGIN
        return query (SELECT captain.id AS cap_id, captain.name, captain.exp, captain.company_name, spaceship.id AS ship_id, spaceship.type, spaceship.req_exp FROM captain
		INNER JOIN spaceship ON captain.exp >= spaceship.req_exp);
    END
$$;

alter function show_available_captains() owner to s243900;

