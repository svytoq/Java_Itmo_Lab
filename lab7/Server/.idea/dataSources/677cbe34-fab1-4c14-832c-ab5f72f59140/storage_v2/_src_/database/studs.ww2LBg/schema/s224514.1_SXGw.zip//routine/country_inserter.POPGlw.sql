create function country_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	rand INTEGER;
	length integer;
	i INTEGER DEFAULT 1;
	i2 INTEGER DEFAULT 1;
	group_of_country group_of_team;
	name text;
	count integer default 0;
	chars text[] = '{a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z}';

BEGIN
	for i in 1..N loop

	rand = random();
	length = random() * 10;

	while count<length or name=null loop
		name = concat(chars[1+random()*(array_length(chars, 1)-1)], name);
		count = count+1;
	end loop;

  	i2 = i2 % 8;
	IF 		 i2 = 1 THEN group_of_country := 'A';
	ELSEIF i2 = 2 THEN group_of_country := 'B';
	ELSEIF i2 = 3 THEN group_of_country := 'C';
	ELSEIF i2 = 4 THEN group_of_country := 'D';
	ELSEIF i2 = 5 THEN group_of_country := 'E';
	ELSEIF i2 = 6 THEN group_of_country := 'F';
	ELSEIF i2 = 7 THEN group_of_country := 'G';
	ELSE group_of_country := 'H';
	END IF;

	insert into "СТРАНА_УЧАСТНИЦА" values(DEFAULT, initcap(name), group_of_country);
	name = NULL;
	group_of_country = NULL;
	count = 0;
 	i2 = i2 + 1;

	end loop;
END;
$$;

alter function country_inserter(integer) owner to s224514;

