create function tomuchworkers() returns trigger
    language plpgsql
as
$$
BEGIN
    if (SELECT count(*) from list_of_workers  where organization_id = NEW.organization_id)>= (SELECT work_places from organization
    WHERE id = NEW.organization_id) THEN
      RAISE NOTICE 'Работников итак много, иди отсюда... ';
      ROLLBACK;
      RETURN new;
    end if;
  RETURN new;
END;
$$;

alter function tomuchworkers() owner to s225099;

