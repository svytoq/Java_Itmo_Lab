create function "выдатьПорядковыйНомерУчастника"("н_соревнование_ид" integer) returns integer
    language plpgsql
as
$$
declare
            макс_номер int;
        begin
            макс_номер := (select coalesce(max(номер_уч), 0) from Зарег_Участники
                where соревнование_ид = н_соревнование_ид);
            return макс_номер + 1;
        end;
$$;

alter function "выдатьПорядковыйНомерУчастника"(integer) owner to s265091;

