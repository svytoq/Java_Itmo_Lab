create function zaselenie_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	i INTEGER DEFAULT 1;
	id_hotel integer default 1;
	date_zaseleniya timestamp default '2018-7-6 0:42:4';
	date_vyseleniya timestamp default '2018-7-8 0:42:4';
	id_strany integer default 1;
  maxNcountry integer;
	maxNhotel integer;
BEGIN
  Select count(ИД_СТРАНЫ) from СТРАНА_УЧАСТНИЦА into maxNcountry;
	Select count(ИД_ОТЕЛЯ) from ОТЕЛЬ into maxNhotel;
  if (N / 4)-1 > maxNcountry THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "СТРАНА_УЧАСТНИЦА"';
	END if;
	if (N / 4)-1 > maxNhotel THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "ОТЕЛЬ"';
	END if;
	for i in 1..N loop

		if i % 6 = 0 THEN
			id_strany = id_strany + 1;
			id_hotel = id_hotel + 1;
		End if;

		insert into "ЗАСЕЛЕНИЕ" values(DEFAULT, id_strany, id_hotel, date_zaseleniya, date_vyseleniya);

		date_zaseleniya = date_zaseleniya + interval '1 day';
		date_vyseleniya = date_vyseleniya + interval '1 day';
	end loop;
END;
$$;

alter function zaselenie_inserter(integer) owner to s224514;

