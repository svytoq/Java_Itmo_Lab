create function send_request() returns trigger
    language plpgsql
as
$$
DECLARE
    row            request_position%rowtype;
    new_order_id   integer;
    new_person     integer;
    new_snowmobile integer;
BEGIN
    INSERT INTO orders(to_Antarctida) VALUES (true) RETURNING new_order_id = order_id;
    FOR row IN SELECT *
               FROM request_position
               WHERE request_position.station = NEW.station_id
                 AND request_position.processed = false
        LOOP
            UPDATE row SET order_id = new_order_id, processed = true;
            IF row.type = order_type('medicines')
            THEN
                INSERT INTO order_position(type, medicines_type, amount, order_id)
                VALUES (row.type, row.medicines_type, row.amount, new_order_id);
            ELSIF row.type = order_type('equipment')
            THEN
                INSERT INTO order_position(type, equipment_type, order_id)
                VALUES (row.type, row.equipment_type, new_order_id);
            ELSIF row.type = order_type('person')
            THEN
                SELECT person_id
                INTO new_person
                FROM person
                WHERE arrival_date IS NULL
                  AND station IS NULL
                  AND on_station IS NULL
                LIMIT 1;
                INSERT INTO order_position(type, order_id, person_id) VALUES (row.type, new_order_id, new_person);
            ELSIF row.type = order_type('snowmobile')
            THEN
                SELECT snowmobile_id
                INTO new_snowmobile
                FROM snowmobile
                WHERE station IS NULL
                  AND on_station IS NULL
                LIMIT 1;
                INSERT INTO order_position(type, order_id, person_id) VALUES (row.type, new_order_id, new_person);
            ELSIF row.type = order_type('fuel')
            THEN
                INSERT INTO order_position(type, amount, order_id) VALUES (row.type, row.amount, new_order_id);
            ELSIF row.type = order_type('food')
            THEN
                INSERT INTO order_position(type, amount, order_id) VALUES (row.type, row.amount, new_order_id);
            END IF;
        END LOOP;
    UPDATE station SET send_request = false WHERE station_id = NEW.station_id;
    RETURN NEW;
END;
$$;

alter function send_request() owner to s265113;

