create function amount_of_films(c_id uuid) returns integer
    language plpgsql
as
$$
declare
    amount integer;
begin
    amount = (
        select count()
        from company c
                 join film f on f.company_id = c.id
        where c.id = c_id
    );
    return amount;
end;
$$;

alter function amount_of_films(uuid) owner to s264452;

