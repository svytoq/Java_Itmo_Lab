create function create_new_contract_for_actor(actorid integer, contracttype text, contractreward integer, currencyid integer, ratingamount integer, listingdescription text) returns void
    language plpgsql
as
$$
begin
    with insertListing as (
        insert into listing (seller, author_id, description) values ('Actor', actorId, listingDescription)
            returning listing_id as listingId
    )
    insert
    into contract_listing(type, reward, currency, rating_amount, listing_id)
    values (contractType::contract_type, contractReward, currencyId, ratingAmount,
            (select listingId from insertListing));
end;
$$;

alter function create_new_contract_for_actor(integer, text, integer, integer, integer, text) owner to s263063;

