create function create_new_item_listing_for_clan(clanid integer, itemid integer, itemprice integer, itemamount integer, currencyid integer, listingdescription text) returns void
    language plpgsql
as
$$
declare clanItemAmount int;
begin
    clanItemAmount = (select amount from clan_inventory where clan_id = clanId and item_id = itemAmount);
    if (clanItemAmount is null or clanItemAmount < itemAmount) then
        return;
    end if;
    update clan_inventory set amount = amount - itemAmount where clan_id = clanId and item_id = itemId;
    with insertListing as (
        insert into listing (seller, clan_id, description) values ('Clan', clanId, listingDescription)
            returning listing_id as listingId
    )
    insert
    into item_listing (listing_id, item_id, price, amount, currency)
    values ((select listingId from insertListing), itemId, itemPrice, itemAmount, currencyId);
end;
$$;

alter function create_new_item_listing_for_clan(integer, integer, integer, integer, integer, text) owner to s263063;

