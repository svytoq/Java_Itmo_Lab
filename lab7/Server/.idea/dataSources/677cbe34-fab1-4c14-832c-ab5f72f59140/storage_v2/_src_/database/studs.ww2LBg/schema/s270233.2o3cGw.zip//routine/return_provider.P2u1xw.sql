create function return_provider() returns trigger
    language plpgsql
as
$$
DECLARE
BEGIN
    SELECT factory_id FROM providers WHERE providers.id = NEW._from INTO NEW._to;
    NEW.ret_time = localtime;
    RETURN NEW;
END;
$$;

alter function return_provider() owner to s270233;

