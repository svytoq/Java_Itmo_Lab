create function add_buildings(count integer) returns void
    language plpgsql
as
$$
BEGIN
FOR i IN 1..count LOOP
INSERT INTO КОРПУС VALUES(i);
END LOOP;
END;
$$;

alter function add_buildings(integer) owner to s225141;

