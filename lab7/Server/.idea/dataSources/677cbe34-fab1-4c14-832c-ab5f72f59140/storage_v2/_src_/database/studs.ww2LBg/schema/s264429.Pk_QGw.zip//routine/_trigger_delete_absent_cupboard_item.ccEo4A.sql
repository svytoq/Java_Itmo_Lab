create function _trigger_delete_absent_cupboard_item() returns trigger
    language plpgsql
as
$$
begin
    if new.amount = 0 then
        delete from cupboard_item where cupboard_id = new.cupboard_id and product_id = new.product_id;
        return NULL; -- do not execute other triggers
    end if;
    return new;
end;
$$;

alter function _trigger_delete_absent_cupboard_item() owner to s264429;

