create function capute_sys(using_army_id integer) returns text
    language plpgsql
as
$$
declare
 caputing_sys int;
 using_army_fraction int;
begin

select space_objects.system, fraction_id
  into caputing_sys, using_army_fraction from army inner join space_objects 
  on army.planet_id = space_objects.id 
  where army.id = using_army_id limit 1;

if exists (select 1 from army inner join space_objects 
   on army.planet_id = space_objects.id 
   where army.fraction_id != using_army_fraction and space_objects.system = caputing_sys) then
return 'we can t capute this systems';
else
update stellar_systems set (fraction) = (using_army_fraction) where id = caputing_sys; 
return 'ok';
end if;
end;
$$;

alter function capute_sys(integer) owner to s264479;

