create function delete_coffee_score() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM оценка WHERE оценка.id = OLD.оценка;
END;
$$;

alter function delete_coffee_score() owner to s265082;

