create function lesson_attendance_update_at_lesson_end(in_student_id bigint) returns void
    language plpgsql
as
$$
begin
insert into lesson_attendances as la (student_id, lesson_id, classes_attended)
select in_student_id, n.lesson_id, 1
from notes n
inner join students s on n.id = s.stage_note_id and s.id = in_student_id
on conflict (student_id, lesson_id)
do update set classes_attended = la.classes_attended + 1;
end;
$$;

alter function lesson_attendance_update_at_lesson_end(bigint) owner to s244706;

