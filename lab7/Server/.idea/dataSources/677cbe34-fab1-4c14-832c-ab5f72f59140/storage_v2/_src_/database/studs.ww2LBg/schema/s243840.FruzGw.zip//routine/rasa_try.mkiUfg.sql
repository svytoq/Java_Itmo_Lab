create function раса_try() returns trigger
    language plpgsql
as
$$
BEGIN
/*
IF NEW.название IN (select * from название_расы) THEN
*/
IF ((NEW.k_дружелюбности>100) or (NEW.k_дружелюбности<0)) THEN 
/*Select 'lol error!';*/
RAISE NOTICE 'lol error1!';
RETURN null;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function раса_try() owner to s243840;

