create function check_workers_logs() returns trigger
    language plpgsql
as
$$
BEGIN
         IF (SELECT count(1) FROM СОТРУДНИКИ WHERE СОТРУДНИКИ.НОМЕР_ПАСПОРТА = NEW.ИД_СОТРУДНИК) IS NULL THEN
             RAISE EXCEPTION 'Такой сотрудник не найден';
         END IF;
         IF NEW.ЗАРПЛАТА_В_ЧАС < 0 THEN 
             RAISE EXCEPTION 'Когда плохо сотрудник не работал, зарплата не может отрицательной';
         END IF;
         RETURN NEW;
    END;
$$;

alter function check_workers_logs() owner to s242297;

