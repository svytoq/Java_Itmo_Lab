create function check_person_birthdate() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.дата_рождения >= CURRENT_DATE) THEN
		RAISE EXCEPTION 'Человек: дата рождения превышает текущую дату!';
	END IF;
	RETURN NEW;
END;
$$;

alter function check_person_birthdate() owner to s223758;

