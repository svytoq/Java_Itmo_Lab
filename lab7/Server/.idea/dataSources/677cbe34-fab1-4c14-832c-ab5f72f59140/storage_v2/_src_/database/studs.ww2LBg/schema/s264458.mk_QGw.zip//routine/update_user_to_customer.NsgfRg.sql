create function update_user_to_customer(id integer, user_id integer, level character varying, title character varying, wallet character varying) returns void
    language plpgsql
as
$$
BEGIN

  PERFORM insert_customer(id, user_id, level, title, wallet);
  RAISE NOTICE 'Заказчик создан';

END;

$$;

alter function update_user_to_customer(integer, integer, varchar, varchar, varchar) owner to s264458;

