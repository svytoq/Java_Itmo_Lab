create function del_senator() returns trigger
    language plpgsql
as
$$
BEGIN
         UPDATE ОТДЕЛЫ_СЕНАТА SET ГЛАВА = NULL WHERE ГЛАВА= OLD.ID_ЧЛЕНА;
  RETURN NULL;
END;
$$;

alter function del_senator() owner to s225081;

