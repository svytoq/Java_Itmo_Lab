create function check_carriage_position(train integer, position_in_train smallint) returns boolean
    language sql
as
$$
SELECT NOT EXISTS (
	SELECT * FROM carriages WHERE (train_id = train) AND (position = position_in_train)
)
$$;

alter function check_carriage_position(integer, smallint) owner to s208059;

