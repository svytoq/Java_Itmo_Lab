create function add_new_item_to_storage(item_name text, needed_amount integer, seller text, phone text, seller_email text, seller_bill text) returns boolean
    strict
    language plpgsql
as
$$
begin
    insert into "СКЛАД" ("НАЗВАНИЕ", "НЕОБХОДИМОЕ_КОЛ-ВО") values (item_name,needed_amount);
    insert into "ПОСТАВЩИКИ" ("НАЗВАНИЕ", "ТЕЛЕФОН", email, "НОМЕР_СЧЁТА")
        values
            (seller,phone,seller_email,seller_bill);
    return true;
end;
$$;

alter function add_new_item_to_storage(text, integer, text, text, text, text) owner to s265080;

