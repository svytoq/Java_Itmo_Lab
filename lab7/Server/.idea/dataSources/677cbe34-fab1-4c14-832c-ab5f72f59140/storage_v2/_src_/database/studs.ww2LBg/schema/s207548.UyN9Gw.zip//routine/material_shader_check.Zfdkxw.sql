create function material_shader_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (SELECT COUNT(*) FROM Shader WHERE Shader.ShaderProgramID = NEW.ShaderProgramID AND Shader."type" = 'Vertex') != 1 THEN
		RAISE EXCEPTION 'Material shader should have vertex shader';
	END IF;

	IF (SELECT COUNT(*) FROM Shader WHERE Shader.ShaderProgramID = NEW.ShaderProgramID AND Shader."type" = 'Fragment') != 1 THEN
		RAISE EXCEPTION 'Material shader should have fragment shader';
	END IF;

	IF (SELECT COUNT(*) FROM Shader WHERE Shader.ShaderProgramID = NEW.ShaderProgramID AND Shader."type" = 'TessEval')  != 0 THEN
		IF (SELECT COUNT(*) FROM Shader WHERE Shader.ShaderProgramID = NEW.ShaderProgramID AND Shader."type" = 'TessControl') = 0 THEN
		RAISE EXCEPTION 'Material shader should have TessControl shader because TessEval exists';
		END IF;
	END IF;

	RETURN NEW;
END;
$$;

alter function material_shader_check() owner to s207548;

