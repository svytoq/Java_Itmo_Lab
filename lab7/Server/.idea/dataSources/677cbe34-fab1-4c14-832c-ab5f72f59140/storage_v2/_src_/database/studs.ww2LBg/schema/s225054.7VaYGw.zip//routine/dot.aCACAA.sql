create function dot() returns void
    language plpgsql
as
$$
BEGIN
DROP TABLE ПЕРСОНАЖИ CASCADE;
DROP TABLE ГОДЫ_ОБУЧЕНИЯ CASCADE;
DROP TABLE ВАЖНЫЕ_СОБЫТИЯ CASCADE;
DROP TABLE ВОЛШЕБНЫЕ_ЖИВОТНЫЕ CASCADE;
DROP TABLE ВОЛШЕБНЫЕ_ИГРЫ CASCADE;
DROP TABLE ЗАКЛИНАНИЯ CASCADE;
DROP TABLE ЗАКЛИНАНИЯ_ПЕРСОНАЖЕЙ CASCADE;
DROP TABLE КРЕСТРАЖИ CASCADE;
DROP TABLE ЛОКАЦИИ CASCADE;
DROP TABLE ОРГАНИЗАЦИИ CASCADE;
DROP TABLE ПРОФЕССИИ CASCADE;
DROP TABLE УЧЕБНЫЕ_ПРЕДМЕТЫ CASCADE;
DROP TABLE ФАКУЛЬТЕТЫ CASCADE;
DROP TABLE ШКОЛЫ_МАГИИ CASCADE;

RETURN;
END;
$$;

alter function dot() owner to s225054;

