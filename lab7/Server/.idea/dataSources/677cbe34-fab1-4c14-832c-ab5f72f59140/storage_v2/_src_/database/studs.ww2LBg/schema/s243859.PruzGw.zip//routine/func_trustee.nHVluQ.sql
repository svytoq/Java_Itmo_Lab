create function func_trustee() returns trigger
    language plpgsql
as
$$
DECLARE 
  age integer = cast((current_date - (SELECT дата_рождения FROM абитуриент WHERE NEW.ид_лица = ид_абитуриента))/365 as integer);
  new_entrant_id_in_people bigint = (SELECT ид_человека FROM абитуриент WHERE NEW.ид_абитуриента = ид_абитуриента);
BEGIN
  IF NEW.ид_лица IN (SELECT ид_человека FROM абитуриент)
    THEN 
      IF NEW.ид_лица = new_entrant_id_in_people
        THEN RAISE NOTICE 'Абитуриент не может являтся дов. лицом самого себя'; RETURN NULL;
      END IF;
      IF age < 18
        THEN RAISE NOTICE 'Несовершеннолетний не может являтся дов. лицом'; RETURN NULL;
      END IF;
  END IF;
    RETURN NEW;
END;
$$;

alter function func_trustee() owner to s243859;

