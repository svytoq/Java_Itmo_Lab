create function cool_func(bd date) returns SETOF record
    language sql
as
$$
select ИД, ИМЯ, ПОЛ, ДАТА_РОЖДЕНИЯ from ЧЕЛОВЕК
where ДАТА_РОЖДЕНИЯ = bd;
$$;

alter function cool_func(date) owner to s242352;

