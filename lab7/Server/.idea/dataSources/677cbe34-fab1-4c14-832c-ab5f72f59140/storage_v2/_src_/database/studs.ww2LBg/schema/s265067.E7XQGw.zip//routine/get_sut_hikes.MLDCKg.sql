create function get_sut_hikes(vparticipant_id bigint)
    returns TABLE(num bigint, type_hike text, category bigint, com_ncom text, month text, numberdays bigint, place text, country text)
    language plpgsql
as
$$
BEGIN
      return query SELECT sugg_hikes.num, sugg_hikes.type_hike, sugg_hikes.category, sugg_hikes.com_ncom, sugg_hikes.month,sugg_hikes.number_days, sugg_hikes.name, sugg_hikes.country from sugg_hikes right join suitable_hikes on suitable_hikes.hike_id = sugg_hikes.num
             where suitable_hikes.wish_id in (select wishes.wish_id from wishes where wishes.participant_id=vparticipant_id);
  return next ;
    END
$$;

alter function get_sut_hikes(bigint) owner to s265067;

