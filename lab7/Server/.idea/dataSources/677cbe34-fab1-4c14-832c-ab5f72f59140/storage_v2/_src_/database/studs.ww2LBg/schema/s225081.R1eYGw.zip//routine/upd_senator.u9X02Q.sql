create function upd_senator() returns void
    language plpgsql
as
$$
DECLARE
  I INT;
  DEP INT;
  NUM INT;
BEGIN
  SELECT COUNT(*) FROM ОТДЕЛЫ_СЕНАТА INTO STRICT NUM;
  FOR I IN SELECT ID_ЧЛЕНА FROM ЧЛЕНЫ_СЕНАТА LOOP
    SELECT ОТДЕЛ FROM ЧЛЕНЫ_СЕНАТА WHERE ID_ЧЛЕНА = I INTO STRICT DEP;
    IF DEP ISNULL THEN DEP = RANDOM()*(NUM-1)+1::INT;
      UPDATE ЧЛЕНЫ_СЕНАТА SET ОТДЕЛ = DEP WHERE  ID_ЧЛЕНА=I;
    END IF ;
  END LOOP;
END;
$$;

alter function upd_senator() owner to s225081;

