create function check_firm_weap_tow() returns trigger
    language plpgsql
as
$$
DECLARE
  rec INTEGER;
  rec2 INTEGER;
BEGIN

  rec := (SELECT firm_tower.id_firm FROM firm_tower, firm_weapon WHERE NEW.id_tower = firm_tower.id_tower AND
  NEW.id_weapon = firm_weapon.id_weapon AND firm_tower.id_firm = firm_weapon.id_firm);
  IF rec is NULL THEN
    RAISE EXCEPTION 'Different firms';
  END IF;

  RETURN NEW;

END;
$$;

alter function check_firm_weap_tow() owner to s184884;

