create function create_goals(current_operation_id integer, should_attack boolean, should_catch boolean, should_free boolean) returns text
    language plpgsql
as
$$
declare
  begin
    if should_attack = 't' then
     insert into goals (operation_id, goal_description) values (current_operation_id, 'attack');
    end if;
    
    if should_catch = 't' then
     insert into goals (operation_id, goal_description) values (current_operation_id, 'catch');
    end if;
    
    if should_free = 't' then
     insert into goals (operation_id, goal_description) values (current_operation_id, 'free');
    end if;
    
    return 'Цели созданы';
  end;
$$;

alter function create_goals(integer, boolean, boolean, boolean) owner to s263148;

