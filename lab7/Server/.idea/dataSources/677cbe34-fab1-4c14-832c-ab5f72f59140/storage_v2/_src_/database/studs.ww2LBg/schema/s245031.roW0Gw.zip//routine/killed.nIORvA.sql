create function killed() returns trigger
    language plpgsql
as
$$
begin
if new.ОЗ<=0 then new.Жив:= false;
else new.Жив:=true;
end if;
return new;
end;
$$;

alter function killed() owner to s245031;

