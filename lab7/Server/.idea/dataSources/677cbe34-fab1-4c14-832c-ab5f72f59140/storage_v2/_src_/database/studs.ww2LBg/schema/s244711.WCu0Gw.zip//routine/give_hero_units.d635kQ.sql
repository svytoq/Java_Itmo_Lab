create function give_hero_units(_hero integer, amount integer) returns void
    language plpgsql
as
$$
DECLARE
	map_size int;
	reliefs_amount smallint;
	relief smallint;
	is_passable boolean;
	command text;
BEGIN
	FOR i IN 1 .. amount LOOP
		INSERT INTO hero_unit
			(hero, unit)
			VALUES
			(_hero, get_first_not_claimed_unit());
	END LOOP;
END;
$$;

alter function give_hero_units(integer, integer) owner to s244711;

