create function weapon_stats() returns trigger
    language plpgsql
as
$$
declare a int;
    declare b int;
    declare grip int;
    declare stock int;
    declare sight int;
    declare barrel int;
    declare mag int;
    declare gun int;
begin
    b := NEW.тип;

    grip := (select рукоять from "Чертежи_оружия" where id = NEW.схема);
    stock := (select приклад from "Чертежи_оружия" where id = NEW.схема);
    sight := (select прицел from "Чертежи_оружия" where id = NEW.схема);
    barrel := (select ствол from "Чертежи_оружия" where id = NEW.схема);
    mag := (select магазин from "Чертежи_оружия" where id = NEW.схема);
    gun := (select затвор from "Чертежи_оружия" where id = NEW.схема);

    case b
        when 0 then
            assert (select произв_пист from "Корпорации" where id = grip) = true, 'Данная корпорация не производит пистолеты';
            assert (select произв_пист from "Корпорации" where id = stock) = true, 'Данная корпорация не производит пистолеты';
            assert (select произв_пист from "Корпорации" where id = sight) = true, 'Данная корпорация не производит пистолеты';
            assert (select произв_пист from "Корпорации" where id = barrel) = true, 'Данная корпорация не производит пистолеты';
            assert (select произв_пист from "Корпорации" where id = mag) = true, 'Данная корпорация не производит пистолеты';
            assert (select произв_пист from "Корпорации" where id = gun) = true, 'Данная корпорация не производит пистолеты';
        when 1 then
            assert (select произв_пп from "Корпорации" where id = grip) = true, 'Данная корпорация не производит пистолеты-пулемёты';
            assert (select произв_пп from "Корпорации" where id = stock) = true, 'Данная корпорация не производит пистолеты-пулемёты';
            assert (select произв_пп from "Корпорации" where id = sight) = true, 'Данная корпорация не производит пистолеты-пулемёты';
            assert (select произв_пп from "Корпорации" where id = barrel) = true, 'Данная корпорация не производит пистолеты-пулемёты';
            assert (select произв_пп from "Корпорации" where id = mag) = true, 'Данная корпорация не производит пистолеты-пулемёты';
            assert (select произв_пп from "Корпорации" where id = gun) = true, 'Данная корпорация не производит пистолеты-пулемёты';
        when 2 then
            assert (select произв_дроб from "Корпорации" where id = grip) = true, 'Данная корпорация не производит дробовики';
            assert (select произв_дроб from "Корпорации" where id = stock) = true, 'Данная корпорация не производит дробовики';
            assert (select произв_дроб from "Корпорации" where id = sight) = true, 'Данная корпорация не производит дробовики';
            assert (select произв_дроб from "Корпорации" where id = barrel) = true, 'Данная корпорация не производит дробовики';
            assert (select произв_дроб from "Корпорации" where id = mag) = true, 'Данная корпорация не производит дробовики';
            assert (select произв_дроб from "Корпорации" where id = gun) = true, 'Данная корпорация не производит дробовики';
        when 3 then
            assert (select произв_рпг from "Корпорации" where id = grip) = true, 'Данная корпорация не производит ракетомёты';
            assert (select произв_рпг from "Корпорации" where id = stock) = true, 'Данная корпорация не производит ракетомёты';
            assert (select произв_рпг from "Корпорации" where id = sight) = true, 'Данная корпорация не производит ракетомёты';
            assert (select произв_рпг from "Корпорации" where id = barrel) = true, 'Данная корпорация не производит ракетомёты';
            assert (select произв_рпг from "Корпорации" where id = mag) = true, 'Данная корпорация не производит ракетомёты';
            assert (select произв_рпг from "Корпорации" where id = gun) = true, 'Данная корпорация не производит ракетомёты';
        when 4 then
            assert (select произв_шт_винт from "Корпорации" where id = grip) = true, 'Данная корпорация не производит штурмовые винтоки';
            assert (select произв_шт_винт from "Корпорации" where id = stock) = true, 'Данная корпорация не производит штурмовые винтоки';
            assert (select произв_шт_винт from "Корпорации" where id = sight) = true, 'Данная корпорация не производит штурмовые винтоки';
            assert (select произв_шт_винт from "Корпорации" where id = barrel) = true, 'Данная корпорация не производит штурмовые винтоки';
            assert (select произв_шт_винт from "Корпорации" where id = mag) = true, 'Данная корпорация не производит штурмовые винтоки';
            assert (select произв_шт_винт from "Корпорации" where id = gun) = true, 'Данная корпорация не производит штурмовые винтоки';
        when 5 then
            assert (select произв_сн_винт from "Корпорации" where id = grip) = true, 'Данная корпорация не производит снайперские винтовки';
            assert (select произв_сн_винт from "Корпорации" where id = stock) = true, 'Данная корпорация не производит снайперские винтовки';
            assert (select произв_сн_винт from "Корпорации" where id = sight) = true, 'Данная корпорация не производит снайперские винтовки';
            assert (select произв_сн_винт from "Корпорации" where id = barrel) = true, 'Данная корпорация не производит снайперские винтовки';
            assert (select произв_сн_винт from "Корпорации" where id = mag) = true, 'Данная корпорация не производит снайперские винтовки';
            assert (select произв_сн_винт from "Корпорации" where id = gun) = true, 'Данная корпорация не производит снайперские винтовки';
        end case;

    NEW.производитель := (select затвор from "Чертежи_оружия" where id = NEW.схема);
    NEW.урон := (select баз_ур from "Типы_пушек" where id = b);
    NEW.стих_урон := (select баз_стих_ур from "Типы_пушек" where id = b);
    NEW.скоростредьность := (select баз_скр from "Типы_пушек" where id = b);
    NEW.точность := (select баз_точность from "Типы_пушек" where id = b);
    NEW.скр_перез := (select баз_скр_перез from "Типы_пушек" where id = b);
    NEW.магазин := (select баз_маг from "Типы_пушек" where id = b);
    NEW.цена := (select баз_цена from "Типы_пушек" where id = b);
    a := NEW.производитель;

    case a
        when 0 then
            NEW.название := 'Звонок по связи';
            NEW.точность := NEW.точность * 1.2;
            NEW.урон := NEW.урон * 0.95;
        when 1 then NEW.название := 'Шершень';
                    NEW.урон := NEW.урон * 0.9;
                    NEW.скоростредьность := NEW.скоростредьность * 1.5;
        when 2 then NEW.название := 'Снайдер';
        when 3 then NEW.название := 'Детородный орган';
                    NEW.скр_перез := NEW.скр_перез * 0.9;
        when 4 then NEW.название := 'Вдоводел';
                    NEW.стихия := 0;
        when 5 then NEW.название := 'Дурошлёп';
        when 6 then NEW.название := 'Нюкем';
                    NEW.стихия := 4;
        when 7 then NEW.название := 'Размельчитель';
        end case;

    return new;
end;
$$;

alter function weapon_stats() owner to s245031;

