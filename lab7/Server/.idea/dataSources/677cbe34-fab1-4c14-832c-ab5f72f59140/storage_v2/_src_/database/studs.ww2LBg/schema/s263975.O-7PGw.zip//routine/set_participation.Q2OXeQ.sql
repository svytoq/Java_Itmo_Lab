create function set_participation() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO student_participation (stud_id, ev_id) VALUES (NEW.stud_id, NEW.ev_id) ON CONFLICT DO NOTHING;
END
$$;

alter function set_participation() owner to s263975;

