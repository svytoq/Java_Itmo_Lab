create function register_company(id integer, title character varying, inn character varying, kpp character varying, ogrn character varying, creation date, ipo boolean, wallet character varying) returns void
    language plpgsql
as
$$
BEGIN

  PERFORM insert_company(id, title, inn, kpp, ogrn, creation, NULL, ipo, wallet);
  RAISE NOTICE 'Компания зарегистрирована';

END;

$$;

alter function register_company(integer, varchar, varchar, varchar, varchar, date, boolean, varchar) owner to s264458;

