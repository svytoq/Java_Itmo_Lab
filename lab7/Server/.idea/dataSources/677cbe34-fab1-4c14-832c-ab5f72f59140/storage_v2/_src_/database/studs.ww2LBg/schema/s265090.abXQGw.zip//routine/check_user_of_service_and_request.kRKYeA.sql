create function check_user_of_service_and_request() returns trigger
    language plpgsql
as
$$
DECLARE
    USER_SER  INT := (SELECT user_id
                      FROM service
                      WHERE ID = NEW.service);
    USER_REQ INT := (SELECT AUTHOR
                     FROM request
                     WHERE ID = NEW.request);
BEGIN
    IF USER_SER != USER_REQ THEN
        RETURN NULL;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_user_of_service_and_request() owner to s265090;

