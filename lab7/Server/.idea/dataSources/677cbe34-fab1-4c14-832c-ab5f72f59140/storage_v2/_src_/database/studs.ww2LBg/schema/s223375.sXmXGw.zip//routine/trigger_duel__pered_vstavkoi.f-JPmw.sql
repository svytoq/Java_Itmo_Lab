create function триггер_дуэль_перед_вставкой() returns trigger
    language plpgsql
as
$$
DECLARE dead_id INTEGER;
BEGIN
  IF (SELECT count(*)
      FROM Самурай
      WHERE (NEW.Первый_самурай = id OR NEW.Второй_самурай = id) AND Жив = TRUE) < 2
  THEN
    RAISE EXCEPTION 'Самурай должен быть жив';
  END IF;
  IF NEW.Id_победивший IS NULL
  THEN
    IF (SELECT "Самурай"."Навык"
        FROM "Самурай"
        WHERE id = NEW.Первый_самурай) > (SELECT "Самурай"."Навык"
                                          FROM "Самурай"
                                          WHERE id = NEW.Второй_самурай)
    THEN
      NEW.Id_победивший = NEW.Первый_самурай;
    ELSE
      NEW.Id_победивший = NEW.Второй_самурай;
    END IF;
  END IF;
  IF NEW.Id_победивший = NEW.Первый_самурай
  THEN
    dead_id = NEW.Второй_самурай;
  ELSE
    dead_id = NEW.Первый_самурай;
  END IF;
  UPDATE Самурай
  SET Жив = FALSE
  WHERE id = dead_id;
  RETURN NEW;
END;
$$;

alter function триггер_дуэль_перед_вставкой() owner to s223375;

