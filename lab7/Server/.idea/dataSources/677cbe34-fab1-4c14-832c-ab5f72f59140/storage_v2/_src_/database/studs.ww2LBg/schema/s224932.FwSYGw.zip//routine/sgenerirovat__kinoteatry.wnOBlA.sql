create function сгенерировать_кинотеатры("число_на_сеть" integer) returns void
    language plpgsql
as
$$
DECLARE
        currId int = 0;
        row RECORD;
BEGIN
            SELECT MAX(ид) + 1 INTO currId FROM Кинотеатры;
            IF currId IS NULL THEN
                currId = 0;
            END IF;

        FOR row IN SELECT * FROM Сети LOOP
                FOR j IN 1 .. число_на_сеть LOOP
                        INSERT INTO Кинотеатры(ид, ид_сети, название, город, адрес)
                         VALUES (currId, row.ид, 'Кинотеатр ' || currId, 'СПб', 'Чкаловская д. ' || currId);
                        currId = currId + 1;
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_кинотеатры(integer) owner to s224932;

