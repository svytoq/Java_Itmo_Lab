create function check_payment() returns trigger
    language plpgsql
as
$$
BEGIN
IF (((SELECT ДЕНЬГИ FROM ПОЛЬЗОВАТЕЛИ WHERE ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПЛАТЕЛЬЩИКА) 
- (SELECT СТОИМОСТЬ FROM РАСЦЕНКИ WHERE ИД_РАСЦЕНКИ = NEW.ИД_РАСЦЕНКИ)) < 0) THEN
RAISE WARNING 'У пользователя не хватает денег для оплаты';
RETURN NULL;
ELSEIF (NEW.ИД_ПЛАТЕЛЬЩИКА = NEW.ИД_ПОЛУЧАТЕЛЯ) THEN
RAISE WARNING 'Плательщик и получатель должны быть разными людьми';
RETURN NULL;
ELSE
UPDATE ПОЛЬЗОВАТЕЛИ SET ДЕНЬГИ = ДЕНЬГИ - (SELECT СТОИМОСТЬ FROM РАСЦЕНКИ WHERE ИД_РАСЦЕНКИ = NEW.ИД_РАСЦЕНКИ) WHERE ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПЛАТЕЛЬЩИКА;
UPDATE ПОЛЬЗОВАТЕЛИ SET ДЕНЬГИ = ДЕНЬГИ + (SELECT СТОИМОСТЬ FROM РАСЦЕНКИ WHERE ИД_РАСЦЕНКИ = NEW.ИД_РАСЦЕНКИ) WHERE ИД_ПОЛЬЗОВАТЕЛЯ = NEW.ИД_ПОЛУЧАТЕЛЯ;
RETURN NEW;

END IF;
END;
$$;

alter function check_payment() owner to s242361;

