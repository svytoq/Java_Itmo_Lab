create function check_322() returns trigger
    language plpgsql
as
$$
BEGIN
   IF EXISTS (SELECT * FROM БК_Матчи
   WHERE NEW.ID_Команды = БК_Матчи.ID_Команды)
   THEN
      RAISE EXCEPTION 'Данный матч уже куплен другой мафиозной организацией';
END IF;
RETURN NEW;
END
$$;

alter function check_322() owner to s241870;

