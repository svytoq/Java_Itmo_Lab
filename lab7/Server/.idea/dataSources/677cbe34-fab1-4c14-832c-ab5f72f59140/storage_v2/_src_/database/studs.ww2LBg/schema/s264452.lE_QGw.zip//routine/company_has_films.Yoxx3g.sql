create function company_has_films(c_id uuid) returns boolean
    language plpgsql
as
$$
declare
    checker integer;
begin
    checker = (
        select count()
        from company c
                 join film f on f.company_id = c.id
        where c.id = c_id
    );

    if (checker > 0) then
        return true;
    else
        return false;
    end if;
end;
$$;

alter function company_has_films(uuid) owner to s264452;

