create function check_ing() returns trigger
    language plpgsql
as
$$
DECLARE
  name CHAR(100);
  ing INTEGER;
BEGIN

name = NEW.type;
if (NEW.h_h_id is NULL) 
THEN
RAISE EXCEPTION 'All ingridients should be attached to h_h';
end IF;

if (name NOT IN ('ribleaf', 'mandrake', 'bryonia', 'forktail', 'manticore', 'bruxa'))
THEN
RAISE EXCEPTION 'This ingridient is inappropriate for h_h';

ELSE

SELECT INTO ing count(ing_id) from ingridient WHERE type = name;
if (ing > 1)
THEN
RAISE EXCEPTION 'This type of ingridient already attached to h_h';
end if;
end IF;
  
   RETURN NEW;
END;
$$;

alter function check_ing() owner to s268428;

