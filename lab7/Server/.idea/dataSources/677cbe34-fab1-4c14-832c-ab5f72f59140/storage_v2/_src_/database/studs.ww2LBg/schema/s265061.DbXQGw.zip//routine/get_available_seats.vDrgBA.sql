create function get_available_seats(flightid integer)
    returns TABLE(num character varying, class s265061.seat_class)
    language plpgsql
as
$$
begin
        return query
                select seat.number, seat.class from seat
                left join ticket t on seat.id = t.seat_id
                where t.id is null and flight_id=flightId;

    end;
$$;

alter function get_available_seats(integer) owner to s265061;

