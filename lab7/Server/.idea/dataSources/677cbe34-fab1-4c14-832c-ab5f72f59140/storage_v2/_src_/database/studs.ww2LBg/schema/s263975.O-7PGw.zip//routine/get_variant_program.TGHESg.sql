create function get_variant_program(st_name character varying, st_surname character varying, st_birthday date)
    returns TABLE("Университет" text, "Программа" text, "Проходной балл" double precision, "Сумма баллов" double precision)
    language plpgsql
as
$$
declare
    st_id bigint;
begin
    st_id := (select student.id
              from student
              where student.name ~* st_name
                and student.surname ~* st_surname
                and student.birthday = st_birthday
              limit 1);

    return query
        select o.name,
               up.name,
               sum(min_points),
               sum(points)
        from university
                 join organization o on university.org_id = o.id
                 join university_programs up on university.org_id = up.univ_id
                 join university_program_subjects ups on up.id = ups.prog_id
                 join subject s on ups.subj_id = s.id
                 join event_subjects es on s.id = es.subj_id
                 join event e on es.ev_id = e.id
                 join exam e2 on e.id = e2.ev_id
                 join result r on e.id = r.ev_id
                 join student s2 on r.stud_id = s2.id
        where s2.id = st_id
        group by o.name, up.name
        having sum(min_points) <= sum(points);

end;
$$;

alter function get_variant_program(varchar, varchar, date) owner to s263975;

