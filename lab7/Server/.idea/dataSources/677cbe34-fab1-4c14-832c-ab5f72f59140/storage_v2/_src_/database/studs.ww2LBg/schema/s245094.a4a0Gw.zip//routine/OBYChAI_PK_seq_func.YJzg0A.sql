create function "ОБЫЧАЙ_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "ОБЫЧ_ИД" FROM "ОБЫЧАЙ");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."ОБЫЧ_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''ОБЫЧАЙ_ОБЫЧ_ИД_seq'', max("ОБЫЧ_ИД") + 1) FROM "ОБЫЧАЙ"';
                        NEW."ОБЫЧ_ИД" := max_id + 1;
                END IF; 
                RETURN NEW;
        END;
$$;

alter function "ОБЫЧАЙ_PK_seq_func"() owner to s245094;

