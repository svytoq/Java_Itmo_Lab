create function closeallvote() returns void
    language plpgsql
as
$$
DECLARE
    temp integer;
BEGIN
    temp = (SELECT MAX(ид) FROM сезоны);
    IF temp>1 THEN
        FOR i IN 1..temp LOOP
            PERFORM closeVote(i);
        END LOOP;
    END IF;
END;
$$;

alter function closeallvote() owner to s242558;

