create function trigger_buy_equipment() returns trigger
    language plpgsql
as
$$
declare
    equipment_price int;
    org_account_id int;
    org_money_amount int;
  begin
    select price into equipment_price 
    from equipments where id = new.equipment_id;
    
    select amount, id into org_money_amount, org_account_id from accounts
    where organization_id = new.organization_id;
    
    if equipment_price > org_money_amount then
      raise exception 'У вашей организации недостаточно средств';
    end if;
    
    update accounts set amount = amount - equipment_price where id = org_account_id;
    
    return new;
  end;
$$;

alter function trigger_buy_equipment() owner to s263148;

