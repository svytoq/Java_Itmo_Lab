create function buildid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('buildings_id_seq')!=NEW.ID THEN
NEW.ID=nextval('buildings_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function buildid() owner to s225102;

