create function stock_availability() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.availability IS NULL THEN
        NEW.availability := 0;
        RAISE NOTICE 'Supposed, that this trademark is empty!';
    END IF;
    RETURN NEW;
END;
$$;

alter function stock_availability() owner to s264475;

