create function repair_detail() returns trigger
    language plpgsql
as
$$
DECLARE
max_dur numeric(10, 2) = 0;
creature_money numeric(10, 2) = 0;
creature_money_shop numeric(10, 2) = 0;
BEGIN
SELECT money_amount INTO creature_money FROM creatures WHERE creature_id = NEW.client_id;
SELECT money_amount INTO creature_money_shop FROM creatures WHERE creature_id IN ( SELECT creature_id FROM creatures WHERE creature_id IN ( SELECT shop_id FROM SHOPS WHERE shop_id = NEW.shop_id ) );
SELECT max_durability INTO max_dur FROM details WHERE detail_id IN ( SELECT detail_id FROM ship_detiails WHERE ship_detail_id = NEW.ship_detail_id );
IF( creature_money < NEW.cost ) THEN
RAISE EXCEPTION 'У существа не хватает денег для ремонта детали';
END IF;
UPDATE details SET current_durability = max_dur WHERE detail_id IN ( SELECT detail_id FROM ship_detiails WHERE ship_detail_id = NEW.ship_detail_id );
UPDATE creatures SET money_amount = ( creature_money - NEW.cost ) WHERE creature_id = NEW.client_id;
UPDATE creatures SET money_amount = (creature_money_shop + NEW.cost) WHERE creature_id IN ( SELECT creature_id FROM creatures WHERE creature_id IN ( SELECT shop_id FROM SHOPS WHERE shop_id = NEW.shop_id ) );
RETURN NEW;
END;
$$;

alter function repair_detail() owner to s265078;

