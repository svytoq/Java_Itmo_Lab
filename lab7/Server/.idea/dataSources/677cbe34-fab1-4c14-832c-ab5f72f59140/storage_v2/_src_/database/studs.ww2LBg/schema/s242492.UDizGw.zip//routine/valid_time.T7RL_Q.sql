create function valid_time() returns trigger
    language plpgsql
as
$$
begin
if new.время_нач > new.время_кон then
raise exception 'время начала должно быть меньше времени конца!';
end if;
return new;
end
$$;

alter function valid_time() owner to s242492;

