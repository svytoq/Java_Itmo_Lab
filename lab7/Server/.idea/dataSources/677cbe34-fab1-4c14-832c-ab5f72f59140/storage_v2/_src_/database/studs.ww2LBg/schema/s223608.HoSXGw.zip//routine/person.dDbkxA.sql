create function person() returns trigger
    language plpgsql
as
$$
DECLARE
   	r person%rowtype;
	c integer;
BEGIN
if new.tf = false then
new.dod = CURRENT_DATE; 
end if;
END
$$;

alter function person() owner to s223608;

