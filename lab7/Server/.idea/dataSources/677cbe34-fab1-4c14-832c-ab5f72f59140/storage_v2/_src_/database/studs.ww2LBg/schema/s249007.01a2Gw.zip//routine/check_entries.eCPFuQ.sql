create function check_entries() returns trigger
    language plpgsql
as
$$
declare counter integer;
declare deathdate date;
declare is_god integer;
begin
  if (tg_op = 'INSERT') then
    select into deathdate deathday from person where id = new.person_id;
    if((select count(*) from note_killer where note_killer.person_id = new.person_id) != 0) then
      select into is_god id from note_killer where note_killer.person_id = new.person_id;
      if((select count(*) from god_of_death where god_of_death.killer_id = is_god) != 0) then
        raise exception 'You cannot kill the god';
      end if;
    end if;
    if(deathdate is null) then
      update person set deathday=new.death_date_time where person.id = new.person_id;
    end if;
    select into counter count(*) from entry where page_id = new.page_id;
    update page set count_of_entries = counter where id = new.page_id;
    return new;
  end if;
  if (tg_op = 'UPDATE' or tg_op = 'DELETE') then
    raise exception 'You can not change or delete entry';
    return null;
  end if;
end;
$$;

alter function check_entries() owner to s249007;

