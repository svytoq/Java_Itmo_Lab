create function perks_for_unitsid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('perks_for_units_id_seq')!=NEW.ID THEN
NEW.ID=nextval('perks_for_units_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function perks_for_unitsid() owner to s225102;

