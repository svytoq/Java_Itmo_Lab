create function delete_user() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM fairy_tale WHERE fairy_tale.id_author = OLD.id_user;
    DELETE FROM bookshelf WHERE bookshelf.id_user = OLD.id_user;
    RETURN NULL;
END;
$$;

alter function delete_user() owner to s264912;

