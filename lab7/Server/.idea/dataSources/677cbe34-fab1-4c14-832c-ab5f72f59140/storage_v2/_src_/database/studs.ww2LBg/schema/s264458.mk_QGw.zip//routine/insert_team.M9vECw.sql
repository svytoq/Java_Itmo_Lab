create function insert_team(id integer, company_id integer, title character varying, creation date, close_date date, process_type text, description text) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO team (id,
            company_id,
            title,
            creation,
            close_date,
            process_type,
            description)

  VALUES (insert_team.id,
      insert_team.company_id,
      insert_team.title,
      insert_team.creation,
      insert_team.close_date,
      insert_team.process_type,
      insert_team.description);
END;

$$;

alter function insert_team(integer, integer, varchar, date, date, text, text) owner to s264458;

