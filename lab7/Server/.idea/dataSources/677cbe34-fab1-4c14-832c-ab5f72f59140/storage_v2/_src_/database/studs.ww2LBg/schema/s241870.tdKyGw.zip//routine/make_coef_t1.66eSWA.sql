create function make_coef_t1(matchid integer) returns numeric
    language plpgsql
as
$$
declare
team1_b integer ;
team2_b integer ;
team1_coef decimal ;
begin
SELECT Команды.Бюджет into team1_b FROM Команды t
INNER JOIN Матчи m ON t.ID_Команды = m.ID_Команды1
WHERE m.ID_Матча = matchid;
SELECT Команды.Бюджет into team2_b FROM Команды t
INNER JOIN Матчи m ON t.ID_Команды = m.ID_Команды2
WHERE m.ID_Матча = matchid;
team1_coef =((team2_b/team1_b)*0.5)+1;
return team1_coef;
end
$$;

alter function make_coef_t1(integer) owner to s241870;

