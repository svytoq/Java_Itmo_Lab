create function fillhouse1() returns text
    language plpgsql
as
$$
DECLARE
name TEXT;
age REAL;
house INT;
BEGIN 
name = 'Maurice Webb';
age = 0.666;
house = 1;
FOR i IN 1..30 LOOP
EXECUTE format('INSERT INTO "Житель" ("Имя", "Кол-во лет в партии", "ID_Дома") VALUES($1,$2,$3);') using name, age, house;
END LOOP;
RETURN 'filled';
END
$$;

alter function fillhouse1() owner to s265082;

