create function stock() returns trigger
    language plpgsql
as
$$
BEGIN
IF (NEW.день_акции=date_part('day', now()) and NEW.месяц_акции=date_part('month', now()))
then RAISE exception 'Ошибка: нельзя добавить акцию в день акции';
else
RETURN NEW;
END IF;
END;
$$;

alter function stock() owner to s242419;

