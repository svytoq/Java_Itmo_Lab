create function get_distance(dino_name character varying, new_x numeric, new_y numeric) returns numeric
    stable
    language plpgsql
as
$$
declare
    old_x numeric;
    old_y numeric;
begin
    select hab.x_coord into old_x from habitat as hab join dinosaur as d using(habitat_id) where d.name like dino_name;
    select hab.y_coord into old_y from habitat as hab join dinosaur as d using(habitat_id) where d.name like dino_name;
    return |/((new_x - old_x)^2 - (new_y - old_y)^2);
end
$$;

alter function get_distance(varchar, numeric, numeric) owner to s263229;

