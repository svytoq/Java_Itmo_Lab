create function emptytube(tubeid integer) returns integer
    language plpgsql
as
$$
declare 
begin
UPDATE "Tube" set "PotionId" = null Where "Id" = tubeId;
return 1;
end;
$$;

alter function emptytube(integer) owner to s265097;

