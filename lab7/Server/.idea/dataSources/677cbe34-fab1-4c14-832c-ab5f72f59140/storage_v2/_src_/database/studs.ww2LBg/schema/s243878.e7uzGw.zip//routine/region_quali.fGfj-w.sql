create function region_quali(region integer)
    returns TABLE(team text, team_id integer, dpc_points integer)
    language plpgsql
as
$$
begin 
return query 
select team.name as team, team.id as team_id, team.dpc_points as dpc_points
from team 
where team.region_id = region
    and team.dpc_points>=0
    and team.id not in (select team.id from team where team.dpc_points>=0 order by team.dpc_points desc limit 8)
order by team.dpc_points desc
limit 8;
end
$$;

alter function region_quali(integer) owner to s243878;

