create function fx_rndstr(n integer) returns character varying
    language plpgsql
as
$$
DECLARE
    count1 integer;
    retValue varchar;
BEGIN
    retValue := '';
    FOR count1 IN 1..n LOOP
        retValue:=retValue || chr( (floor(random()*26+65))::integer );
    END LOOP;
    RETURN retValue;
END;
$$;

alter function fx_rndstr(integer) owner to s243135;

