create function count_earnings1() returns trigger
    language plpgsql
as
$$
declare
earnings1 integer;
gain_earn integer;

BEGIN
Gain_earn = (select gain.earnings from gain where new.gain_id = gain.gain_id);
Earnings1 = (new.earnings - old.earnings) + gain_earn;
Update gain SET gain_id = new.gain_id, earnings = earnings1 WHERE gain_id = new.gain_id;
Return NULL;
end;
$$;

alter function count_earnings1() owner to s265447;

