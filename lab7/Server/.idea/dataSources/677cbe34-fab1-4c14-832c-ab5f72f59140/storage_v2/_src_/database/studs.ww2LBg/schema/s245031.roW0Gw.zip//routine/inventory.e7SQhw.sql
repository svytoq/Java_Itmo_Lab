create function inventory() returns trigger
    language plpgsql
as
$$
begin

update Характеристики
set СИЛ=СИЛ-coalesce(Эффекты.СИЛ_бнс, 0), 
ВСП=ВСП-coalesce(Эффекты.ВСП_бнс, 0), 
ВНС=ВНС-coalesce(Эффекты.ВНС_бнс, 0), 
ИНТ=ИНТ-coalesce(Эффекты.ИНТ_бнс, 0), 
ХАР=ХАР-coalesce(Эффекты.ХАР_бнс, 0), 
ЛВК=ЛВК-coalesce(Эффекты.ЛВК_бнс, 0), 
УДЧ=УДЧ-coalesce(Эффекты.УДЧ_бнс, 0),
Базовая_защита=Базовая_защита-Броня.защита
from  Броня
left join Эффекты
on Броня.эффект=Эффекты.id 
where Характеристики.id in (
select Люди.Характеристики from Люди
where old.id=Люди.Инвентарь)
and Броня.id=old.носимая_броня;

update Характеристики
set СИЛ=СИЛ+coalesce(Эффекты.СИЛ_бнс, 0),
ВСП=ВСП+coalesce(Эффекты.ВСП_бнс, 0), 
ВНС=ВНС+coalesce(Эффекты.ВНС_бнс, 0), 
ИНТ=ИНТ+coalesce(Эффекты.ИНТ_бнс, 0), 
ХАР=ХАР+coalesce(Эффекты.ХАР_бнс, 0), 
ЛВК=ЛВК+coalesce(Эффекты.ЛВК_бнс, 0), 
УДЧ=УДЧ+coalesce(Эффекты.УДЧ_бнс, 0),
Базовая_защита=Базовая_защита+Броня.защита
from  Броня
left join Эффекты
on Броня.эффект=Эффекты.id 
where Характеристики.id in (
select Люди.Характеристики from Люди
where new.id=Люди.Инвентарь)
and Броня.id=new.носимая_броня;
return new;

end;
$$;

alter function inventory() owner to s245031;

