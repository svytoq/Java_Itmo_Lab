create function random_int() returns integer
    language sql
as
$$
select (random() * 20)::int
$$;

alter function random_int() owner to s269380;

