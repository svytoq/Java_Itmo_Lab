create function "ЗАКАЗ_ИД_ОБН"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ЗАКАЗ_ИД!=NEW.ЗАКАЗ_ИД THEN
NEW.ЗАКАЗ_ИД=OLD.ЗАКАЗ_ИД;
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function "ЗАКАЗ_ИД_ОБН"() owner to s242456;

