create function insert_people() returns void
    language plpgsql
as
$$
DECLARE
    count INTEGER = 0;
    sex char;
  BEGIN
    LOOP
      IF (random()>0.5)
        THEN sex = 'M';
        ELSE sex = 'F';
      END IF;
      INSERT INTO people VALUES (DEFAULT, insert_random(), insert_random(), sex, '5/12/1998', null, DEFAULT, trunc(random()*100) + 1);
      count = count + 1;
      EXIT WHEN count = 100000;
    END LOOP;
  END;
$$;

alter function insert_people() owner to s225107;

