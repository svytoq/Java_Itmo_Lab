create function people() returns trigger
    language plpgsql
as
$$
BEGIN
        if NEW.Возраст not between 2 and 120 then
            Raise exception 'Возраст not between 2 .. 120';
        end if;
        RETURN NEW;
    END;
$$;

alter function people() owner to s269380;

