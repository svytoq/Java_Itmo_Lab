create function catch_criminal(hunter integer, criminal integer) returns text
    language plpgsql
as
$$
DECLARE
    is_success boolean;
  BEGIN
    INSERT INTO Attempt_to_catch (hunter_id, criminal_id) VALUES (hunter, criminal);
    
    SELECT a.is_success INTO is_success FROM Attempt_to_catch as a 
    WHERE a.hunter_id = hunter AND a.criminal_id = criminal;
    
    IF is_success = 't' THEN
      RETURN 'You`ve catched criminal. Congrats!';
    ELSE
      RETURN 'You`ve missed criminal((';
    END IF;
  END;
$$;

alter function catch_criminal(integer, integer) owner to s263081;

