create function forma_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	rand INTEGER;
	length integer;
	i INTEGER DEFAULT 1;
	count integer default 0;
	chars text[] = '{a,b,c,d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,y,z}';
	colour text;
	id_strany integer default 1;
	nomer integer default 1;
  maxN integer;

BEGIN
  Select count(ИД_СТРАНЫ) from СТРАНА_УЧАСТНИЦА into maxN;
  if (N % 3)-1 > maxN THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "СТРАНА_УЧАСТНИЦА"';
	END if;

	for i in 1..N loop

		rand = random();
		length = random() * 10;

		while count<length or colour=null loop
			colour = concat(chars[1+random()*(array_length(chars, 1)-1)], colour);
			count = count+1;
		end loop;

    if nomer % 4 = 0 THEN
      id_strany = id_strany + 1;
      nomer = 1;
    END IF;

		insert into "ФОРМА_ИГРОКОВ" values(DEFAULT, id_strany, initcap(colour), nomer);
		colour = NULL;
		count = 0;
    nomer = nomer+1;
	end loop;
END;
$$;

alter function forma_inserter(integer) owner to s224514;

