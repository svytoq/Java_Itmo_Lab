create function stock_msg_last() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.availability = 0 THEN
        RAISE NOTICE 'Bought the last pack of treatment!';
    END IF;
    RETURN NEW;
END;
$$;

alter function stock_msg_last() owner to s264475;

