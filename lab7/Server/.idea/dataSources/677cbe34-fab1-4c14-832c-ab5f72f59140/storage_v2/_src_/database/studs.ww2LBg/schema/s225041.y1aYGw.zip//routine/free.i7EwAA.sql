create function free()
    returns TABLE(id integer, fullname character varying)
    language plpgsql
as
$$
DECLARE
		freed record;
			BEGIN
				FOR freed IN (
					SELECT PRISONER.id, PRISONER.fullName 
					FROM PRISONER WHERE freedom<=current_date
				)
				LOOP
					id = freed.id;
					fullName = freed.fullName;
					DELETE FROM PRISONER WHERE PRISONER.id = freed.id;
					RETURN NEXT;
				END LOOP;
			END;
$$;

alter function free() owner to s225041;

