create function get_service_suggestions_in_dormitory(dormitory_id integer)
    returns TABLE(id integer, name character varying, description character varying, status s265087."STATUS", creation_date timestamp with time zone, author integer, service integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT SUGGESTION.ID          as ID,
                        SUGGESTION.NAME        as SUGGESTION_NAME,
                        SUGGESTION.DESCRIPTION as SUGGESTION_DESCRIPTION,
                        SUGGESTION.STATUS,
                        SUGGESTION.CREATION_DATE,
                        SUGGESTION.AUTHOR,
                        SERVICE.ID             as SERVICE
                 FROM USERS
                          JOIN DORMITORY ON USERS.DORMITORY = DORMITORY.ID
                          JOIN SUGGESTION ON SUGGESTION.AUTHOR = USERS.ID
                          JOIN SERVICE_SUGGESTION ON SERVICE_SUGGESTION.ID = SUGGESTION.ID
                          JOIN SERVICE ON SERVICE_SUGGESTION.SERVICE = SERVICE.ID
                 WHERE DORMITORY.ID = DORMITORY_ID;
END;
$$;

alter function get_service_suggestions_in_dormitory(integer) owner to s265087;

