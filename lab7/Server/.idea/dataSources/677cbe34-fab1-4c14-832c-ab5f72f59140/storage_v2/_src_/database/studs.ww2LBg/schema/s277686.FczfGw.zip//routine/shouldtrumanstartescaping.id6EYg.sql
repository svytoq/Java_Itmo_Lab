create function shouldtrumanstartescaping() returns boolean
    language plpgsql
as
$$
BEGIN
IF(SELECT level_awareness >= 10 FROM  truman_status)
THEN UPDATE Truman_status SET is_escaping = TRUE;
ELSE UPDATE Truman_status SET is_escaping = FALSE;
END IF;
IF(SELECT level_awareness >= 10 FROM  truman_status)
THEN RETURN TRUE;
ELSE RETURN FALSE;
END IF;
END;
$$;

alter function shouldtrumanstartescaping() owner to s277686;

