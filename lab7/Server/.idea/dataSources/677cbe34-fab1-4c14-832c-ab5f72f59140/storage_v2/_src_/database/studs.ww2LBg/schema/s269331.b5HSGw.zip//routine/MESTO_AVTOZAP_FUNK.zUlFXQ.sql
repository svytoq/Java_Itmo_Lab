create function "МЕСТО_АВТОЗАП_ФУНК"() returns trigger
    language plpgsql
as
$$
BEGIN

IF NEW.МЕСТО IS NULL THEN
NEW.МЕСТО = 'Сделать самому';
END IF;

RETURN NEW;
END;
$$;

alter function "МЕСТО_АВТОЗАП_ФУНК"() owner to s269331;

