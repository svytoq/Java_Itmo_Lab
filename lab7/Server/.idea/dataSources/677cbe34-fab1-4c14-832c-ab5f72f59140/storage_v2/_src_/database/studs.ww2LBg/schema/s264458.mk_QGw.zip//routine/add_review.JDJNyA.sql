create function add_review(id integer, project_id integer, user_id integer, stars integer, description text, time_value timestamp without time zone) returns void
    language plpgsql
as
$$
BEGIN

  PERFORM insert_review(id, project_id, user_id, stars, description, time_value);

END;

$$;

alter function add_review(integer, integer, integer, integer, text, timestamp) owner to s264458;

