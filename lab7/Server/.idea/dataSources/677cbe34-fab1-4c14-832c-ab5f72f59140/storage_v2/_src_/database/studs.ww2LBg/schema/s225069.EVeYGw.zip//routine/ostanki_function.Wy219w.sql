create function ostanki_function() returns trigger
    language plpgsql
as
$$
begin
new.Remain_ID=nextval('Remains_Remain_ID_seq');
return new;
end;
$$;

alter function ostanki_function() owner to s225069;

