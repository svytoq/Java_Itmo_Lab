create function getarmy(id bigint) returns SETOF s251091."АРМИЯ"
    language sql
as
$$
select * from АРМИЯ where АРМИЯ.ID = $1;
$$;

alter function getarmy(bigint) owner to s251091;

