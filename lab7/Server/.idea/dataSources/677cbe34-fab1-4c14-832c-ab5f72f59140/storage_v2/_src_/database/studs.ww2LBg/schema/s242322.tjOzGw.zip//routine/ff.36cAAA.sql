create function ff() returns boolean
    language plpgsql
as
$$
begin
create table aa(gh integer);
select 1/0;
end;
$$;

alter function ff() owner to s242322;

