create function random_string() returns character varying
    strict
    language plpgsql
as
$$
DECLARE
  generated_string varchar(30);
BEGIN
  SELECT array_to_string(ARRAY(SELECT chr((97 + round(random() * 25)) :: integer) 
  INTO generated_string FROM generate_series(1,15)), '');
  RETURN generated_string;
END;
$$;

alter function random_string() owner to s263081;

