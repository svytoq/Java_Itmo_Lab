create function current_player_achievements(player_name text)
    returns TABLE(name text, achievement_date date, condition text)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT achievements.name, achievements.achieving_date, achievements.conditions FROM player JOIN achievements ON player.id=achievements.player_id WHERE player.name=player_name;
END;
$$;

alter function current_player_achievements(text) owner to s225102;

