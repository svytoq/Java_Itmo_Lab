create function order_plan() returns trigger
    language plpgsql
as
$$
DECLARE
 id_ingr integer;
 mass float;
 id_loc integer;
 finish boolean;
 end_date date;
 having_mass float;
 end_persent float;
 snum integer;
  BEGIN
SELECT MAX(НОМЕР_В_ОЧЕРЕДИ) INTO snum FROM СТАТУС_ЗАКАЗА;
IF snum IS NULL THEN snum = 1;
END IF;  

FOR id_ingr, mass IN SELECT ИД_ИНГРЕДИЕНТА, МАССА FROM СОСТАВ WHERE ИД_ЛЕКАРСТВА = NEW.ИД_ЛЕКАРСТВА
LOOP
FOR having_mass IN SELECT МАССА  FROM НАЛИЧИЕ_ИНГРЕДИЕНТОВ WHERE (ИД_ИНГРЕДИЕНТА = id_ingr) AND (ГОДЕН_ДО > current_date) AND ИСПОЛЬЗОВАНО = FALSE
LOOP
IF (mass > 0) THEN
mass := mass - having_mass;
UPDATE НАЛИЧИЕ_ИНГРЕДИЕНТОВ SET ИСПОЛЬЗОВАНО = TRUE WHERE (ИД_ИНГРЕДИЕНТА = id_ingr) AND (МАССА = having_mass);
END IF;
END LOOP; 

IF (mass > 0) THEN
finish := FALSE; 
SELECT ИД_ЛОКАЦИИ INTO id_loc FROM get_loc(id_ingr, mass);
IF (snum <> 1) THEN 
end_date := (SELECT MAX(ДАТА_ЗАВЕРШЕНИЯ) FROM СТАТУС_ЗАКАЗА) + round((SELECT MIN(distance) FROM get_loc(id_ingr, mass))/(select КОРАБЛЬ.СРЕДНЯЯ_СКОРОСТЬ from КОРАБЛЬ))::integer;
ELSE end_date := current_date + round((SELECT MIN(distance) FROM get_loc(id_ingr, mass))/(select КОРАБЛЬ.СРЕДНЯЯ_СКОРОСТЬ from КОРАБЛЬ))::integer;
END IF;
ELSE finish := TRUE; end_date := current_date;
END IF;

INSERT INTO ПЛАН_МАРШРУТ VALUES (NEW.ИД_ЗАКАЗА, id_ingr, id_loc, finish, end_date, mass);
END LOOP;
 
end_persent := (SELECT COUNT(ИД_ЗАКАЗА) FROM ПЛАН_МАРШРУТ WHERE (ИД_ЗАКАЗА = NEW.ИД_ЗАКАЗА) AND (СОБРАНО = TRUE)) / 
(SELECT COUNT(ИД_ЗАКАЗА) FROM ПЛАН_МАРШРУТ WHERE (ИД_ЗАКАЗА = NEW.ИД_ЗАКАЗА));
SELECT MAX(ДАТА_ЗАВЕРШЕНИЯ)  INTO end_date  FROM ПЛАН_МАРШРУТ WHERE ИД_ЗАКАЗА = NEW.ИД_ЗАКАЗА;

INSERT INTO СТАТУС_ЗАКАЗА VALUES (NEW.ИД_ЗАКАЗА, snum+1, end_persent, end_date);
RETURN NEW;
  END;
$$;

alter function order_plan() owner to s242425;

