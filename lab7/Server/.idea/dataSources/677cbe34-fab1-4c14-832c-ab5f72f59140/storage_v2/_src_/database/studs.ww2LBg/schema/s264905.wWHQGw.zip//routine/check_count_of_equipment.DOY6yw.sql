create function check_count_of_equipment() returns trigger
    language plpgsql
as
$$
DECLARE
	count_of integer;
BEGIN
	IF (NEW.name <> 'АВТО') THEN
		SELECT COUNT(*) INTO count_of FROM Equipment WHERE name = NEW.name;
		IF count_of = NEW.count THEN
			RETURN NEW;
		ELSE
			RAISE 'Количество оборудования не соответствует количеству в таблицу Equipment';
		END IF;
	ELSE 
		SELECT COUNT(*) INTO count_of FROM Auto;
		IF count_of = NEW.count THEN
			RETURN NEW;
		ELSE
			RAISE 'Количество авто не соответствует количеству в таблицу Auto';
		END IF;
	END IF;
    RETURN NEW;
END;
$$;

alter function check_count_of_equipment() owner to s264905;

