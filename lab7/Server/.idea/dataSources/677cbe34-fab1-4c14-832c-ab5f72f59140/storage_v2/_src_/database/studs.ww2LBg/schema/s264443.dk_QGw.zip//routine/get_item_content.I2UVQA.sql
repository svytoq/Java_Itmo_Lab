create function get_item_content(main_item_id integer)
    returns TABLE(name character varying, length real, width real, height real, color integer, material character varying, part_count integer)
    language plpgsql
as
$$
BEGIN
        RETURN QUERY
            SELECT p.name, p.length, p.width, p.height, p.color, p.material, p.part_count
            FROM item_part p
            WHERE p.item_id = main_item_id;
    END;
$$;

alter function get_item_content(integer) owner to s264443;

