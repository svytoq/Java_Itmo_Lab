create function check_cases(championship_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    IF NOT EXISTS(SELECT case_id
                  FROM championship_case
                  WHERE championship_case.championship_id = check_cases.championship_id) THEN
        RAISE EXCEPTION 'Championship should contains at least one platform';
    END IF;

    RETURN true;
END;
$$;

alter function check_cases(integer) owner to s264448;

