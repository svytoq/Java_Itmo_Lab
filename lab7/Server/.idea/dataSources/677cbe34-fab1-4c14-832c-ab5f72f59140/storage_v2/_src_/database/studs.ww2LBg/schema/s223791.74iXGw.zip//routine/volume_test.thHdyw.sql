create function volume_test() returns text
    language plpgsql
as
$$
DECLARE
                count_children INTEGER = (SELECT COUNT(*) FROM children);
            BEGIN
                IF count_children < 100000 THEN
                    PERFORM add_children(100000 - count_children, CAST('1960-01-01' AS DATE));
                END IF;
                IF (SELECT pg_database_size('postgres')) < 150000000 THEN
                    RETURN 'test passed';
                ELSE
                    RETURN 'test failed';
                END IF;
            END;
$$;

alter function volume_test() owner to s223791;

