create function get_abonent_and_contract_and_tariff()
    returns TABLE(surname character varying, name character varying, patronymic character varying, passport character varying, phone character varying, connum character varying, balance integer, tariff text)
    stable
    language plpgsql
as
$$
begin
    RETURN QUERY SELECT A.SURNAME,
                        A.NAME,
                        A.PATRONYMIC,
                        A.passport,
                        A.phone,
                        c.number,
                        c.balance,
                        t.NAME
                 FROM abonent AS A
                          join contract c on A.id = c.abonent_id
                          JOIN tariff t on c.tariff_id = t.id;
end;
$$;

alter function get_abonent_and_contract_and_tariff() owner to s265109;

