
BEGIN
IF (NEW.Date >= CURRENT_TIMESTAMP AND NEW.Time >= CURRENT_TIMESTAMP)  THEN
RAISE EXCEPTION 'Raids: Date and Time are bigger then the current date and time!';
END IF;
IF (NEW.Date >= CURRENT_TIMESTAMP) THEN
RAISE EXCEPTION 'Raids: Date is bigger then the current date!';
END IF;
IF (NEW.Time >= CURRENT_TIMESTAMP) THEN
RAISE EXCEPTION 'Raids: Time is bigger then the current Time!';
END IF;
RETURN NEW;
END;
