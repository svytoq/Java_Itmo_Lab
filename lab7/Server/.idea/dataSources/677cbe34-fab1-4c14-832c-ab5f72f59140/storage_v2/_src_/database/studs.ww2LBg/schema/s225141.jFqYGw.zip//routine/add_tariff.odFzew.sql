create function add_tariff() returns trigger
    language plpgsql
as
$$
DECLARE
counts integer := 0;
IsExist integer := 1;
BEGIN
SELECT COUNT(*) INTO counts FROM ИНТЕРНЕТ_ТАРИФ;
WHILE IsExist != 0 LOOP
counts := counts + 1;
SELECT COUNT(*) INTO IsExist FROM ИНТЕРНЕТ_ТАРИФ WHERE ИД = counts;
END LOOP;
NEW.ИД := counts;
RETURN NEW;
END
$$;

alter function add_tariff() owner to s225141;

