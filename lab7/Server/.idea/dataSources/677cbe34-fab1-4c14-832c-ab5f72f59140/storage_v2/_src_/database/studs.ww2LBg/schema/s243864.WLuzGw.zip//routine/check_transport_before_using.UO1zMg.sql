create function check_transport_before_using() returns trigger
    language plpgsql
as
$$
DECLARE
    required_access_level SMALLINT;
    transport_availability BOOLEAN;
    BEGIN
    transport_availability := (SELECT availability FROM transport WHERE id = NEW.transport_id);
    required_access_level := (SELECT required_access_lvl FROM transport WHERE id = NEW.transport_id);
    IF NEW.access_level < required_access_level THEN
      RAISE EXCEPTION 'Employee''s admission level must be higher to access this transport.';
    ELSE IF (transport_availability = FALSE) THEN
      RAISE EXCEPTION 'This transport is not available right now. Try again later.';
      ELSE
        UPDATE transport SET availability = FALSE WHERE id = NEW.transport_id;
      END IF;
    END IF;
    RETURN NEW;
  END;
$$;

alter function check_transport_before_using() owner to s243864;

