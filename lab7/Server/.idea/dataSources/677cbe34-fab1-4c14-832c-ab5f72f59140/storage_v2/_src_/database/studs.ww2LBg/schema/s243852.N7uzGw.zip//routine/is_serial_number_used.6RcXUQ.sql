create function is_serial_number_used(f_serial_number character varying) returns boolean
    language plpgsql
as
$$
DECLARE
  serial_number_from_db varchar(11) = (SELECT serial_number
                                       FROM app_user
                                       where app_user.serial_number = f_serial_number);
BEGIN
  if serial_number_from_db IS NOT NULL THEN
    return true;
  end if;
  return false;
END;
$$;

alter function is_serial_number_used(varchar) owner to s243852;

