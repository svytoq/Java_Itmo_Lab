create function breakdown_solved() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (TG_OP = 'INSERT') THEN
        UPDATE "Breakdowns" set is_solved=true where id=NEW.id_breakdown;
        RETURN NEW;
    ELSIF (TG_OP = 'DELETE') THEN
        UPDATE "Breakdowns" set is_solved=true where id=NEW.id_breakdown;
        RETURN OLD;
    END IF;
    return null;
END;
$$;

alter function breakdown_solved() owner to s264434;

