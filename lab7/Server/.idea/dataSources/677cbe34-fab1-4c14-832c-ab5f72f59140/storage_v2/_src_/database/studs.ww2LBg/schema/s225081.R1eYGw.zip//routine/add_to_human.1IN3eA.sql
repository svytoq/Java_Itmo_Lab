create function add_to_human(n integer) returns void
    language plpgsql
as
$$
DECLARE
  NM VARCHAR ;
  SIR VARCHAR;
  PASSW VARCHAR;
  LOG_IN VARCHAR;
  I INTEGER;
BEGIN
  NM = 'ANON';
  SIR = 'ANONIM';
  PASSW = 'QWERTY';
  LOG_IN = 'ANONIMOUS';
 FOR I IN 1..N LOOP
   INSERT INTO human VALUES (DEFAULT , NM, PASSW, SIR,LOG_IN);
   NM=NM||I;
     SIR=SIR||I;
     PASSW =PASSW||I;
     LOG_IN=LOG_IN||I;
 END LOOP;
END;

$$;

alter function add_to_human(integer) owner to s225081;

