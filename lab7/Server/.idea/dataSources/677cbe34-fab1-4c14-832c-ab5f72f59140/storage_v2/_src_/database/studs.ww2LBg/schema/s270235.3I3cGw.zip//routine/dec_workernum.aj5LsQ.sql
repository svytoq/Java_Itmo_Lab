create function dec_workernum() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE factories
    SET worker_num = worker_num - 1
    WHERE factories.id_factory = OLD.id_factory;
    RETURN NEW;
END;
$$;

alter function dec_workernum() owner to s270235;

