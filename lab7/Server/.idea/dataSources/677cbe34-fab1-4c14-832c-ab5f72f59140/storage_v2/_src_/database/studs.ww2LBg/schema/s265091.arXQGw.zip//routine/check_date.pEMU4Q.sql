create function check_date() returns trigger
    language plpgsql
as
$$
declare
            кол_сорев int;
        begin
            кол_сорев := (select count(*) from Соревнование where дата = new.дата and ск_ид = new.ск_ид);
            if кол_сорев = 0 then
                return new;
            else return null;
            end if;
        end;
$$;

alter function check_date() owner to s265091;

