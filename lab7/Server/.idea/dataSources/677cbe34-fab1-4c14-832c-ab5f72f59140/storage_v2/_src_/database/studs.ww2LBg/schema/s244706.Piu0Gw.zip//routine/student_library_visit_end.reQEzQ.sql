create function student_library_visit_end(in_student_id bigint) returns void
    language plpgsql
as
$$
declare
spell_id bigint;
spell_kind spell_kind;
begin
select id, kind from spells s
inner join student_library_visits slv
on s.id = slv.acquiring_spell_id and slv.student_id = in_student_id
into spell_id, spell_kind;

delete from spells_students spst
using spells s
where spst.student_id = in_student_id and spst.spell_id = s.id and s.kind = spell_kind;

insert into spells_students (student_id, spell_id)
values (in_student_id, spell_id);

delete from student_library_visits slv
where slv.student_id = in_student_id;
end;
$$;

alter function student_library_visit_end(bigint) owner to s244706;

