create function fixation() returns trigger
    language plpgsql
as
$$
DECLARE
  tarif bigint;
  date DATE;
  ostatok_metro bigint;
  ostatok_bus bigint;
  ostatok_tram bigint;
  ostatok_troll bigint;
  card_ID bigint;
  fixator "ФИКСАТОР";


BEGIN
  card_ID = (SELECT "Код_карты" FROM "Карты_пассажира" WHERE "Карты_пассажира"."Код_карты" = new."Код_карты");
    IF(card_ID IS NOT NULL )
      THEN
          tarif = (SELECT "Код_Тарифа" FROM "Карты_пассажира" WHERE "Карты_пассажира"."Код_карты" = new."Код_карты"); -- Тариф карты, которой оплачивают
          date =  (SELECT "Дата_окончания_действия" FROM "Карты_пассажира" WHERE "Карты_пассажира"."Код_карты" = new."Код_карты");
          ostatok_metro = (SELECT "Остаток_поездок_в_метро" FROM "Карты_пассажира" WHERE "Карты_пассажира"."Код_карты" = new."Код_карты" );
          ostatok_bus = (SELECT "Остаток_поездок_в_автобусах" FROM "Карты_пассажира" WHERE "Карты_пассажира"."Код_карты" = new."Код_карты" );
          ostatok_tram = (SELECT "Остаток_поездок_в_трамваях" FROM "Карты_пассажира" WHERE "Карты_пассажира"."Код_карты" = new."Код_карты" );
          ostatok_troll = (SELECT "Остаток_поездок_в_троллейбусах" FROM "Карты_пассажира" WHERE "Карты_пассажира"."Код_карты" = new."Код_карты" );
          fixator = (SELECT "Вид_фиксатора" FROM "Место_оплаты_проезда" WHERE "Место_оплаты_проезда"."Код_места_оплаты_проезда" =  new."Код_места_оплаты_проезда");

          CASE tarif
              WHEN 19
                THEN IF (fixator = 'ВАЛИДАТОР')
                       THEN
                           UPDATE "Карты_пассажира" SET "Остаток_денежных_средств" = "Остаток_денежных_средств"-31 WHERE "Код_карты" = new."Код_карты";
                       ELSE
                           UPDATE "Карты_пассажира" SET "Остаток_денежных_средств" = "Остаток_денежных_средств"-36 WHERE "Код_карты" = new."Код_карты";
                     END IF;

          ELSE
            IF (fixator = 'ТУРНИКЕТ')
              THEN
                  IF ( (date < new."Дата_фиксации") OR  ostatok_metro = 0)
                      THEN RAISE EXCEPTION 'Невозможно зафиксировать проезд. Карта не действительна';
                  ELSE
                      UPDATE "Карты_пассажира" SET  "Остаток_поездок_в_метро" = "Остаток_поездок_в_метро" - 1 WHERE "Код_карты" = new."Код_карты";
                  END if;
            ELSEIF ((date < new."Дата_фиксации") OR ( (ostatok_bus = 0) AND (ostatok_troll = 0) AND  (ostatok_tram = 0)) )
                THEN
                  RAISE EXCEPTION 'Невозможно зафиксировать проезд. Карта не действительна';
            END IF;
          END CASE;
      ELSE
        RAISE EXCEPTION 'Невозможно зафиксировать проезд. Карта не действительна';
    END IF;
  RETURN new;
end;
$$;

alter function fixation() owner to s244710;

