create function "АВТОРЫ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('АВТОРЫ_ИД_seq')!=NEW.ИД THEN
    NEW.ИД=nextval('АВТОРЫ_ИД_seq');
        RETURN NEW;
ELSE
RETURN NEW;
END IF;   
    END;
$$;

alter function "АВТОРЫ_ИД"() owner to s225058;

