create function "СЕАНС_ПЕРСОНАЛ_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF (exists(SELECT FROM "СЕАНС_ПЕРСОНАЛ" WHERE "СЕАНС_ПЕРСОНАЛ"."ИД_СЕАНСА" = NEW."ИД_СЕАНСА"))
AND
(exists(SELECT FROM "СЕАНС_ПЕРСОНАЛ" WHERE "СЕАНС_ПЕРСОНАЛ"."ИД_ПЕРСОНАЛ" = NEW."ИД_ПЕРСОНАЛ"))
THEN
RAISE 'Такое отношение уже записано в БД.';
END IF;
IF NOT (exists(SELECT FROM "СЕАНС" WHERE "СЕАНС"."ИД" = NEW."ИД_СЕАНСА"))
THEN
RAISE 'Такого сеанса нет в БД.';
END IF;
IF NOT (exists(SELECT FROM "ПЕРСОНАЛ" WHERE "ПЕРСОНАЛ"."ИД_ПЕРСОНАЛ" = NEW."ИД_ПЕРСОНАЛ"))
THEN
RAISE 'Такого персонала нет в БД.';
END IF;
return NEW;
END;
$$;

alter function "СЕАНС_ПЕРСОНАЛ_ТФ"() owner to s223443;

