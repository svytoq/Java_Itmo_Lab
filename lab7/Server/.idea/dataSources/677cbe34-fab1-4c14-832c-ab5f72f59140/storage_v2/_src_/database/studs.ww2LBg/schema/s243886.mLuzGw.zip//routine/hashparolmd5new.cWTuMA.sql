create function hashparolmd5new() returns trigger
    language plpgsql
as
$$
begin 
UPDATE ЧЕЛОВЕК set ПАРОЛЬ=md5(cast(ПАРОЛЬ as text)); 
RETURN NEW; 
END;
$$;

alter function hashparolmd5new() owner to s243886;

