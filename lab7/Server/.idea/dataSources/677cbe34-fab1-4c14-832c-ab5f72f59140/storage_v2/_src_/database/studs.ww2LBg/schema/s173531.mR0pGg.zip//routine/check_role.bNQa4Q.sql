create function check_role() returns trigger
    language plpgsql
as
$$
DECLARE A RECORD;
BEGIN
	SELECT id, role INTO A FROM user_roles_has_users where id = NEW.id;
        IF (A.id = NEW.id AND A.role = NEW.role) THEN
            RAISE EXCEPTION 'У пользователя уже есть такая роль';
            END IF;
END
$$;

alter function check_role() owner to s173531;

