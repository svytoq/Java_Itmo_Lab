create function deleteozu() returns trigger
    language plpgsql
as
$$
begin
 delete from УСТРОЙСТВА where  УСТРОЙСТВА.ИД_ОЗУ = ОЗУ.ИД;
 end;
$$;

alter function deleteozu() owner to s243855;

