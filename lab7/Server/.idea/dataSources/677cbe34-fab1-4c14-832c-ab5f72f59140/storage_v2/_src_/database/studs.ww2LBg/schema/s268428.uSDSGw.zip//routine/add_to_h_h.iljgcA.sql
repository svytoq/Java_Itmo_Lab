create function add_to_h_h(id integer, h_h integer) returns integer
    language plpgsql
as
$$
begin

 UPDATE sorcerer set h_h_id = h_h WHERE sorcerer_id = id;
 
 RETURN 0;
 end
$$;

alter function add_to_h_h(integer, integer) owner to s268428;

