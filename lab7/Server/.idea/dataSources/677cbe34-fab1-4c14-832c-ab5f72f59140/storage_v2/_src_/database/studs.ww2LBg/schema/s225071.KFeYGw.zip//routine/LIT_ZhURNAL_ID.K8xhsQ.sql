create function "ЛИТ_ЖУРНАЛ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('ЛИТ_ЖУРНАЛ_ИД_ЖУРНАЛА_seq')!=NEW.ИД_ЖУРНАЛА
THEN NEW.ИД_ЖУРНАЛА=nextval('ЛИТ_ЖУРНАЛ_ИД_ЖУРНАЛА_seq');
ELSE
  RETURN NEW;
END IF;
END;
$$;

alter function "ЛИТ_ЖУРНАЛ_ИД"() owner to s225071;

