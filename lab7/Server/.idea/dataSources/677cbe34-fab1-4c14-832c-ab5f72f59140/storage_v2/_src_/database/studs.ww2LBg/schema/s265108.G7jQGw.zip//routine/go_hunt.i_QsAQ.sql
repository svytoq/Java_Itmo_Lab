create function go_hunt(magician_list integer[], creature integer) returns text
    language plpgsql
as
$$
DECLARE
  info_exist boolean;
  is_not_dead boolean;
  hunting int;
  magician int;
BEGIN
  IF creature_exists(creature) AND all_magicians_exist(magician_list) THEN
    
  SELECT 1 INTO info_exist FROM Infos i
  WHERE creature_id = creature AND magician_id = ANY (magician_list);
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Вы не можете охотиться на монстра, сначала получите информацию о том, что он жив';
  END IF;
  
  SELECT 1 INTO is_not_dead FROM Creatures c
  WHERE c.id = creature AND c.hp_level != 0;
  
  IF NOT FOUND THEN
    RAISE EXCEPTION 'Ваш монстр уже мертв, вы не можете начать охоту на него';
  ELSE
      INSERT INTO Huntings (creature_id) VALUES (creature) RETURNING id INTO hunting;
      FOREACH magician IN ARRAY magician_list 
      LOOP
        INSERT INTO Magician_to_hunting (hunting_id, magician_id) VALUES (hunting, magician);
      END LOOP;
  END IF;
    END IF;

  RETURN FORMAT('Id охоты - %s', hunting);
END;
$$;

alter function go_hunt(integer[], integer) owner to s265108;

