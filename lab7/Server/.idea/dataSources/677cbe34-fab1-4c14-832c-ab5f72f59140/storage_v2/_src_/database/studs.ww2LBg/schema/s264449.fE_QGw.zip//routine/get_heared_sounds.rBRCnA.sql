create function get_heared_sounds()
    returns TABLE(s_name character varying, s_coor_x integer, s_coor_y integer, s_volume numeric, s_dur interval, p_name character varying, p_coor_x integer, p_coor_y integer, p_time timestamp without time zone)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY
    SELECT s.NAME, s.COOR_X, s.COOR_Y, s.VOLUME, s.DURATION, p.NAME, pp.COOR_X, pp.COOR_Y, pp.TIME_P
    FROM s264449.Sound_Fact AS s CROSS JOIN s264449.Person_Position as pp JOIN s264449.Person AS p ON p.ID = pp.PERSON_ID
    WHERE (
        get_distance(s.COOR_X, s.COOR_Y, pp.COOR_X, pp.COOR_Y) <= s.VOLUME
        AND pp.TIME_P > s.START_TIME
        AND pp.TIME_P < s.START_TIME + s.DURATION
    );
END
$$;

alter function get_heared_sounds() owner to s264449;

