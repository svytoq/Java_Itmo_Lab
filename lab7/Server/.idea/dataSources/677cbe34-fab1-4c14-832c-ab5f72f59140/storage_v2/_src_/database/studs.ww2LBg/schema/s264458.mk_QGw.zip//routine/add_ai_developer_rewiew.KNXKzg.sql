create function add_ai_developer_rewiew(id integer, previous_data integer, review_id integer, developer_id integer) returns void
    language plpgsql
as
$$
DECLARE
  accuracy DOUBLE PRECISION;
  precision_value DOUBLE PRECISION;
  recall DOUBLE PRECISION;
  f1 DOUBLE PRECISION;
  prediction text;


BEGIN

  accuracy = random();
  precision_value = random();
  recall = random();
  f1 = random();

  IF accuracy > 0.3 AND precision_value > 0.3 AND recall > 0.3 AND f1 > 0.3 THEN
    prediction = 'Good work';
    UPDATE developer
    SET salary = salary + (AVG(accuracy, precision_value, recall, f1)*100)::integer
    WHERE id = add_ai_developer_rewiew.developer_id;
  ELSE
    prediction = 'Bad work';
    UPDATE developer
    SET salary = salary - (AVG(accuracy, precision_value, recall, f1)*100)::integer
    WHERE id = add_ai_developer_rewiew.developer_id;
  END IF;

  PERFORM insert_ai_developer_review(
          id,
          previous_data,
          review_id,
          developer_id,
          accuracy,
          precision_value,
          recall,
          f1,
          prediction);

END;

$$;

alter function add_ai_developer_rewiew(integer, integer, integer, integer) owner to s264458;

