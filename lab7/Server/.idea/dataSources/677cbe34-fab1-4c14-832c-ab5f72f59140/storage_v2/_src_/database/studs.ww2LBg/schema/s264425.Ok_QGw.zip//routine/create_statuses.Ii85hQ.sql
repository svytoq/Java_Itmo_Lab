create function create_statuses() returns void
    language plpgsql
as
$$
begin
    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Бомж', 0);

    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Нищий', 500);

    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Работяга', 2000);

    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Клерк', 10000);

    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Босс', 25000);

    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Бизнесмен', 50000);

    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Депутат', 100000);

    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Министр', 250000);

    INSERT INTO "Status"("Name", "Rating")
    VALUES ('Президент', 500000);

    RETURN;
end
$$;

alter function create_statuses() owner to s264425;

