create function add_t_w(tr_id integer, w_id integer) returns integer
    language plpgsql
as
$$
DECLARE
tr_type CHAR(20);
begin
 
 INSERT INTO training_witcher VALUES
 (w_id, tr_id);
 
 SELECT INTO tr_type type FROM training where training_id = tr_id;
 
 IF tr_type = 'sword_fight' 
 THEN
 UPDATE skill_witcher set lev = lev + 3 WHERE (skill_id = 1 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 4 WHERE (skill_id = 2 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 5 WHERE (skill_id = 3 AND witcher_id = w_id);
 end if;
 
 IF tr_type = 'survival' 
  THEN
 UPDATE skill_witcher set lev = lev + 5 WHERE (skill_id = 6 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 4 WHERE (skill_id = 2 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 2 WHERE (skill_id = 3 AND witcher_id = w_id);
 end if;
 
  IF tr_type = 'reading' 
  THEN
 UPDATE skill_witcher set lev = lev + 2 WHERE (skill_id = 6 AND witcher_id = w_id);
 UPDATE skill_witcher set lev = lev + 6 WHERE (skill_id = 5 AND witcher_id = w_id);
 end if;
 
 RETURN training_id;
 end
$$;

alter function add_t_w(integer, integer) owner to s268428;

