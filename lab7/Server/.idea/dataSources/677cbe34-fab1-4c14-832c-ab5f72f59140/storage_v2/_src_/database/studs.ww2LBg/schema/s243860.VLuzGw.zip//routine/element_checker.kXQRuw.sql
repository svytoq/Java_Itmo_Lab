create function element_checker() returns trigger
    language plpgsql
as
$$
DECLARE
element integer;
begin_date date;
    BEGIN
            SELECT t.element_id INTO element FROM techniques t WHERE t.id = NEW.technique_id;
            IF (element = NULL) THEN RETURN NEW;
            END IF;
        BEGIN    
            SELECT e.date_of_learning INTO begin_date FROM ninjas_elements e WHERE e.ninja_id = NEW.user_id AND e.element_id = element;
        EXCEPTION
            WHEN NO_DATA_FOUND THEN 
                RAISE EXCEPTION 'Element used by the technique is not learned yet'
                USING HINT = 'Please  check the value';
        END;
        IF (begin_date > NEW.date_of_learning) THEN RAISE EXCEPTION 'Element used by the technique is not learned yet'
            USING HINT = 'Please  check the value';
        END IF;
        RETURN NEW;
    END;
$$;

alter function element_checker() owner to s243860;

