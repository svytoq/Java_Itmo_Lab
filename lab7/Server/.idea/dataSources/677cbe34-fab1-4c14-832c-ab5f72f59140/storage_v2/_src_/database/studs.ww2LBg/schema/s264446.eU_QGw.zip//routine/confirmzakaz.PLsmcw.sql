create function confirmzakaz(zakaz integer, materialcenter integer) returns void
    language plpgsql
as
$$
declare
today int;
r tests%rowtype;
begin
	perform (addTozakaz(zakaz,2138));
    for r in (select * from tests where order_id=zakaz)
    loop
        today := (select id from deliveries
         where deliveries.departure_date=now()::DATE AND deliveries.center_id=materialCenter
         AND deliveries.lab_id=(select lab_id from labs_tests 
                                        where r.test_kind_id=labs_tests.test_id
                                        order by random() limit 1));
        update tests
        set delivery_id=today
        where id=r.id;
    end loop;
end;
$$;

alter function confirmzakaz(integer, integer) owner to s264446;

