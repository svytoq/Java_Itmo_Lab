create function movetoscene(shortyid integer, sceneid integer) returns boolean
    language plpgsql
as
$$
DECLARE 
	shorty_scene integer;
BEGIN 
	select scene_id into shorty_scene from Shorty where shorty_id = shortyId;
	IF (shorty_scene is NULL) THEN RETURN false; END IF;
	IF (select NOT exists (SELECT 1 FROM Door JOIN Changeable using(changeable_id) WHERE ((shorty_scene = scene1_id AND sceneId = scene2_id) OR (shorty_scene = scene2_id AND sceneId = scene1_id)) AND is_state = true)) THEN RETURN false; END IF;
	UPDATE Shorty SET scene_id = sceneId WHERE shortyId = shorty_id;
	UPDATE Shorty SET action_until_feed = (action_until_feed - 1) WHERE shorty_id = shortyId and action_until_feed != 0;
	INSERT INTO Object_to_action (shorty_id, action_id, time) VALUES (shortyId, 5, now());
	RETURN true;
END;
$$;

alter function movetoscene(integer, integer) owner to s265072;

