create function event(i integer) returns void
    language plpgsql
as
$$
DECLARE
j integer;
BEGIN
j = 0;
loop
j = j + 1;
insert into ПЕРСОН_СОБЫТИЕ values((select * FROM(SELECT ИМЯ FROM ПЕРСОНАЖИ ORDER BY RANDOM()) AS POP LIMIT 1), (select * FROM(SELECT НАЗВАНИЕ_СОБ FROM СОБЫТИЯ ORDER BY RANDOM()) AS POP LIMIT 1));
if j = i then exit;
end if;
end loop;
END;
$$;

alter function event(integer) owner to s223859;

