create function checks() returns trigger
    language plpgsql
as
$$
BEGIN
  lock table refill in access exclusive mode;
  return new;
end;
$$;

alter function checks() owner to s243872;

