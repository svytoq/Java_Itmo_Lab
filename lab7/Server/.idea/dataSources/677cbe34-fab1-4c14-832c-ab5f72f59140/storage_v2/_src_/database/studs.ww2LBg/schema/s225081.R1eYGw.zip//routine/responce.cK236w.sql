create function responce() returns trigger
    language plpgsql
as
$$
DECLARE
 SOSL VARCHAR(30);
 BEGIN
   SELECT СОСЛОВИЕ FROM ЛЮДИ WHERE ID_ЧЕЛ = NEW.СЕНАТОР INTO SOSL;
   IF SOSL ='ПАТРИЦИЙ' THEN
     RETURN NEW;
     ELSE
       RAISE NOTICE '% НЕ МОЖЕТ НЕСТИ ОТВЕТСТВЕННОСТЬ ЗА ПОЛИТИЧЕСКИЙ ПЛАН', SOSL;
   RETURN NULL;
   END IF;

 END;
$$;

alter function responce() owner to s225081;

