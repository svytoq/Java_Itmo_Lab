create function ins_character(n text, dob date, un text, p text) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO characters (name, date_of_birth, username, password) VALUES (n, dob, un, p);
END;
$$;

alter function ins_character(text, date, text, text) owner to s278172;

