create function integrity_check_children_sex() returns boolean
    language plpgsql
as
$$
DECLARE
                field_name text;
            BEGIN
                INSERT INTO CHILDREN(id, iq, birthday, weight, status) VALUES (1,1, '2014-01-01', 25, 'AVAILABLE');
                RETURN FALSE;
            EXCEPTION WHEN not_null_violation THEN
                GET STACKED DIAGNOSTICS field_name = COLUMN_NAME;
                RETURN (field_name = 'sex');
            END;
$$;

alter function integrity_check_children_sex() owner to s223791;

