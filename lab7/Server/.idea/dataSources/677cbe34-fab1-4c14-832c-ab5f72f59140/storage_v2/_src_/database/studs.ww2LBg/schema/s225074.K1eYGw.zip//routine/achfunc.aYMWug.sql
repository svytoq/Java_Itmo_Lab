create function achfunc() returns trigger
    language plpgsql
as
$$
BEGIN
INSERT INTO ACHIEVEMENT(event_id, description)
VALUES(new.event_id, 'Completed Event "' || new.description || '"');
RETURN new;
END;
$$;

alter function achfunc() owner to s225074;

