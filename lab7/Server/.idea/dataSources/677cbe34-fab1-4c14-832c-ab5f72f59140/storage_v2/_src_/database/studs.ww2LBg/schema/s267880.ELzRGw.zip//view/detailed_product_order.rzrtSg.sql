create view detailed_product_order
            (product_order_id, user_profile_id, product_prototype_id, price, planned_delivery_date, delivery_address,
             additional_description, order_status, name, date_of_birth, email, telephone_number, password_hash,
             privilege, assigned_workers_count, finished_workers_count)
as
SELECT product_order_with_user_info.product_order_id,
       product_order_with_user_info.user_profile_id,
       product_order_with_user_info.product_prototype_id,
       product_order_with_user_info.price,
       product_order_with_user_info.planned_delivery_date,
       product_order_with_user_info.delivery_address,
       product_order_with_user_info.additional_description,
       product_order_with_user_info.order_status,
       product_order_with_user_info.name,
       product_order_with_user_info.date_of_birth,
       product_order_with_user_info.email,
       product_order_with_user_info.telephone_number,
       product_order_with_user_info.password_hash,
       product_order_with_user_info.privilege,
       product_order_progress.assigned_workers_count,
       product_order_progress.finished_workers_count
FROM s267880.product_order_with_user_info
         LEFT JOIN s267880.product_order_progress USING (product_order_id);

alter table detailed_product_order
    owner to s267880;

