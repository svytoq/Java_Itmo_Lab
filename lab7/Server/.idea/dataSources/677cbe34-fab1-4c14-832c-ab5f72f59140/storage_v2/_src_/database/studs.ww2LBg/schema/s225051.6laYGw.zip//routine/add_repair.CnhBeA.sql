create function add_repair() returns trigger
    language plpgsql
as
$$
declare
cost integer;
masint integer;
mid1 integer;
mid2 integer;
mid3 integer;
mid4 integer;
begin
masint=(select id from masters order by random() limit 1);

mid1 = (select exemplars.id from exemplars inner join changes on exemplars.id=changes.exemplar_id inner 
join ships on changes.ship_id=ships.id where new.ship_id=ships.id order by changes.end_date desc limit 1);
cost = (select wear from exemplars where id=mid1)*(select exemplars.cost from exemplars where id=mid1);
insert into repairs (techwork_id,exemplar_id,master_id,repair_cost) values(new.id,mid1,masint,cost);

mid2 = (select Exemplars.ID from Exemplars inner join Changes on Exemplars.ID=Changes.Exemplar_ID inner 
join Ships on Changes.Ship_ID=Ships.ID where new.Ship_ID=Ships.ID and Exemplars.ID!=mid1 order by Changes.End_Date desc limit 1);
cost = (select Wear from Exemplars where ID=mid2)*(select exemplars.cost from Exemplars where ID=mid2);
insert into repairs (TechWork_ID,Exemplar_ID,Master_ID,Repair_Cost) values(new.ID,mid2,masint,cost);

mid3 = (select Exemplars.ID from Exemplars inner join Changes on Exemplars.ID=Changes.Exemplar_ID inner 
join Ships on Changes.Ship_ID=Ships.ID where new.Ship_ID=Ships.ID and Exemplars.ID!=mid1 and 
Exemplars.ID!=mid2 order by Changes.End_Date desc limit 1);
cost = (select Wear from Exemplars where ID=mid3)*(select exemplars.cost from Exemplars where ID=mid3);
insert into repairs (TechWork_ID,Exemplar_ID,Master_ID,Repair_Cost) values(new.ID,mid3,masint,cost);

mid4 = (select Exemplars.ID from Exemplars inner join Changes on Exemplars.ID=Changes.Exemplar_ID inner 
join Ships on Changes.Ship_ID=Ships.ID where new.Ship_ID=Ships.ID and Exemplars.ID!=mid1 and Exemplars.ID!=mid2 and Exemplars.ID!=mid3 order by Changes.End_Date desc limit 1);
cost = (select Wear from Exemplars where ID=mid4)*(select exemplars.cost from Exemplars where ID=mid4);
insert into repairs (TechWork_ID,Master_ID,Exemplar_ID,Repair_Cost) values(new.id,masint,mid4,cost);

return new;
end;
$$;

alter function add_repair() owner to s225051;

