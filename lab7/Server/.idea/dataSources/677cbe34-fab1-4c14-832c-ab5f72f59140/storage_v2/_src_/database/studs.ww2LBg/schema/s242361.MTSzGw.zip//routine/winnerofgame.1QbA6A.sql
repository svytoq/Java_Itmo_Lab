create function winnerofgame(number integer, OUT "ИД_ТРИБУТА" bigint, OUT "ИД_ПОЛЬЗОВАТЕЛЯ" integer, OUT "ФАМИЛИЯ" character varying, OUT "ИМЯ" character varying, OUT "ДИСТРИКТ" smallint) returns SETOF record
    language sql
as
$$
SELECT ТРИБУТЫ.ИД_ТРИБУТА, ТРИБУТЫ.ИД_ПОЛЬЗОВАТЕЛЯ, ПОЛЬЗОВАТЕЛИ.ФАМИЛИЯ, ПОЛЬЗОВАТЕЛИ.ИМЯ, ПОЛЬЗОВАТЕЛИ.ДИСТРИКТ FROM ТРИБУТЫ 
JOIN ПОЛЬЗОВАТЕЛИ USING (ИД_ПОЛЬЗОВАТЕЛЯ)
WHERE (ИД_ИГРЫ = number) and (ТРИБУТЫ.СТАТУС = 'Победитель');
$$;

alter function winnerofgame(integer, out bigint, out integer, out varchar, out varchar, out smallint) owner to s242361;

