create function insert_clans_rel() returns void
    language plpgsql
as
$$
BEGIN
    FOR i IN 1..20 LOOP
      FOR j IN i+1..20 LOOP
        INSERT INTO clans_rel VALUES (DEFAULT, i, j, 5000, 22);
      END LOOP;
    END LOOP;
  END;
$$;

alter function insert_clans_rel() owner to s225107;

