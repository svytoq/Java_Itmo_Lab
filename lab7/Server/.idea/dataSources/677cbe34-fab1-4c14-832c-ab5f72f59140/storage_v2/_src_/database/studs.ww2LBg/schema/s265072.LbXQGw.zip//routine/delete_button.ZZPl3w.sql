create function delete_button() returns trigger
    language plpgsql
as
$$
begin 
	delete from Button where Button.subject_id = OLD.changeable_id;
	return new;
end;
$$;

alter function delete_button() owner to s265072;

