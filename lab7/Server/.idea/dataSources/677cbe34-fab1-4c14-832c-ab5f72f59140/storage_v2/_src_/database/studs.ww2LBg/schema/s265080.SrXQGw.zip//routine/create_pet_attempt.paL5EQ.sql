create function create_pet_attempt(fio text, adress text, phone text, pet_name text) returns text
    strict
    language plpgsql
as
$$
declare

begin
insert into "ЖЕЛАЮЩИЕ_ПРИЮТИТЬ"( "АДРЕС", "ТЕЛЕФОН", "ФИО")  values
    (adress,phone,fio);
insert into "ЖЕЛАЮЩИЕ_ГРЫЗУНЫ"("ИД_ГРЫЗУНА", "ИД_ЖЕЛАЮЩЕГО") values ((SELECT "ИД" FROM "ГРЫЗУНЫ" WHERE "ИМЯ" = pet_name),(SELECT "ИД" FROM "ЖЕЛАЮЩИЕ_ПРИЮТИТЬ" ORDER BY "ИД" DESC LIMIT 1));
return 'записи сделаны';
end;
$$;

alter function create_pet_attempt(text, text, text, text) owner to s265080;

