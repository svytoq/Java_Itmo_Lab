create function return_table(integer)
    returns TABLE(id integer)
    language plpgsql
as
$$
DECLARE
  hero alias for $1;
  i INTEGER DEFAULT 1;
  n INTEGER;
  p INTEGER;
BEGIN

p = (SELECT "Битва".id FROM "Битва" WHERE "Битва".id_победителя=hero LIMIT 1);
  RETURN NEXT;

  for i in 1..(SELECT count("Битва".id) FROM "Битва" WHERE "Битва".id_победителя=hero) loop
    n = trunc(random() * (SELECT COUNT(*) FROM "Битва" WHERE "Битва".id_победителя=hero)+1);
    if(p IN (SELECT "Битва".id FROM "Битва" WHERE "Битва".id_победителя=hero and "Битва".id=n))THEN
      n = trunc(random() * (SELECT COUNT(*) FROM "Битва")+1);
    p = (SELECT "Битва".id FROM "Битва" WHERE "Битва".id_победителя=hero);
        else RETURN NEXT;
      end if;
    end loop;
END
$$;

alter function return_table(integer) owner to s225133;

