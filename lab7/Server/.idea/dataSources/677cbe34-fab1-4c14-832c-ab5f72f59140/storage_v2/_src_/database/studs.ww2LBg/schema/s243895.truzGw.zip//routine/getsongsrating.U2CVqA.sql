create function getsongsrating(id bigint) returns bigint[]
    language plpgsql
as
$$
declare
	rating bigint[2];
	likes bigint = 0;
	dislikes bigint = 0;
	begin
	rating[1] = 0;
	rating[2] = 0;
	Select count (rate) into likes from soundtrack_rate WHERE soundtrack_id=id AND rate > 0 GROUP BY soundtrack_id;
	Select count (rate) into dislikes from soundtrack_rate WHERE soundtrack_id=id AND rate < 0 GROUP BY soundtrack_id;
	if (likes is not NULL) then rating[1]=likes;
	end if;
	if (dislikes is not NULL) then rating[2]=dislikes;
	end if;
	return rating;
	end;
$$;

alter function getsongsrating(bigint) owner to s243895;

