create function calculatemarketpricecars(boughtprice integer, yearofproduction integer, numberofcarsproduced integer, mileage integer) returns void
    language sql
as
$$
UPDATE FOR_SALE_CARS 
SET MARKET_PRICE = boughtPrice + POWER((2020 - yearOfProduction), 2) * 300 + 20000000 / numberOfCarsProduced + 20000000 / mileage + boughtPrice * 65 / 100;
$$;

alter function calculatemarketpricecars(integer, integer, integer, integer) owner to s265085;

