create function find_delivery_responsible() returns integer
    language plpgsql
as
$$
BEGIN
        RETURN (
            SELECT emp.id FROM employee AS emp
            LEFT JOIN delivery_order AS ord ON ord.responsible_id = emp.id
            WHERE emp.department = 'delivery'
            GROUP BY emp.id
            ORDER BY count(ord.id)
            LIMIT 1
        );
    END;
$$;

alter function find_delivery_responsible() owner to s265092;

