create function you_fired(worker_id integer) returns void
    language plpgsql
as
$$
BEGIN
    IF ((SELECT count(*) FROM volunteer WHERE on_work = true AND id = worker_id) > 0) THEN
        UPDATE volunteer SET on_work = false, isbs_id = null, environment_id = null WHERE id = worker_id;
        RAISE NOTICE 'Работник % уволеен', (SELECT name FROM volunteer WHERE id = worker_id);
    ELSEIF ((SELECT count(*) FROM volunteer WHERE on_work = false AND id = worker_id) > 0) THEN
        RAISE NOTICE 'Данные человек не работает в нашей организации';
    ELSE
        RAISE NOTICE 'Данные по такому человеку не найдены';
    END IF;
END
$$;

alter function you_fired(integer) owner to s263977;

