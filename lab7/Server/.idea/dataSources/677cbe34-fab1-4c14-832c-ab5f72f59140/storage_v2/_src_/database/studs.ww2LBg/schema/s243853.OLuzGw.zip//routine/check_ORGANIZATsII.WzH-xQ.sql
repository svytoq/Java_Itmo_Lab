create function "check_ОРГАНИЗАЦИИ"() returns trigger
    language plpgsql
as
$$
BEGIN 
IF NOT EXISTS(SELECT ИД_РЕЛИГИИ, ИД_ГОСУДАРСТВА FROM ГОСУДАРСТВА_РЕЛИГИИ 
WHERE (NEW.ИД_РЕЛИГИИ = ИД_РЕЛИГИИ) AND (NEW.ИД_ГОСУДАРСТВА = ИД_ГОСУДАРСТВА)) 
THEN RAISE EXCEPTION 'РЕЛИГИЯ и ГОСУДАРСТВО ОРГАНИЗАЦИИ должны СУЩЕСТВОВАТЬ';
END IF; 
RETURN NEW; 
END
$$;

alter function "check_ОРГАНИЗАЦИИ"() owner to s243853;

