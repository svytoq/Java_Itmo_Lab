create function comparetable(searchtime time without time zone) returns boolean
    language plpgsql
as
$$
BEGIN
RETURN (SELECT COUNT(*) = 2  FROM
(SELECT time, activity FROM Truman_schedule
UNION
SELECT time, activity FROM show_schedule) AS compare_table WHERE time = to_date(searchTime,'hh24:mi:ss'));
END
$$;

alter function comparetable(time) owner to s277686;

