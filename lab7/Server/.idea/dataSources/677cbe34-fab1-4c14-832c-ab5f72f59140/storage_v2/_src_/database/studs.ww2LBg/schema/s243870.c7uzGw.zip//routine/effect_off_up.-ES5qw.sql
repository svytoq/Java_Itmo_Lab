create function effect_off_up() returns trigger
    language plpgsql
as
$$
BEGIN
IF (NEW.Момент_Снятия is not null AND OLD.Момент_Снятия is null) THEN
NEW.Момент_Снятия := current_timestamp;
END IF;
RETURN NEW;
END;
$$;

alter function effect_off_up() owner to s243870;

