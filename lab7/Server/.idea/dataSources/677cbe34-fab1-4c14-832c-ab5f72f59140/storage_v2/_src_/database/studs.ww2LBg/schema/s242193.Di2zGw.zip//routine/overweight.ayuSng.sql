create function overweight() returns trigger
    language plpgsql
as
$$
DECLARE
	   _character_weight real;
	   _max_weight real;
	   _new_weight real;
	BEGIN
		SELECT sum(Вес) INTO _character_weight FROM "К_Предметы" WHERE Id IN
		(SELECT Предмет_ИД FROM "К_Инвентарь" WHERE Персонаж_ИД = NEW.Персонаж_ИД);
		SELECT Максимальный_Вес INTO _max_weight FROM "К_Персонажи" WHERE Id = NEW.Персонаж_ИД;
		SELECT Вес INTO _new_weight FROM "К_Предметы" WHERE Id = NEW.Предмет_ИД;
		IF (_character_weight + _new_weight > _max_weight) THEN
			RETURN NULL;
		END IF;
		RETURN NEW;
	END;
$$;

alter function overweight() owner to s242193;

