create function cascade_album() returns trigger
    language plpgsql
as
$$
BEGIN
DELETE FROM "Композиция" WHERE "Альбом_ИД" = old.ИД;
  DELETE FROM "Композиция_Альбом" WHERE "Альбом_ИД" = old.ИД;
    RETURN OLD;
  END;
$$;

alter function cascade_album() owner to s223569;

