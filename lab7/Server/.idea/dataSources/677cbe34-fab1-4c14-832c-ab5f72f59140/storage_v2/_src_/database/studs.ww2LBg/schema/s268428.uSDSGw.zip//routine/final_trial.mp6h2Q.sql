create function final_trial(s_id integer) returns integer
    language plpgsql
as
$$
DECLARE
bruxa_q INTEGER;
h_h INTEGER;
forktail_q INTEGER;
manticore_q INTEGER;
bryonia_q INTEGER;
ribleaf_q INTEGER;
mandrake_q INTEGER;
quality INTEGER = 0;
witcherJr RECORD;
res INTEGER = 0;
general_q INTEGER;
sorcerer_lvl INTEGER;
survived BOOLEAN = TRUE;
begin
SELECT INTO h_h h_h_id from stream where stream_id = s_id ;

SELECT INTO bruxa_q i.quality from ingridient as i where h_h_id = h_h and type = 'bruxa';
SELECT INTO forktail_q i.quality from ingridient as i where h_h_id = h_h and type = 'forktail';
SELECT INTO manticore_q i.quality from ingridient as i where h_h_id = h_h and type = 'manticore';

SELECT INTO bryonia_q i.quality from ingridient as i where h_h_id = h_h and type = 'bryonia';
SELECT INTO ribleaf_q i.quality from ingridient as i where h_h_id = h_h and type = 'ribleaf';
SELECT INTO mandrake_q i.quality from ingridient as i where h_h_id = h_h and type = 'mandrake';

general_q = bruxa_q + forktail_q + manticore_q +  bryonia_q + ribleaf_q + mandrake_q; 

SELECT INTO sorcerer_lvl lev from sorcerer where h_h_id = h_h;
sorcerer_lvl = sorcerer_lvl/2.9;
for witcherJr in 
SELECT sw.witcher_id as w_id, sw.lev as lvl  from witcher as w join skill_witcher as sw on w.witcher_id = sw.witcher_id where (w.role = 'witcherJr' and w.stream_id = s_id  and sw.skill_id = 6)
LOOP
res = (witcherJr.lvl/1.4*10*sorcerer_lvl/10 + 1)/2 + general_q/12;
if (res < 50) 
THEN
survived = FALSE;
ELSE
survived = TRUE;
end IF;

INSERT INTO ingridient VALUES
(DEFAULT, 1,  survived, res);
end LOOP;




 RETURN 0;
 end
$$;

alter function final_trial(integer) owner to s268428;

