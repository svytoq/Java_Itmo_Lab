create function orgisactive(org_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
result boolean := true;
d date;
BEGIN
select max(op.Дата) into d from Операция op inner join Список_операций spOp on(op.ИД=spOp.ИД_Операции) where spOp.ИД_Организации=$1;
IF d>(now()::date-interval '3 years')
THEN return true;
ELSE return false;
END IF;
END;
$$;

alter function orgisactive(integer) owner to s185017;

