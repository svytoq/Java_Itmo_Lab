create function lend_book(l_book_id integer, l_reader_id integer, l_employee_id integer, for_days integer) returns boolean
    language plpgsql
as
$$
declare
    can_borrow boolean;
begin
    select check_age_for_book(l_reader_id, l_book_id) into can_borrow;
    if can_borrow then
        insert into borrowed_books (book_id, reader_id, employee_id, due_date)
        VALUES (l_book_id, l_reader_id, l_employee_id, current_date + for_days);
        return true;
    else
        RAISE EXCEPTION 'Book % is not allowed for reader %', l_book_id, l_reader_id
            USING HINT = 'Reader is under 18';
    end if;
end
$$;

alter function lend_book(integer, integer, integer, integer) owner to s265089;

