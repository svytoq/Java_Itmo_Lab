create function buildings_from_tech(tname text)
    returns TABLE(name text, price_production integer, price_resource integer, requirements text, properties text)
    language plpgsql
as
$$
BEGIN
		RETURN QUERY SELECT buildings.name, buildings.price_production, buildings.price_resource, buildings.requirements, buildings.properties FROM  (technologies JOIN building_tech ON technologies.id = building_tech.tech_id) JOIN buildings ON building_tech.building_id = buildings.id WHERE technologies.tech_name = tname; 
	END;
$$;

alter function buildings_from_tech(text) owner to s225102;

