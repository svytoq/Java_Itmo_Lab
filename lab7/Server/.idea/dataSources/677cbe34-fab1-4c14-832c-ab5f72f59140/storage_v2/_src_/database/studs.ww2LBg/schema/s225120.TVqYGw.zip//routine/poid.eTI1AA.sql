create function poid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_ДОЛЖНОСТИ := nextval('positions_seq');
	return new;
end
$$;

alter function poid() owner to s225120;

