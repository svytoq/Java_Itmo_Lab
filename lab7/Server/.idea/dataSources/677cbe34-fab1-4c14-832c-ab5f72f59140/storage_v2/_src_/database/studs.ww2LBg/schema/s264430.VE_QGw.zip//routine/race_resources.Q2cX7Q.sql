create function race_resources(race text)
    returns TABLE(stones bigint, wood bigint, gold bigint, steel bigint, food bigint)
    language sql
as
$$
select sum(stones), sum(wood), sum(gold), sum(steel), sum(food) from provinces inner join resource on provinces.resourсe_id=resource.id where provinces.race_name=$1
$$;

alter function race_resources(text) owner to s264430;

