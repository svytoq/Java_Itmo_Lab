create function resquad(solders integer[], squads integer[]) returns void
    language plpgsql
as
$$
DECLARE
counter integer = 0;
array_size integer;
squad_now integer; 
squad_size integer; 
cap_array integer ARRAY[100];
solder_index integer ARRAY[1];
new_cap integer;
BEGIN
	array_size := ARRAY_LENGTH(solders, 1);
	IF (array_size IS NOT NULL) AND (array_size = ARRAY_LENGTH(squads, 1)) THEN
		SELECT array_agg(capitain_id) INTO STRICT cap_array FROM squad;
		while counter < array_size
		LOOP
			counter := counter + 1;
			SELECT squad_id INTO STRICT squad_now FROM Solder where soldier_id = solders[counter];
			IF squads[counter] != squad_now THEN
				SELECT count(*) INTO STRICT squad_size FROM Solder where squad_id = squad_now;
				IF (squad_size > 1) THEN
					UPDATE SOLDER SET squad_id = squads[counter] WHERE soldier_id = solders[counter];
					solder_index[1] := solders[counter];
					IF (cap_array @>solder_index) THEN 
						SELECT soldier_id INTO STRICT new_cap FROM Solder where squad_id = squad_now LIMIT 1;
						UPDATE Squad SET capitain_id = new_cap WHERE capitain_id = solders[counter];
						SELECT array_agg(capitain_id) INTO STRICT cap_array FROM squad;
					END IF;
				END IF;
			END IF;
		END LOOP;
	END IF;
END;
$$;

alter function resquad(integer[], integer[]) owner to s265478;

