create function nationsid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('nations_id_seq')!=NEW.ID THEN
NEW.ID=nextval('nations_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function nationsid() owner to s225102;

