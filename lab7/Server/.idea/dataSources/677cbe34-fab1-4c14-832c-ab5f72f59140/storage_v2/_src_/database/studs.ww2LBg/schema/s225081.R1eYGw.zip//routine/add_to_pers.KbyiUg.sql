create function add_to_pers(n integer) returns void
    language plpgsql
as
$$
DECLARE
  NM VARCHAR ;
 SIR VARCHAR;
  BODY TEXT;
  I INTEGER;
BEGIN
  NM = 'PERSON';
 BODY = 'ABRACADABRA';
 SIR='PERSON';
 FOR I IN 1..N LOOP
   INSERT INTO SERIES VALUES (DEFAULT , BODY, NM);
   NM=NM||I;
     BODY=BODY||I;
SIR =SIR||I;
 END LOOP;
END;

$$;

alter function add_to_pers(integer) owner to s225081;

