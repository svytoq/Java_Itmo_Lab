create function place_units_in_building(building_amount integer, units_amount integer) returns void
    language plpgsql
as
$$
DECLARE
	b int;
	um int;
BEGIN
	FOR i IN 1 .. building_amount LOOP
		SELECT (random() * (count(*) - 1)) + 1 INTO b
			FROM building_instances;

		SELECT (random() * units_amount) + 1 INTO um;

		FOR j IN 1 .. um LOOP
			INSERT INTO building_unit
				(unit, building)
				VALUES
				(get_first_not_claimed_unit(), 
				b);
		END LOOP;
	END LOOP;
END;
$$;

alter function place_units_in_building(integer, integer) owner to s244711;

