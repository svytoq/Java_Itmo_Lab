create function "ЭПОХА_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "ЭПОХА_ИД" FROM "ЭПОХА");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."ЭПОХА_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''ЭПОХА_ЭПОХА_ИД_seq'', max("ЭПОХА_ИД") + 1) FROM "ЭПОХА"';
                        NEW."ЭПОХА_ИД" := max_id + 1;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "ЭПОХА_PK_seq_func"() owner to s245094;

