create function testisready(test integer) returns void
    language plpgsql
as
$$
DECLARE
notReadyAmount int;
zakaz int;
BEGIN
    zakaz := (select order_id from tests where id=test limit 1);
    notReadyAmount := (select count(*) from tests where order_id=zakaz AND ready='f');
    if notReadyAmount=0 then
        update zakazs
        set ready='t'
        where id=zakaz;
    end if;
end;
$$;

alter function testisready(integer) owner to s264446;

