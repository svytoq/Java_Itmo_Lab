create function check_creature_notes_all_kinds_present() returns trigger
    language plpgsql
as
$$
begin
if exists(
values ('Fight'::student_stage, 'Female'::student_gender),
('Fight'::student_stage, 'Male'::student_gender),
('FightWon'::student_stage, 'Female'::student_gender),
('FightWon'::student_stage, 'Male'::student_gender),
('FightLost'::student_stage, 'Female'::student_gender),
('FightLost'::student_stage, 'Male'::student_gender)
except
select stage, text_gender from notes where creature_id = new.id
)
then raise exception 'new creature entries must have associated notes for Fight, FightWon, FightLost stages for all genders';
end if;
return null;
end;
$$;

alter function check_creature_notes_all_kinds_present() owner to s243871;

