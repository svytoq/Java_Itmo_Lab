create function insertintomonth() returns trigger
    language plpgsql
as
$$
DECLARE

Y INTEGER;
MONTH1 INTEGER;
TEAM INTEGER;
ZAB INTEGER;
PROP INTEGER;
POINTS INTEGER;
WIN INTEGER;
LOSE INTEGER;
DRAW INTEGER;
RAZNI INTEGER;
  win1 INTEGER;
  win2 INTEGER;
  nich integer;
  timest TIMESTAMP;
BEGIN
  timest = NEW.ВРЕМЯ_ПРОВЕДЕНИЯ;

MONTH1 = DATE_PART('month', timest);
Y = NEW.ГОДИД;
win1 = 0;
  win2 = 0;
  nich = 0;

  IF (NEW.ОЧКИ_ПЕРВОЙ_КОМАНДЫ > NEW.ОЧКИ_ВТОРОЙ_КОМАНДЫ) THEN
    win1 = 1;
    ELSIF (NEW.ОЧКИ_ПЕРВОЙ_КОМАНДЫ < NEW.ОЧКИ_ВТОРОЙ_КОМАНДЫ) THEN
    win2 = 1;
    ELSE
      BEGIN
      win1 = 0;
      win2 = 0;
      nich =1;
      END ;
  END IF;

IF EXISTS(SELECT КОМАНДАИД FROM "СТАТИСТИКА_ПО_МЕСЯЦАМ" WHERE ГОДИД=NEW.ГОДИД AND МЕСЯЦ=MONTH1 AND КОМАНДАИД=NEW.ПЕРВАЯ_КОМАНДА) THEN
BEGIN

  UPDATE "СТАТИСТИКА_ПО_МЕСЯЦАМ" SET "КОЛИЧЕСТВО_ЗАБИТЫХ"="КОЛИЧЕСТВО_ЗАБИТЫХ"+NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ПЕРВОЙ_КОМАНДОЙ,
    "КОЛИЧЕСТВО_ПРОПУЩЕННЫХ" = "КОЛИЧЕСТВО_ПРОПУЩЕННЫХ"+NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ВТОРОЙ_КОМАНДОЙ,
    "НАБРАННЫЕ_ОЧКИ" = "НАБРАННЫЕ_ОЧКИ" + NEW.ОЧКИ_ПЕРВОЙ_КОМАНДЫ,
    "КОЛИЧСТВО_ПОБЕД" = "КОЛИЧСТВО_ПОБЕД" + win1,
    "КОЛИЧЕСТВО_ПОРАЖЕНИЙ" = "КОЛИЧЕСТВО_ПОРАЖЕНИЙ" + win2,
    "КОЛИЧЕСТВО_НИЧЬИХ" = "КОЛИЧЕСТВО_НИЧЬИХ" + nich,
    "РАЗНИЦА_ЗАБИТЫХ_ПРОПУЩЕННЫХ" = "РАЗНИЦА_ЗАБИТЫХ_ПРОПУЩЕННЫХ" +NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ПЕРВОЙ_КОМАНДОЙ -NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ВТОРОЙ_КОМАНДОЙ
  WHERE "ГОДИД" = Y AND "МЕСЯЦ" = MONTH1 AND "КОМАНДАИД"=NEW.ПЕРВАЯ_КОМАНДА;
RETURN new;
END;

ELSE
BEGIN
TEAM = NEW.ПЕРВАЯ_КОМАНДА;
ZAB= NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ПЕРВОЙ_КОМАНДОЙ;
PROP = NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ВТОРОЙ_КОМАНДОЙ;
POINTS= NEW.ОЧКИ_ПЕРВОЙ_КОМАНДЫ;
RAZNI = ZAB-PROP;
IF NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ПЕРВОЙ_КОМАНДОЙ>NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ВТОРОЙ_КОМАНДОЙ THEN
BEGIN
WIN = 1;
LOSE=0;
DRAW =0;
INSERT INTO СТАТИСТИКА_ПО_МЕСЯЦАМ VALUES(Y,MONTH1,TEAM,ZAB,PROP,POINTS,WIN,LOSE,DRAW,RAZNI);
END;
ELSIF NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ПЕРВОЙ_КОМАНДОЙ<NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ВТОРОЙ_КОМАНДОЙ THEN
BEGIN
WIN = 0;
LOSE=1;
DRAW =0;
INSERT INTO СТАТИСТИКА_ПО_МЕСЯЦАМ VALUES(Y,MONTH1,TEAM,ZAB,PROP,POINTS,WIN,LOSE,DRAW,RAZNI);
END;
ELSIF NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ПЕРВОЙ_КОМАНДОЙ=NEW.КОЛИЧЕСТВО_ЗАБИТЫХ_ВТОРОЙ_КОМАНДОЙ THEN
BEGIN
WIN = 0;
LOSE=0;
DRAW =1;
INSERT INTO СТАТИСТИКА_ПО_МЕСЯЦАМ VALUES(Y,MONTH1,TEAM,ZAB,PROP,POINTS,WIN,LOSE,DRAW,RAZNI);
END;
END IF;

  RETURN NEW;
END;
  RETURN NEW;
END IF;
  END
$$;

alter function insertintomonth() owner to s247413;

