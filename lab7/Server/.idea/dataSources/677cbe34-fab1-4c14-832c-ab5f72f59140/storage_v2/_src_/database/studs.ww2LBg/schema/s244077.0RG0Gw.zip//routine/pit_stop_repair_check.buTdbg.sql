create function pit_stop_repair_check() returns trigger
    language plpgsql
as
$$
DECLARE
  BEGIN
   IF (NOT(
     (SELECT team_id FROM pit_stop_places WHERE (pit_stop_places.id = NEW.place_id)) =
     (SELECT team_id FROM cars WHERE (cars.id = NEW.car_id))
   ))
     THEN RAISE EXCEPTION 'Place and car must be in one team';
     RETURN NULL;
  END IF;
  RETURN NEW;
END;
$$;

alter function pit_stop_repair_check() owner to s244077;

