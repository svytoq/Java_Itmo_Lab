create function form_product_order(client_user_profile_id integer, ordered_product_prototype_id integer, wanted_delivery_date date, delivery_address text) returns integer
    language sql
as
$$
insert into product_order (user_profile_id, product_prototype_id, planned_delivery_date, delivery_address)
    values (client_user_profile_id, ordered_product_prototype_id, wanted_delivery_date, form_product_order.delivery_address)
    returning product_order_id;
$$;

alter function form_product_order(integer, integer, date, text) owner to s267880;

