create function get_distance(x1 integer, y1 integer, x2 integer, y2 integer) returns integer
    immutable
    language plpgsql
as
$$
BEGIN
    RETURN |/((x2 - x1)^2 + (y2 - y1)^2);
END
$$;

alter function get_distance(integer, integer, integer, integer) owner to s264449;

