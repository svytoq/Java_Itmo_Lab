create function _trigger_delete_super_product() returns trigger
    language plpgsql
as
$$
begin
    delete from product where id = old.super_id;
    return new;
end;
$$;

alter function _trigger_delete_super_product() owner to s264429;

