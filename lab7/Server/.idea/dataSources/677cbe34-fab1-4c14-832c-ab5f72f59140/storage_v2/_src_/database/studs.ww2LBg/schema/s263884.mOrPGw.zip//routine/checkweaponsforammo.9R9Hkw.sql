create function checkweaponsforammo(ammoid integer)
    returns TABLE(nameweapon text)
    language plpgsql
as
$$
begin 
RETURN QUERY 
select "name" from "weapon" where "caliber" = (SELECT "caliber" from ammunition where "id" = ammoID);
end;
$$;

alter function checkweaponsforammo(integer) owner to s263884;

