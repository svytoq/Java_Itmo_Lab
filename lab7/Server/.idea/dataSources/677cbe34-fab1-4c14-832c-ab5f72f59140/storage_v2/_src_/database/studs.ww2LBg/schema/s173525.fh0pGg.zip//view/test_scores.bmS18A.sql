create view test_scores
            (attempt_id, subject_id, test_id, user_id, pass_score, max_score, score, test_amount_of_time, spent_time) as
SELECT attempts.attempt_id,
       tests.subject_id,
       attempts.test_id,
       attempts.user_id,
       tests.test_pass_score                         AS pass_score,
       s173525.get_test_max_score(attempts.test_id)  AS max_score,
       s173525.get_score(attempts.attempt_id)        AS score,
       tests.test_amount_of_time,
       attempts.attempt_end - attempts.attempt_start AS spent_time
FROM s173525.attempts
         JOIN s173525.tests ON attempts.test_id = tests.test_id
         JOIN s173525.questions ON questions.test_id = tests.test_id
GROUP BY attempts.attempt_id, attempts.test_id, tests.subject_id, attempts.user_id, tests.test_pass_score,
         tests.test_amount_of_time
ORDER BY attempts.attempt_id;

alter table test_scores
    owner to s173525;

