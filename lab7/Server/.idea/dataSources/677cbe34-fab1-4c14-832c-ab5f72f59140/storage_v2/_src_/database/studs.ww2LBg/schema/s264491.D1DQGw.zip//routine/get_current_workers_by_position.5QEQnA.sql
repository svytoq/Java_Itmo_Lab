create function get_current_workers_by_position(pos_id integer)
    returns TABLE(id integer, full_name character varying, corp_rank numeric, worker_rank numeric, title character varying, depart character varying, salary numeric, option numeric, bonus numeric, head_name character varying)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT W.id,
                        W.full_name,
                        W.corporate_rank,
                        W.workers_rank,
                        P.title,
                        D.name,
                        P.salary,
                        W.option,
                        W.bonus,
                        W2.full_name
                 from WORKER W
                          INNER JOIN POSITION P on P.id = W.position_id
                          INNER JOIN DEPARTMENT D on D.id = W.department_id
                          INNER JOIN WORKER W2 on D.head_id = W2.id
                 WHERE W.position_id = pos_id
                 ORDER BY W.id ASC;

END;
$$;

alter function get_current_workers_by_position(integer) owner to s264491;

