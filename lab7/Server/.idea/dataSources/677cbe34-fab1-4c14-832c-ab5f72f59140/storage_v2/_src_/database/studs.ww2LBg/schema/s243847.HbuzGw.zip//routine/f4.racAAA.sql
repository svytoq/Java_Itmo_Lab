create function f4() returns trigger
    language plpgsql
as
$$
BEGIN
UPDATE Сектора SET Кол_пс = Кол_пс-1
WHERE ID_Сектора = NEW.ID_Сектора;
RETURN NEW;
END;
$$;

alter function f4() owner to s243847;

