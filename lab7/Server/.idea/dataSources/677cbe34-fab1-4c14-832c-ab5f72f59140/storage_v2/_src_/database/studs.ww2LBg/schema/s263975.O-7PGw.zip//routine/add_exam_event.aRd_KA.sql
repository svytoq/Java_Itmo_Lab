create function add_exam_event(event_name character varying, subjid bigint[], rev integer) returns bigint
    language plpgsql
as
$$
declare
    evId bigint;
    s     bigint;
begin
    insert into event(name) values (event_name) returning id into evId;
    foreach s in array subjId
        loop
            insert into event_subjects(ev_id, subj_id) values (evId, s);
        end loop;

    insert into exam(ev_id, revision) values (evId, rev);
    return evId;
end;
$$;

alter function add_exam_event(varchar, bigint[], integer) owner to s263975;

