create function checkfamilyparams() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (NEW."Loyalty") > 100 THEN NEW."Loyalty" = 100; END IF;
    IF (NEW."Loyalty") < 0 THEN NEW."Loyalty" = 0; END IF;

    IF (NEW."Care") > 100 THEN NEW."Care" = 100; END IF;
    IF (NEW."Care") < 0 THEN NEW."Care" = 0; END IF;

    IF (NEW."Education") > 100 THEN NEW."Education" = 100; END IF;
    IF (NEW."Education") < 0 THEN NEW."Education" = 0; END IF;

    IF (NEW."Alimony") < 0 THEN NEW."Alimony" = 0; END IF;

    IF (NEW."Satiety") > 50 THEN NEW."Satiety" = 50; END IF;
    IF (NEW."Satiety") < 0 THEN NEW."Satiety" = 0; END IF;

    RETURN NEW;
END;
$$;

alter function checkfamilyparams() owner to s264425;

