create function insert_random_database(count integer) returns void
    language plpgsql
as
$$
BEGIN
        PERFORM insert_cinema_circuit(count / 100);
        PERFORM insert_cinemas(count / 50);
        PERFORM insert_rooms(count / 100);
        PERFORM insert_places();
        PERFORM insert_users(count*2);
        PERFORM insert_people(count);
        PERFORM insert_genres(count);
        PERFORM insert_films(count/4);
        PERFORM insert_sessions();
        PERFORM insert_responses();
        PERFORM inset_genres_to_filmes();
END;
$$;

alter function insert_random_database(integer) owner to s242395;

