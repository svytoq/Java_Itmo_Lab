create function check_serial_place() returns trigger
    language plpgsql
as
$$
DECLARE
  r int;
BEGIN
  if new.id = 0 or new.id = -1
  then
    loop
      BEGIN
        insert into place (name) values (new.name);
        return null;
        EXCEPTION
        when unique_violation
          then
            r = nextval(pg_get_serial_sequence('place', 'id'));
      end;
    end loop;
  else return new;
  end if;
ENd;
$$;

alter function check_serial_place() owner to s243872;

