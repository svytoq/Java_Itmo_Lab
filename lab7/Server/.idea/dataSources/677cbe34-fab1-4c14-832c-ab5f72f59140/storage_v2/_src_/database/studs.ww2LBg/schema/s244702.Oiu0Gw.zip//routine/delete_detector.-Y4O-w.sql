create function delete_detector() returns trigger
    language plpgsql
as
$$
DECLARE status status;
BEGIN
        status=(SELECT system.status FROM system WHERE old.system_id=system.system_id);
        IF status = 'on' THEN RAISE EXCEPTION 'Нельзя удалить детектор из работающей системы';
        end IF ;
        return old;
END;
$$;

alter function delete_detector() owner to s244702;

