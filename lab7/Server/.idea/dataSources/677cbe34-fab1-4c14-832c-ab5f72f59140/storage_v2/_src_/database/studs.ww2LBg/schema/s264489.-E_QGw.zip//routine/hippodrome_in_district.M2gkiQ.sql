create function hippodrome_in_district() returns trigger
    language plpgsql
as
$$
DECLARE
--         Проверяем, чтобы ипподром был, только там где население больше 5000
        population_district integer;
    BEGIN
        SELECT population INTO population_district FROM Districts d WHERE d.id = NEW.district;
        IF (population_district < 5000) THEN
            RAISE EXCEPTION 'В таком маленьком районе не может быть ипподрома';
        END IF;
        RETURN NEW;
    END;
$$;

alter function hippodrome_in_district() owner to s264489;

