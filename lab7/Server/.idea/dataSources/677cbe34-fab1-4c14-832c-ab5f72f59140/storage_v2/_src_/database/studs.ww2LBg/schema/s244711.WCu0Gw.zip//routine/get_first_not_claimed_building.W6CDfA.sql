create function get_first_not_claimed_building() returns integer
    language plpgsql
as
$$
DECLARE
	building int;
BEGIN
	SELECT id INTO STRICT building
		FROM building_instances
		WHERE (NOT is_building_claimed(id))
		LIMIT 1;

	RETURN building;
END;
$$;

alter function get_first_not_claimed_building() owner to s244711;

