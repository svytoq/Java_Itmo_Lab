create function species_salary_statistics()
    returns TABLE(name text, avg_salary double precision, max_salary double precision, min_salary double precision)
    language sql
as
$$
SELECT worm_species.name, 
AVG(salary)::float AS avg_salary,
  MAX(salary)::float AS max_salary, 
MIN(salary)::float AS min_salary 
FROM worms JOIN worm_species ON worms.species=worm_species.name 
GROUP BY worm_species.name ORDER BY avg_salary DESC;
$$;

alter function species_salary_statistics() owner to s265098;

