create function check_if_alive(id integer) returns boolean
    language plpgsql
as
$$
declare
stat text;
begin
select СТАТУС into stat from МИССИИ where ЦЕЛЬ = id and ТИП = 1;
if stat = 'Выполнена' then
return false;
else
return true;
        end if;
end;
$$;

alter function check_if_alive(integer) owner to s242322;

