create function person_updates_func() returns trigger
    language plpgsql
as
$$
BEGIN
NEW.КТО_ИЗМЕНИЛ := CURRENT_USER;
NEW.КОГДА_ИЗМЕНИЛ := CURRENT_TIMESTAMP;
RETURN NEW;
END;
$$;

alter function person_updates_func() owner to s269331;

