create function fahri_task(sch character varying DEFAULT ''::character varying) returns void
    language plpgsql
as
$$
begin
    if sch = ''
    then raise exception 'Уважаемый пользователь, Вы не правильно вызвали функцию - пример вызова psql -h pg -d studs -f script3.sql -v v1="''dima''";';
    end if;

    declare
        count int := 1;
        temp text := '';
--         pid int := 0;
        tables cursor for (select tablename from pg_catalog.pg_tables where schemaname = sch);
    begin

        if (select count(*) from information_schema.tables where table_schema = sch) < 1
        then raise exception 'Таблиц нет в данной схеме';
        end if;

        raise notice 'Схема: %',sch;
        raise notice ' ';
        raise notice 'No. Имя таблицы';
        raise notice '--- -----------';

        for row in tables
            loop
                execute format('select pg_cursors.name from pg_cursors where statement like %L', concat('%', row.tablename, '%'))
                    into temp;

                if temp is not NULL
                then
--                     execute format('select pid from pg_stat_activity where usename = %L;', sch) into pid;
                    raise notice '% %', rpad(count::text, 3, ' '), rpad(row.tablename, 13, ' ');
                    count = count + 1;
                end if;
            end loop;
    end;
end;
$$;

alter function fahri_task(varchar) owner to s270239;

