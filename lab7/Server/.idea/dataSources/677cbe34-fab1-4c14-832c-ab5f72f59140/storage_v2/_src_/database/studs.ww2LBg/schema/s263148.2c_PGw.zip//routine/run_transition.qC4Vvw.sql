create function run_transition() returns trigger
    language plpgsql
as
$$
declare
    character_current_org_id int;
    new_base_id int;
  begin
    select organization_id into character_current_org_id 
    from characters where id = new.character;
    
    if character_current_org_id != new.from_org then
      raise exception 'Вы не состоите в данной организации';
    end if;
    
    select b.id into new_base_id from bases b 
    inner join regions r on (r.id=b.region_id)
    inner join organizations o on (r.organization_id = o.id)
    where o.id = new.to_org limit 1;
    
    update characters set 
    base_id = new_base_id, organization_id = new.to_org, team_id = null
    where id = new.character;
    
    return new;
  end;
$$;

alter function run_transition() owner to s263148;

