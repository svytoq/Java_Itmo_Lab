create function check_grade_date_and_time() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (NEW.дата >= CURRENT_TIMESTAMP) THEN
		RAISE EXCEPTION 'Успеваемость: дата и время превышает текущую дату и время!';
	END IF;
	RETURN NEW;
END;
$$;

alter function check_grade_date_and_time() owner to s223758;

