create function recruit(pass integer) returns void
    language plpgsql
as
$$
declare
        location integer;
        otd record;
        otd_id integer;
        p_id integer;
        otd_c integer;
    begin
        if exists(select 1 from ЧЛЕНЫ_ПОЛИЦИИ where ПАСПОРТ = pass) then
            raise notice 'Гражданин % уже завербован', pass;
            return;
        end if;
        select МЕСТОПОЛОЖЕНИЕ into location from ГРАЖДАНЕ where ПАСПОРТ = pass;
        select count(*) into otd_c from ОТДЕЛЫ where МЕСТОПОЛОЖЕНИЕ = location;
        if otd_c = 0 then
            select ИД into otd_id from ОТДЕЛЫ order by random() limit 1;
        else 
            select ИД into otd_id from ОТДЕЛЫ where МЕСТОПОЛОЖЕНИЕ = location order by random() limit 1;
        end if;
        insert into ЧЛЕНЫ_ПОЛИЦИИ values(DEFAULT, pass, otd_id, 0) returning ИД into p_id;
        insert into ПСИХ_ПОРТРЕТ values(p_id, 50, 50, 50);
    end;
$$;

alter function recruit(integer) owner to s242322;

