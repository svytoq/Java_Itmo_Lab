create function get_item_data(main_item_id integer)
    returns TABLE(item_id integer, name character varying, price real, length real, width real, height real, in_stock_storage boolean, in_stock_shop boolean, store_room character varying)
    language plpgsql
as
$$
BEGIN
        RETURN QUERY
            SELECT it.id AS item_id, it.name, it.price, it.length, it.width, it.height,
                   it.in_stock_storage, it.in_stock_shop, room.name
            FROM item it
            INNER JOIN store_room room ON it.store_room_id = room.id
            WHERE it.id = main_item_id;
    END;
$$;

alter function get_item_data(integer) owner to s264443;

