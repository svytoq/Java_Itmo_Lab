create function count_force_army2() returns trigger
    language plpgsql
as
$$
BEGIN
		UPDATE АРМИЯ SET БОЕВАЯ_МОЩЬ = (select sum(БОЕВАЯ_МОЩЬ) from ОТРЯД
									   WHERE ОТРЯД.ID_АРМИИ = NEW.ID_АРМИИ )
									   where АРМИЯ.ID = NEW.ID_АРМИИ;
	return null;
	END;
$$;

alter function count_force_army2() owner to s251091;

