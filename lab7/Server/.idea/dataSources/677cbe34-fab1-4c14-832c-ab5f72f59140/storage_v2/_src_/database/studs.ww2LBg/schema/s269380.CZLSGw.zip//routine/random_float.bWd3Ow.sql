create function random_float(val_max integer) returns double precision
    language sql
as
$$
select (random() * val_max)
$$;

alter function random_float(integer) owner to s269380;

