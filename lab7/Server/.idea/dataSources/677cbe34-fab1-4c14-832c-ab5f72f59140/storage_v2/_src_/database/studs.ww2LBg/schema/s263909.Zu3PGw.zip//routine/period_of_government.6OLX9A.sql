create function period_of_government(country_leader_id integer) returns integer
    language plpgsql
as
$$
declare
    start_of_period date;
    end_of_period date;
    period  integer;
begin
    start_of_period = (select beginning_of_reign from country_lord where lord_id = country_leader_id);
    end_of_period = (select end_of_reign from country_lord where lord_id = country_leader_id);
    period = (select end_of_period - start_of_period);
    return period;
end;
$$;

alter function period_of_government(integer) owner to s263909;

