create function func_min_exam_mark() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NOT (EXISTS (SELECT код_предмета FROM предмет WHERE код_предмета = NEW.код_предмета)) 
    THEN RAISE NOTICE 'Предмета с кодом % не существует', new.код_предмета; RETURN NULL;
  END IF;
  IF NEW.балл < (SELECT порог FROM предмет WHERE код_предмета = NEW.код_предмета) 
    THEN RAISE NOTICE 'Балл абитуриента (%) ниже порогового (%)', new.балл, (SELECT порог FROM предмет WHERE код_предмета = NEW.код_предмета); RETURN NULL;
  END IF;
  IF NEW.балл > 100
    THEN RAISE NOTICE 'Балл абитуриента выше 100'; RETURN NULL;
  END IF;
    RETURN NEW;
END;
$$;

alter function func_min_exam_mark() owner to s243859;

