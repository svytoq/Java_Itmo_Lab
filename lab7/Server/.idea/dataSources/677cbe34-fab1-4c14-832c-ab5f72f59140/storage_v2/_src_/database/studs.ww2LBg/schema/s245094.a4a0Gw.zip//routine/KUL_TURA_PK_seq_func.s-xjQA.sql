create function "КУЛЬТУРА_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "КУЛЬТ_ИД" FROM "КУЛЬТУРА");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."КУЛЬТ_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''КУЛЬТУРА_КУЛЬТ_ИД_seq'', max("КУЛЬТ_ИД") + 1) FROM "КУЛЬТУРА"';
                        NEW."КУЛЬТ_ИД" := max_id + 1;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "КУЛЬТУРА_PK_seq_func"() owner to s245094;

