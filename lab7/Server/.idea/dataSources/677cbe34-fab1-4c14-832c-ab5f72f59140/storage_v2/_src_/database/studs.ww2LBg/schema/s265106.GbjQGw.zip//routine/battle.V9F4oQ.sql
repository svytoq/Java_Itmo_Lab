create function battle(army_1 integer, army_2 integer) returns integer
    language plpgsql
as
$$
declare
        app_area_1 int;
        app_area_2 int;
    begin

        app_area_1 = (select army_type
                      from army
                      where id = army_1);
        app_area_2 = (select army_type
                      from army
                      where id = army_2);
        if (app_area_1 = app_area_2) then
            if (calc_army_power(army_1) > calc_army_power(army_2)) then
                return army_1;
            else
                if (calc_army_power(army_1) = calc_army_power(army_2)) then
                    return 0;
                else
                    return army_2;
                end if;
            end if;
        end if;
        return -1;
    end;
$$;

alter function battle(integer, integer) owner to s265106;

