create function lgotniki_func() returns trigger
    language plpgsql
as
$$
DECLARE
  old_vid_logoti "ВИДЫ_ЛЬГОТ";

BEGIN

    IF(SELECT "Вид_льготы" FROM "Льготники" WHERE "Код_пассажира" = new."Код_пассажира" AND "Вид_льготы" = new."Вид_льготы" ) IS NOT NULL 
      THEN RAISE EXCEPTION 'Добавление льготы невозможно.Данная Льгота не может быть предоставлена данному пассажиру';

    END IF;




    IF (new."Вид_льготы" = 'Учащийся общеобр. учреждения' OR  new."Вид_льготы" = 'Студент очной формы обучения')
                            AND ((SELECT "Код_пассажира" FROM "Льготники" WHERE "Код_пассажира" = new."Код_пассажира"
                                  GROUP BY "Код_пассажира" HAVING count("Код_льготы") > 0) IS NOT NULL)
      THEN RAISE EXCEPTION 'Добавление льготы невозможно.Данная Льгота не может быть предоставлена данному пассажиру';
    END IF;


    IF ((SELECT "Код_пассажира" FROM "Льготники" WHERE "Код_пассажира" = new."Код_пассажира"
                                  GROUP BY "Код_пассажира" HAVING count("Код_льготы") > 0) IS NOT NULL )
        THEN
            old_vid_logoti =  (SELECT "Вид_льготы" FROM "Льготники"
                                WHERE "Код_пассажира" = new."Код_пассажира"
                                      AND ("Вид_льготы" ='Учащийся общеобр. учреждения'));
            IF (old_vid_logoti is NOT null)
              THEN
                RAISE EXCEPTION 'Добавление льготы невозможно.Данная Льгота не может быть предоставлена данному пассажиру';
            END IF;

            old_vid_logoti =  (SELECT "Вид_льготы" FROM "Льготники"
                                        WHERE "Код_пассажира" = new."Код_пассажира" AND ("Вид_льготы" ='Студент очной формы обучения'));
            IF (old_vid_logoti is NOT null )
              THEN
                RAISE EXCEPTION 'Добавление льготы невозможно. Данная льгота не может быть предоставлена данному пассажиру';
             END IF;

    end if;
RETURN new;
END;
$$;

alter function lgotniki_func() owner to s244710;

