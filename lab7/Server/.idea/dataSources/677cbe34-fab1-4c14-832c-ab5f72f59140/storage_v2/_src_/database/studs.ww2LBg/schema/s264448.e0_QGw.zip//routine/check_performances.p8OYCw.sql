create function check_performances(championship_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
    cur_performance performance%rowtype;
BEGIN
    FOR cur_performance IN
        (SELECT * FROM performance WHERE
            (SELECT team.championship_id FROM team
                JOIN project ON team.team_id = project.team_id AND project.project_id = performance.project_id)
                = check_performances.championship_id)
    LOOP
        IF championship_id != ANY (SELECT judge.championship_id FROM judge WHERE judge_team_id = cur_performance.judge_team_id) THEN
            RAISE EXCEPTION 'Judge team should be from the same championship';
        END IF;

        IF NOT EXISTS(SELECT * FROM championship_platform WHERE championship_platform.championship_id = check_performances.championship_id
                                                            AND platform_id = cur_performance.platform_id) THEN
            RAISE EXCEPTION 'Unavailable platform for this championship!';
        END IF;
    END LOOP;
    RETURN true;
END;
$$;

alter function check_performances(integer) owner to s264448;

