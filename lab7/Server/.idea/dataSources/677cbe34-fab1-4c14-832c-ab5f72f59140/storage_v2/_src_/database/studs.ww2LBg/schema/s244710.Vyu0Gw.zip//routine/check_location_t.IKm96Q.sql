create function check_location_t() returns trigger
    language plpgsql
as
$$
DECLARE
  tip_fiksatora "ФИКСАТОР";
  BEGIN
    tip_fiksatora = (SELECT "Вид_фиксатора" FROM "Место_оплаты_проезда" where ( "Место_оплаты_проезда"."Код_места_оплаты_проезда" = new."Код_места_оплаты_проезда"));

    IF (tip_fiksatora != 'ВАЛИДАТОР') THEN RAISE EXCEPTION 'Добавление невозможно. Тип фиксатора не соответствет типу транспорта';
      END IF;
  RETURN new;
  END;
$$;

alter function check_location_t() owner to s244710;

