create function "СЕАНС_ПЕРСОНАЛ_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "СЕАНС_ПЕРСОНАЛ" ("ИД_ПЕРСОНАЛ","ИД_СЕАНСА")
VALUES ((SELECT "ИД_ПЕРСОНАЛА" FROM "ПЕРСОНАЛ" OFFSET floor(random()* 100) LIMIT 1),(SELECT "ИД" FROM "СЕАНС" OFFSET floor(random()*7) LIMIT 1));
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END LOOP;
END;
$$;

alter function "СЕАНС_ПЕРСОНАЛ_ТЕСТ"(integer) owner to s223443;

