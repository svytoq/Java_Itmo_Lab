create function warriors() returns trigger
    language plpgsql
as
$$
DECLARE
  POL  VARCHAR(3);
  SOSL SOSL;
BEGIN
  SELECT ПОЛ
  FROM ЛЮДИ
  WHERE ID_ЧЕЛ = NEW.ID_ВОИНА
  INTO POL;
  SELECT СОСЛОВИЕ
  FROM ЛЮДИ
  WHERE ID_ЧЕЛ = NEW.ID_ВОИНА
  INTO SOSL;
  IF POL = 'муж'  AND SOSL != 'ТОРГОВЕЦ'
  THEN
    IF NEW.ДОЛЖНОСТЬ != 'ЛЕГИОНЕР'
    THEN
      RETURN NEW;
    ELSEIF SOSL = 'ПАТРИЦИЙ'
      THEN RETURN NEW;
    ELSE RAISE NOTICE '% НЕ МОЖЕТ БЫТЬ ЛЕГИОНЕРОМ. ТОЛЬКО ПАТРИЦИЙ', SOSL;
      RETURN NULL;
    END IF;
  ELSEIF POL = 'жен' 
    THEN
      RAISE NOTICE 'ВОИНАМИ МОГУТ БЫТЬ ТОЛЬКО МУЖЧИНЫ';
      RETURN NULL;
  ELSEIF SOSL = 'ТОГОВЕЦ'
    THEN
      RAISE NOTICE 'ТОРГОВЕЦ НЕ МОЖЕТ БЫТЬ ВОИНОМ';
      RETURN NULL;
  END IF;
  RETURN NULL;
END;
$$;

alter function warriors() owner to s225081;

