create function book_the_car(car integer, defects character varying) returns void
    language plpgsql
as
$$
declare
    request integer;
begin
    INSERT INTO client_requests(lights, lock, start_a_ride, tell_about_defects)
    VALUES (false, false, false, defects);
    request = (select request_id from client_requests order by request_id desc limit 1);
    INSERT INTO booked_car(car_id, request_id) VALUES (car, request);
    INSERT INTO ride(car_id, route, speed_in_km_h, mileage) VALUES (car, ' ', 0, 0);
end;
$$;

alter function book_the_car(integer, varchar) owner to s263138;

