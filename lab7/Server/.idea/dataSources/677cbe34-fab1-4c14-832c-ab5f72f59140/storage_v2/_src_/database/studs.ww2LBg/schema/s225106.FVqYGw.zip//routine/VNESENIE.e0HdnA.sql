create function "ВНЕСЕНИЕ"() returns trigger
    language plpgsql
as
$$
DECLARE
chel1 int;
chel2 int;
rel int;
BEGIN
SELECT ИД INTO STRICT chel1 FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=NEW.ИД_ЧЕЛ_1;
SELECT ИД INTO STRICT chel2 FROM ЧЕЛОВЕК WHERE КОРОТКОЕ_ИМЯ=NEW.ИД_ЧЕЛ_2;
SELECT ИД INTO STRICT rel FROM ОТНОШЕНИЕ WHERE ОТНОШЕНИЕ=NEW.ИД_ОТН;
NEW.ИД_ЧЕЛ_1=chel1;
NEW.ИД_ЧЕЛ_2=chel2;
NEW.ИД_ОТН=rel;
RETURN NEW;
END;
$$;

alter function "ВНЕСЕНИЕ"() owner to s225106;

