create function insert_event_members() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
    event integer = trunc(random()*100)+1;
    clan integer = trunc(random()*20)+1;
  BEGIN
    LOOP
      if NOT EXISTS(SELECT * FROM event_members WHERE clan_id = clan AND event_id = event)
        THEN
          INSERT INTO event_members VALUES (event, clan);
          count = count + 1;
        ELSE
          event = trunc(random()*100)+1;
          clan = trunc(random()*20)+1;
      END IF;
      EXIT WHEN count = 500;
    END LOOP;
  END;
$$;

alter function insert_event_members() owner to s225107;

