create function trigger_buy_weapon() returns trigger
    language plpgsql
as
$$
declare
    weapon_price int;
    org_account_id int;
    org_money_amount int;
  begin
    select price into weapon_price 
    from weapons where id = new.weapon_id;
    
    select a.amount, a.id into org_money_amount, org_account_id from characters c
    inner join organizations o on (c.organization_id = o.id)
    inner join accounts a on (a.organization_id = o.id)
    where c.id = new.character_id;
    
    if weapon_price > org_money_amount then
      raise exception 'У вашей организации недостаточно средств';
    end if;
    
    update accounts set amount = amount - weapon_price where id = org_account_id;
    
    return new;
  end;
$$;

alter function trigger_buy_weapon() owner to s263148;

