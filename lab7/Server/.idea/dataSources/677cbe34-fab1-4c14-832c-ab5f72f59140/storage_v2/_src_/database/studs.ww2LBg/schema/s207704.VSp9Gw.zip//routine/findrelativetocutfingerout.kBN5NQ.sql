create function findrelativetocutfingerout(smoker integer)
    returns TABLE(firstname character varying, lastname character varying, relationship character varying)
    language plpgsql
as
$$
begin
        return query
        SELECT P.firstName, P.lastName, RS.relationship from person P inner join
            (SELECT personId, R.relationship from relative R
                where smokerid = smoker AND isfingercuttingoff = false) RS
            on RS.personid = P.id;
    end;
$$;

alter function findrelativetocutfingerout(integer) owner to s207704;

