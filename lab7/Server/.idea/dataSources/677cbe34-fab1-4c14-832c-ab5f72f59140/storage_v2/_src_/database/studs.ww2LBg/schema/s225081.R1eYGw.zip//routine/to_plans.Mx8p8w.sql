create function to_plans(count integer) returns void
    language plpgsql
as
$$
DECLARE
  J    INT;
  NM   VARCHAR(30);
  STAT BOOLEAN;
  DAT  DATE;
BEGIN
  DAT = '0431-02-03 BC';
  FOR J IN 1..COUNT LOOP
    STAT = TRUE;
    NM = 'ПЛАН_'||J;
    IF J % 16 = 0
    THEN DAT = DAT + 31;
      STAT = FALSE; END IF;
    INSERT INTO ПОЛИТИЧЕСКИЕ_ПЛАНЫ VALUES (DEFAULT, NM, DAT, STAT);
  END LOOP;
END;
$$;

alter function to_plans(integer) owner to s225081;

