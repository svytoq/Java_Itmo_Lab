create function "ПРОИЗВЕДЕНИЯ_СОБРАНИЯ"(id integer)
    returns TABLE("НАЗВАНИЕ_ПРОИЗВЕДЕНИЯ" character varying, "ГОД_НАПИСАНИЯ" smallint, "ГОД_ИЗДАНИЯ" smallint, "ТЕМА" character varying, "ЖАНР" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"ПРОИЗВЕДЕНИЯ"."НАЗВАНИЕ_ПРОИЗВЕДЕНИЯ", "ПРОИЗВЕДЕНИЯ"."ГОД_НАПИСАНИЯ", "ПРОИЗВЕДЕНИЯ"."ГОД_ИЗДАНИЯ", "ПРОИЗВЕДЕНИЯ"."ТЕМА","ПРОИЗВЕДЕНИЯ"."ЖАНР"
FROM "ПРОИЗВЕДЕНИЯ" NATURAL JOIN "СОДЕРЖАНИЕ" WHERE "СОДЕРЖАНИЕ"."ИД_СОБРАНИЯ" = id;
END;
$$;

alter function "ПРОИЗВЕДЕНИЯ_СОБРАНИЯ"(integer) owner to s225071;

