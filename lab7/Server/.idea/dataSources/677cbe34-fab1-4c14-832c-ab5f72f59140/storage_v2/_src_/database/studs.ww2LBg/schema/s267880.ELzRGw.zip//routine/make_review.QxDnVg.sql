create function make_review(client_user_profile_id integer, product_prototype_id integer, comment text, rating integer) returns void
    language sql
as
$$
insert into review(user_profile_id, product_prototype_id, "comment", rating)
    values ($1, $2, $3, $4)
    on conflict(user_profile_id, product_prototype_id)
    do update set "comment" = make_review.comment, rating = make_review.rating;
$$;

alter function make_review(integer, integer, text, integer) owner to s267880;

