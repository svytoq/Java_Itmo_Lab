create function check_weapons_before_using() returns trigger
    language plpgsql
as
$$
DECLARE
    required_access_level SMALLINT;
    weapon_count INTEGER;
    BEGIN
    weapon_count := (SELECT quantity FROM weaponry where id = NEW.weapon_id);
    required_access_level := (SELECT required_access_lvl FROM weaponry WHERE id = NEW.weapon_id);
    IF NEW.access_level < required_access_level THEN
      RAISE EXCEPTION 'Employee''s admission level must be higher to access this weapon.';
    ELSE IF weapon_count = 0 THEN
      RAISE EXCEPTION 'Insufficient quantity of weapons. Try again later.';
      ELSE
        UPDATE weaponry SET quantity = quantity-1 WHERE id = NEW.weapon_id;
      END IF;
    END IF;
    RETURN NEW;
  END;
$$;

alter function check_weapons_before_using() owner to s243864;

