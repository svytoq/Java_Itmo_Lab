create function get_danger_q(id_crt integer) returns integer
    language plpgsql
as
$$
DECLARE
age int;
attitude text;
c_avg_life int;
c_puberty_age int;
danger_quotient int;
type_row record;
BEGIN
SELECT attitude_human, birthday, avg_life, puberty_age INTO type_row 
FROM creature JOIN type 
ON id_type = type.id WHERE creature.id = id_crt;
attitude = type_row.attitude_human;
c_avg_life = type_row.avg_life;
c_puberty_age = type_row.puberty_age;
age = extract(year from age(type_row.birthday));
CASE attitude
WHEN 'Вражда' THEN danger_quotient = 5;
WHEN 'Недоверие' THEN danger_quotient = 4;
WHEN 'Раводушие' THEN danger_quotient = 2;
ELSE danger_quotient = 0;
END CASE;
IF age <= c_puberty_age THEN
danger_quotient = danger_quotient + 2;
ELSIF age < c_avg_life THEN
danger_quotient = danger_quotient + 5;
ELSE
danger_quotient = danger_quotient + 3;
END IF;
RETURN danger_quotient;
END;
$$;

alter function get_danger_q(integer) owner to s243856;

