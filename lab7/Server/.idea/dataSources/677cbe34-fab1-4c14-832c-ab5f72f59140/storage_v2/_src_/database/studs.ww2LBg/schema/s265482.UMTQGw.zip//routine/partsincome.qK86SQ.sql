create function partsincome() returns void
    language sql
as
$$
update shipments
    set count_left    = count_left + delivery_size,
        delivery_date = delivery_date + delivery_interval
    where delivery_date = current_date;
$$;

alter function partsincome() owner to s265482;

