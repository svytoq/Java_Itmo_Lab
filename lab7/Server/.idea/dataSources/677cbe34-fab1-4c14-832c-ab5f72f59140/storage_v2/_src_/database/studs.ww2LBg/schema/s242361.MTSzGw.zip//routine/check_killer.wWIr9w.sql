create function check_killer() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((NEW.ИД_УБИЙЦЫ IS NOT NULL) and (NEW.ИД_ИГРЫ != (SELECT ИД_ИГРЫ FROM ТРИБУТЫ WHERE ИД_ТРИБУТА = NEW.ИД_УБИЙЦЫ)))THEN
RAISE WARNING 'Трибут и убийца должны быть в одной игре';
RETURN NULL;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function check_killer() owner to s242361;

