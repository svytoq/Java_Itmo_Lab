create function count() returns integer
    language plpgsql
as
$$
DECLARE
i INTEGER :=1;
j INTEGER:=1;
k INTEGER:=1;
l INTEGER:=1;
BEGIN
WHILE i=1 LOOP
j=i*6;
k=5+7/7+6;
l=4+k/6*7;
k=4+l/7;
l=18/6*7;
k=l/7+3;
l=(21+3)/6*7;
k=2+l/7;
l=(27+3)/6*7+1;
k=l/6;
i=0;
END LOOP;
RETURN l;
END;
$$;

alter function count() owner to s243874;

