create function hsv_to_rgb(hue double precision, saturation double precision, value double precision) returns integer
    language plpgsql
as
$$
declare
    c double precision := null;
    x double precision := null;
    m double precision := null;
    mr double precision := null;
    mg double precision := null;
    mb double precision := null;
    r double precision := null;
    g double precision := null;
    b double precision := null;
begin
    c := value * saturation;
    x := c * (1.0 - abs(fmod(hue*6, 2) - 1.0));
    m := value - c;
    if 0 <= hue and hue < 60.0/360 then
        mr := c; mg := x; mb := 0;
    elseif 60.0/360 <= hue and hue < 120.0/360 then
        mr := x; mg := c; mb := 0;
    elseif 120.0/360 <= hue and hue < 180.0/360 then
        mr := 0; mg := c; mb := x;
    elseif 180.0/360 <= hue and hue < 240.0/360 then
        mr := 0; mg := x; mb := c;
    elseif 240.0/360 <= hue and hue < 300.0/360 then
        mr := x; mg := 0; mb := c;
    else
        mr := c; mg := 0; mb := x;
    end if;

    r := (mr + m)*255;
    g := (mg + m)*255;
    b := (mb + m)*255;

    return floor(r)*256*256 + floor(g)*256 + floor(b);
end;
$$;

alter function hsv_to_rgb(double precision, double precision, double precision) owner to s264429;

