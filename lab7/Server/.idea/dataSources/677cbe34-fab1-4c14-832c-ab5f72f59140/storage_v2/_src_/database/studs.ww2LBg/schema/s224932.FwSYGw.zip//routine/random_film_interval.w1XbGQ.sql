create function random_film_interval() returns interval
    language plpgsql
as
$$
BEGIN
        return random() * interval '2 months';
END;
$$;

alter function random_film_interval() owner to s224932;

