create function addschedulerating(rating integer, comments text, schedule integer) returns text
    strict
    language plpgsql
as
$$
DECLARE
ret int;
BEGIN
	INSERT INTO оценка(оценка, отзыв) VALUES(rating, comments) RETURNING id INTO ret;
	INSERT INTO оценка_расписания(id, id_оценки, id_расписания) VALUES(ret, ret, schedule);
	RETURN 'Оценка на расписание добавлена, id - ' || ret;
END;
$$;

alter function addschedulerating(integer, text, integer) owner to s265082;

