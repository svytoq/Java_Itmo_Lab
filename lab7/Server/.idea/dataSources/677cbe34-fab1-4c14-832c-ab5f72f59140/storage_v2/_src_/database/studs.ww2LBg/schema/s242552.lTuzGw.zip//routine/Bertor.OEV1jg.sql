create function "Бертор"(id integer, "id_базы" integer, "название" character varying) returns void
    language plpgsql
as
$$
BEGIN
insert into корабль values(ID, 400, название, '[46, 50]' , 6300, 'создается',11900, ID_базы, now(), null);
insert into оружие_корабль values(4, ID);
insert into оружие_корабль values(9, ID);
insert into оружие_корабль values(13, ID);
END;
$$;

alter function "Бертор"(integer, integer, varchar) owner to s242552;

