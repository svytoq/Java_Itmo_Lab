create function demon_salary(n character varying) returns SETOF void
    language plpgsql
as
$$
declare
    demon_id int;
    count_of_missions int;
BEGIN
demon_id = (select worker_id from demon_card join worker w on demon_card.worker_id = w.id where name = n);
count_of_missions = (select count(*) from mission where worker_id = demon_id);
update demon_card set salary = (count_of_missions*30000) where worker_id = demon_id;
END;
$$;

alter function demon_salary(varchar) owner to s265936;

