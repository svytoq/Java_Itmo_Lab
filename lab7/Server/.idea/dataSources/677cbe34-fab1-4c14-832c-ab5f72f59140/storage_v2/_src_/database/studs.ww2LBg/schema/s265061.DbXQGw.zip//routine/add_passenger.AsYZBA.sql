create function add_passenger(character varying, character varying, character varying, pasp character, date) returns boolean
    language plpgsql
as
$$
begin
  if  (select true from  passenger where passport_no=$4) then return true; end if ;
  insert into passenger (passport_no, name, second_name, third_name, birthday)
  values (pasp, $1, $2, $3, $5);
  return true;
end;
$$;

alter function add_passenger(varchar, varchar, varchar, char, date) owner to s265061;

