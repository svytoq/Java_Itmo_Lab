create function gen_fake_data() returns text
    language plpgsql
as
$$
DECLARE
region_one int;
BEGIN
  INSERT INTO Space_yard(id, price)
  SELECT i, random_between(100,1000) FROM generate_series(10, 10000) as i;
  
  INSERT INTO Store(id, name)
  SELECT i, random_string() FROM generate_series(10, 10000) as i;
  
  INSERT INTO Jail(id, name)
  SELECT i, random_string() FROM generate_series(10, 10000) as i;
  
  INSERT INTO Planet(id, yard_id, store_id, jail_id, name)
  SELECT i, i, i, i, random_string() FROM generate_series(10, 10000) as i;
  
  INSERT INTO Space_ship(id, planet_id, name, fuel) 
  SELECT i, random_between(10, 10000), random_string(), random_between(100000, 10000000)  FROM generate_series(10, 50000) as i;
  
  INSERT INTO Inventory(id)
  SELECT i FROM generate_series(10, 50000) as i;
  
  INSERT INTO Hunter(id, ship_id, inventory_id, name, money_amount, skills)
  SELECT i, i, i, random_string(), random_between(100000, 10000000), random_between(10,100) FROM generate_series(10, 50000) as i;
  
  INSERT INTO Weapon(id, inventory_id, store_id, name, price, level)
  SELECT i, 
  CASE WHEN i%2=0 THEN random_between(10, 50000) ELSE null END, 
  CASE WHEN i%2!=0 THEN random_between(10, 10000) ELSE null END, 
  random_string(), random_between(5000, 200000), random_between(1, 100)
  FROM generate_series(10, 100000) as i;
  
  INSERT INTO Criminal (id, planet_id, jail_id, name, skills, price)
  SELECT i, GREATEST(i%10000,10),
  CASE WHEN i%5=0 THEN GREATEST(i%10000,10) ELSE null END,
  random_string(), 
  random_between(1, 100),
  random_between(100000, 10000000)
  FROM generate_series(10, 40000) as i;
  
  INSERT INTO Space_gate (id, come_from, go_to, fuel, price)
  SELECT i, i, i+1, random_between(1000, 100000), random_between(100, 1000)  FROM generate_series(100, 9999) as i;
  
  RETURN 'Fake data generated';
END;
$$;

alter function gen_fake_data() owner to s263081;

