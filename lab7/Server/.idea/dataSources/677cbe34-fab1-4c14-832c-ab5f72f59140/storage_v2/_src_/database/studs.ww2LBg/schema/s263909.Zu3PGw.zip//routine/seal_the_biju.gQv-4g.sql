create function seal_the_biju(biju_for_sealing integer, new_jinchuriki integer) returns void
    language plpgsql
as
$$
declare
    previous_jinchuriki integer;
begin
    previous_jinchuriki = (select ninja_id from jinchuriki where biju = biju_for_sealing limit 1);
    update ninja
    set status = 'dead'
    where ninja_id = previous_jinchuriki;
    insert into jinchuriki (ninja_id, biju) values (new_jinchuriki, biju_for_sealing);
end;
$$;

alter function seal_the_biju(integer, integer) owner to s263909;

