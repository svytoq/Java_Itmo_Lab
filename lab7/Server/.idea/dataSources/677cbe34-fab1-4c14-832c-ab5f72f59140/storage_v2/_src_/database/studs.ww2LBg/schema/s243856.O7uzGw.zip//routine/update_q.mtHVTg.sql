create function update_q() returns void
    language plpgsql
as
$$
DECLARE
t_row find_creature%rowtype;
danger_q int;
BEGIN
FOR t_row IN SELECT * FROM find_creature LOOP
DELETE FROM find_creature where id_creature=t_row.id_creature;
insert into find_creature values (t_row.id_creature,1,t_row.beg_date);
end loop;
end;
$$;

alter function update_q() owner to s243856;

