create function order_check_if_closed() returns trigger
    language plpgsql
as
$$
BEGIN
            IF OLD."СТАТУС" = 'ЗАВЕРШЕН' THEN
	                RAISE EXCEPTION 'ЗАКАЗ АРХИВИРОВАН';
			        END IF;
				        RETURN NEW;
					    END;

$$;

alter function order_check_if_closed() owner to s242213;

