create function playerid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('player_id_seq')!=NEW.ID THEN
NEW.ID=nextval('player_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function playerid() owner to s225102;

