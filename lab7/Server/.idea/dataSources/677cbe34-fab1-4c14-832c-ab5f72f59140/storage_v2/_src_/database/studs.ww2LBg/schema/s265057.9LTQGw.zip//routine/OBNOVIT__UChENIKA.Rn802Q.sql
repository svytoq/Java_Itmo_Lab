create function "ОБНОВИТЬ_УЧЕНИКА"() returns trigger
    language plpgsql
as
$$
DECLARE
	is_checked boolean;
	stud_level smallint;
	count_studs smallint;
	age_person ВОЗРАСТ;
	age_group ВОЗРАСТ;
	age interval;
BEGIN
	IF (NEW.ГРУППА_ИД is not null AND NEW.УРОВЕНЬ is null) THEN
		RAISE NOTICE 'Если уровень не установлен, нельзя определить ученика в группу';
		RETURN NULL;
	END IF;
	IF (NEW.УРОВЕНЬ IS NOT NULL) THEN
		IF (OLD.УРОВЕНЬ IS NULL) THEN
			SELECT INTO stud_level УРОВЕНЬ FROM ЭКЗАМЕН WHERE УЧЕНИК_ИД=NEW.УЧЕНИК_ИД AND ТИП='ТЕСТИРОВАНИЕ' AND РЕЗУЛЬТАТ=TRUE;
			IF (not stud_level=NEW.УРОВЕНЬ or stud_level is NULL) THEN
				RAISE NOTICE 'Нельзя установить уровень, т.к. ученик не проходил тестирование';
				RETURN NULL;
			END IF;
		ELSIF (OLD.УРОВЕНЬ>NEW.УРОВЕНЬ) THEN
			RAISE NOTICE 'Новый уровень меньше прежнего';
			RETURN NULL;
		ELSIF (OLD.УРОВЕНЬ<NEW.УРОВЕНЬ) THEN
			SELECT INTO stud_level УРОВЕНЬ FROM ЭКЗАМЕН WHERE ВРЕМЯ_НАЧАЛА=(
				SELECT MAX(ВРЕМЯ_НАЧАЛА) FROM ЭКЗАМЕН WHERE УЧЕНИК_ИД=NEW.УЧЕНИК_ИД AND ТИП='СЕРТИФИКАТ' AND РЕЗУЛЬТАТ=TRUE);
			IF (stud_level is null) THEN
				RAISE NOTICE 'Ученик не сдал ни одного экзамена';
				RETURN NULL;
			END IF;
			stud_level=stud_level+1;
			IF (stud_level!=NEW.УРОВЕНЬ) THEN
				RAISE NOTICE 'Уровень ученика должен быть на 1 больше, чем уровень на последнем экзамене=%',stud_level-1;
				RETURN NULL;
			END IF;
		END IF;
	ELSE 
		IF (OLD.УРОВЕНЬ IS NOT NULL) THEN
			RAISE NOTICE 'Новый уровень должен быть не меньше старого и не равен NULL';
			RETURN NULL;
		END IF;
	END IF;
	IF (NEW.ГРУППА_ИД IS NOT NULL) THEN
		IF ((OLD.ГРУППА_ИД IS NOT NULL AND NOT NEW.ГРУППА_ИД=OLD.ГРУППА_ИД)OR(OLD.ГРУППА_ИД IS NULL)) THEN
			SELECT INTO count_studs КОЛИЧЕСТВО_УЧЕНИКОВ FROM ГРУППА WHERE ГРУППА_ИД=NEW.ГРУППА_ИД;
			IF (count_studs=8) THEN
				RAISE NOTICE 'В группе уже достаточное количество учеников, нельзя добавить этого ученика';
				RETURN NULL;
			END IF;
		END IF;
		IF (NEW.ОЖИДАНИЕ=TRUE) THEN
			RAISE NOTICE 'У ученика уже установлена группа, ожидание != true';
			RETURN NULL;
		END IF;
		SELECT INTO stud_level,age_group УРОВЕНЬ,ВОЗРАСТ FROM ГРУППА WHERE ГРУППА_ИД=NEW.ГРУППА_ИД;
		IF (stud_level!=NEW.УРОВЕНЬ or NEW.УРОВЕНЬ IS NULL) THEN
			RAISE NOTICE 'Уровень ученика % не соответствует уровню группы %',NEW.УРОВЕНЬ,stud_level;
			RETURN NULL;
		END IF;
		age:=age(NEW.ДАТА_РОЖДЕНИЯ);
		if (age>='5 YEARS' and age <'11 YEARS') THEN age_person:='ДЕТИ';
		ELSIF (age>='11 YEARS' AND age<'16 YEARS') THEN age_person:='ПОДРОСТКИ';
		ELSIF (age>='16 YEARS' and age<'65 YEARS') THEN 
			age_person:='ВЗРОСЛЫЕ';
		ELSE age_person:='ПЕНСИОНЕРЫ';
		END IF;
		IF (age_person!=age_group) THEN
			RAISE NOTICE 'Возраст ученика % не соответствует возрасту группы %',age_person,age_group;
			RETURN NULL;
		END IF;
	END IF;
	IF (NEW.СТОИМОСТЬ_ОБУЧЕНИЯ=17500) THEN
		IF NOT EXISTS(SELECT УРОВЕНЬ FROM ЭКЗАМЕН WHERE УЧЕНИК_ИД=NEW.УЧЕНИК_ИД AND ТИП='СЕРТИФИКАТ' AND РЕЗУЛЬТАТ=TRUE) THEN 
			RAISE NOTICE 'Ученику нельзя предоставить скидку, т.к. он не сдал ни одного экзамена';
			RETURN NULL;
		END IF;
	END IF;
	RETURN NEW;
END;
$$;

alter function "ОБНОВИТЬ_УЧЕНИКА"() owner to s265057;

