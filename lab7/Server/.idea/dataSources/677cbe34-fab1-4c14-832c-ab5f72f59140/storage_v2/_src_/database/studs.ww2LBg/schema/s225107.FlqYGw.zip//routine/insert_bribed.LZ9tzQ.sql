create function insert_bribed() returns void
    language plpgsql
as
$$
DECLARE
    count integer = 0;
    bribed_id integer = trunc(random()*10000)+1;
    briber_id integer = trunc(random()*10000)+1;
    clan integer = trunc(random()*20)+1;
  BEGIN
    LOOP
      if (NOT EXISTS(SELECT * FROM bribed WHERE bribe = bribed_id))
         AND (NOT briber_id = bribed_id)
         AND (NOT EXISTS(SELECT * FROM clan_members WHERE clan_id = clan AND hum_id = bribed_id))
        THEN
          INSERT INTO bribed VALUES (DEFAULT, bribed_id, clan, briber_id, '5/12/1998');
          count = count + 1;
        ELSE
          bribed_id = trunc(random()*10000)+1;
          briber_id= trunc(random()*10000)+1;
          clan = trunc(random()*20)+1;
      END IF;
      EXIT WHEN count = 50;
    END LOOP;
  END;
$$;

alter function insert_bribed() owner to s225107;

