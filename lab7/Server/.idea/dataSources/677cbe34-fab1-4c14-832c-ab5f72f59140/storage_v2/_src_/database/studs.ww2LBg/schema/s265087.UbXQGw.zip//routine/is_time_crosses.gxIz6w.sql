create function is_time_crosses(agreed_time timestamp with time zone, producer_id integer, consumer_id integer) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN agreed_time IN (SELECT REQUEST.agreed_time
                           FROM USERS
                                    JOIN request ON USERS.id = request.author
                                    JOIN suggestion_request ON request.id = suggestion_request.request
                                    JOIN suggestion ON suggestion_request.suggestion = suggestion.id
                           WHERE (USERS.ID = PRODUCER_ID OR USERS.ID = CONSUMER_ID)
                             AND (REQUEST.author = PRODUCER_ID)
                             AND (SUGGESTION.author = CONSUMER_ID));
END;
$$;

alter function is_time_crosses(timestamp with time zone, integer, integer) owner to s265087;

