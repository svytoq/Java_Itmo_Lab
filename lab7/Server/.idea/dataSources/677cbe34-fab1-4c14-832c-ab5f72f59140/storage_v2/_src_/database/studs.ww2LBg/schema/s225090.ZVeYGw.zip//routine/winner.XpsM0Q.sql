create function winner() returns trigger
    language plpgsql
as
$$
BEGIN
IF (NEW."points1" > new."points2" AND new."team1_id" = new."winner_id") THEN RETURN new;
  ELSE new."winner_id" = new."team2_id";
END IF;
IF (NEW."points2" > new."points1" AND new."team2_id" = new."winner_id") THEN RETURN new;
  ELSE new."winner_id" = new."team1_id";
END IF;
RETURN new;
END;
$$;

alter function winner() owner to s225090;

