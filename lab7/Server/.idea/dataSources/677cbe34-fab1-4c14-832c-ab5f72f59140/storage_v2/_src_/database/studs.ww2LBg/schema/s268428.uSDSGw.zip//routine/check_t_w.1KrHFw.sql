create function check_t_w() returns trigger
    language plpgsql
as
$$
DECLARE
  role_name CHAR(50);
BEGIN
  SELECT INTO role_name role
  FROM witcher
  WHERE witcher_id = NEW.witcher_id;
 
  IF (role_name != 'witcherJr')
  THEN
    RAISE EXCEPTION 'Witcher is not witcherJr';
  END IF;
  
   RETURN NEW;
END;
$$;

alter function check_t_w() owner to s268428;

