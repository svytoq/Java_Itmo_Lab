create function comparelocation() returns character varying
    language plpgsql
as
$$
BEGIN
RETURN 'Seagrove,E Ruskin St,Trumans house';
END;
$$;

alter function comparelocation() owner to s277686;

