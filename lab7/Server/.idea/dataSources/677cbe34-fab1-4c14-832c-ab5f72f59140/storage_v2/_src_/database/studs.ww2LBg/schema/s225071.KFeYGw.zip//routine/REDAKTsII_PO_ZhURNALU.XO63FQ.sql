create function "РЕДАКЦИИ_ПО_ЖУРНАЛУ"(name character varying)
    returns TABLE("ИД_РЕДАКЦИИ" smallint, "ИД_ЖУРНАЛА" character varying, "НАЧАЛО" date, "КОНЕЦ" date, "РУКОВОДИТЕЛЬ" smallint, "ГЛАВНЫЙ_РЕДАКТОР" smallint)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"РЕДАКЦИИ"."ИД_РЕДАКЦИИ", "РЕДАКЦИИ"."ИД_ЖУРНАЛА", "РЕДАКЦИИ"."НАЧАЛО", "РЕДАКЦИИ"."КОНЕЦ","РЕДАКЦИИ"."РУКОВОДИТЕЛЬ","РЕДАКЦИИ"."ГЛАВНЫЙ_РЕДАКТОР"
FROM "РЕДАКЦИИ" WHERE "ЖУРНАЛ_ПО_НАЗВАНИЮ"(name)::SMALLINT = "РЕДАКЦИИ"."ИД_ЖУРНАЛА";
END;
$$;

alter function "РЕДАКЦИИ_ПО_ЖУРНАЛУ"(varchar) owner to s225071;

