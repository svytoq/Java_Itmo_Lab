create function "ВСЕ_ЦИТАТЫ_АВТОРА"(firstname character varying, secondname character varying)
    returns TABLE("ЦИТАТА" text)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT ЦИТАТЫ.ЦИТАТА FROM АВТОРЫ JOIN ЦИТАТЫ ON АВТОРЫ.ИД=ЦИТАТЫ.АВТОР WHERE ИМЯ = firstname and ФАМИЛИЯ = secondname;
END;
$$;

alter function "ВСЕ_ЦИТАТЫ_АВТОРА"(varchar, varchar) owner to s225058;

