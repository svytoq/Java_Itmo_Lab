create function _trigger_add_products_entry() returns trigger
    language plpgsql
as
$$
declare
    _id integer := 0;
begin
    insert into product(name) values (TG_ARGV[0]) returning id into _id;
    new.super_id := _id;
    return new;
end;
$$;

alter function _trigger_add_products_entry() owner to s264429;

