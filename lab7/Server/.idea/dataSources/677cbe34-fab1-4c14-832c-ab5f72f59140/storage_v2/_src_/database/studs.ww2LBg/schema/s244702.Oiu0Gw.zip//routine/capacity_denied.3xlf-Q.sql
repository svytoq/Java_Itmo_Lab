create function capacity_denied() returns trigger
    language plpgsql
as
$$
DECLARE MAX_CAPACITY NUMERIC;
        CURRENT_CAPACITY NUMERIC;
BEGIN
   CURRENT_CAPACITY:=(select SUM(CAPACITY) from device_information);
   MAX_CAPACITY:=2000000000;
  IF CURRENT_CAPACITY>MAX_CAPACITY THEN RAISE EXCEPTION 'Превышена максимальная мощность потребителей'; else
  RETURN new;
    end if;
END;
$$;

alter function capacity_denied() owner to s244702;

