create function check_dead() returns trigger
    language plpgsql
as
$$
begin 
			if (is_a_human_die() == NEW.ИД_ВЫЗЫВАЮЩЕГО) then
			end if;
			return NEW;
		end;

$$;

alter function check_dead() owner to s242093;

