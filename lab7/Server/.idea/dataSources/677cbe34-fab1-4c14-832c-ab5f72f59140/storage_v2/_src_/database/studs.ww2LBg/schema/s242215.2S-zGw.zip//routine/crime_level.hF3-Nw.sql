create function crime_level(id_r integer) returns bigint
    language plpgsql
as
$$
DECLARE result bigint;

BEGIN
  SELECT COUNT("id_Преступления") FROM Район
  INNER JOIN Адрес ON Район.id_Района = Адрес.id_Района
  INNER JOIN "Место_преступления" ON "Адрес"."id_Адреса" = "Место_преступления"."id_Адреса"
  WHERE Район.id_Района = id_r
  into result;
  RETURN result;

END;

$$;

alter function crime_level(integer) owner to s242215;

