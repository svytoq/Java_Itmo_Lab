create function update_max_number_childrens() returns trigger
    language plpgsql
as
$$
BEGIN
  IF (SELECT count(*)
      FROM type_group
        JOIN "group" ON new.group = "group".id
      WHERE type_group.id = "group".type_group AND (SELECT count(*)
                                                    FROM children
                                                    WHERE children."group" = new."group")
                                                   <
                                                   max_number_children) = 0
  THEN
    RAISE EXCEPTION 'Превышенно количество детей в данном типе группы';
  END IF;
  RETURN new;
END;
$$;

alter function update_max_number_childrens() owner to s243872;

