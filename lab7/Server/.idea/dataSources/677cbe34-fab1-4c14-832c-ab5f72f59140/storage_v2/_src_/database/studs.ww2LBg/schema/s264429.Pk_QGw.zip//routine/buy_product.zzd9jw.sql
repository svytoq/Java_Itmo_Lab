create function buy_product(_store_id integer, _product_id integer, _amount real) returns void
    language plpgsql
as
$$
declare
    fact_amount real := 0;
begin
    select amount from store_item where store_id = _store_id and product_id = _product_id into fact_amount;
    if (_amount > fact_amount) then
        return;
    else
        update store_item set amount = fact_amount - _amount where store_id = _store_id and product_id = _product_id;
    end if;
end
$$;

alter function buy_product(integer, integer, real) owner to s264429;

