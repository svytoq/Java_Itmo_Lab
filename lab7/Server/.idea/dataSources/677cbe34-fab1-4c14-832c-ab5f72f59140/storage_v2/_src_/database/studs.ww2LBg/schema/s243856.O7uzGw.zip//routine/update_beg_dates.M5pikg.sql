create function update_beg_dates() returns void
    language plpgsql
as
$$
DECLARE
t_row find_creature%rowtype;
birth_date date;
b_date date;
BEGIN
FOR t_row IN SELECT * FROM find_creature LOOP
birth_date = (SELECT birthday FROM creature 
WHERE id = t_row.id_creature);
b_date = t_row.beg_date;
WHILE b_date <= birth_date LOOP
b_date = b_date + 365;
END LOOP;
b_date = b_date + (365 * (random() * 10 + 8))::int;
UPDATE find_creature SET beg_date = b_date
WHERE id_creature = t_row.id_creature;
END LOOP;
END;
$$;

alter function update_beg_dates() owner to s243856;

