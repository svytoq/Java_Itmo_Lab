create function insertfunction() returns trigger
    language plpgsql
as
$$
DECLARE

  Y INTEGER;
  COM1 INTEGER;
  COM2 INTEGER;
  P1 INTEGER;
  P2 INTEGER;
  COMGROUP CHAR;
BEGIN
  Y = NEW.ГОДИД;
  COM1= NEW.ПЕРВАЯ_КОМАНДА;
  COM2= NEW.ВТОРАЯ_КОМАНДА;
  SELECT ГРУППА INTO COMGROUP FROM ГРУППОВОЙ_ЭТАП ;
  P1 = NEW.ОЧКИ_ПЕРВОЙ_КОМАНДЫ;
  P2 = NEW.ОЧКИ_ВТОРОЙ_КОМАНДЫ;

  IF(NEW.ЭТАП =1) THEN

    IF EXISTS(SELECT КОМАНДАИД FROM "КВАЛИФИКАЦИЯ" WHERE ГОДИД= NEW.ГОДИД AND КОМАНДАИД=COM1) THEN
      BEGIN
        P1= NEW.ОЧКИ_ПЕРВОЙ_КОМАНДЫ + (SELECT "ОЧКИ" FROM "КВАЛИФИКАЦИЯ" WHERE "ГОДИД"=Y AND "КОМАНДАИД"=COM1);
        P2= NEW.ОЧКИ_ВТОРОЙ_КОМАНДЫ + (SELECT "ОЧКИ" FROM "КВАЛИФИКАЦИЯ" WHERE "ГОДИД"=Y AND "КОМАНДАИД"=COM2);
        UPDATE "КВАЛИФИКАЦИЯ" SET ОЧКИ=P1 WHERE "КВАЛИФИКАЦИЯ".КОМАНДАИД=COM1 AND "КВАЛИФИКАЦИЯ".ГОДИД=Y;
        UPDATE "КВАЛИФИКАЦИЯ" SET ОЧКИ=P2 WHERE "КВАЛИФИКАЦИЯ".КОМАНДАИД=COM2 AND "КВАЛИФИКАЦИЯ".ГОДИД=Y;
        RETURN NEW;
      END ;
    ELSE
      BEGIN
        INSERT INTO "КВАЛИФИКАЦИЯ"(ОЧКИ,КОМАНДАИД,ГОДИД) VALUES(P1, COM1,Y);
        INSERT INTO "КВАЛИФИКАЦИЯ"(ОЧКИ,КОМАНДАИД,ГОДИД) VALUES(P2, COM2,Y);
        RETURN  NEW;
      END;

      RETURN NEW;
    END IF ;
  END IF;

  IF(NEW.ЭТАП =3) THEN

    IF EXISTS(SELECT КОМАНДАИД FROM "ПЛЕЙ-ОФФ" WHERE ГОДИД= NEW.ГОДИД AND КОМАНДАИД=COM1) THEN
    BEGIN
      P1= NEW.ОЧКИ_ПЕРВОЙ_КОМАНДЫ + (SELECT "ОЧКИ" FROM "ПЛЕЙ-ОФФ" WHERE "ГОДИД"=Y AND "КОМАНДАИД"=COM1);
      P2= NEW.ОЧКИ_ВТОРОЙ_КОМАНДЫ + (SELECT "ОЧКИ" FROM "ПЛЕЙ-ОФФ" WHERE "ГОДИД"=Y AND "КОМАНДАИД"=COM2);
      UPDATE "ПЛЕЙ-ОФФ" SET ОЧКИ=P1 WHERE "ПЛЕЙ-ОФФ".КОМАНДАИД=COM1 AND "ПЛЕЙ-ОФФ".ГОДИД=Y;
      UPDATE "ПЛЕЙ-ОФФ" SET ОЧКИ=P2 WHERE "ПЛЕЙ-ОФФ".КОМАНДАИД=COM2 AND "ПЛЕЙ-ОФФ".ГОДИД=Y;
      RETURN NEW;
    END ;
      ELSE
        BEGIN
        INSERT INTO "ПЛЕЙ-ОФФ"(КОМАНДАИД,ГОДИД,ОЧКИ) VALUES(COM1,Y,P1);
        INSERT INTO "ПЛЕЙ-ОФФ"(КОМАНДАИД,ГОДИД,ОЧКИ) VALUES(COM2,Y,P2);
          RETURN  NEW;
          END;

    RETURN NEW;
    END IF ;
  END IF;

  IF (NEW.ЭТАП = 2) THEN


    IF EXISTS(SELECT КОМАНДАИД FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД= NEW.ГОДИД AND КОМАНДАИД=COM1) THEN
      BEGIN
        P1= NEW.ОЧКИ_ПЕРВОЙ_КОМАНДЫ + (SELECT "ОЧКИ" FROM "ГРУППОВОЙ_ЭТАП" WHERE "ГОДИД"=Y AND "КОМАНДАИД"=COM1);
        P2= NEW.ОЧКИ_ВТОРОЙ_КОМАНДЫ + (SELECT "ОЧКИ" FROM "ГРУППОВОЙ_ЭТАП" WHERE "ГОДИД"=Y AND "КОМАНДАИД"=COM2);
        UPDATE ГРУППОВОЙ_ЭТАП SET ОЧКИ=P1 WHERE ГРУППОВОЙ_ЭТАП.КОМАНДАИД=COM1 AND ГРУППОВОЙ_ЭТАП.ГОДИД=Y;
        UPDATE ГРУППОВОЙ_ЭТАП SET ОЧКИ=P2 WHERE ГРУППОВОЙ_ЭТАП.КОМАНДАИД=COM2 AND ГРУППОВОЙ_ЭТАП.ГОДИД=Y;
        RETURN NEW;
      END ;
    ELSE
      BEGIN
        /*INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'J',P1);*/
        /*INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'J',P2);*/

        IF (SELECT COUNT(КОМАНДАИД) FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД=Y AND ГРУППА='A' LIMIT 1) < 4 THEN
          BEGIN
          INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'A',P1);
          INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'A',P2);
            END ;
         ELSIF (SELECT COUNT(КОМАНДАИД) FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД=Y AND ГРУППА='B' LIMIT 1) < 4 THEN
            BEGIN
              INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'B',P1);
              INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'B',P2);
            END ;
            ELSIF (SELECT COUNT(КОМАНДАИД) FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД=Y AND ГРУППА='C' LIMIT 1) < 4 THEN
              BEGIN
                INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'C',P1);
                INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'C',P2);
              END ;
              ELSIF (SELECT COUNT(КОМАНДАИД) FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД=Y AND ГРУППА='D' LIMIT 1) < 4 THEN
                BEGIN
                  INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'D',P1);
                  INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'D',P2);
                END ;
                ELSIF (SELECT COUNT(КОМАНДАИД) FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД=Y AND ГРУППА='E' LIMIT 1) < 4 THEN
                  BEGIN
                    INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'E',P1);
                    INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'E',P2);
                  END ;
                  ELSIF (SELECT COUNT(КОМАНДАИД) FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД=Y AND ГРУППА='F' LIMIT 1) < 4 THEN
                    BEGIN
                      INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'F',P1);
                      INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'F',P2);
                    END ;
                    ELSIF (SELECT COUNT(КОМАНДАИД) FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД=Y AND ГРУППА='G' LIMIT 1) < 4 THEN
                      BEGIN
                        INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'G',P1);
                        INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'G',P2);
                      END ;
                      ELSIF (SELECT COUNT(КОМАНДАИД) FROM ГРУППОВОЙ_ЭТАП WHERE ГОДИД=Y AND ГРУППА='H' LIMIT 1) < 4 THEN
                        BEGIN
                          INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM1,Y,'H',P1);
                          INSERT INTO ГРУППОВОЙ_ЭТАП(КОМАНДАИД,ГОДИД,ГРУППА,ОЧКИ) VALUES(COM2,Y,'H',P2);
                        END ;
        END IF;

        RETURN NEW;
      END;
    END IF;
  END IF ;

  IF (NEW.ЭТАП = 4) THEN
    IF (P1 > P2) THEN
      UPDATE ГОД SET ПОБЕДИТЕЛЬИД=COM1 WHERE ГОД.ИД = Y;
      RETURN NEW;
    ELSE
      UPDATE ГОД SET ПОБЕДИТЕЛЬИД=COM2 WHERE ГОД.ИД = Y;
      RETURN NEW;
      END IF ;
  END IF;
END
$$;

alter function insertfunction() owner to s247413;

