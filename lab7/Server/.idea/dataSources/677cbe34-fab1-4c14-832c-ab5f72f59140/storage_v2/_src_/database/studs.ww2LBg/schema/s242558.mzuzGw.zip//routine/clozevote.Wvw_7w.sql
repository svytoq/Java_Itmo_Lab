create function clozevote() returns void
    language plpgsql
as
$$
DECLARE
temp integer;
BEGIN
temp = (SELECT MAX(ид) FROM сезоны);
FOR i IN 1..temp LOOP
IF NOT EXISTS(SELECT 1 FROM награждения WHERE сезон_ид=i) THEN
PERFORM closeVote(i);
END IF;
END LOOP;
END;
$$;

alter function clozevote() owner to s242558;

