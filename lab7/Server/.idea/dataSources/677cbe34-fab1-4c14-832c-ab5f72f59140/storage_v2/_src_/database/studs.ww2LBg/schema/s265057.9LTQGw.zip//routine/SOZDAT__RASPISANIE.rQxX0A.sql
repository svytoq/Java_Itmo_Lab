create function "СОЗДАТЬ_РАСПИСАНИЕ"(event_id integer) returns boolean
    language plpgsql
as
$$
DECLARE
	lesson record;
	semecter record;
	lesson_hour_start timestamp;
	lesson_hour_finish timestamp;
BEGIN
	SELECT INTO lesson * FROM ЗАНЯТИЕ WHERE ЗАНЯТИЕ_ИД=event_id;
	SELECT INTO semecter * FROM СЕМЕСТР WHERE СЕМЕСТР_ИД=lesson.СЕМЕСТР_ИД;
	IF (finish_date>semecter.ДАТА_КОНЦА or finish_date is NULL) THEN
		RAISE NOTICE 'Заданное время конца больше, чем конец семестра';
		RETURN FALSE;
	END IF;
	lesson_hour_start:=lesson.ВРЕМЯ_НАЧАЛА+'7 days';
	lesson_hour_finish:=lesson.ВРЕМЯ_КОНЦА+'7 days';
	WHILE (lesson_hour_finish<=finish_date and lesson_hour_start<lesson_hour_finish) LOOP
		INSERT INTO ЗАНЯТИЕ(ГРУППА_ИД,ПРЕП_ИД,АУД_ИД,ВРЕМЯ_НАЧАЛА,ВРЕМЯ_КОНЦА,СЕМЕСТР_ИД) VALUES (lesson.ГРУППА_ИД,lesson.ПРЕП_ИД,lesson.АУД_ИД,lesson_hour_start,lesson_hour_finish,lesson.СЕМЕСТР_ИД);
		--RAISE NOTICE 'Первое занятие %,  %',lesson_hour_start,lesson_hour_finish;
		--RETURN TRUE;
		lesson_hour_start:=lesson.ВРЕМЯ_НАЧАЛА+'7 days';
		lesson_hour_finish:=lesson.ВРЕМЯ_КОНЦА+'7 days';
		RAISE NOTICE 'Первое занятие %,  %',lesson_hour_start,lesson_hour_finish;
		RETURN TRUE;
	END LOOP;
	RETURN TRUE;
END;
$$;

alter function "СОЗДАТЬ_РАСПИСАНИЕ"(integer) owner to s265057;

