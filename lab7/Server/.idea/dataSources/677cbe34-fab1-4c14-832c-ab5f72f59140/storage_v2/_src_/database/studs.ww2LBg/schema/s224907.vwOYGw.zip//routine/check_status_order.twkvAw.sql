create function check_status_order() returns trigger
    language plpgsql
as
$$
declare
    result boolean;
begin
    result = exists(Select 1 from "order" where "order".id = NEW.order_id and "order".status = 'Оплачен');
    if (result = True) then
        return NEW;
    end if;
    raise exception 'you cannot write a review if the order has not been paid';
end;
$$;

alter function check_status_order() owner to s224907;

