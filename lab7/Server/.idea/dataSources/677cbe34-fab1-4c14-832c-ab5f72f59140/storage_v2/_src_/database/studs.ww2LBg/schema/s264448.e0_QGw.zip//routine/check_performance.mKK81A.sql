create function check_performance() returns trigger
    language plpgsql
as
$$
DECLARE
    championship_number integer;
BEGIN
    SELECT team.championship_id INTO championship_number FROM project JOIN team ON team.team_id = project.team_id WHERE project.project_id = NEW.project_id;

    IF NOT EXISTS(SELECT * FROM championship_platform WHERE platform_id = NEW.platform_id AND championship_id = championship_number) THEN
        RAISE EXCEPTION 'Platform should be available for this championship.';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_performance() owner to s264448;

