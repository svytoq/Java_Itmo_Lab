create function race_result_check() returns trigger
    language plpgsql
as
$$
DECLARE
  pil_id INT;
  carr_id INT;
  BEGIN
   pil_id:=(SELECT piloting_id FROM race_results WHERE ((race_results.car_id = NEW.car_id) AND (race_results.race_id = NEW.race_id)));
   carr_id:=(SELECT car_id FROM race_results WHERE (race_results.car_id = NEW.car_id));
   IF (NOT(carr_id = (SELECT car_id FROM piloting WHERE (piloting.id = pil_id))))
     THEN RAISE EXCEPTION 'No such piloting found';
     RETURN NULL;
  END IF;
  RETURN NEW;
END;
$$;

alter function race_result_check() owner to s244077;

