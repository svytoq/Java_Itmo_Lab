create function add_match_settings(new_settings_key text, new_settings_value text, match_id integer) returns void
    language plpgsql
as
$$
DECLARE
settings_id int;
BEGIN
settings_id = add_simulation_settings(settings_key, settings_value);
insert into match_settings(match_log_id, simulation_settings_id) 
values (
(select match_log_id from match where id = match_id limit 1),
settings_id
);
END;
$$;

alter function add_match_settings(text, text, integer) owner to s264450;

