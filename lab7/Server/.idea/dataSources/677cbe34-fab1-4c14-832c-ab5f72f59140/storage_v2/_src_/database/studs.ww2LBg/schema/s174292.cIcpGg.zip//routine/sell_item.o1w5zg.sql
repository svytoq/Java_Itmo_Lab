create function sell_item(witcher_id integer, npc_id integer, item_id integer, count integer) returns void
    language plpgsql
as
$$
declare
    total_price integer;
begin
    if (((select exists(select * from s174292.witcher where s174292.witcher.id = witcher_id)) = TRUE) and
        ((select exists(select * from s174292.npc where s174292.npc.id = npc_id)) = TRUE) and
        ((select exists(select * from s174292.items where s174292.items.id = item_id)) = TRUE)
        ) then
        if ((select exists(select *
                           from s174292.witcher_inventory
                           where s174292.witcher_inventory.witcher_id = s174292.sell_item.witcher_id
                             and s174292.witcher_inventory.item_id = s174292.sell_item.item_id)) = TRUE) then
            if ((select s174292.witcher_inventory.count
                 from s174292.witcher_inventory
                 where s174292.witcher_inventory.witcher_id = s174292.sell_item.witcher_id
                   and s174292.witcher_inventory.item_id = s174292.sell_item.item_id) >= s174292.sell_item.count) then
                select s174292.items.cost into total_price from s174292.items where s174292.items.id = item_id;
                total_price = total_price * count;
                if ((select s174292.npc.money from s174292.npc where s174292.npc.id = npc_id) >=
                    total_price) then
                    --Update money
                    update s174292.witcher set money=money + total_price where s174292.witcher.id = witcher_id;
                    update s174292.npc set money=money - total_price where s174292.npc.id = npc_id;

                    --Update witcher inventory
                    if ((select s174292.witcher_inventory.count
                         from s174292.witcher_inventory
                         where s174292.witcher_inventory.witcher_id = s174292.sell_item.witcher_id
                           and s174292.witcher_inventory.item_id = s174292.sell_item.item_id) >
                        s174292.sell_item.count) then
                        update s174292.witcher_inventory
                        set count=count - s174292.sell_item.count
                        where s174292.witcher_inventory.witcher_id = s174292.sell_item.witcher_id
                          and s174292.witcher_inventory.item_id = s174292.sell_item.item_id;
                    else
                        delete
                        from s174292.witcher_inventory
                        where s174292.witcher_inventory.witcher_id = s174292.sell_item.witcher_id
                          and s174292.witcher_inventory.item_id = s174292.sell_item.item_id;
                    end if;

                    --Update npc inventory
                    if ((select exists(select *
                                       from s174292.npc_inventory
                                       where s174292.npc_inventory.item_id = s174292.sell_item.item_id
                                         and s174292.npc_inventory.npc_id = s174292.sell_item.npc_id)) =
                        TRUE)
                    then
                        update s174292.npc_inventory
                        set count=count + s174292.sell_item.count
                        where s174292.npc_inventory.npc_id = s174292.sell_item.npc_id
                          and s174292.npc_inventory.item_id = s174292.sell_item.item_id;
                    else
                        insert into s174292.npc_inventory(npc_id, item_id, count)
                        values (s174292.sell_item.npc_id, s174292.sell_item.item_id, s174292.sell_item.count);
                    end if;
                else
                    raise NOTICE 'not enough money';
                end if;
            else
                raise NOTICE 'not enough items';
            end if;
        else
            raise NOTICE 'Witcher does not have item';
        end if;
    else
        raise NOTICE 'Not found witcher_id or npc_id or item_id';
    end if;
end;
$$;

alter function sell_item(integer, integer, integer, integer) owner to s174292;

