create function insert_media() returns void
    language plpgsql
as
$$
DECLARE
        film record;
BEGIN
        FOR film IN (SELECT ид from Фильмы)
        LOOP
                insert into Медиа(название, ид_фильма, тип, url) 
                        values(random_string(20),
                         film.ид, random_string(5), random_string(30));
        END LOOP;
END;
$$;

alter function insert_media() owner to s224932;

