create function insert_project(id integer, title character varying, description text, date_start date, date_end date, cost numeric, wallet character varying) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO project (id,
             title,
             description,
             date_start,
             date_end,
             cost,
             wallet)

  VALUES (insert_project.id,
      insert_project.title,
      insert_project.description,
      insert_project.date_start,
      insert_project.date_end,
      insert_project.cost,
      insert_project.wallet);
END;

$$;

alter function insert_project(integer, varchar, text, date, date, numeric, varchar) owner to s264458;

