create function class_submission_function() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE DEBUG 'Trigger function class_submission_function() fired';
    IF EXISTS(
            SELECT 1
            FROM classes_participants
            WHERE student_id = new.student_id
              AND class_id = new.class_id
        )
    THEN
        RETURN new;
    ELSE
        RAISE WARNING 'Student with id % is not participant of class with id %',
            new.student_id, new.class_id;
        RETURN NULL;
    END IF;
END;
$$;

alter function class_submission_function() owner to s268925;

