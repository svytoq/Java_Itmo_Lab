create function prisoner_reputations(searchfullname character varying)
    returns TABLE(reputation_name character varying, reputation_effect text)
    language plpgsql
as
$$
DECLARE
		found_reputation record;
		BEGIN
			FOR found_reputation IN (
				SELECT name, effect 
				FROM REPUTATION
				JOIN REPUTATION_PRISONER
				ON REPUTATION.id = REPUTATION_PRISONER.reputation_fk
				JOIN PRISONER
				ON PRISONER.id = REPUTATION_PRISONER.prisoner_fk
				WHERE PRISONER.fullName = searchFullName
			)
			LOOP
				reputation_name = found_reputation.name;
				reputation_effect = found_reputation.effect;
				RETURN NEXT;
			END LOOP;
		END;

$$;

alter function prisoner_reputations(varchar) owner to s225041;

