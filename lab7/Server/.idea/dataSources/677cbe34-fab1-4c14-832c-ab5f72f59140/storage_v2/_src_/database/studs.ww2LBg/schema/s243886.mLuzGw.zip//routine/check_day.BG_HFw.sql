create function check_day() returns trigger
    language plpgsql
as
$$
BEGIN 
IF (select ДАТА_РОЖДЕНИЯ FROM АКТЕР JOIN (АКТЕРСКИЙ_СОСТАВ JOIN ФИЛЬМ ON (АКТЕРСКИЙ_СОСТАВ.ИД_Ф= ФИЛЬМ.ИД)) ON (АКТЕР.ИД=АКТЕРСКИЙ_СОСТАВ.ИД_А) WHERE АКТЕР.ИД = NEW.ИД 
 )!=(select ФИЛЬМ.ГОД FROM АКТЕР JOIN (АКТЕРСКИЙ_СОСТАВ JOIN ФИЛЬМ ON (АКТЕРСКИЙ_СОСТАВ.ИД_Ф= ФИЛЬМ.ИД)) ON (АКТЕР.ИД=АКТЕРСКИЙ_СОСТАВ.ИД_А) WHERE АКТЕР.ИД = NEW.ИД ) THEN 
RETURN NEW; 
ELSE 
RETURN NULL; 
END IF; 
END;
$$;

alter function check_day() owner to s243886;

