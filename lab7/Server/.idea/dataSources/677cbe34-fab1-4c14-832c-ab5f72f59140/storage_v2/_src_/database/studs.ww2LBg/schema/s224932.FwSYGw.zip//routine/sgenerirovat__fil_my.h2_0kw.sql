create function сгенерировать_фильмы("число" integer) returns void
    language plpgsql
as
$$
DECLARE
        currId int = 0;
        row RECORD;
        start_scene timestamp;
        end_scene timestamp;
        release timestamp;
BEGIN
            SELECT MAX(ид) + 1 INTO currId FROM Фильмы;
            IF currId IS NULL THEN
                currId = 0;
            ELSE
                currId = currId + 1;
            END IF;

        FOR j IN 1 .. число LOOP
                        start_scene = random_film_date();
                        end_scene = start_scene + random_film_interval();
                                release = end_scene + random_film_interval();
                INSERT INTO Фильмы(ид, название, начало_съемок, конец_съемок, премьера,
                 продолжительность, бюджет, возрастной_рейтинг, кассовые_сборы)
                VALUES (currId, 'Звездные войны ' || currId, start_scene, end_scene, release,
                 (120 + 10 * random()), (200 + 100 * random()), 'NC-17', (50 + 120 * random()));
                currId = currId + 1;
        END LOOP;
END;
$$;

alter function сгенерировать_фильмы(integer) owner to s224932;

