create function fight_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
    N alias for $1;
    i INTEGER DEFAULT 1;
    hero_1 integer DEFAULT 1;
    hero_2 integer DEFAULT 1;
BEGIN
        for i in 1..N loop

        WHILE ((hero_1 = hero_2) OR (hero_1 in (SELECT id_проигравшего FROM "Битва")) OR (hero_2 in (SELECT id_проигравшего FROM "Битва"))) LOOP
            hero_1 = (SELECT "Герой"."id" FROM "Герой", "Битва" where "Герой".id not in ("Битва".id_проигравшего) ORDER BY random() LIMIT 1);
            hero_2 = (SELECT "Герой"."id" FROM "Герой", "Битва" where "Герой".id not in ("Битва".id_проигравшего) ORDER BY random() LIMIT 1);
        END LOOP;

            insert into "Битва"(id_Замка, id_победителя, id_проигравшего, Артефакт, Магия) values
              (
                  (SELECT "Замок"."id" FROM "Замок" ORDER BY random() LIMIT 1),
                  hero_1,
                  hero_2,
                  (SELECT "Артефакт".id FROM "Артефакт", "Битва", "Экипировка" WHERE "Экипировка".id_героя=hero_2 AND "Артефакт".id_экипировки="Экипировка".id ORDER BY random() LIMIT 1),
                  (SELECT "id" FROM "Магия" WHERE "Магия".id_героя=hero_2 ORDER BY random() LIMIT 1)
              );

          hero_1:=1;
          hero_2:=1;
    end loop;

END;
$$;

alter function fight_inserter(integer) owner to s225133;

