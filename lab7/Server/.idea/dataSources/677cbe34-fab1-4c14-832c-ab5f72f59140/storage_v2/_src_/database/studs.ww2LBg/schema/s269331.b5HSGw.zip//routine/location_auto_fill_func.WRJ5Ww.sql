create function location_auto_fill_func() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.СТРАНА IS NULL THEN
NEW.СТРАНА = 'Российская Федерация';
END IF;

IF NEW.ГОРОД IS NULL THEN
NEW.ГОРОД = 'Санкт-Петербург';
END IF;

RETURN NEW;
END;
$$;

alter function location_auto_fill_func() owner to s269331;

