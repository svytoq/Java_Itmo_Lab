create function next_process(id integer) returns SETOF character varying
    language sql
as
$$
SELECT process_name FROM process WHERE process_id IN (SELECT next_id FROM next WHERE process_id = id);
$$;

alter function next_process(integer) owner to s249413;

