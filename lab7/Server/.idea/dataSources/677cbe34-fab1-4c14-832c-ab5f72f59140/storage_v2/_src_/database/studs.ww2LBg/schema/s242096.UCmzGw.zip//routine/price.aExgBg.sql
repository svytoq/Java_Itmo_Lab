create function price() returns trigger
    language plpgsql
as
$$
BEGIN
	IF(TG_OP = 'UPDATE') THEN
		IF(NEW.Цена < 0) THEN 
		 RETURN OLD.Цена;
		END IF;
		IF( NEW.Наценка < 0) THEN
		 RETURN OLD.Наценка;
		END IF;
	END IF;
END
$$;

alter function price() owner to s242096;

