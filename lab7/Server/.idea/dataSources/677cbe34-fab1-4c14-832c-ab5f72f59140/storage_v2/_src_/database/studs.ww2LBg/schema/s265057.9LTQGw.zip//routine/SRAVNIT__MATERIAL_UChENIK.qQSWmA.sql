create function "СРАВНИТЬ_МАТЕРИАЛ_УЧЕНИК"() returns trigger
    language plpgsql
as
$$
DECLARE
	book_level smallint;
	stud_level smallint;
BEGIN
	SELECT INTO book_level УРОВЕНЬ FROM МАТЕРИАЛ_УЧЕНИКА WHERE МАТ_УЧЕНИК_ИД=NEW.МАТ_УЧЕНИК_ИД;
	SELECT INTO stud_level УРОВЕНЬ FROM УЧЕНИК WHERE УЧЕНИК_ИД=NEW.УЧЕНИК_ИД;
	IF (book_level!=stud_level or stud_level is null) THEN
		RAISE NOTICE 'Уровень материала % и уровень ученика % не совпадают',NEW.МАТ_УЧЕНИК_ИД,NEW.УЧЕНИК_ИД;
		RETURN NULL;
	ELSE RETURN NEW;
	END IF;
END;
$$;

alter function "СРАВНИТЬ_МАТЕРИАЛ_УЧЕНИК"() owner to s265057;

