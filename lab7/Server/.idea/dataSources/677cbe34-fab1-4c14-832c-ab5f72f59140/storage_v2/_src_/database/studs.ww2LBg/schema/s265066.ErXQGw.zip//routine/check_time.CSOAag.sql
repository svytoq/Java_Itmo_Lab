create function check_time(time_val timestamp without time zone) returns boolean
    language plpgsql
as
$$
begin
    if extract(hour from time_val) < 10 or extract(hour from time_val) > 21
    or (extract(minute from time_val) != 00 and extract(minute from time_val) != 30) then
        return false;
    end if;
    return true;
end;
$$;

alter function check_time(timestamp) owner to s265066;

