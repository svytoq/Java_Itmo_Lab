create function mage_in_train_func() returns trigger
    language plpgsql
as
$$
DECLARE
    IS_IN_TRAINING INTEGER;
BEGIN
    IS_IN_TRAINING = (SELECT COUNT(SIDEKICK) FROM TRAINING WHERE SIDEKICK = NEW.EFFECT_FROM GROUP BY SIDEKICK) 
                    + (SELECT COUNT(LEAD_MAGE) FROM TRAINING WHERE LEAD_MAGE = NEW.EFFECT_FROM GROUP BY LEAD_MAGE);
    IF (IS_IN_TRAINING = 0) THEN 
        RAISE EXCEPTION 'No mages were involed in the effect casting.';
RETURN NULL;
    END IF;
RETURN NEW;
END;
$$;

alter function mage_in_train_func() owner to s265092;

