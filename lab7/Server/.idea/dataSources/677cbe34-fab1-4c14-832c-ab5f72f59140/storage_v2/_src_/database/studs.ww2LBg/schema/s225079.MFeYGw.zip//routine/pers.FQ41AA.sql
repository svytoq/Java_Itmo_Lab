create function pers() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (SELECT РАСА.ТИП FROM РАСА WHERE НАЗВАНИЕ=OLD.РАСА) NOT IN(SELECT РАСА.ТИП FROM РАСА WHERE НАЗВАНИЕ=NEW.РАСА) THEN
	RAISE 'НЕЛЬЗЯ ИЗМЕНИТЬ У ПЕРСОНАЖА ТИП РАСЫ!';
	RETURN OLD;
	ELSE RETURN NEW;
	END IF;
END;
$$;

alter function pers() owner to s225079;

