create function spend_details(detail_type_id integer, product_order_id integer, quantity integer) returns void
    language sql
as
$$
insert into used_detail (detail_type_id, product_order_id, quantity) 
    values ($1, $2, $3)
    on conflict (detail_type_id, product_order_id) do update set quantity = used_detail.quantity + $3;
$$;

alter function spend_details(integer, integer, integer) owner to s267880;

