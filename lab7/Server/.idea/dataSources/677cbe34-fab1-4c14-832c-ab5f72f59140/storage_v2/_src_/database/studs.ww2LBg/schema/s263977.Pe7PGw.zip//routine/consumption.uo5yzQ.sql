create function consumption() returns trigger
    language plpgsql
as
$$
DECLARE
    emp integer;
    before integer;
    after integer;
BEGIN
    FOR emp IN SELECT id FROM isbs WHERE is_built = true LIMIT (SELECT count(*) FROM isbs WHERE is_built = true)
        LOOP
            IF ((SELECT oxygen FROM isbs WHERE id = emp) < 0 OR
                (SELECT food FROM isbs WHERE id = emp) < 0) THEN
                UPDATE volunteer SET isbs_id = null, environment_id = null, on_work = false WHERE isbs_id = emp;
                RAISE NOTICE 'Купол номер % непригоден к эксплуатации', (SELECT id FROM isbs WHERE id=emp);
                UPDATE isbs SET is_work = false WHERE id = emp;
            ELSEIF ((SELECT money FROM total_money) < 0) THEN
                UPDATE volunteer SET isbs_id = null, environment_id = null, on_work = false WHERE isbs_id = emp;
                RAISE NOTICE 'МЫ БАНКРОТЫ!';
                UPDATE isbs SET is_work = false WHERE id = id;
            ELSEIF ((SELECT oxygen FROM isbs WHERE id = emp) > 0 AND
                    (SELECT food FROM isbs WHERE id = emp) > 0) THEN
                UPDATE isbs SET is_work = true WHERE id = emp;
            END IF;
        END LOOP;

    FOR emp IN SELECT id FROM environment LIMIT (SELECT count(*) FROM environment)
        LOOP
            UPDATE environment SET
                consumption_oxygen = (SELECT sum(n.consumption_oxygen) FROM nature n
                                                                                INNER JOIN environment e on n.environment_id = e.id
                                      WHERE environment_id = emp)
            WHERE id = emp;
        END LOOP;

    FOR emp IN SELECT id FROM isbs WHERE is_work = true LIMIT (SELECT count(*) FROM isbs WHERE is_built = true)
        LOOP
            before = (SELECT oxygen FROM isbs WHERE id = emp);
            IF ((SELECT is_work FROM isbs WHERE id = emp) = true AND (SELECT count(*) FROM volunteer WHERE isbs_id = emp) > 0) THEN
                UPDATE isbs SET

                                food = food - (SELECT sum(need_food) FROM volunteer
                                                                              INNER JOIN isbs ON volunteer.isbs_id = isbs.id
                                               WHERE volunteer.on_work = true AND volunteer.isbs_id = emp),

                                oxygen = oxygen - (SELECT sum(need_oxygen) FROM volunteer
                                                                                    INNER JOIN isbs ON volunteer.isbs_id = isbs.id
                                                   WHERE volunteer.on_work = true AND volunteer.isbs_id = emp)

                WHERE is_built = true AND id = emp;

                IF ((SELECT count(*) FROM environment WHERE isbs_id = emp) > 0) THEN
                    UPDATE isbs SET
                        oxygen = oxygen - (SELECT sum(consumption_oxygen) FROM environment
                                           WHERE environment.isbs_id = emp)
                    WHERE id = emp;
                END IF;

                after = (SELECT oxygen FROM isbs WHERE id = emp);

                IF (after > before) THEN
                    UPDATE isbs SET auto_oxygen = true WHERE id = emp;
                ELSE
                    UPDATE isbs SET auto_oxygen = false WHERE id = emp;
                END IF;
            ELSE
                IF ((SELECT count(*) FROM environment WHERE isbs_id = emp) > 0) THEN
                    UPDATE isbs SET
                        oxygen = oxygen - (SELECT sum(consumption_oxygen) FROM environment
                                           WHERE environment.isbs_id = emp)
                    WHERE id = emp;
                END IF;
                IF (after > before) THEN
                    UPDATE isbs SET auto_oxygen = true WHERE id = emp;
                ELSE
                    UPDATE isbs SET auto_oxygen = false WHERE id = emp;
                END IF;
            END IF;

        END LOOP;

    UPDATE total_money SET money = money - (SELECT sum(need_money) FROM volunteer WHERE on_work = true);
    UPDATE transport SET distance = distance - 1 WHERE ready = false;

    IF ((SELECT count(*) FROM transport WHERE ready = false AND distance <= 0) > 0) THEN
        UPDATE isbs SET food = food + t.quantity FROM transport t WHERE isbs.id = t.isbs_id AND t.ready = false AND t.name = 'Еда' AND t.distance <= 0;
        UPDATE isbs SET oxygen = isbs.oxygen + t.quantity FROM transport t WHERE isbs.id = t.isbs_id AND t.ready = false AND t.name = 'Воздух' AND t.distance <= 0;
        UPDATE basis_isbs SET need_resource = need_resource - t.quantity FROM transport t WHERE basis_isbs.id = t.isbs_id AND t.ready = false AND t.name = 'Ресурс' AND t.distance <= 0;
        UPDATE transport SET ready = true, quantity = 0, distance = 0 WHERE ready = false AND distance <= 0;
    END IF;

    IF ((SELECT count(*) FROM basis_isbs WHERE is_done = false AND need_resource <= 0) > 0) THEN
        UPDATE isbs SET is_built = true FROM basis_isbs b WHERE basis_id = b.id AND b.need_resource <= 0;
        UPDATE basis_isbs SET is_done = true WHERE is_done = false AND need_resource <= 0;
    END IF;

    RETURN null;
END
$$;

alter function consumption() owner to s263977;

