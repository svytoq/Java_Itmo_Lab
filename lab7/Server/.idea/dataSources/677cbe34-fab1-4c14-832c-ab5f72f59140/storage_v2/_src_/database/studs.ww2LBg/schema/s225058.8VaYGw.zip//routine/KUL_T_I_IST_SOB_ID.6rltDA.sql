create function "КУЛЬТ_И_ИСТ_СОБ_ИД"() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('КУЛЬТ_И_ИСТ_СОБ_ИД_seq')!=NEW.ИД THEN
    NEW.ИД=nextval('КУЛЬТ_И_ИСТ_СОБ_ИД_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;   
    END;
$$;

alter function "КУЛЬТ_И_ИСТ_СОБ_ИД"() owner to s225058;

