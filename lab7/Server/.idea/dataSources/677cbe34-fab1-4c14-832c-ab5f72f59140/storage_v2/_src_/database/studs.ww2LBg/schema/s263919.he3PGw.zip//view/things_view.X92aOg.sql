create view things_view(thing_id, thing_name, rarity, character_name, price) as
SELECT t.thing_id,
       t.thing_name,
       t.rarity,
       cha.character_name,
       t.price
FROM s263919.thing t
         JOIN s263919."character" cha USING (thing_id)
WHERE t.is_selling = true;

alter table things_view
    owner to s263919;

