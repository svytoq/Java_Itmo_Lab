create function person_function() returns trigger
    language plpgsql
as
$$
begin
new.Human_ID=nextval('Human_Human_ID_seq');
return new;
end;
$$;

alter function person_function() owner to s225069;

