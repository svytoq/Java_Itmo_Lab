create function formatform() returns trigger
    language plpgsql
as
$$
BEGIN
    NEW.ЦВЕТ_ФОРМЫ:= INITCAP(LOWER(RTRIM(LTRIM(NEW.ЦВЕТ_ФОРМЫ))));
  return NEW;
  END;
$$;

alter function formatform() owner to s224514;

