create function check_coordinates() returns trigger
    language plpgsql
as
$$
DECLARE
	pos INTPOINT;
	size SMALLINT;
BEGIN
	pos = NEW.pos;

	IF ((pos.x IS NULL) OR (pos.y IS NULL)) THEN
		RAISE EXCEPTION 'Coordinates cannot be null';
	END IF;

	size = (SELECT maps.size FROM maps WHERE id = NEW.map);

	IF ((pos.x >= size) OR (pos.y >= size)) THEN
		RAISE EXCEPTION 'Coordinates cannot be greater than map size';
	END IF;

	RETURN NEW;
END;
$$;

alter function check_coordinates() owner to s244711;

