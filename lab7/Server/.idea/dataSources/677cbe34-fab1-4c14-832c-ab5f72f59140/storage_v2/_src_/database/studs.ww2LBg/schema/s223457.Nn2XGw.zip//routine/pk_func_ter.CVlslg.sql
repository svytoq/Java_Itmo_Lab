create function pk_func_ter() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_ter');
  RETURN new;
END;
$$;

alter function pk_func_ter() owner to s223457;

