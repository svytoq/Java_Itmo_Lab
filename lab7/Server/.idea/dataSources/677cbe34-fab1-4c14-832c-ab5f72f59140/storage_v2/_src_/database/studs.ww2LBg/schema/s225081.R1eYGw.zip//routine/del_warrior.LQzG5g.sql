create function del_warrior() returns trigger
    language plpgsql
as
$$
BEGIN
         UPDATE ПОДРАЗДЕЛЕНИЕ SET КОМАНДИР = NULL WHERE КОМАНДИР= OLD.ID_ВОИНА;
  RETURN NULL;
END;
$$;

alter function del_warrior() owner to s225081;

