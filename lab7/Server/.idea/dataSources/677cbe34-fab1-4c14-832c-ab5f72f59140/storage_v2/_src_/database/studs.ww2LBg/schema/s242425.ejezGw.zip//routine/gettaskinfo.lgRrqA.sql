create function gettaskinfo(id integer)
    returns TABLE(idmedicine integer, namemedicine text, medicineamount integer, numberinque integer, progress double precision, finishdate date)
    language sql
as
$$
select ЛЕКАРСТВО.ИД_ЛЕКАРСТВА, 
        ЛЕКАРСТВО.НАЗВАНИЕ,
        ЗАКАЗ.КОЛИЧЕСТВО,
        СТАТУС_ЗАКАЗА.НОМЕР_В_ОЧЕРЕДИ,
        СТАТУС_ЗАКАЗА.ВЫПОЛНЕНИЕ,
        СТАТУС_ЗАКАЗА.ДАТА_ЗАВЕРШЕНИЯ
    from ЗАКАЗ 
        join ЛЕКАРСТВО using(ИД_ЛЕКАРСТВА)
        join СТАТУС_ЗАКАЗА using(ИД_ЗАКАЗА)
    where ЗАКАЗ.НАЗВАНИЕ_АПТЕЧНОЙ_СЕТИ='abc'
    order by СТАТУС_ЗАКАЗА.НОМЕР_В_ОЧЕРЕДИ;
$$;

alter function gettaskinfo(integer) owner to s242425;

