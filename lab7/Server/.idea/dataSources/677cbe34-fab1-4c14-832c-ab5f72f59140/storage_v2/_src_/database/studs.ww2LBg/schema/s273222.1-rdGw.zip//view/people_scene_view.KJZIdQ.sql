create view people_scene_view(name, id) as
SELECT people.name,
       scene.id
FROM s273222.people
         JOIN s273222.stand_in ON stand_in.people_id = people.id
         JOIN s273222.scene ON stand_in.scene_id = scene.id;

alter table people_scene_view
    owner to s273222;

