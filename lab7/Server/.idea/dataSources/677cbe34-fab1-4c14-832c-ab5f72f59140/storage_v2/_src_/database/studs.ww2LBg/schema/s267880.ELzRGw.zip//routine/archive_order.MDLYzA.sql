create function archive_order(worker_id integer, product_order_id integer) returns void
    language plpgsql
as
$$
begin
    update product_making set is_finished = true where product_making.worker_id = $1 and product_making.product_order_id = $2 and is_finished = false;
    if not found then
        raise exception 'Can only archive active order';
    end if;
end
$$;

alter function archive_order(integer, integer) owner to s267880;

