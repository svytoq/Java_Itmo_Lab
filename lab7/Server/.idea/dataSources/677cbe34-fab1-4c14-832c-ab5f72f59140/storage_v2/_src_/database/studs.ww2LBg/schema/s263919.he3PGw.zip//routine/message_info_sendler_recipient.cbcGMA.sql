create function message_info_sendler_recipient(originator integer, addressee integer)
    returns TABLE(sender_id integer, recipient_id integer, content character varying)
    language plpgsql
as
$$
begin
    return query select m.sender_id, m.recipient_id, m.content from message m where (originator = m.sender_id) or (addressee = m.recipient_id) ;
end;
$$;

alter function message_info_sendler_recipient(integer, integer) owner to s263919;

