create function great_peopleid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('great_people_id_seq')!=NEW.ID THEN
NEW.ID=nextval('great_people_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function great_peopleid() owner to s225102;

