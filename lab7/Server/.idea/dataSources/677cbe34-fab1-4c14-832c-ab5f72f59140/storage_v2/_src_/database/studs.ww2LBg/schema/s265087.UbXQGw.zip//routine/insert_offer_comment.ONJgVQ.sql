create function insert_offer_comment(content character varying, author integer, parent_comment integer, offer integer) returns void
    language plpgsql
as
$$
DECLARE
    COMMENT_ID INTEGER;
BEGIN
    INSERT INTO COMMENT (CONTENT, CREATION_DATE, AUTHOR, PARENT_COMMENT)
    VALUES (CONTENT, CURRENT_TIMESTAMP, AUTHOR, PARENT_COMMENT)
    RETURNING id INTO COMMENT_ID;
    INSERT INTO OFFER_COMMENT (OFFER, COMMENT)
    VALUES (OFFER, COMMENT_ID);
END;
$$;

alter function insert_offer_comment(varchar, integer, integer, integer) owner to s265087;

