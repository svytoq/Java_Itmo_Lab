create function insert_genres_to_films() returns void
    language plpgsql
as
$$
DECLARE
        film record;
        genres record;
BEGIN
        FOR genres IN (SELECT ид from Жанры)
        LOOP
                FOR film IN (SELECT ид from Фильмы)
                LOOP
                    if (random() > 0.8) THEN
                        insert into Фильмы_Жанры 
                                values(film.ид, genres.ид);
                    end if;
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_genres_to_films() owner to s242395;

