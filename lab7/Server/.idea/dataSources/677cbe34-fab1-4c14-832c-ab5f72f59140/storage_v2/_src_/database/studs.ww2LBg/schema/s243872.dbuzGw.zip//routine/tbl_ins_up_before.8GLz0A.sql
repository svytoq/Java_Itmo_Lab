create function tbl_ins_up_before() returns trigger
    language plpgsql
as
$$
BEGIN

  IF EXISTS(SELECT *
            FROM place
            WHERE id = NEW.id)
  THEN
    begin
      perform setval(pg_get_serial_sequence('place', 'id'), max(id))
      FROM place;
      new.id = (select max(id)
                FROM place)+1;
      RETURN new;
    end;
  END IF;

  RETURN NEW;

END
$$;

alter function tbl_ins_up_before() owner to s243872;

