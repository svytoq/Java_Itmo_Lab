create function getkiller(number bigint, OUT "ИД_ТРИБУТА" bigint, OUT "ИД_ПОЛЬЗОВАТЕЛЯ" integer, OUT "ФАМИЛИЯ" character varying, OUT "ИМЯ" character varying, OUT "ОРУЖИЕ" character varying) returns SETOF record
    language sql
as
$$
SELECT ИД_ТРИБУТА, ПОЛЬЗОВАТЕЛИ.ИД_ПОЛЬЗОВАТЕЛЯ, ПОЛЬЗОВАТЕЛИ.ФАМИЛИЯ, ПОЛЬЗОВАТЕЛИ.ИМЯ, ОРУЖИЕ.НАЗВАНИЕ
FROM ТРИБУТЫ
JOIN ПОЛЬЗОВАТЕЛИ USING(ИД_ПОЛЬЗОВАТЕЛЯ)
JOIN ОРУЖИЕ USING(ИД_ОРУЖИЯ)
WHERE ИД_УБИЙЦЫ = number;
$$;

alter function getkiller(bigint, out bigint, out integer, out varchar, out varchar, out varchar) owner to s242361;

