create function buy_item() returns trigger
    language plpgsql
as
$$
DECLARE
	price real;
	pers_money real;
	BEGIN
		SELECT "Деньги" INTO pers_money FROM "К_Персонажи" where Id = NEW.Персонаж_ИД;
		Select Цена into price from К_Предметы where Id = NEW.Предмет_ИД;
 		IF (price > pers_money) THEN
 			RETURN NULL;
 		END if;
 		UPDATE "К_Персонажи" SET "Деньги" = ("К_Персонажи".Деньги - price) WHERE
 		"К_Персонажи".Id = NEW.Персонаж_ИД;
 		RETURN NEW;
		END;
$$;

alter function buy_item() owner to s243870;

