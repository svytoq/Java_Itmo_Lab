create function create_objects() returns void
    language plpgsql
as
$$
begin
    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (1, 'Абонемент в бар', -30000, true, 'Настроение');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (2, 'Абонемент в спортзал', -15000, true, 'Занятие спортом');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (3, 'Личный тренер', -60000, true, 'Занятие спортом');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (4, 'Таблица умножения', -150, false, 'Обучение');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (5, 'Аттестат', -5000, false, 'Обучение');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (6, 'Диплом ПТУ', -25000, false, 'Обучение');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (7, 'Диплом ВУЗа', -200000, false, 'Обучение');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (8, 'Иностранный диплом', -1000000, false, 'Обучение');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (9, 'Костюм', -50000, false, 'Рейтинг');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (10, 'Палатка', -500, false, 'Недвижимость');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (11, 'Съемная комната', -15000, true, 'Недвижимость');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (13, 'Квартира', -9000000, false, 'Недвижимость');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (14, 'Офис', -30000000, false, 'Недвижимость');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (15, 'Коттедж', -90000000, false, 'Недвижимость');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (16, 'Вилла', -150000000, false, 'Недвижимость');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (17, 'Кроссовки', -2000, false, 'Транспорт');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (18, 'Велик', -10000, false, 'Транспорт');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (19, 'ВАЗ', -60000, false, 'Транспорт');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (20, 'Крутая машина', -1500000, false, 'Транспорт');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (21, 'Вертолет', -18000000, false, 'Транспорт');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (22, 'Яхта', -60000000, false, 'Транспорт');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (23, 'Паспорт', -1000, false, 'Социальные услуги');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (24, 'Должность депутата', -15000000, false, 'Политика');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (25, 'Должность министра обороны', -15000000, false, 'Политика');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (26, 'Должность министра финансов', -15000000, false, 'Политика');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (27, 'Должность президента', -30000000, false, 'Политика');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (28, 'Пособие по безработице', 400, true, 'Социальные услуги');

    INSERT INTO "Object"(ID, "Name", "Money", "Payment_type", "Type")
    VALUES (29, 'Льготы по инвалидности', 700, true, 'Социальные услуги');

end
$$;

alter function create_objects() owner to s264425;

