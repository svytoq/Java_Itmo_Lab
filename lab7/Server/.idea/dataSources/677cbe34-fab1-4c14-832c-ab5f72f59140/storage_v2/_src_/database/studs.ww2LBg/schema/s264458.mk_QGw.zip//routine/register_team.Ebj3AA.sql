create function register_team(id integer, company_id integer, title character varying, creation date, process_type text, description text) returns void
    language plpgsql
as
$$
BEGIN

  PERFORM insert_team(id, company_id, title, creation, NULL, process_type, description);
  RAISE NOTICE 'Команда "%" создана',title;

END;

$$;

alter function register_team(integer, integer, varchar, date, text, text) owner to s264458;

