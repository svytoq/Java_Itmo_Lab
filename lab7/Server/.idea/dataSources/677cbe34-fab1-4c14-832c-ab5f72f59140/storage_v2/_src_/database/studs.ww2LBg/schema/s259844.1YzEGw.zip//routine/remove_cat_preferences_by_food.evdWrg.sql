create function remove_cat_preferences_by_food() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM food_preference WHERE
        food_preference.food_id = NEW.food_id AND
        food_preference.cat_id IN (SELECT cat_id FROM cat_allergen
            WHERE cat_allergen.allergen_id = NEW.allergen_id);

    RETURN NEW;
END;
$$;

alter function remove_cat_preferences_by_food() owner to s259844;

