create function wrupdate() returns trigger
    language plpgsql
as
$$
BEGIN
		UPDATE team SET wins = wins + 1 where id = NEW.winner_id;
		UPDATE team SET losses = losses + 1 where id = NEW.loser_id;
		return new;
	END;
$$;

alter function wrupdate() owner to s243878;

