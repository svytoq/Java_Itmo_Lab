create function find_related_service_for_two_users(user_id_1 integer, user_id_2 integer)
    returns TABLE(producer_id integer, name_producer character varying, surname_producer character varying, consumer_id integer, name_consumer character varying, surname_consumer character varying, suggestion_name character varying, agreed_time timestamp with time zone, crosses boolean)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT suggestion.author,
                        (SELECT NAME FROM USERS WHERE ID = SUGGESTION.AUTHOR),
                        (SELECT surname FROM USERS WHERE ID = SUGGESTION.AUTHOR),
                        REQUEST.author,
                        (SELECT NAME FROM USERS WHERE ID = REQUEST.author),
                        (SELECT surname FROM USERS WHERE ID = REQUEST.author),
                        SUGGESTION.NAME,
                        REQUEST.agreed_time,
                        (SELECT IS_TIME_CROSSES(REQUEST.agreed_time, suggestion.author, REQUEST.author))
                 FROM USERS
                          JOIN request ON USERS.id = request.author
                          JOIN suggestion_request ON request.id = suggestion_request.request
                          JOIN suggestion ON suggestion_request.suggestion = suggestion.id
                 WHERE (USERS.ID = USER_ID_1 OR USERS.ID = USER_ID_2)
                   AND (REQUEST.author = USER_ID_1 OR REQUEST.author = USER_ID_2)
                   AND (SUGGESTION.author = USER_ID_1 OR SUGGESTION.author = USER_ID_2);
END;
$$;

alter function find_related_service_for_two_users(integer, integer) owner to s265087;

