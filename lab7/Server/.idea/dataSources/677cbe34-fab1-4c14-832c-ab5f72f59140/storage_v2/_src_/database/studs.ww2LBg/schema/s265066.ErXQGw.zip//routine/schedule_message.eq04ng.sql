create function schedule_message(msg integer, employee integer, room_val integer, time_val timestamp without time zone) returns integer
    language plpgsql
as
$$
declare
    time_ok bool;
begin
    if room_val < 1 or room_val > 30 then
        raise exception 'room outside bounds'; 
        end if;
    if (select msg_state from Messages where msg_id=msg) != 'encrypted' then
        raise exception 'message must be encrypted'; 
    end if;

    select date_trunc('minute', time_val) into time_val;

    select check_time(time_val) into time_ok;
    if not time_ok then 
        raise exception 'time bad';
    end if;

    if exists(select 1 from Msg_exchanges where
        room=room_val and exc_time=time_val) then 
        raise exception 'room-time conflict';
    end if;

    if exists(select 1 from Msg_exchanges where
        employee_id=employee and exc_time=time_val) then
        raise exception 'employee-time conflict';
    end if;

    update Messages  set msg_state = 'planned'
        where msg_id=msg;

    insert into Msg_exchanges(room, exc_time, employee_id, out_msg, msg_ex_state)
        values(room_val, time_val, employee, msg, 'scheduled');

    return 1;
end;
$$;

alter function schedule_message(integer, integer, integer, timestamp) owner to s265066;

