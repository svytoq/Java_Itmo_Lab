create function continent_function() returns trigger
    language plpgsql
as
$$
begin
new.Continent_ID=nextval('Continents_Continent_ID_seq');
return new;
end;
$$;

alter function continent_function() owner to s225069;

