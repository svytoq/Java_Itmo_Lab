create function add_book_author(book_isbn character, author_first_name character varying, author_last_name character varying, author_patronymic character varying) returns boolean
    language plpgsql
as
$$
declare
    found_book_id boolean;
    author_id     int;
begin
    select (case when count(*) > 0 then books.book_id else 0 end)
    into found_book_id
    from books
    where books.isbn = book_ISBN;
    if found_book_id = 0 then
        RAISE EXCEPTION 'No book with ISBN = %', book_ISBN
            USING HINT = 'Check book ISBN or add book';
    end if;

    select (case when count(*) > 0 then a.author_id else 0 end)
    into author_id
    from authors a
    where a.first_name = author_first_name
      and a.last_name = author_last_name
      and a.patronymic = author_patronymic;
    if author_id = 0 then
        RAISE EXCEPTION 'No such author'
            USING HINT = 'First add information about author';
    end if;

    insert into books_authors values (found_book_id, author_id);
    return true;
end
$$;

alter function add_book_author(char, varchar, varchar, varchar) owner to s265089;

