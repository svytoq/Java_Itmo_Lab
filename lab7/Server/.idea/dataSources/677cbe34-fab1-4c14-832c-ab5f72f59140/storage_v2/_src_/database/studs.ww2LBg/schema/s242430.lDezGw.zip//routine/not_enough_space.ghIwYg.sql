create function not_enough_space() returns trigger
    language plpgsql
as
$$
BEGIN
IF (select count(*) from tormented where (tormented.idsubcircle=NEW.idsubcircle))+1 >
(SELECT PunishmentCapacity*SubCirclePunishmentMaxAmount FROM Subcircle natural join punishment where subcircle.idsubcircle = NEW.idsubcircle) THEN
RAISE EXCEPTION 'Недостаточно места для грешников!';
END IF;
RETURN NEW;
END;
$$;

alter function not_enough_space() owner to s242430;

