create function get_workers(factory_id integer)
    returns TABLE(name character varying, surname character varying, birth_date timestamp without time zone, contacts character varying, address text, salary double precision)
    language sql
as
$$
SELECT humans.name, humans.surname, humans.birth_date, humans.contacts, humans.address, providers.salary
FROM humans
         JOIN providers ON providers.human_id = humans.id
WHERE providers.factory_id = $1;
$$;

alter function get_workers(integer) owner to s270233;

