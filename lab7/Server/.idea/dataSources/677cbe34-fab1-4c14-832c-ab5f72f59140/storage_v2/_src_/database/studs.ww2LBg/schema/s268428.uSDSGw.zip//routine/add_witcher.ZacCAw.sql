create function add_witcher(name character, birthdate integer, school_id integer, stream_id integer, st_sword integer, sil_sword integer) returns integer
    language plpgsql
as
$$
DECLARE
person_id INTEGER;
role_id INTEGER;
witcher_id INTEGER;
begin
 person_id = add_person(name, birthdate, true);
 role_id = add_role('witcher', school_id, st_sword, NULL, sil_sword);
 witcher_id = nextval('witcher_witcher_id_seq'); 
 INSERT INTO witcher VALUES
 (witcher_id, 'witcher', person_id, role_id, stream_id);
 
 UPDATE sword set owner_id = witcher_id WHERE sword_id = st_sword;
 UPDATE sword set owner_id = witcher_id WHERE sword_id = sil_sword;
 
 RETURN 0;
 end
$$;

alter function add_witcher(char, integer, integer, integer, integer, integer) owner to s268428;

