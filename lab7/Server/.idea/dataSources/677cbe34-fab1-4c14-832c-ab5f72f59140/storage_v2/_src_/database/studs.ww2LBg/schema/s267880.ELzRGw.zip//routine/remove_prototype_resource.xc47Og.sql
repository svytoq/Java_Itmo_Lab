create function remove_prototype_resource(product_prototype_id integer, product_prototype_resource_id integer) returns void
    language sql
as
$$
delete from product_prototype_resource where product_prototype_id = $1 and product_prototype_resource_id = $2;
$$;

alter function remove_prototype_resource(integer, integer) owner to s267880;

