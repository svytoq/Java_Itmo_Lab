create function army_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
    N alias for $1;
    moral INTEGER;
    i INTEGER DEFAULT 1;
    k integer;

BEGIN

    if((select max(id) from "Войско") >= i)THEN
      i:=(select max(id) from "Войско") + 1;
    END If;

    for k in i..(N + i - 1) loop

        moral := trunc(random() * 30 + 1);
        insert into "Войско" values(k, moral, (SELECT id FROM "Герой" ORDER BY random() LIMIT 1), (SELECT id FROM "Хронология" ORDER BY random() LIMIT 1));

    end loop;

END;
$$;

alter function army_inserter(integer) owner to s225133;

