create function битва() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.система not IN (select название from система) THEN
insert into система values(NEW.система, null, -1);
END IF;
return NEW;
END;
$$;

alter function битва() owner to s242552;

