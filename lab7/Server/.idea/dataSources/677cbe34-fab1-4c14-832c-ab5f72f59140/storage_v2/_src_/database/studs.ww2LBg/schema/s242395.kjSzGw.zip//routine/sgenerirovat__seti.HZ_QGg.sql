create function сгенерировать_сети(count integer) returns void
    language plpgsql
as
$$
DECLARE
        startId integer = 0;
        currId int;
BEGIN
            SELECT MAX(ид) + 1 INTO startId FROM Сети;
            IF startId IS NULL THEN
                startId = 0;
            END IF;
                currId = startId;
        WHILE currId <> startId + count LOOP
                INSERT INTO Сети(ид, название, сайт) VALUES (currId, 'Сеть ' || currId, 'мираж' || currId || '.ру');
                currId = currId + 1;
        END LOOP;
END;
$$;

alter function сгенерировать_сети(integer) owner to s242395;

