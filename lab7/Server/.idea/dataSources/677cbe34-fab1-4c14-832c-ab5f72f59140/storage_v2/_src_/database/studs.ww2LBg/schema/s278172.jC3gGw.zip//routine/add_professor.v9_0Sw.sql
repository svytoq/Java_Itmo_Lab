create function add_professor(n text, dob date, subj integer) returns void
    language plpgsql
as
$$
DECLARE
    char_id int;
BEGIN
    INSERT INTO characters (name, date_of_birth) VALUES (n, dob);
    char_id = (
        SELECT id
        FROM characters
        WHERE name = n
          AND date_of_birth = dob
    );
    INSERT INTO character_roles (role_id, character_id)
    VALUES (3, char_id);
    INSERT INTO professors (character_id, subject_id)
    VALUES (char_id, subj);
END
$$;

alter function add_professor(text, date, integer) owner to s278172;

