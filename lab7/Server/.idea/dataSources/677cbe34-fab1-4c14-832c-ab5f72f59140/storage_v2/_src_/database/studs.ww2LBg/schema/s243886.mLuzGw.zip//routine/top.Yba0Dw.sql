create function top(name text, OUT "НАЗВАНИЕ" text, OUT "КАССА" integer) returns SETOF record
    language sql
as
$$
SELECT ФИЛЬМ.НАЗВАНИЕ, АНАЛИЗ.КАССА FROM ФИЛЬМ JOIN АНАЛИЗ ON (ФИЛЬМ.ИД = АНАЛИЗ.ИД_Ф) JOIN ФИЛЬМ_ЖАНР ON (ФИЛЬМ.ИД = ФИЛЬМ_ЖАНР.ИД_Ф) JOIN ЖАНР_Ф ON (ФИЛЬМ_ЖАНР.ИД_Ж = ЖАНР_Ф.ИД) WHERE ЖАНР_Ф.ЖАНР = name;
$$;

alter function top(text, out text, out integer) owner to s243886;

