create function check_prem() returns trigger
    language plpgsql
as
$$
BEGIN
	IF NEW.Оценка_работы = 4 AND NEW.Премия > 5000
		THEN
		RAISE EXCEPTION 'Премия не может быть больше 5000 если оценка работы 4';
	END IF;

	IF NEW.Оценка_работы = 5 AND NEW.Премия > 15000
		THEN
		RAISE EXCEPTION 'Премия не может быть больше 15000';
	END IF;

	IF NEW.Оценка_работы < 4 AND NEW.Премия > 0
		THEN
		RAISE EXCEPTION 'Премия не полагается офицерам, чья оценка работы меньше 4';
	END IF;

	RETURN NEW;

END;
$$;

alter function check_prem() owner to s242215;

