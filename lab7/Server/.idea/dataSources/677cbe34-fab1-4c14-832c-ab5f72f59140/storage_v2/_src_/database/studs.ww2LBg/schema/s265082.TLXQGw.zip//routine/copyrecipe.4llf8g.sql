create function copyrecipe(recipe integer, client integer) returns integer
    strict
    language plpgsql
as
$$
DECLARE
newRecipeId int;
BEGIN
INSERT INTO рецепт(клиент) VALUES (client) RETURNING id INTO newRecipeId;
	INSERT INTO компонент_рецепта(рецепт, ингредиент, количество, порядок_добавления) SELECT newRecipeId, ингридиент, количество, порядок_добавления FROM компонент_рецепта WHERE  рецепт = recipe;
	RETURN newRecipeId;
END;
$$;

alter function copyrecipe(integer, integer) owner to s265082;

