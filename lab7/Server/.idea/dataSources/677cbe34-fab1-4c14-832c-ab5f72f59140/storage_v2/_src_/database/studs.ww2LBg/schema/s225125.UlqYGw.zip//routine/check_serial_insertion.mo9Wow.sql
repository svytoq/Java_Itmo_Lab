create function check_serial_insertion() returns trigger
    language plpgsql
as
$$
DECLARE
  serial_val integer;
BEGIN
  EXECUTE 'SELECT ($1).' || TG_ARGV[0] INTO serial_val USING NEW;
  BEGIN
    IF serial_val <> currval(TG_ARGV[1]) THEN
      RAISE EXCEPTION 'Нельзя явно указывать значение атрибута % таблицы %',
        TG_ARGV[0], TG_TABLE_NAME
        USING HINT = 'Не указывайте значение поля, либо укажите значение DEFAULT';
    END IF;
  EXCEPTION
    WHEN object_not_in_prerequisite_state THEN
      RAISE EXCEPTION 'Нельзя явно указывать значение атрибута % таблицы %',
        TG_ARGV[0], TG_TABLE_NAME
        USING HINT = 'Не указывайте значение поля, либо укажите значение DEFAULT';
  END;
  RETURN NEW;
END
$$;

alter function check_serial_insertion() owner to s225125;

