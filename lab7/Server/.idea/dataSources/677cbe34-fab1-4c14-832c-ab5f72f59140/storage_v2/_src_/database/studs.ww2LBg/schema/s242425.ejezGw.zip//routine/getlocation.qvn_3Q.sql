create function getlocation(id_ingredient integer, amount integer) returns integer
    language plpgsql
as
$$
DECLARE
        value integer;
        ship_x float;
        ship_y float;
    BEGIN
        select ШИРОТА into ship_x from КОРАБЛЬ;
        select ДОЛГОТА into ship_y from КОРАБЛЬ;

        select m1 into value from (
            values  (1, 2, 25),
                    (1, 3, 12),
                    (2, 3, 56))
            as t (m1, m2, distance) where distance = 56;
        
        return value;
    END;

$$;

alter function getlocation(integer, integer) owner to s242425;

