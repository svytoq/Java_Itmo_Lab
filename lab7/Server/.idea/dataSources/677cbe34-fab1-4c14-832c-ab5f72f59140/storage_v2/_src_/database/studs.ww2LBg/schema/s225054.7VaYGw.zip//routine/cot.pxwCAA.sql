create function cot() returns void
    language plpgsql
as
$$
BEGIN
CREATE TABLE ВОЛШЕБНЫЕ_ИГРЫ (
ИГРА VARCHAR(30) PRIMARY KEY,
MIN_ИГРОКОВ INT CHECK (MIN_ИГРОКОВ > 0),
MAX_ИГРОКОВ INT CHECK (MAX_ИГРОКОВ >0),
ПРАВИЛА TEXT,
CHECK (MAX_ИГРОКОВ  >= MIN_ИГРОКОВ)
);

CREATE TABLE ПЕРСОНАЖИ (
ID SERIAL PRIMARY KEY,
ФАМИЛИЯ VARCHAR(20) NOT NULL,
ИМЯ VARCHAR(20) NOT NULL,
ID_МАТЕРИ INT REFERENCES ПЕРСОНАЖИ(ID),
ID_ОТЦА INT REFERENCES ПЕРСОНАЖИ(ID),
ЦВЕТ_ГЛАЗ VARCHAR(20) NOT NULL,
ЦВЕТ_ВОЛОС VARCHAR(20) NOT NULL,
ID_НАЧАЛЬНИКА INT REFERENCES ПЕРСОНАЖИ(ID),
ЛЮБИМАЯ_ИГРА VARCHAR(30) REFERENCES ВОЛШЕБНЫЕ_ИГРЫ(ИГРА)
);

CREATE TABLE ЗАКЛИНАНИЯ (
НАИМЕНОВАНИЕ VARCHAR(40) PRIMARY KEY,
ПРИМЕНЕНИЕ TEXT,
УРОВЕНЬ_УРОНА INT CHECK (УРОВЕНЬ_УРОНА >= 0 AND УРОВЕНЬ_УРОНА <= 10)
);


CREATE TABLE ЗАКЛИНАНИЯ_ПЕРСОНАЖЕЙ (
ID_ПЕРСОНАЖА INT REFERENCES ПЕРСОНАЖИ(ID),
ЗАКЛИНАНИЕ VARCHAR(40) REFERENCES ЗАКЛИНАНИЯ(НАИМЕНОВАНИЕ),
PRIMARY KEY (ID_ПЕРСОНАЖА, ЗАКЛИНАНИЕ)
);

CREATE TABLE ОРГАНИЗАЦИИ (
НАИМЕНОВАНИЕ VARCHAR(40) PRIMARY KEY,
ID_СОЗДАТЕЛЯ INT REFERENCES ПЕРСОНАЖИ(ID),
ID_ГЛАВЫ INT REFERENCES ПЕРСОНАЖИ(ID),
ЦЕЛЬ TEXT,
КОЛИЧЕСТВО_УЧАСТНИКОВ INT CHECK(КОЛИЧЕСТВО_УЧАСТНИКОВ > 0)
);

CREATE TABLE ПРОФЕССИИ(
НАЗВАНИЕ VARCHAR(40) PRIMARY KEY,
ОБЯЗАННОСТИ TEXT
);

CREATE TABLE ФАКУЛЬТЕТЫ (
НАЗВАНИЕ VARCHAR(40) PRIMARY KEY,
ГЕРБ VARCHAR(30),
ШКОЛА_МАГИИ VARCHAR(40)
);


CREATE TABLE ЛОКАЦИИ(
НАЗВАНИЕ VARCHAR(40) PRIMARY KEY, 
СТЕПЕНЬ_ЗАЩИЩЕННОСТИ INT CHECK (СТЕПЕНЬ_ЗАЩИЩЕННОСТИ >= 0 AND СТЕПЕНЬ_ЗАЩИЩЕННОСТИ <= 10)
);

CREATE TABLE ШКОЛЫ_МАГИИ (
НАЗВАНИЕ VARCHAR(40) PRIMARY KEY,
ЛОКАЦИЯ VARCHAR(40) REFERENCES ЛОКАЦИИ(НАЗВАНИЕ),
УРОВЕНЬ_ПРЕСТИЖНОСТИ INT CHECK (УРОВЕНЬ_ПРЕСТИЖНОСТИ >= 0 AND УРОВЕНЬ_ПРЕСТИЖНОСТИ <= 10)
);

CREATE TABLE УЧЕБНЫЕ_ПРЕДМЕТЫ (
НАИМЕНОВАНИЕ VARCHAR(40) PRIMARY KEY,
ФАКУЛЬТЕТ VARCHAR(40) REFERENCES ФАКУЛЬТЕТЫ(НАЗВАНИЕ),
ID_ПРЕПОДАВАТЕЛЯ INT REFERENCES ПЕРСОНАЖИ(ID),
УЧЕБНИК VARCHAR(40) 
);

CREATE TABLE ГОДЫ_ОБУЧЕНИЯ (
НОМЕР_ГОДА INT PRIMARY KEY CHECK (НОМЕР_ГОДА > 0),
НАЧАЛО DATE NOT NULL, 
КОНЕЦ DATE NOT NULL,
CHECK (КОНЕЦ>НАЧАЛО)
);

CREATE TABLE КРЕСТРАЖИ(
НАЗВАНИЕ_КРЕСТРАЖА VARCHAR(40) PRIMARY KEY,
КОГДА_УНИЧТОЖЕН INT REFERENCES ГОДЫ_ОБУЧЕНИЯ(НОМЕР_ГОДА)
);

CREATE TABLE ВАЖНЫЕ_СОБЫТИЯ (
НАЗВАНИЕ VARCHAR(50) PRIMARY KEY,
ЛОКАЦИЯ VARCHAR(40) REFERENCES ЛОКАЦИИ(НАЗВАНИЕ),
ГОД_ОБУЧЕНИЯ INT REFERENCES ГОДЫ_ОБУЧЕНИЯ(НОМЕР_ГОДА)
);

CREATE TABLE ВОЛШЕБНЫЕ_ЖИВОТНЫЕ (
ИМЯ VARCHAR(30) PRIMARY KEY,
ТИП VARCHAR(40) NOT NULL,
ЦВЕТ VARCHAR(20) NOT NULL,
ID_ХОЗЯИНА INT REFERENCES ПЕРСОНАЖИ(ID),
ОСОБЫЙ_НАВЫК VARCHAR(50),
ЛОКАЦИЯ VARCHAR(40) REFERENCES ЛОКАЦИИ(НАЗВАНИЕ)
);

ALTER TABLE ПЕРСОНАЖИ
ADD COLUMN ФАКУЛЬТЕТ VARCHAR(40) REFERENCES ФАКУЛЬТЕТЫ(НАЗВАНИЕ),
ADD COLUMN ПРОФЕССИЯ VARCHAR(40) REFERENCES ПРОФЕССИИ(НАЗВАНИЕ)
;

RETURN;
END;
$$;

alter function cot() owner to s225054;

