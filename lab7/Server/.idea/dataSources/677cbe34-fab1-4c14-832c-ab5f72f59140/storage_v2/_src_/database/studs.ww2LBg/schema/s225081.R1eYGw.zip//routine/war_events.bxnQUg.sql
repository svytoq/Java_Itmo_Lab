create function war_events() returns trigger
    language plpgsql
as
$$
DECLARE
  POST_INIT POS;
  POST_REV  POS;
BEGIN
  SELECT ДОЛЖНОСТЬ
  FROM ВОИНЫ
  WHERE ID_ВОИНА = NEW.ИНИЦИАТОР
  INTO POST_INIT;
  SELECT ДОЛЖНОСТЬ
  FROM ВОИНЫ
  WHERE ID_ВОИНА = NEW.ПРОТИВНИК
  INTO POST_REV;

  IF POST_INIT != 'РЯДОВОЙ ВОИН' AND POST_REV != 'РЯДОВОЙ ВОИН'
  THEN
    RETURN NEW;
  ELSE
    RAISE NOTICE 'ИНИЦИАТОРАМИ НЕ МОГУТ БЫТЬ РЯДОВЫЕ ВОИНЫ';
    RETURN NULL;
  END IF;
END;
$$;

alter function war_events() owner to s225081;

