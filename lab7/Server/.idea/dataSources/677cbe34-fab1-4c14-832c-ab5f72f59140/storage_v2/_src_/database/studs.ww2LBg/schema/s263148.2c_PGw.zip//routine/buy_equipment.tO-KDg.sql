create function buy_equipment(buyer_org_id integer, buying_equipment_id integer) returns text
    language plpgsql
as
$$
declare
  begin
    -- если такой организации/техники нет в таблице, то произойдет ошибка
    insert into organization_has_equipment (organization_id, equipment_id) 
    values (buyer_org_id, buying_equipment_id);
    
    return 'Техника была успешно приобретена';
  end;
$$;

alter function buy_equipment(integer, integer) owner to s263148;

