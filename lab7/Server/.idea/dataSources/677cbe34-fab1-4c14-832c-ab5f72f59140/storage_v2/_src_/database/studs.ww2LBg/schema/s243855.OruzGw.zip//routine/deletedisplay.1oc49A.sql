create function deletedisplay() returns trigger
    language plpgsql
as
$$
begin
 delete from УСТРОЙСТВА where  УСТРОЙСТВА.ИД_ДИСПЛЕЯ = ДИСПЛЕЙ.ИД;
 end;
$$;

alter function deletedisplay() owner to s243855;

