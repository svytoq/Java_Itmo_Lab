create function to_interval(num numeric) returns interval
    language plpgsql
as
$$
DECLARE
 inter interval;
 str text;

 BEGIN
  str :=(num/12)||' year '||(num - num/12)||' months';
  inter:= str;
  return inter;
END;
$$;

alter function to_interval(numeric) owner to s244702;

