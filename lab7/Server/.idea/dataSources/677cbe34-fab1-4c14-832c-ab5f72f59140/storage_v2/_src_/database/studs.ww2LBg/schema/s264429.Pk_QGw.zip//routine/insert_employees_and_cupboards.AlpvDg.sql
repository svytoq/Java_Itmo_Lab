create function insert_employees_and_cupboards() returns void
    language plpgsql
as
$$
declare
    i integer := 0;
begin
    for i in 1 .. 1500 loop
        insert into "group" values (i);
    end loop;
end;
$$;

alter function insert_employees_and_cupboards() owner to s264429;

