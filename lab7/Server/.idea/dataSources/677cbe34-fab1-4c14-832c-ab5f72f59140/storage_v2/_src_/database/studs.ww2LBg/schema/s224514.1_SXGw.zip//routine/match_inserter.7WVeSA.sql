create function match_inserter(integer) returns void
    language plpgsql
as
$$
DECLARE
  N ALIAS for $1;
	i INTEGER DEFAULT 1;
	id_1country integer default 1;
	id_2country integer default 2;
	id_1forma integer default 1;
	id_2forma integer default 2;
	id_judge integer default 1;
	id_stadium integer default 1;
	date_of_match date default '2018-07-06 00:00:00';
  maxNcountry integer;
	maxNforma integer;
	maxNstadium integer;
	maxNjudge integer;
BEGIN
	Select count(ИД_СТРАНЫ) from СТРАНА_УЧАСТНИЦА into maxNcountry;
	Select count(ИД_ФОРМЫ_ИГРОКОВ) from ФОРМА_ИГРОКОВ into maxNforma;
	Select count(ИД_СТАДИОНА) from СТАДИОН into maxNstadium;
	Select count(ИД_СУДЬИ) from СУДЬЯ into maxNjudge;
  if (N / 4) > maxNforma THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "ФОРМА_ИГРОКОВ"';
	END if;
	if (N / 4) > maxNcountry THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "СТРАНА_УЧАСТНИЦА"';
	END if;
	if (N / 2) > maxNstadium THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "СТАДИОН"';
	END if;
	if (N / 2) > maxNjudge THEN
			RAISE EXCEPTION 'Ошибка: недостаточно строк в таблице "СУДЬЯ"';
	END if;
	for i in 1..N loop

	if i % (N / 4) = 0 THEN
		id_1country = id_1country + 1;
		if id_2country != id_1country THEN id_2country = 1; ELSE id_2country = id_2country + 1; END IF;
		id_1forma = id_1forma + 1;
		if id_1forma != id_2forma THEN id_2forma = id_2forma + 1; ELSE id_2forma = 1; END IF;
	END IF;

		insert into "МАТЧ" values(DEFAULT, id_1country, id_2country, id_1forma, id_2forma, date_of_match, id_stadium, id_judge);
		date_of_match = date_of_match + interval '1 day';
		if i % 2 = 1 THEN id_stadium = id_stadium + 1; END IF;
		if i % 2 = 0 THEN id_judge = id_judge + 1; END IF;
	end loop;
END;
$$;

alter function match_inserter(integer) owner to s224514;

