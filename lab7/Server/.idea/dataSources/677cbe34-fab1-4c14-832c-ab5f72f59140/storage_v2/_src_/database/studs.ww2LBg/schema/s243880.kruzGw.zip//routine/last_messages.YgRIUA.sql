create function last_messages("id_ОТПРАВИТЕЛЬ" integer)
    returns TABLE("ИД" bigint, "ДАТА" timestamp without time zone, "СООБЩЕНИЕ" character varying, "ИД_ПОЛУЧАТЕЛЯ" integer, "ИД_ОТПРАВИТЕЛЬ" integer)
    language sql
as
$$
(select * from (
(SELECT ЛИЧНЫЕ_СООБЩЕНИЯ.*
 FROM (
    SELECT MAX(ДАТА) AS max, case when ИД_ПОЛУЧАТЕЛЯ = $1 then ИД_ПОЛУЧАТЕЛЯ else ИД_ОТПРАВИТЕЛЬ end AS user
    FROM ЛИЧНЫЕ_СООБЩЕНИЯ
WHERE ИД_ПОЛУЧАТЕЛЯ = $1 
 GROUP BY user, ИД_ПОЛУЧАТЕЛЯ, ИД_ОТПРАВИТЕЛЬ
        ) AS a
 inner JOIN ЛИЧНЫЕ_СООБЩЕНИЯ ON  (a.user = ИД_ПОЛУЧАТЕЛЯ) and (a.max = ЛИЧНЫЕ_СООБЩЕНИЯ.ДАТА)
 ORDER BY ИД asc)

EXCEPT all

(SELECT ЛИЧНЫЕ_СООБЩЕНИЯ.*
 FROM (
    SELECT MAX(ДАТА) AS max, case when ИД_ПОЛУЧАТЕЛЯ = $1 then ИД_ПОЛУЧАТЕЛЯ else ИД_ОТПРАВИТЕЛЬ end AS user
    FROM ЛИЧНЫЕ_СООБЩЕНИЯ
WHERE ИД_ОТПРАВИТЕЛЬ = $1 
 GROUP BY user, ИД_ПОЛУЧАТЕЛЯ, ИД_ОТПРАВИТЕЛЬ
        ) AS a
 inner JOIN ЛИЧНЫЕ_СООБЩЕНИЯ ON  (a.user = ИД_ОТПРАВИТЕЛЬ) and (a.max = ЛИЧНЫЕ_СООБЩЕНИЯ.ДАТА)
 ORDER BY ИД asc)
)AS b 
where b.ДАТА  in (select max(ДАТА) from ЛИЧНЫЕ_СООБЩЕНИЯ where  ИД_ОТПРАВИТЕЛЬ = $1 or ИД_ПОЛУЧАТЕЛЯ= $1)
)

union
(select * from (
(SELECT ЛИЧНЫЕ_СООБЩЕНИЯ.*
 FROM (
    SELECT MAX(ДАТА) AS max, case when ИД_ПОЛУЧАТЕЛЯ = $1 then ИД_ПОЛУЧАТЕЛЯ else ИД_ОТПРАВИТЕЛЬ end AS user
    FROM ЛИЧНЫЕ_СООБЩЕНИЯ
WHERE ИД_ОТПРАВИТЕЛЬ = $1 
 GROUP BY user, ИД_ПОЛУЧАТЕЛЯ, ИД_ОТПРАВИТЕЛЬ
        ) AS a
 inner JOIN ЛИЧНЫЕ_СООБЩЕНИЯ ON  (a.user = ИД_ОТПРАВИТЕЛЬ) and (a.max = ЛИЧНЫЕ_СООБЩЕНИЯ.ДАТА)
 ORDER BY ИД asc)


EXCEPT all

(SELECT ЛИЧНЫЕ_СООБЩЕНИЯ.*
 FROM (
    SELECT MAX(ДАТА) AS max, case when ИД_ПОЛУЧАТЕЛЯ = $1 then ИД_ПОЛУЧАТЕЛЯ else ИД_ОТПРАВИТЕЛЬ end AS user
    FROM ЛИЧНЫЕ_СООБЩЕНИЯ
WHERE ИД_ПОЛУЧАТЕЛЯ = $1 or ИД_ОТПРАВИТЕЛЬ = $1  
 GROUP BY user, ИД_ПОЛУЧАТЕЛЯ, ИД_ОТПРАВИТЕЛЬ
        ) AS a
 inner JOIN ЛИЧНЫЕ_СООБЩЕНИЯ ON  (a.user = ИД_ПОЛУЧАТЕЛЯ) and (a.max = ЛИЧНЫЕ_СООБЩЕНИЯ.ДАТА)
 ORDER BY ИД asc)
)AS c 
where c.ДАТА  in (select max(ДАТА) from ЛИЧНЫЕ_СООБЩЕНИЯ where  ИД_ОТПРАВИТЕЛЬ = $1)
)


EXCEPT all



(select * from (
(SELECT ЛИЧНЫЕ_СООБЩЕНИЯ.*
 FROM (
    SELECT MAX(ДАТА) AS max, case when ИД_ПОЛУЧАТЕЛЯ = $1 then ИД_ПОЛУЧАТЕЛЯ else ИД_ОТПРАВИТЕЛЬ end AS user
    FROM ЛИЧНЫЕ_СООБЩЕНИЯ
WHERE ИД_ПОЛУЧАТЕЛЯ = $1 
 GROUP BY user, ИД_ПОЛУЧАТЕЛЯ, ИД_ОТПРАВИТЕЛЬ
        ) AS a
 inner JOIN ЛИЧНЫЕ_СООБЩЕНИЯ ON  (a.user = ИД_ПОЛУЧАТЕЛЯ) and (a.max = ЛИЧНЫЕ_СООБЩЕНИЯ.ДАТА)
 ORDER BY ИД asc)

EXCEPT all

(SELECT ЛИЧНЫЕ_СООБЩЕНИЯ.*
 FROM (
    SELECT MAX(ДАТА) AS max, case when ИД_ПОЛУЧАТЕЛЯ = $1 then ИД_ПОЛУЧАТЕЛЯ else ИД_ОТПРАВИТЕЛЬ end AS user
    FROM ЛИЧНЫЕ_СООБЩЕНИЯ
WHERE ИД_ОТПРАВИТЕЛЬ = $1 
 GROUP BY user, ИД_ПОЛУЧАТЕЛЯ, ИД_ОТПРАВИТЕЛЬ
        ) AS a
 inner JOIN ЛИЧНЫЕ_СООБЩЕНИЯ ON  (a.user = ИД_ОТПРАВИТЕЛЬ) and (a.max = ЛИЧНЫЕ_СООБЩЕНИЯ.ДАТА)
 ORDER BY ИД asc)
)AS b 
where b.ДАТА  in (select max(ДАТА) from ЛИЧНЫЕ_СООБЩЕНИЯ where ИД_ОТПРАВИТЕЛЬ = $1)
)

union
(select * from (
(SELECT ЛИЧНЫЕ_СООБЩЕНИЯ.*
 FROM (
    SELECT MAX(ДАТА) AS max, case when ИД_ПОЛУЧАТЕЛЯ = $1 then ИД_ПОЛУЧАТЕЛЯ else ИД_ОТПРАВИТЕЛЬ end AS user
    FROM ЛИЧНЫЕ_СООБЩЕНИЯ
WHERE ИД_ОТПРАВИТЕЛЬ = $1 
 GROUP BY user, ИД_ПОЛУЧАТЕЛЯ, ИД_ОТПРАВИТЕЛЬ
        ) AS a
 inner JOIN ЛИЧНЫЕ_СООБЩЕНИЯ ON  (a.user = ИД_ОТПРАВИТЕЛЬ) and (a.max = ЛИЧНЫЕ_СООБЩЕНИЯ.ДАТА)
 ORDER BY ИД asc)


EXCEPT all

(SELECT ЛИЧНЫЕ_СООБЩЕНИЯ.*
 FROM (
    SELECT MAX(ДАТА) AS max, case when ИД_ПОЛУЧАТЕЛЯ = $1 then ИД_ПОЛУЧАТЕЛЯ else ИД_ОТПРАВИТЕЛЬ end AS user
    FROM ЛИЧНЫЕ_СООБЩЕНИЯ
WHERE ИД_ПОЛУЧАТЕЛЯ = $1 or ИД_ОТПРАВИТЕЛЬ = $1  
 GROUP BY user, ИД_ПОЛУЧАТЕЛЯ, ИД_ОТПРАВИТЕЛЬ
        ) AS a
 inner JOIN ЛИЧНЫЕ_СООБЩЕНИЯ ON  (a.user = ИД_ПОЛУЧАТЕЛЯ) and (a.max = ЛИЧНЫЕ_СООБЩЕНИЯ.ДАТА)
 ORDER BY ИД asc)
)AS c 
where c.ДАТА  in (select max(ДАТА) from ЛИЧНЫЕ_СООБЩЕНИЯ where ИД_ПОЛУЧАТЕЛЯ= $1 or ИД_ОТПРАВИТЕЛЬ = $1)
)
$$;

alter function last_messages(integer) owner to s243880;

