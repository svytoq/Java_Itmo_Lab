create function "ПЕРСОНАЛ_РАБОТА_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "ПЕРСОНАЛ_РАБОТА" ("ИД_ПЕРСОНАЛА","ИД_РАБОТЫ")
VALUES ((SELECT "ИД_ПЕРСОНАЛА" FROM "ПЕРСОНАЛ" OFFSET floor(random()* 100) LIMIT 1),(SELECT "ИД_РАБОТЫ" FROM "ВЫПОЛНЯЕМАЯ_РАБОТА" OFFSET floor(random()*200) LIMIT 1));
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END LOOP;
END;
$$;

alter function "ПЕРСОНАЛ_РАБОТА_ТЕСТ"(integer) owner to s223443;

