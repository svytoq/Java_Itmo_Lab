create function "ПРОИЗВЕДЕНИЯ_ТЕМЫ"(name character varying)
    returns TABLE("НАЗВАНИЕ_ПРОИЗВЕДЕНИЯ" character varying, "ГОД_НАПИСАНИЯ" smallint, "ГОД_ИЗДАНИЯ" smallint, "ТЕМА" character varying, "ЖАНР" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"ПРОИЗВЕДЕНИЯ"."НАЗВАНИЕ_ПРОИЗВЕДЕНИЯ", "ПРОИЗВЕДЕНИЯ"."ГОД_НАПИСАНИЯ", "ПРОИЗВЕДЕНИЯ"."ГОД_ИЗДАНИЯ", "ПРОИЗВЕДЕНИЯ"."ТЕМА","ПРОИЗВЕДЕНИЯ"."ЖАНР"
FROM "ПРОИЗВЕДЕНИЯ" WHERE "ПРОИЗВЕДЕНИЯ"."ТЕМА" = name;
END;
$$;

alter function "ПРОИЗВЕДЕНИЯ_ТЕМЫ"(varchar) owner to s225071;

