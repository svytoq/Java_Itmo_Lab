create function "ЧЕЛОВЕК_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
 IF NEW."ИД_ЧЕЛОВЕКА" IS NULL THEN
    NEW."ИД_ЧЕЛОВЕКА" = generate_UUID();
  END IF;
  IF NEW."ДАТА_РОЖДЕНИЯ" > current_date THEN
  RAISE 'Дата рождения не может быть позже чем текущая дата';
  END IF;
  IF NEW."ИМЯ" IS NULL THEN
  RAISE 'Графа "ИМЯ" не может быть пустой.';
END IF;
IF NEW."ФАМИЛИЯ" IS NULL THEN
RAISE 'Графа "ФАМИЛИЯ" не может быть пустой.';
END IF;
  return NEW;
  END;
$$;

alter function "ЧЕЛОВЕК_ТФ"() owner to s223443;

