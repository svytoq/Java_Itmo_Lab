create function create_incident() returns trigger
    language plpgsql
as
$$
begin
    insert into Black_list (Passenger_id) values (NEW.Passenger_id);
    insert into Incidents (Action_id, Time_police_officer_id)
    values (NEW.id, (select id from Time_police_officers where Priority = 1));
    delete from Tickets where Passenger_id = NEW.Passenger_id;
    return NEW;
end;
$$;

alter function create_incident() owner to s265103;

