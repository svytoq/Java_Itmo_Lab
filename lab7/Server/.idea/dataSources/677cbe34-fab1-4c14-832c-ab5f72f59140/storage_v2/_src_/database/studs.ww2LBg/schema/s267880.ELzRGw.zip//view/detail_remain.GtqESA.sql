create view detail_remain(detail_type_id, quantity_remain) as
SELECT a.detail_type_id,
       a.imported - COALESCE(b.consummed, 0::bigint) AS quantity_remain
FROM (SELECT storage.detail_type_id,
             sum(storage.quantity) AS imported
      FROM s267880.storage
      GROUP BY storage.detail_type_id) a
         LEFT JOIN (SELECT used_detail.detail_type_id,
                           sum(used_detail.quantity) AS consummed
                    FROM s267880.used_detail
                    GROUP BY used_detail.detail_type_id) b USING (detail_type_id);

alter table detail_remain
    owner to s267880;

