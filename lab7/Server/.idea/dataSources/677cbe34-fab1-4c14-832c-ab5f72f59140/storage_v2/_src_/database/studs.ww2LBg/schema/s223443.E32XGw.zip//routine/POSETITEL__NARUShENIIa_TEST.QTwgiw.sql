create function "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
  w money = 54;
s money = 1020;
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ" ("ИД_ПОСЕТИТЕЛЬ","ИД_НАРУШЕНИЕ")
VALUES ((SELECT "ИД_ПОСЕТИТЕЛЬ" FROM "ПОСЕТИТЕЛЬ" OFFSET floor(random()* 100) LIMIT 1),(SELECT "ИД_НАРУШЕНИЕ" FROM "НАРУШЕНИЯ" OFFSET floor(random()*200) LIMIT 1));
k = k + 1;
  w = w + CAST(99 AS MONEY);
s = s +CAST(1322 AS MONEY);
END LOOP;
END;
$$;

alter function "ПОСЕТИТЕЛЬ_НАРУШЕНИЯ_ТЕСТ"(integer) owner to s223443;

