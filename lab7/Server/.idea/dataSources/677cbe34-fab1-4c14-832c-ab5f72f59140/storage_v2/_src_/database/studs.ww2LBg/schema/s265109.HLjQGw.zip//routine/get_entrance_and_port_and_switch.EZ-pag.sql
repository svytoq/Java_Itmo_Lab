create function get_entrance_and_port_and_switch()
    returns TABLE(num_entr integer, street text, house integer, floor character varying, switch_ip character varying, switch_model text, port_num integer, port_type s265109.typort)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT n.number,
                        n.street,
                        n.house,
                        s.floor,
                        s.IP,
                        s.model,
                        p.number,
                        p.kind
                 from entrance as n
                          join switch s on n.id = s.entrance_id
                          join port p on s.id = p.switch_id;
end;
$$;

alter function get_entrance_and_port_and_switch() owner to s265109;

