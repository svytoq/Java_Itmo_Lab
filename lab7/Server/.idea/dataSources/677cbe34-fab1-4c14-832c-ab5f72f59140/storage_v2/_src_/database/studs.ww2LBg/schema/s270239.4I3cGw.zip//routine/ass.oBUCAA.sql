create function ass()
    returns TABLE(name text)
    language plpgsql
as
$$
DECLARE
    DECLARE curs1 CURSOR FOR SELECT *  FROM planet where id = 1;
    DECLARE curs2 CURSOR FOR SELECT *  FROM place where id = 2;
            res text;
BEGIN
    open curs1;
    open curs2;
    return query select
                     split_part(
                             TRIM(both ' ' from split_part(pg_cursors.statement, 'FROM', 2)), ' ' , 1  )
                 from pg_cursors;
END
$$;

alter function ass() owner to s270239;

