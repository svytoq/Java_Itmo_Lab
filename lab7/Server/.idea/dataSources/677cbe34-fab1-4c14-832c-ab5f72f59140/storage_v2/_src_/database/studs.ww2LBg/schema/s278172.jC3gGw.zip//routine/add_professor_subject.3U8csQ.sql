create function add_professor_subject(char_id integer, subj integer) returns void
    language plpgsql
as
$$
BEGIN
    IF EXISTS(
            SELECT *
            FROM professors
            WHERE character_id = char_id
              AND subject_id = subj
        ) THEN
        RETURN;
    END IF;
    INSERT INTO professors (character_id, subject_id)
    VALUES (char_id, subj);
END
$$;

alter function add_professor_subject(integer, integer) owner to s278172;

