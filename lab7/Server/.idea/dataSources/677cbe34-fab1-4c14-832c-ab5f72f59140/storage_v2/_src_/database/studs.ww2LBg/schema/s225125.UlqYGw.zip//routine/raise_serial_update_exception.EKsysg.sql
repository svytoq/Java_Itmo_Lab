create function raise_serial_update_exception() returns trigger
    language plpgsql
as
$$
BEGIN
  RAISE EXCEPTION 'Нельзя изменять значение поля % таблицы %',
    TG_ARGV[0], TG_TABLE_NAME;
END
$$;

alter function raise_serial_update_exception() owner to s225125;

