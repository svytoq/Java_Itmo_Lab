create function проверка_наград() returns trigger
    language plpgsql
as
$$
BEGIN

IF NOT EXISTS(
	SELECT 1 FROM Фильмы_Группы 
	JOIN Группы ON Группы.ид = Фильмы_Группы.ид_группы 
	JOIN Роли ON Группы.ид = Роли.ид_группы 
	JOIN Люди ON Роли.ид_человека = Люди.ид 
	WHERE Фильмы_Группы.ид_фильма = NEW.ид_фильма 
	AND Люди.ид = NEW.ид_человека
) THEN
	RAISE EXCEPTION 'Человек не может получать награду за фильм, в съемке которого не участвовал';
END IF;

RETURN NEW;
END;
$$;

alter function проверка_наград() owner to s242395;

