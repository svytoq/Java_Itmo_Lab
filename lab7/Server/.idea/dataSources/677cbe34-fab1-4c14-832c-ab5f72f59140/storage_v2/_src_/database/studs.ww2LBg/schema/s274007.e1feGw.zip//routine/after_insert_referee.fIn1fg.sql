create function after_insert_referee() returns trigger
    language plpgsql
as
$$
BEGIN
    IF (SELECT count(*) FROM Referee WHERE competition_id = NEW.competition_id) > 1
    THEN DELETE FROM Referee WHERE id = (SELECT max(id) FROM Referee);
    END IF;
    return new;
END;
$$;

alter function after_insert_referee() owner to s274007;

