create function ordering(weapon integer, client integer) returns integer
    language plpgsql
as
$$
DECLARE
    order_id integer;
BEGIN
    order_id := (SELECT max(id) from "Заказы") + 1;

    INSERT INTO "Заказы" (id, заказчик, "Оружие")
    VALUES (order_id, client, weapon);

    RETURN order_id;
END;
$$;

alter function ordering(integer, integer) owner to s245031;

