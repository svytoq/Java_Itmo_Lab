create function "ИЕРАРХИЯ_МЕСТ_func"() returns trigger
    language plpgsql
as
$$
-- Одно и то же место не может быть предком и потомком другого места одновременно 
        BEGIN
                IF NEW."МЕСТО_ИД" IN 
                                (SELECT "МЕСТО_ИД" 
                                FROM "ГЕОЛОКАЦИЯ"(NEW."РОДИТЕЛЬ_ИД")) THEN
                        RAISE EXCEPTION 'Place #% is already a parent of #%', NEW."МЕСТО_ИД",                              
                                                                                                                       NEW."РОДИТЕЛЬ_ИД";
                        NEW."РОДИТЕЛЬ_ИД" := OLD."РОДИТЕЛЬ_ИД";
                END IF;
                RETURN NEW;
        END;
$$;

alter function "ИЕРАРХИЯ_МЕСТ_func"() owner to s245094;

