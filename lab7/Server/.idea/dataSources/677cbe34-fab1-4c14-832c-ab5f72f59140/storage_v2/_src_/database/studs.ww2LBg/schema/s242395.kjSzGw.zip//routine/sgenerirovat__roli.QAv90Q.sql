create function сгенерировать_роли() returns void
    language plpgsql
as
$$
DECLARE
        people record;
        groupp record;
BEGIN
        FOR people IN (SELECT ид from Люди)
        LOOP
                FOR groupp IN (SELECT ид from Группы)
                LOOP
                        If (random() > 0.9) THEN
                        insert into Роли(название, ид_человека, ид_группы) 
                                values(random_string(10) , people.ид , groupp.ид);
                        END If;
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_роли() owner to s242395;

