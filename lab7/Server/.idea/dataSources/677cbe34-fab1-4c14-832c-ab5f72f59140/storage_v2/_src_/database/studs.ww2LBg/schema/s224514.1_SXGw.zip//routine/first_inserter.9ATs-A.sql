create function first_inserter() returns void
    language plpgsql
as
$$
DECLARE
  sequences text[] = '{country_id_country_seq, stadium_id_stadium_seq, judge_id_judge_seq, player_form_id_form_seq,
  player_id_player_seq, hotel_id_hotel_seq, accommodation_id_accommodation_seq, match_id_match_seq, card_id_card_seq, goal_id_goal_seq, users_id_user_seq}';
  i INTEGER DEFAULT 1;
BEGIN
  INSERT INTO country values(1, 'ASDQW', 'A');
  INSERT INTO country values(2, 'BASDQW', 'B');
  INSERT INTO stadium values(1, 'BARAKH', 'ORLOVSKAYA29', 15000);
  INSERT INTO judge values(1, 'ABDULOV', 'ABDUL', 'ABDULOVICH', 'BELGIUM');
  INSERT INTO player_form values(1, 1, 'GREEN', 1);
  INSERT INTO player_form values(2, 2, 'RED', 1);
  INSERT INTO player values(1, 'BARAKHOV', 'BARAKH', 'BARAKHOVICH', 1, 'ЛЗ');
  INSERT INTO hotel values(1, 'GYYYY', 'YUZHNAYA7');
  INSERT INTO accommodation values(1, 1, 1, '2004-10-19 10:23:54', '2004-10-20 10:23:54');
  INSERT INTO match values(1, 1, 2, 1, 2, NULL, 1, 1);
  INSERT INTO card values(1, 1, 1, 'Красная', NULL);
  INSERT INTO goal values(1, 1, 1, NULL, 'Пенальти');
  INSERT INTO users VALUES (1,'test','test', 'test', 'tset');
  for i in 1..10 loop
    if i = 1 OR i = 4 THEN
      PERFORM pg_catalog.setval(sequences[i], 2, true);
    ELSE
      PERFORM pg_catalog.setval(sequences[i], 1, true);
    END IF;
  end loop;
END;
$$;

alter function first_inserter() owner to s224514;

