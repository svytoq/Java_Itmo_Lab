create function valid_id_winer() returns trigger
    language plpgsql
as
$$
BEGIN
IF (NEW.ИД_АТАК_СТРАНЫ <> NEW.ИД_СТРАНЫ_ПОБЕДИТЕЛЯ) AND (NEW.ИД_ОБОРОН_СТРАНЫ <> NEW.ИД_СТРАНЫ_ПОБЕДИТЕЛЯ) THEN
RAISE EXCEPTION 'Одна из сторон должна победить (ид_битвы=%)',NEW.ИД_СОБЫТИЯ;
END IF;
RETURN NEW;
END
$$;

alter function valid_id_winer() owner to s243853;

