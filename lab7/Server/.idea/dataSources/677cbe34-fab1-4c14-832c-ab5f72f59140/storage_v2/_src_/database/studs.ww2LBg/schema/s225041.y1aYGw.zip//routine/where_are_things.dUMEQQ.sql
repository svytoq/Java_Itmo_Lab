create function where_are_things(type_id integer)
    returns TABLE(id integer, room_assignment text, room_access integer)
    language plpgsql
as
$$
DECLARE
		found_thing record;
		BEGIN
			FOR found_thing IN (
				SELECT ROOM.id, assignment, ACCESS
				FROM ROOM
				JOIN OBJECT
				ON OBJECT.room_fk = ROOM.id
				WHERE OBJECT.thing_type_fk = type_id
			)
			LOOP
				id = found_thing.id;
				room_assignment = found_thing.assignment;
				room_access = found_thing.access_fk;
				RETURN NEXT;
			END LOOP;
		END;

$$;

alter function where_are_things(integer) owner to s225041;

