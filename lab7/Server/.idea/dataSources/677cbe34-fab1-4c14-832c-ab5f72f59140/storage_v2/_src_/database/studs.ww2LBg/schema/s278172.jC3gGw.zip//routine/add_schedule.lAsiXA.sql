create function add_schedule() returns trigger
    language plpgsql
as
$$
DECLARE
    people_counter int;
BEGIN
    people_counter = (
        SELECT COUNT(*)
        FROM students
        WHERE year = (
            SELECT year
            FROM subjects
            WHERE subjects.id = new.subject_id
        )
    );
    IF people_counter > (SELECT capacity FROM places WHERE id = new.place_id) THEN
        RAISE 'Not enough capacity of the place';
    END IF;
    RETURN new;
END;
$$;

alter function add_schedule() owner to s278172;

