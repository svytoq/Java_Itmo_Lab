create function om(_tbl regclass, OUT result integer) returns integer
    language plpgsql
as
$$
BEGIN
EXECUTE format('SELECT count(ID) FROM %s ', _tbl)
INTO result;
END
$$;

alter function om(regclass, out integer) owner to s243858;

