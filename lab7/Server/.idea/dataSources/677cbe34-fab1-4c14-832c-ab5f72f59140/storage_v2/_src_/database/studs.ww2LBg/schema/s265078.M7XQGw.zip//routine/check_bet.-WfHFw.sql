create function check_bet() returns trigger
    language plpgsql
as
$$
DECLARE
creature_money numeric(10, 2) = 0;
BEGIN
SELECT money_amount INTO creature_money FROM creatures WHERE creature_id = NEW.bettor_id;
IF( creature_money < NEW.money_amount ) THEN
RAISE EXCEPTION 'У существа не хватает денег для ставки';
END IF;
UPDATE bets SET active = TRUE WHERE bet_id = NEW.bet_id; 
RETURN NEW;
END;
$$;

alter function check_bet() owner to s265078;

