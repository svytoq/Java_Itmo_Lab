create function get_workers_for(product_order_id integer) returns SETOF s267880.product_making_with_worker_and_profile
    language sql
as
$$
select * from product_making_with_worker_and_profile where product_order_id = $1;
$$;

alter function get_workers_for(integer) owner to s267880;

