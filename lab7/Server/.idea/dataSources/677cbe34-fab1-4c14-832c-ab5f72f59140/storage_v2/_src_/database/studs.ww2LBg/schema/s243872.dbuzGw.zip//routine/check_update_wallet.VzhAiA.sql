create function check_update_wallet() returns trigger
    language plpgsql
as
$$
BEGIN
  update refill
  set amount = 100
  where id = 1;
  return new;
end;
$$;

alter function check_update_wallet() owner to s243872;

