create function create_client(client_name text, discount_amount double precision) returns s259844.client
    strict
    language plpgsql
as
$$
DECLARE
    ret client;
BEGIN
    INSERT INTO client(name, discount)
        VALUES (client_name, discount_amount)
        RETURNING * INTO ret;

    RETURN ret;
END;
$$;

alter function create_client(text, double precision) owner to s259844;

