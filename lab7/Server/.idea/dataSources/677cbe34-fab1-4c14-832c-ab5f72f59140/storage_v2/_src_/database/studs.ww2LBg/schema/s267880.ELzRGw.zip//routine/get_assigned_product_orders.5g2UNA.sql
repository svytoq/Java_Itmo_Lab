create function get_assigned_product_orders(worker_id integer, is_finished boolean DEFAULT false) returns SETOF s267880.product_order_with_worker_info
    language sql
as
$$
select * from product_order_with_worker_info where worker_id = $1 and is_finished = $2;
$$;

alter function get_assigned_product_orders(integer, boolean) owner to s267880;

