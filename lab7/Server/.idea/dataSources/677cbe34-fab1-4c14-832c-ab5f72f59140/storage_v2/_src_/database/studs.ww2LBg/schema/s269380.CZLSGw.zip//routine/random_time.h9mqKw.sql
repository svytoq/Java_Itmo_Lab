create function random_time(time_after time without time zone, disp integer) returns time without time zone
    language plpgsql
as
$$
begin
    time_after := (time_after + ( interval '1 hour')*random_intmax(disp))::time;
    return time_after;
end;
$$;

alter function random_time(time, integer) owner to s269380;

