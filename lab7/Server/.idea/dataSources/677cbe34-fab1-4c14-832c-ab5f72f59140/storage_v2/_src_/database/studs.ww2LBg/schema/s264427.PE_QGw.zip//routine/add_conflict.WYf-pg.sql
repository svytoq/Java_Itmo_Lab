create function add_conflict(target_square integer, squad integer DEFAULT 0, date_reg date DEFAULT '1932-11-30'::date) returns text
    language plpgsql
as
$$
DECLARE
val text;
count_squad integer;
count_emu_group integer;
count_emu integer;
count_mas integer = 0;
counter integer = 1;
count_kills integer = 0;
count_conflict integer;
extra_kills integer;
target_kills integer;
square_emu integer;
target_emu_group integer = 0;
solders integer ARRAY[100];
weapons integer ARRAY[100];
squad_size integer;
weapons_size integer;
BEGIN
if squad = 0 THEN
Select count(distinct(squad_id)) INTO STRICT count_squad from Solder;
squad := (count_squad*random()-0.5)::int+1;
end if;
Select array_agg(Solder.soldier_id) INTO STRICT solders from Solder
where Solder.squad_id = squad;
Select array_agg(Solder.weapon_id) INTO STRICT weapons from Solder
where Solder.squad_id = squad;
Select count(Solder.soldier_id) INTO STRICT squad_size from Solder
where Solder.squad_id = squad;
Select count(Solder.weapon_id) INTO STRICT weapons_size from Solder
where Solder.squad_id = squad;
Select count(*) INTO STRICT count_conflict FROM War_Conflict;
count_conflict := count_conflict + 1;
SELECT count(group_id) INTO STRICT count_emu_group FROM Emu_Group;
while counter <= count_emu_group
LOOP
Select square_number INTO STRICT square_emu FROM Migration_Data where emu_group_id = counter Order By migration_data_id DESC LIMIT 1;
Select quantity INTO STRICT count_emu FROM Emu_Group where group_id = counter;
if square_emu = target_square AND count_emu > 0 THEN
target_emu_group := counter;
counter := 200;
END IF;
counter := counter +1;
END LOOP;
IF target_emu_group = 0 THEN
val := 'We didn`t find this';
ELSE
val := 'We attacked emu';
count_kills := (20*random())::int+30;
if count_emu - count_kills < 6 THEN
UPDATE Emu_Group SET disbandment_date = date_reg WHERE group_id = target_emu_group;
count_kills := count_emu;
END IF;
counter := 1;
extra_kills := count_kills % squad_size;
INSERT INTO War_Conflict (square_number, squad_id, Emu_loss, Soldiers_loss, mechanism_loss) VALUES
(target_square, squad, count_kills, 0, 0);
while counter <= squad_size
LOOP
SELECT counter_Emu INTO STRICT target_kills FROM Solder where soldier_id = solders[counter];
if extra_kills > 0 THEN
target_kills := target_kills + 1;
extra_kills := extra_kills - 1;
END IF;
target_kills := target_kills + count_kills % squad_size;
UPDATE SOLDER SET counter_Emu = target_kills, last_fight_id = count_conflict WHERE soldier_id = solders[counter];
counter := counter + 1;
END LOOP;
UPDATE Emu_Group SET quantity = (count_emu - count_kills) WHERE group_id = target_emu_group;
END IF;
counter := 1;
while counter <= weapons_size
LOOP
UPDATE Weapon SET last_fight_id = count_conflict WHERE weapon_id = weapons[counter];
counter := counter + 1;
END LOOP;
RETURN val;
END
$$;

alter function add_conflict(integer, integer, date) owner to s264427;

