create function func()
    returns TABLE(league text, prize integer, team_name text, player_name text, player_kda numeric, playerid integer)
    language plpgsql
as
$$
BEGIN 
RETURN query 
select tournament.name, tournament.prize_pool, team.name, player.nickname,
(stats.kills+stats.assists)::numeric/ case 
when stats.deaths > 0 then stats.deaths::numeric
when stats.deaths = 0 then 1
end as max_kda, player.id
from tournament
join tournament_result on tournament.id = tournament_result.tournament_id
join team on first_id = team.id
join player on first_id = player.team_id
join stats on stats.player_id = player.id
join match on (stats.match_id = match.id)

where 
match.tournament_id = tournament.id
and (stats.kills+stats.assists)::numeric/ case 
when stats.deaths > 0 then stats.deaths::numeric
when stats.deaths = 0 then 1
end = (select max(kda) from kda()
where nazv = tournament.name
group by nazv);
END;
$$;

alter function func() owner to s243878;

