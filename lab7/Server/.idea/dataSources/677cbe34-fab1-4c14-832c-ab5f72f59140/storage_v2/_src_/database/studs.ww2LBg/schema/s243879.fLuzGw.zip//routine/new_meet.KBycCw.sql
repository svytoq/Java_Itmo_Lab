create function new_meet(userid integer, whereid integer, startdate date, hasdresscode boolean, meetingtype text) returns void
    language plpgsql
as
$$
DECLARE
addressName text; eventId int;
typeId int; BEGIN
addressName := (SELECT Адрес FROM Г_Место WHERE ИД = whereId);
IF NOT EXISTS (
SELECT 1 FROM Г_Вид_встречи WHERE Название = meetingType)
THEN
INSERT INTO Г_Вид_встречи (Название) 
VALUES (meetingType);
END IF;
typeId := (SELECT ИД FROM Г_Вид_встречи WHERE Название = meetingType);
INSERT INTO Г_Событие (ИД_Пользователя, Название, Описание, Тип,
Время_начала, Время_окончания) VALUES (userId,
'Встреча (' || meetingType || ')',
'Встреча по адресу: ' || addressName, 'Встреча', startDate::timestamp,
NULL) RETURNING ИД INTO eventId;
INSERT INTO Г_Встреча (ИД_События, ИД_Места, ИД_Вида, Наличие_дресс_кода)
VALUES (eventId, whereId, typeId, hasDressCode);
END;
$$;

alter function new_meet(integer, integer, date, boolean, text) owner to s243879;

