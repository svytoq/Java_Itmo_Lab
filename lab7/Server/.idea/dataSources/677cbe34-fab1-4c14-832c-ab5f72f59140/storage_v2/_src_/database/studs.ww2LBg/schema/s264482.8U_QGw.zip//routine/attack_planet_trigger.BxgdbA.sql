create function attack_planet_trigger() returns trigger
    language plpgsql
as
$$
declare
    attack_army_planet_id int;
    attack_army_object_id int;
    
    current_planet_x bigint;
    current_planet_y bigint;
    current_planet_z bigint;
    current_planet_r bigint;
    
    deffence_planet_id int;
    deffence_planet_is_cooled_down boolean;
    deffence_army_id int;
    attack_planet_army_quantity bigint;
    
    moskoviy_for_magnetic_field bigint;
    
    needed_moskoviy_for_travel bigint;
    
    attack_army_quantity bigint;
    attack_army_moskoviy bigint;
    attack_army_kantoniy bigint;
    deffence_army_quantity bigint;
  begin
    select id, is_cooled_down, army_id into 
    deffence_planet_id, deffence_planet_is_cooled_down, deffence_army_id 
    from planet where object_id = new.object_id;
    
    if not found then
      raise exception 'no such planet';
    end if;
    
    if new.attacker_id = deffence_army_id then
      raise exception 'you`ve already on this planet, no need to attack';
    end if;
    
    -- if planet is cooled_down then you should waste additional moskoviy
    if deffence_planet_is_cooled_down = 'false' then
      moskoviy_for_magnetic_field = 10000;
    else
      moskoviy_for_magnetic_field = 0;
    end if;
    
    -- getting available resources
    select r_a.quantity into attack_army_moskoviy from resource_army as r_a
    inner join resource as r on (r.id = r_a.resource_id)
    where r.name = 'moskoviy' and r_a.army_id = new.attacker_id;
    
    select r_a.quantity into attack_army_kantoniy from resource_army as r_a
    inner join resource as r on (r.id = r_a.resource_id)
    where r.name = 'kantoniy' and r_a.army_id = new.attacker_id;
   
    -- get attacking army object id
    select id, object_id into attack_army_planet_id, attack_army_object_id from planet where army_id = new.attacker_id;
  
    -- get coordinates of current army planet
    select x_coordinate, y_coordinate, z_coordinate, radius
    into current_planet_x, current_planet_y, current_planet_z, current_planet_r
    from space_object where id = attack_army_object_id;
    
    -- count needed moskoviy for travel and magnetic field
    select sqrt(
      power(current_planet_x - s_o.x_coordinate, 2) + 
      power(current_planet_y - s_o.y_coordinate, 2) + 
      power(current_planet_z - s_o.z_coordinate, 2)
    )-current_planet_r-s_o.radius+moskoviy_for_magnetic_field 
    into needed_moskoviy_for_travel from space_object as s_o
    inner join planet as p on (p.object_id = s_o.id)
    where s_o.id = new.object_id;
    
    if needed_moskoviy_for_travel > attack_army_moskoviy then
      raise exception 'Not enough resources';
    end if;
    
    -- waste moskoviy for travel
    update resource_army set quantity = quantity - needed_moskoviy_for_travel 
      where resource_id = (select id from resource where name = 'moskoviy') 
      and army_id = new.attacker_id;
    
    -- find army quantities
    select quantity into deffence_army_quantity from army where id = deffence_army_id;
    select quantity into attack_army_quantity from army where id = new.attacker_id;
    
    -- results of battle
    if deffence_army_quantity = null 
    or deffence_army_quantity = 0 
    or deffence_army_quantity < attack_army_quantity then
    -- attack army has won
      -- waste kantoniy
      update resource_army set quantity = quantity - quantity/2  
      where resource_id = (select id from resource where name = 'kantoniy') 
      and army_id = new.attacker_id;
      -- take place on planet
      update planet set army_id = new.attacker_id where id = deffence_planet_id;
      update planet set army_id = null where id = attack_army_planet_id;
      -- is success = true
      new.is_success = 'true';
      -- remove another army to another planet and lose all resources
      update planet set army_id = deffence_army_id 
      where id = (select id from planet where army_id = null limit 1);
      update resource_army set quantity = 0 where army_id = deffence_army_id; 
    else
    -- deffence army has won
      -- is_success = false
      new.is_success = 'false';
      -- attacking army stays on it's planet and lose all resources
      update resource_army set quantity = 0 where army_id = new.attacker_id; 
    end if;
    -- mining section
    if new.should_mine = 'true' then
      insert into mining (army_id, object_id) values (new.attacker_id, new.object_id);
    end if;
    return new;
  end;
$$;

alter function attack_planet_trigger() owner to s264482;

