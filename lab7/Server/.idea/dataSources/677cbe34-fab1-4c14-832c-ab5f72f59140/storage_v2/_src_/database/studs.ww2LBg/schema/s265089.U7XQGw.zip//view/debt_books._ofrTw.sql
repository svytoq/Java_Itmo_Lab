create view debt_books(first_name, last_name, isbn, title, borrow_date, due_date) as
SELECT r.last_name  AS first_name,
       r.first_name AS last_name,
       b.isbn,
       b.title,
       bb.borrow_date,
       bb.due_date
FROM s265089.readers r
         JOIN s265089.borrowed_books bb USING (reader_id)
         JOIN s265089.books b USING (book_id)
WHERE bb.due_date <= 'now'::text::date
  AND bb.return_date IS NULL;

alter table debt_books
    owner to s265089;

