create function log_contract_operation() returns trigger
    language plpgsql
as
$$
begin
    if old.executor_actor_id is null and new.executor_actor_id is not null then
        insert into listing_history (seller, action, author_id, listing_id)
        values ('Actor', 'Picked', new.executor_actor_id, new.listing_id);
        new.status = 'In progress';
    end if;

    if old.executor_clan_id is null and new.executor_clan_id is not null then
        insert into listing_history (seller, action, clan_id, listing_id)
        values ('Clan', 'Picked', new.executor_clan_id, new.listing_id);
        new.status = 'In progress';
    end if;

    if new.status = 'Closed'::contract_status and new.executor_clan_id is not null then
        insert into listing_history (seller, action, clan_id, listing_id)
        values ('Clan', 'Done', new.executor_clan_id, new.listing_id);
    end if;

    if new.status = 'Closed'::contract_status and new.executor_actor_id is not null then
        insert into listing_history (seller, action, author_id, listing_id)
        values ('Actor', 'Done', new.executor_actor_id, new.listing_id);
    end if;

    return new;
end
$$;

alter function log_contract_operation() owner to s263063;

