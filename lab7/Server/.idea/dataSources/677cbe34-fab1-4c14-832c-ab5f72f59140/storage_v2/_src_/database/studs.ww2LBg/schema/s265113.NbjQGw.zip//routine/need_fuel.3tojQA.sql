create function need_fuel() returns trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO request_position(type, amount)
    VALUES (order_type('fuel'),
            (sum_fuel_cons(NEW.station_id)) * 80);
    RETURN NEW;
END;
$$;

alter function need_fuel() owner to s265113;

