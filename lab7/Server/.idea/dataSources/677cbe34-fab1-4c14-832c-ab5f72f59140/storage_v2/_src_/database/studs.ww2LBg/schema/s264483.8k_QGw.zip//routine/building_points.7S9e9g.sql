create function building_points() returns trigger
    language plpgsql
as
$$
DECLARE 
civilization_id_ integer;
    building_mf_ integer;
    civilization_mf_ integer;

BEGIN
SELECT planet.civilization_id into civilization_id_ from planet, settlement where planet.id =
    (select planet_id from settlement where id = new.settlement_id);
    SELECT military_points into civilization_mf_ from civilization where id = civilization_id_;
    select military_force into building_mf_ from building where id = new.building_id;
update civilization set military_points = (building_mf_ + civilization_mf_) where id = civilization_id_;
    RETURN new;
end;
$$;

alter function building_points() owner to s264483;

