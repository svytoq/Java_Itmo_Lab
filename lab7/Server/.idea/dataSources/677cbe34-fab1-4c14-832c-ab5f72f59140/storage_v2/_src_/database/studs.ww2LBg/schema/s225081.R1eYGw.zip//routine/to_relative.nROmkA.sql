create function to_relative(count integer) returns void
    language plpgsql
as
$$
DECLARE
  J    INT;
  K    INT;
  WIFE INT;
  SOSL SOSL;
BEGIN
  WIFE = 0;
  K = 0;
  FOR J IN SELECT ID_ЧЕЛ
           FROM ЛЮДИ
           WHERE ПОЛ ='муж' LOOP
    IF K = COUNT
    THEN
      EXIT;
    END IF;
    SELECT СОСЛОВИЕ
    FROM ЛЮДИ
    WHERE ID_ЧЕЛ = J
    INTO SOSL;

    SELECT ID_ЧЕЛ
    FROM ЛЮДИ
    WHERE ПОЛ = 'жен' AND СОСЛОВИЕ = SOSL AND ID_ЧЕЛ NOT IN (SELECT ЖЕНА
                                                                FROM БРАК)
    INTO WIFE;
    INSERT INTO БРАК VALUES (DEFAULT, J, WIFE);
    K = K + 1;
  END LOOP;
END;
$$;

alter function to_relative(integer) owner to s225081;

