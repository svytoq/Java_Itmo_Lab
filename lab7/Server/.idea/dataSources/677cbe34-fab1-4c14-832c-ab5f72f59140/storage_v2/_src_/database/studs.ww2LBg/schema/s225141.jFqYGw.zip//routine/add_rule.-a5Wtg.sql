create function add_rule() returns trigger
    language plpgsql
as
$$
DECLARE
counts integer := 0;
IsExist integer := 1;
BEGIN
SELECT COUNT(*) INTO counts FROM ПРАВИЛО;
WHILE IsExist != 0 LOOP
counts := counts + 1;
SELECT COUNT(*) INTO IsExist FROM ПРАВИЛО WHERE ИД = counts;
END LOOP;
NEW.ИД := counts;
RETURN NEW;
END
$$;

alter function add_rule() owner to s225141;

