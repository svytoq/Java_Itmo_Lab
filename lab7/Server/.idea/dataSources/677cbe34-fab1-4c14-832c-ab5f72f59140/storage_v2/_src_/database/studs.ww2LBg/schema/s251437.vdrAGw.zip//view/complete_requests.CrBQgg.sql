create view complete_requests(id, price, status, profile_id, item_id, worker_id, last_changed) as
SELECT request.id,
       request.price,
       request.status,
       request.profile_id,
       request.item_id,
       request.worker_id,
       request.last_changed
FROM s251437.request
WHERE request.status = 'complete'::s251437.requeststatus;

alter table complete_requests
    owner to s251437;

