create function auto_access_0() returns trigger
    language plpgsql
as
$$
DECLARE
level_ int;
type_ varchar;
BEGIN
level_ = (SELECT level FROM access WHERE access.access_id = new.access_id);
case level_
when 0 then type_= 'НЕТ';
when 1 then type_= 'НИЗКИЙ';
when 2 then type_= 'СРЕДНИЙ';
when 3 then type_= 'ВЫСОКИЙ';
else raise exception 'Неверный уровень';
end case;
update access set access_type=type_ where access_id=new.access_id;
return null;
END;
$$;

alter function auto_access_0() owner to s244702;

