create function flight_completed() returns trigger
    language plpgsql
as
$$
declare
    is_completed bool = false;
BEGIN
    IF (TG_OP = 'INSERT' AND NEW.duration is not null) THEN
        IF not EXISTS(select from "Flights" where id_spaceship = NEW.id_spaceship and date_start > NEW.date_start) THEN
            is_completed := true;
        END IF;
    ELSIF (TG_OP = 'UPDATE' and NEW.duration is not null and OLD.duration is null) THEN
        is_completed := true;
    END IF;

    IF (is_completed) THEN
        update "Spaceships" set id_current_planet=NEW.id_planet_to where id=NEW.id_spaceship;
    END IF;

    return NEW;
END;
$$;

alter function flight_completed() owner to s264434;

