create function findp(stop_1 integer, stop_2 integer)
    returns TABLE(x integer, y integer)
    language plpgsql
as
$$
declare x1 integer;
x2 integer;
y1 integer;
y2 integer;
kolvo1 integer;
kolvo2 integer;
i record;
j record;
nach_stop1 integer;
nach_stop2 integer;
string text;
BEGIN
x:=null;
y:=null;
select количество_остановок into kolvo1 from ОСТАНОВКА inner join ХАРАКТЕРИСТИКА_МАРШРУТА on (ОСТАНОВКА.ид_маршрута=ХАРАКТЕРИСТИКА_МАРШРУТА.ид) where ОСТАНОВКА.ид=stop_1;
<<lab>>
BEGIN
if kolvo1 is null 
then return next;
exit lab;
end if;
<<label>>
for i in 1..kolvo1 loop
select нач_остановка into nach_stop1 from ОСТАНОВКА inner join ХАРАКТЕРИСТИКА_МАРШРУТА on (ОСТАНОВКА.ид_маршрута=ХАРАКТЕРИСТИКА_МАРШРУТА.ид) where ОСТАНОВКА.ид=stop_1;
select х_коор into x1 from ОСТАНОВКА where ид=(nach_stop1+i-1);
select у_коор into y1 from ОСТАНОВКА where ид=(nach_stop1+i-1);
select количество_остановок into kolvo2 from ОСТАНОВКА inner join ХАРАКТЕРИСТИКА_МАРШРУТА on (ОСТАНОВКА.ид_маршрута=ХАРАКТЕРИСТИКА_МАРШРУТА.ид) where ОСТАНОВКА.ид=stop_2;
if kolvo2 is null 
then return next;
exit lab;
end if;
for j in 1..kolvo2 loop
select нач_остановка into nach_stop2 from ОСТАНОВКА inner join ХАРАКТЕРИСТИКА_МАРШРУТА on (ОСТАНОВКА.ид_маршрута=ХАРАКТЕРИСТИКА_МАРШРУТА.ид) where ОСТАНОВКА.ид=stop_2;
select х_коор into x2 from ОСТАНОВКА where ид=(nach_stop2+j-1);
select у_коор into y2 from ОСТАНОВКА where ид=(nach_stop2+j-1);
if (x1=x2) and (y1=y2) 
then
x:=x1;
y:=y1;
return next;
exit label;
else
end if;
end loop;
end loop;
END;

END;
$$;

alter function findp(integer, integer) owner to s242419;

