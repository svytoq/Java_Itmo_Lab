create function check_unique_ch() returns trigger
    language plpgsql
as
$$
DECLARE
  rec INTEGER;
BEGIN
  rec := (SELECT chassis.id FROM chassis WHERE NEW.id= chassis.id);
  IF rec is not NULL THEN
      RAISE EXCEPTION 'number % was found', NEW.id;
  END IF;

  rec = (SELECT firm_tower.serial_no FROM firm_tower WHERE NEW.id = firm_tower.serial_no);
  IF rec is not NULL THEN
    RAISE EXCEPTION 'number % was found', NEW.id;
  END IF;

  rec = (SELECT firm_weapon.serial_no FROM firm_weapon WHERE NEW.id = firm_weapon.serial_no);
  IF rec is not NULL THEN
    RAISE EXCEPTION 'number % was found', NEW.id;
  END IF;

  rec = (SELECT firm_engine.serial_no FROM firm_engine WHERE NEW.id = firm_engine.serial_no);
  IF rec is not NULL THEN
    RAISE EXCEPTION 'number % was found', NEW.id;
  END IF;

  RETURN NEW;

END;
$$;

alter function check_unique_ch() owner to s243858;

