create function test(t text) returns integer[]
    language plpgsql
as
$$
DECLARE
  int_ar int[];
  match text[];
  gr text;
BEGIN
  match = regexp_matches(t, '^([0-9]{1,5}|\?)(?:/([0-9]{1,2}|\?)(?:/([0-9]{1,2}|\?))?)?(?:\s([0-9]{2}|\?)(?::([0-9]{2}|\?)(?::([0-9]{2}|\?))?)?)?(?:\s(до З.Э.|от З.Э.))?$');
  
  IF match IS NULL THEN
    RETURN -1;
  END IF;

  FOR i IN 1..3 LOOP
    IF match[i] IS NOT NULL AND match[i] != '?' THEN
      int_ar[i] = match[i]::int;
    ELSE
      int_ar[i] = NULL;
    END IF;
  END LOOP;

  FOR i IN 4..6 LOOP
    IF match[i] IS NOT NULL AND match[i] != '?' THEN
      int_ar[i] = match[i]::int;
    ELSE
      int_ar[i] = 60;
    END IF;
  END LOOP;

  IF match[7] = 'до З.Э.' THEN
    int_ar[1] = -1*int_ar[1];
  END IF;

  IF int_ar[1] < -12000 OR int_ar[1] > 300 OR
     int_ar[2] > 12 OR
     int_ar[3] > 30 OR
     int_ar[4] > 23 AND int_ar[4] != 60 OR
     int_ar[5] > 60 OR
     int_ar[6] > 60 THEN
       RETURN NULL;
  END IF;

  RETURN int_ar;
END
$$;

alter function test(text) owner to s225125;

