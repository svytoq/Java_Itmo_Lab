create function "ВСЕ_МЫСЛИ_СОДЕРЖ_ЦИТАТЫ"(quote text)
    returns TABLE("МЫСЛЬ" text)
    language plpgsql
as
$$
BEGIN 
RETURN QUERY SELECT СУТЬ
FROM ЦИТАТЫ JOIN МЫСЛЬ_И_ЦИТАТА ON ЦИТАТЫ.ИД=ИД_ЦИТАТЫ
JOIN МЫСЛИ ON МЫСЛИ.ИД=ИД_МЫСЛИ WHERE ЦИТАТА = quote; 
END;
$$;

alter function "ВСЕ_МЫСЛИ_СОДЕРЖ_ЦИТАТЫ"(text) owner to s225058;

