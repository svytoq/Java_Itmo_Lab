create function register_user_profile(name character varying, date_of_birth date, email text, telephone_number text, password_hash text) returns integer
    language sql
as
$$
insert into user_profile (
        name, date_of_birth, email, telephone_number, password_hash
    ) values (name, date_of_birth, email, telephone_number, password_hash)
    returning user_profile_id;
$$;

alter function register_user_profile(varchar, date, text, text, text) owner to s267880;

