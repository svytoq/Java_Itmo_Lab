create function insert_groups_to_films() returns void
    language plpgsql
as
$$
DECLARE
        film record;
        groups record;
BEGIN
        FOR groups IN (SELECT ид from Группы)
        LOOP
                FOR film IN (SELECT ид from Фильмы)
                LOOP
                        insert into Фильмы_Группы 
                                values(film.ид,groups.ид);
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_groups_to_films() owner to s224932;

