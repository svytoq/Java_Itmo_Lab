create function check_common() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NOT(NEW.WEAPON_ID IN (SELECT weapon_id FROM weapon WHERE type_of_weapon= 'common')) THEN
    RAISE EXCEPTION 'Общего оружия с таким id не существует';
  END IF;
  RETURN NEW;
END;
$$;

alter function check_common() owner to s225100;

