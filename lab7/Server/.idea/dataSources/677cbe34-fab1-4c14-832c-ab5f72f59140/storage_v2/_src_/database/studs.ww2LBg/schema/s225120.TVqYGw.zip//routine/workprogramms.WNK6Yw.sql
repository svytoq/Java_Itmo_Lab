create function workprogramms() returns trigger
    language plpgsql
as
$$
declare a integer;
begin
	a:= (Select ИД_ДОЛЖНОСТИ from СОТРУДНИКИ inner join ПРИВЯЗКА_ДОЛЖНОСТИ using (ИД_СОТРУДНИКА) inner join ДОЛЖНОСТЬ using (ИД_ДОЛЖНОСТИ) where ИД_СОТРУДНИКА = new.ИД_СОТРУДНИКА and ВИД_ДОЛЖНОСТИ like 'Лектор');
	if (a is null) then
	raise notice 'The person you want to add to programms is not lector';
	return null;
	end if;
	return new;
end;
$$;

alter function workprogramms() owner to s225120;

