create function getarmy(id integer) returns SETOF s264430."АРМИЯ"
    language sql
as
$$
select * from АРМИЯ where АРМИЯ.ID = $1;
$$;

alter function getarmy(integer) owner to s264430;

