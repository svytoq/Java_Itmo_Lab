create function flights_with_the_same_planet(_planet_id integer)
    returns TABLE(spaceship_id integer, spaceship_name character varying, name_planet_from character varying, name_planet_to character varying, date_start timestamp with time zone, date_end timestamp with time zone)
    language plpgsql
as
$$
begin
return query SELECT
                    S.id,
                    S.name,
                    P_FROM.name,
                    P_TO.name,
                    "Flights".date_start,
                    CASE WHEN duration is null THEN null else "Flights".date_start + duration end
from "Flights"
        left join "Planets" P_FROM on P_FROM.id = "Flights".id_planet_from
        left join "Planets" P_TO on P_TO.id = "Flights".id_planet_to
        left join "Spaceships" S on "Flights".id_spaceship = S.id
where id_planet_from = _planet_id or id_planet_to = _planet_id order by "Flights".date_start desc;
end;
$$;

alter function flights_with_the_same_planet(integer) owner to s264434;

