create function non_team_type_control() returns trigger
    language plpgsql
as
$$
DECLARE
  user_type user_spec;
  BEGIN
   user_type:=(SELECT spec FROM users WHERE (users.id = NEW.user_id));
   IF (NOT(user_type = 'SPONSOR'))
     THEN RAISE EXCEPTION 'only sponsors allowed here';
     RETURN NULL;
  END IF;
  RETURN NEW;
END;
$$;

alter function non_team_type_control() owner to s244077;

