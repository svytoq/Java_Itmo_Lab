create function inserting_to_queue() returns trigger
    language plpgsql
as
$$
declare
    my_channel_id integer;
    channel_free timestamp;
    my_door_id integer;
    add_time timestamp;
    min integer;
    max_time timestamp;
begin

    if DATE_PART('year', CURRENT_TIMESTAMP) - NEW.Arrival_year  >= 5
    then UPDATE  Tickets SET Min_on_the_way = (DATE_PART('year', CURRENT_TIMESTAMP) - NEW.Arrival_year) where Passenger_id = NEW.Passenger_id;
            min := DATE_PART('year', CURRENT_TIMESTAMP) - NEW.Arrival_year;
    else UPDATE Tickets set Arrival_year = (DATE_PART('year', CURRENT_TIMESTAMP)) where id = NEW.id;
            min:= NEW.Min_on_the_way;
    end if;


    SELECT c.id into my_channel_id from Channels c join tickets t on c.Starting_station_id = t.Departure_station and c.End_station_id = t.Arrival_station where t.id = NEW.id;

    select max(taken_to) into channel_free from Channels_queue where Channel_id = my_channel_id;

    select id into my_door_id from Doors where Door_type = 'In' and Station_id = NEW.Departure_station;

    select max(taken_from) into max_time from doors_queue where Door_id = my_door_id;
    max_time:= max_time + interval '1 min';

    if channel_free < current_timestamp + interval '30 min' or channel_free IS NULL
    then channel_free = current_timestamp + interval '30 min';
    end if;

    if max_time < channel_free or max_time IS NULL
    then max_time := channel_free;
    end if;

    SELECT date_trunc('min', x) into add_time
    FROM generate_series( (channel_free)::timestamp,  (max_time + interval '1 min')::timestamp, interval  '1 min') t(x)
    WHERE date_trunc('min', x) not in (select taken_from from Doors_queue where door_id = my_door_id);

    insert into Doors_queue (Door_id, taken_from, Ticket_id)
    values (my_door_id, add_time, NEW.id);

    insert into Channels_queue (Channel_id, Taken_from, Taken_to, Ticket_id)
    values (my_channel_id, add_time + interval '1 min', add_time + min * interval '1 min', NEW.id);

    raise info 'You are in the queue. Waiting for you at %', add_time;

    return NEW;
    end;
$$;

alter function inserting_to_queue() owner to s265103;

