create function sex_func() returns trigger
    language plpgsql
as
$$
BEGIN
		IF NEW.Пол = 'М' THEN
			IF ((NEW.Имя = 'Софья') OR (NEW.Имя = 'Анастасия') OR (NEW.Имя = 'Алиса') OR (NEW.Имя = 'Вероника')
				OR (NEW.Имя = 'Дарья') OR (NEW.Имя = 'Ксения') OR (NEW.Имя = 'Алина') OR (NEW.Имя = 'Валерия') 
				OR (NEW.Имя = 'Мария') OR (NEW.Имя = 'Анна') OR (NEW.Имя = 'Елизавета') OR (NEW.Имя = 'Юлия')
				OR (NEW.Имя = 'Кристина') OR (NEW.Имя = 'Елена')) THEN
					RAISE EXCEPTION 'Несоответствие имени и пола!';
			END IF;
		END IF;
		IF NEW.Пол='Ж' THEN
			IF ((NEW.Имя='Матвей') OR (NEW.Имя='Артем') OR (NEW.Имя='Максим') OR (NEW.Имя='Дмитрий') 
				OR (NEW.Имя='Иван') OR (NEW.Имя='Роман') OR (NEW.Имя='Кирилл') OR (NEW.Имя='Никита') 
				OR (NEW.Имя='Сергей') OR (NEW.Имя='Алексей') OR (NEW.Имя='Александр') OR (NEW.Имя='Андрей')
				OR (NEW.Имя='Илья') OR (NEW.Имя='Михаил') OR (NEW.Имя='Константин') OR (NEW.Имя='Владислав') 
				OR (NEW.Имя='Павел') OR (NEW.Имя='Владимир') OR (NEW.Имя='Денис')) THEN
					RAISE EXCEPTION 'Несоответствие имени и пола!';
			END IF;
		END IF;
		RETURN NEW;
	END;
$$;

alter function sex_func() owner to s223868;

