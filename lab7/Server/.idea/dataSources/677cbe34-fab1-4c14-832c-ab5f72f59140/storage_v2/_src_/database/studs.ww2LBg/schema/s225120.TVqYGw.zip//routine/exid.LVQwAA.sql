create function exid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_ЭКСКУРСИИ := nextval('excursions_seq');
	return new;
end
$$;

alter function exid() owner to s225120;

