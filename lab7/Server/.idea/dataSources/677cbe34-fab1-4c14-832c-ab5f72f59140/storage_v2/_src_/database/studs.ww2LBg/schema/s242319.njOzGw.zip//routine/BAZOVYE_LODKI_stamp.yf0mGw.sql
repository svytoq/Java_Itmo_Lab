create function "БАЗОВЫЕ_ЛОДКИ_stamp"() returns trigger
    language plpgsql
as
$$
BEGIN 
    IF NEW.ИД IS NULL THEN
            RAISE EXCEPTION 'ИД cannot be null';
        END IF;
    IF (NEW.ТИП IN (SELECT НАЗВАНИЕ FROM ТИП_ЛОДКИ)) = FALSE THEN 
RAISE EXCEPTION '% cannot have THIS TYPE', NEW.ИД;
        END IF;
  IF (NEW.МАТЕРИАЛ IN (SELECT НАЗВАНИЕ FROM МАТЕРИАЛ)) = FALSE THEN 
RAISE EXCEPTION '% cannot have THIS TYPE', NEW.ИД;
        END IF;
IF NEW.ГРУЗОПОДЪЕМНОСТЬ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ВМЕСТИМОСТЬ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.МАКС_СКОРОСТЬ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.УСКОРЕНИЕ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.УПРАВЛЯЕМОСТЬ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ВЕС IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ЦЕНА IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
RETURN NEW;
  END;
$$;

alter function "БАЗОВЫЕ_ЛОДКИ_stamp"() owner to s242319;

