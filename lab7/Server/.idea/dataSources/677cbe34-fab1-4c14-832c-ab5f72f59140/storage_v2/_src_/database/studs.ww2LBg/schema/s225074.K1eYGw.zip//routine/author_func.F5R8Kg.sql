create function author_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.author_id:= NEXTVAL('author_seq');
RETURN new;
END;
$$;

alter function author_func() owner to s225074;

