create function statistics(startat timestamp without time zone, finishat timestamp without time zone)
    returns TABLE(date text, incoming numeric, outgoing numeric)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY SELECT
                 coalesce(tbl1.date, tbl2.date) AS dayz,
                 coalesce(total, 0)             AS outgoing,
                 coalesce(amount, 0)            AS incoming
               FROM (SELECT
                       to_char(rep.created_at, 'YYYY-MM-dd') AS date,
                       sum(rep.total)                        AS total
                     FROM reports AS rep
                     WHERE rep.created_at >= startAt AND rep.created_at <= finishAt
                     GROUP BY date
                     ORDER BY date ASC) tbl1
                 NATURAL FULL OUTER JOIN (
                                           SELECT
                                             to_char(ord.delivery_at, 'YYYY-MM-dd') AS date,
                                             sum(ord.amount)                        AS amount
                                           FROM orders AS ord
                                           WHERE ord.status = 'COMPLETED'
                                                 AND ord.delivery_at >= startAt
                                                 AND ord.delivery_at <= finishAt
                                           GROUP BY date
                                           ORDER BY date ASC
                                         ) tbl2;
END;
$$;

alter function statistics(timestamp, timestamp) owner to s245701;

