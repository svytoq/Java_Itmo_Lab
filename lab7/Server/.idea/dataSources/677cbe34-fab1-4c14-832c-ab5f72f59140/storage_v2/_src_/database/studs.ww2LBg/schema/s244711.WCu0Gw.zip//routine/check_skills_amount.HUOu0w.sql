create function check_skills_amount() returns trigger
    language plpgsql
as
$$
DECLARE
	maxSkills constant smallint = 8;
BEGIN
	IF ((SELECT COUNT(*)
		FROM skill_instances p
		WHERE p.hero = NEW.hero) > maxSkills) THEN
		RAISE EXCEPTION 
			'Skills amount cannot be more than %
			hero % skill %',
			maxSkills, NEW.hero, NEW.skill;
	END IF;

	RETURN NEW;
END;
$$;

alter function check_skills_amount() owner to s244711;

