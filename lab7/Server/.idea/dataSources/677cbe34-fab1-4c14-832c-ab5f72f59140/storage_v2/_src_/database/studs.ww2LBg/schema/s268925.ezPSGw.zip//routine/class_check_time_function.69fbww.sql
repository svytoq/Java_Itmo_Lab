create function class_check_time_function() returns trigger
    language plpgsql
as
$$
DECLARE
    row classes%rowtype;
BEGIN
    RAISE DEBUG 'Trigger function class_check_time_function() fired';
    IF row.start_date < localtimestamp
    THEN
        RAISE WARNING 'Start time of new class is after now';
        RETURN NULL;
    END IF;
    FOR row IN
        SELECT *
        FROM classes
        WHERE classes.creator_id = new.creator_id
          AND classes.start_date >= localtimestamp
        LOOP
            IF NOT (new.start_date > row.start_date AND new.start_date >= row.end_date) OR
               (new.end_date <= row.start_date AND new.end_date < row.end_date)
            THEN
                RAISE WARNING 'Class start time is not unique and overlaps class with id %', row.id;
                RETURN NULL;
            END IF;
        END LOOP;
    RETURN new;
END;
$$;

alter function class_check_time_function() owner to s268925;

