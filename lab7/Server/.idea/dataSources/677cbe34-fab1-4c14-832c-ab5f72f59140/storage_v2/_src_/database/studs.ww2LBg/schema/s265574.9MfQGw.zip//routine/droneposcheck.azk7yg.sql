create function droneposcheck() returns trigger
    language plpgsql
as
$$
begin
    if((new.x <> 0 or new.y <> 0) and new.isonboard = true) then
        raise notice 'You cant move on board';
        return null;
    else
        raise notice 'Pos changed (old: x=%, y=% | new: x=%, y=%)', old.x, old.y, new.x, new.y ;
        return new;
    end if;
end;
$$;

alter function droneposcheck() owner to s265574;

