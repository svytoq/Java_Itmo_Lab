create function sell_of_item_up() returns trigger
    language plpgsql
as
$$
declare
	price real;
	BEGIN
		IF (NEW.Статус = 'продан' AND OLD.Статус = 'в инвентаре') THEN
			Select Цена into price from К_Предметы where Id = OLD.Предмет_ИД;
			UPDATE "К_Персонажи" SET "Деньги" = "К_Персонажи".Деньги + price WHERE "К_Персонажи".Id = OLD.Персонаж_ИД;
			NEW.Момент_Отдачи := current_timestamp;
		END IF;
		RETURN NEW;
		END;
$$;

alter function sell_of_item_up() owner to s242193;

