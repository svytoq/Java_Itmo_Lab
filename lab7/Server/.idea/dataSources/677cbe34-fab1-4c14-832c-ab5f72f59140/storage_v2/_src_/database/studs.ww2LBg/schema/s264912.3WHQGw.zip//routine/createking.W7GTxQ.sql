create function createking(charactername text, end_time timestamp without time zone, w integer) returns text
    language plpgsql
as
$$
declare
    id_ch int;
begin
    insert into character(name) values (characterName) returning id_character into id_ch;
    insert into king (id_character, end_time, wisdom) values (id_ch);
    return 'Король создан! id - ' || id_ch;
end;
$$;

alter function createking(text, timestamp, integer) owner to s264912;

