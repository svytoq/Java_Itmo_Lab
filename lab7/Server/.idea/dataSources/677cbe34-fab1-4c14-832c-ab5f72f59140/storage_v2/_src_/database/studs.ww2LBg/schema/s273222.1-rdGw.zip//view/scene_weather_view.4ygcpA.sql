create view scene_weather_view(type, scene_id) as
SELECT weather.type,
       scene_weather.scene_id
FROM s273222.scene
         JOIN s273222.scene_weather ON scene.id = scene_weather.scene_id
         JOIN s273222.weather ON weather.id = scene_weather.weather_id;

alter table scene_weather_view
    owner to s273222;

