create function pk_func_por() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_por');
  RETURN new;
END;
$$;

alter function pk_func_por() owner to s223457;

