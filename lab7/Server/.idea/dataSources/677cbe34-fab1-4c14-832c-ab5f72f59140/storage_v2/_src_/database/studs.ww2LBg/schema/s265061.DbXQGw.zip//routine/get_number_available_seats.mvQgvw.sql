create function get_number_available_seats(date_ date, departure_airport_ character varying, arrival_airport_ character varying)
    returns TABLE(flight_id integer, schedule_departure timestamp with time zone, schedule_arrival timestamp with time zone, seats_number bigint)
    language plpgsql
as
$$
begin
  return query
  with available_flight as (
      select * from flight where
          flight.departure_airport = departure_airport_ and
          flight.arrival_airport = arrival_airport_ and
          flight.schedule_departure::date = date_
  ), available_seats_number as (
      select seat.flight_id, count(*) as seats_number from seat
                                                             left join ticket t on seat.id = t.seat_id
      where t.id is null
      group by seat.flight_id
  )
  select id, available_flight.schedule_departure, available_flight.schedule_arrival, a.seats_number from available_flight
                                                                                                           inner join available_seats_number a on a.flight_id = id;
end;
$$;

alter function get_number_available_seats(date, varchar, varchar) owner to s265061;

