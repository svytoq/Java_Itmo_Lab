create function "РАСХОДЫ_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
q integer = 1;
w integer = 54;
s integer = 1020;
BEGIN
FOR k IN 0..i-1 LOOP
INSERT INTO "РАСХОДЫ" ("ДАТА", "СУММА_РАСХОДЫ_ОПЛАТА_ТРУДА", "КРЕДИТЫ", "АРЕНДА")
VALUES (date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)), q, w, s);
k = k + 1;
q = q + 1;
w = w + 99;
s = s +1320;
END LOOP;
END;
$$;

alter function "РАСХОДЫ_ТЕСТ"(integer) owner to s223443;

