create function add_student(kek1 integer, kek2 character varying, kek3 character varying) returns void
    language sql
as
$$
INSERT INTO STUDENTS(AGE, INITIALS, GENDER) VALUES (kek1, kek2, kek3);
$$;

alter function add_student(integer, varchar, varchar) owner to s263869;

