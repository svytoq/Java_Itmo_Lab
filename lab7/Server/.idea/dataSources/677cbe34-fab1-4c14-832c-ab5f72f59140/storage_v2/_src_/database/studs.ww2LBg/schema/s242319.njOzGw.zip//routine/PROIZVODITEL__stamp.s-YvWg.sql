create function "ПРОИЗВОДИТЕЛЬ_stamp"() returns trigger
    language plpgsql
as
$$
BEGIN 
    IF NEW.ИД IS NULL THEN
            RAISE EXCEPTION 'ИД cannot be null';
        END IF;
   IF NEW.НАЗВАНИЕ_ФИРМЫ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF NEW.ВЕБ_САЙТ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
IF (NEW.ТЕЛЕФОН IS NULL) OR (NEW.ТЕЛЕФОН !~* '^[+][0-9] [(][0-9]{3}[)] [0-9]{3}[-][0-9]{2}[-][0-9]{2}$') THEN
            RAISE EXCEPTION '% cannot be this format of phone', NEW.ИД;
        END IF;
IF (NEW.EMAIL IS NULL) OR (NEW.EMAIL !~ '^[A-Za-z0-9._%-]+@[A-Za-z0-9.-]+[.][A-Za-z]+$') THEN
            RAISE EXCEPTION '% cannot be this format of EMAIL', NEW.ИД;
        END IF;
IF NEW.РЕЙТИНГ IS NULL THEN
            RAISE EXCEPTION '% cannot be null', NEW.ИД;
        END IF;
RETURN NEW;
  END;
$$;

alter function "ПРОИЗВОДИТЕЛЬ_stamp"() owner to s242319;

