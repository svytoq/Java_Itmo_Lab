create function insert_suggestion_request(name character varying, content character varying, author integer, suggestion integer) returns void
    language plpgsql
as
$$
DECLARE
    REQUEST_ID INTEGER;
BEGIN
    INSERT INTO REQUEST (NAME, CONTENT, AUTHOR)
    VALUES (NAME, CONTENT, AUTHOR)
    RETURNING id INTO REQUEST_ID;
    INSERT INTO SUGGESTION_REQUEST (SUGGESTION, REQUEST)
    VALUES (SUGGESTION, REQUEST_ID);
END;
$$;

alter function insert_suggestion_request(varchar, varchar, integer, integer) owner to s265087;

