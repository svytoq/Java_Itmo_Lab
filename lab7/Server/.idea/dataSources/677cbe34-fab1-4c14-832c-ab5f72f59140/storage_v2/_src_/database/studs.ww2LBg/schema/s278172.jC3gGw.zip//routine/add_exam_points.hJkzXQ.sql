create function add_exam_points() returns trigger
    language plpgsql
as
$$
BEGIN

    IF NEW.points != OLD.points THEN
        UPDATE students
        SET points = OLD.points + NEW.points
        WHERE new.student_id = students.id;
    END IF;

    RETURN NEW;
END;
$$;

alter function add_exam_points() owner to s278172;

