create function classification_function() returns trigger
    language plpgsql
as
$$
begin
new.Current_Level_ID=nextval('Classification_Current_Level_ID_seq ');
return new;
end;
$$;

alter function classification_function() owner to s225069;

