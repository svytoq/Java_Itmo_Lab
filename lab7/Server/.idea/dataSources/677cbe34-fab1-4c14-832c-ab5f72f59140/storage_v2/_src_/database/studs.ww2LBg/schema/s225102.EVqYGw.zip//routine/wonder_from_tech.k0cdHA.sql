create function wonder_from_tech(tname text)
    returns TABLE(name text, price_production integer, culture_pts integer, great_people integer, properties text)
    language plpgsql
as
$$
BEGIN
		RETURN QUERY SELECT wonders.name, wonders.price_production, wonders.culture_pts, wonders.great_people, wonders.properties FROM  (technologies JOIN tech_wonder ON technologies.id = tech_wonder.technology) JOIN wonders ON tech_wonder.wonder = wonders.id WHERE technologies.tech_name = tname; 
	END;
$$;

alter function wonder_from_tech(text) owner to s225102;

