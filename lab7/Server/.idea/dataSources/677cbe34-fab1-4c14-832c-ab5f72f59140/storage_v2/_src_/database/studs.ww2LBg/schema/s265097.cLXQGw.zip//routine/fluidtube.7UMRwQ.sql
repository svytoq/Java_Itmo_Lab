create function fluidtube(tubeid integer, potionid integer) returns integer
    language plpgsql
as
$$
declare 
begin
UPDATE "Tube" set "PotionId" = potionId Where "Id" = tubeId;
return 1;
end;
$$;

alter function fluidtube(integer, integer) owner to s265097;

