create function "ВЫПОЛНЯЕМАЯ_РАБОТА_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "ВЫПОЛНЯЕМАЯ_РАБОТА" ("НАЗВАНИЕ", "ОПИСАНИЕ")
VALUES (random_string(random()::integer*10+4), random_string(random()::integer*10+4));
k = k + 1;
END LOOP;
END;
$$;

alter function "ВЫПОЛНЯЕМАЯ_РАБОТА_ТЕСТ"(integer) owner to s223443;

