create function get_player_characters_in_session_count() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
      raise notice 'Player characters in this session: %', (select count(*) from character
      where Character.session_id = NEW.session_id and character.player_id != (select gm_id from Session where Session.id = NEW.session_id));
      return new;
    ELSE
      raise notice 'Player characters in this session: %', (select count(*) from character
      where Character.session_id = OLD.session_id and character.player_id != (select gm_id from Session where Session.id = OLD.session_id));
      return old;
    END IF;
    END;
$$;

alter function get_player_characters_in_session_count() owner to s243838;

