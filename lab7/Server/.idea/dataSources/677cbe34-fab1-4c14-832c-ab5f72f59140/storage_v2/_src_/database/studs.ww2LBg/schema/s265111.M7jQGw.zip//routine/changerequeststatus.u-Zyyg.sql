create function changerequeststatus(request_id integer, new_status s265111.request_status, payload_ text, failure_reason_ text) returns void
    language plpgsql
as
$$
DECLARE
    creator_id     int;
    report_id      int;
    observatory_id int;
BEGIN
    if new_status = 'Ready for execution' or new_status = 'Rejected' then
        update researchrequest set status = new_status where id = request_id;
        return;
    end if;
    if new_status = 'Completed successfully' then
        if payload_ is NULL then
            raise notice 'Payload should not be null!';
            return;
        end if;

        update researchrequest set status = new_status where id = request_id;

        select max(id) + 1 into report_id from researchreport;

        select employee.id
        into creator_id
        from s265111.employee
                 inner join researchrequest on employee.id = researchrequest.creatorid
        where researchrequest.id = request_id;

        select observatory.id
        into observatory_id
        from observatory
                 inner join employee e on observatory.id = e.observatoryid
        where e.id = creator_id;

        insert into researchreport values (report_id, observatory_id, request_id, true, payload_, null);
        return;
    end if;
    if failure_reason_ is NULL then
        raise notice 'Failure reason should not be null!';
        return;
    end if;

    update researchrequest set status = new_status where id = request_id;

    select max(id) + 1 into report_id from researchreport;

    select employee.id
    into creator_id
    from s265111.employee
             inner join researchrequest on employee.id = researchrequest.creatorid
    where researchrequest.id = request_id;

    select observatory.id
    into observatory_id
    from observatory
             inner join employee e on observatory.id = e.observatoryid
    where e.id = creator_id;

    insert into researchreport values (report_id, observatory_id, request_id, false, null, failure_reason_);
    return;

END;
$$;

alter function changerequeststatus(integer, s265111.request_status, text, text) owner to s265111;

