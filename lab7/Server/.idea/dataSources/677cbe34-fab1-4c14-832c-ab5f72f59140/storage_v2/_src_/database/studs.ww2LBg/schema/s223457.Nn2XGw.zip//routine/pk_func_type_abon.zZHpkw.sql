create function pk_func_type_abon() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_type_abon');
  RETURN new;
END;
$$;

alter function pk_func_type_abon() owner to s223457;

