create function change_priority() returns trigger
    language plpgsql
as
$$
begin
    update time_police_officers set Priority = Priority - 1;
    update time_police_officers set Priority = (select max(priority) from time_police_officers) + 1 where Priority = 0;
    return NEW;
end;
$$;

alter function change_priority() owner to s265103;

