create function insert_participant(first_name text, last_name text, birth_date date, championship_id integer, phone_number text, email_address text) returns integer
    language plpgsql
as
$$
DECLARE
    person integer;

BEGIN
    SELECT NEXTVAL('people_person_id_seq') INTO person;

    SELECT insert_person(first_name, last_name, birth_date, phone_number, email_address);

    INSERT INTO participant (person_id, championship_id)
    VALUES (person, insert_participant.championship_id);

    RETURN person;
END;
$$;

alter function insert_participant(text, text, date, integer, text, text) owner to s264448;

