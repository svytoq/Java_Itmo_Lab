create function generate_uuid() returns uuid
    language plpgsql
as
$$
BEGIN
return md5(random()::text || clock_timestamp()::text)::uuid;
END;
$$;

alter function generate_uuid() owner to s223443;

