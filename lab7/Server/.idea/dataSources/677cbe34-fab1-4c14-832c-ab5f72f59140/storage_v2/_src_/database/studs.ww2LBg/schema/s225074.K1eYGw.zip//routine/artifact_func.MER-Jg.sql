create function artifact_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.art_id:= NEXTVAL('artifact_seq');
RETURN new;
END;
$$;

alter function artifact_func() owner to s225074;

