create function note_age() returns trigger
    language plpgsql
as
$$
declare personId integer;
  declare datestart timestamp;
begin
  select into personId person_id from note_killer where id = new.first_owner_id;
  select into datestart birthday from person where id=personId;
  new.age := date_part('year',current_date)-date_part('year',datestart);
return new;
end;

$$;

alter function note_age() owner to s249007;

