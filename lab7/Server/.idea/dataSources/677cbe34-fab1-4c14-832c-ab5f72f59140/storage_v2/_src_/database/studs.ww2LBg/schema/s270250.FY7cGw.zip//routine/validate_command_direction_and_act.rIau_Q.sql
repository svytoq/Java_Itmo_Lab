create function validate_command_direction_and_act() returns trigger
    language plpgsql
as
$$
DECLARE
   person_id_var person.id%type;
   ship_id_var ship.id%type;
   base_id_var base.id%type;
BEGIN
   IF (EXISTS(SELECT command_id FROM command_engine WHERE command_id = NEW.command_id)) THEN
     RAISE EXCEPTION 'no, this command is already a command for an engine';
   END IF;
   SELECT person_id INTO person_id_var FROM command WHERE id = NEW.command_id;
   
   IF (EXISTS(SELECT person_id FROM astronaut WHERE person_id=person_id_var)) THEN
      SELECT ship_id INTO ship_id_var FROM astronaut WHERE person_id=person_id_var;
      IF ship_id_var IS NOT NULL THEN
        UPDATE ship SET direction=NEW.direction WHERE id=ship_id_var;
      ELSE
        RAISE EXCEPTION 'no, this astronaut doesn`t have a ship';
      END IF;
   ELSIF (EXISTS(SELECT person_id FROM base_worker WHERE person_id=person_id_var)) THEN
     SELECT base_id INTO base_id_var FROM base_worker WHERE person_id=person_id_var;
     IF base_id_var IS NOT NULL THEN
        SELECT ship_id INTO ship_id_var FROM base WHERE id=base_id_var;
        IF ship_id_var IS NOT NULL THEN
          UPDATE ship SET direction=NEW.direction WHERE id=ship_id_var;
        ELSE
          RAISE EXCEPTION 'no, this base doesn`t control any ship';
        END IF;
     ELSE
        RAISE EXCEPTION 'no, this base_worker doesn`t have a job';
     END IF;
   END IF;
   RETURN NEW;
END;
$$;

alter function validate_command_direction_and_act() owner to s270250;

