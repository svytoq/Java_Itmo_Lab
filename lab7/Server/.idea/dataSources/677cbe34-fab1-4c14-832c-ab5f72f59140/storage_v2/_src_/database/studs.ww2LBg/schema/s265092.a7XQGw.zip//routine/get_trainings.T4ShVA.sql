create function get_trainings()
    returns TABLE(train_id integer, lead_mage character varying, sidekick character varying, victim character varying, lm_id integer, sk_id integer, v_id integer, res text)
    language plpgsql
as
$$
BEGIN
RETURN QUERY
SELECT T.TRAIN_ID, M.NAME AS LEAD_N, MA.NAME AS SK_NAME, H.NAME, T.LEAD_MAGE, T.SIDEKICK, T.VICTIM, T.RESULT FROM TRAINING T
LEFT JOIN MAGE M ON T.LEAD_MAGE = M.MAGE_ID LEFT JOIN HUMAN H ON T.VICTIM = H.PERSON_ID
LEFT JOIN MAGE MA ON  T.SIDEKICK = MA.MAGE_ID;

    END;
$$;

alter function get_trainings() owner to s265092;

