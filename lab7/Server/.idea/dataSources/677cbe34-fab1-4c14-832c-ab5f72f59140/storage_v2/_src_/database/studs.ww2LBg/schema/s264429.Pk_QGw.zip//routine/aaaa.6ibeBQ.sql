create function aaaa(fnames character varying[]) returns void
    language plpgsql
as
$$
declare
    i integer := 0;
begin
    for i in 1 .. 150000 loop
        insert into person(name) values (fnames[i % 150000]);
    end loop;
end;
$$;

alter function aaaa(character varying[]) owner to s264429;

