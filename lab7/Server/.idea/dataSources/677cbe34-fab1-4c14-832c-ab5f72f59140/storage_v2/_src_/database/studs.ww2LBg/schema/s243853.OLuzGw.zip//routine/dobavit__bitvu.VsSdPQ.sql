create function добавить_битву("название" character varying, "описание" text, "дата_начала" timestamp without time zone, "дата_конца" timestamp without time zone, "ид_войны" integer, "ид_оборон" integer, "ид_атак" integer, "ид_страны_побед" integer, "местность" text) returns void
    language plpgsql
as
$$
DECLARE
id_event integer;
BEGIN
IF ид_войны IS NULL OR ид_оборон IS NULL OR ид_атак IS NULL OR название IS NULL THEN
RAISE EXCEPTION 'Some fields can''t been null';
ELSE
INSERT INTO СОБЫТИЯ(НАЗВАНИЕ_СОБЫТИЯ,ОПИСАНИЕ_СОБЫТИЯ,ДАТА_НАЧАЛА,ДАТА_КОНЦА) VALUES
( название, описание, дата_начала, дата_конца);
id_event := (SELECT ИД_СОБЫТИЯ FROM СОБЫТИЯ WHERE НАЗВАНИЕ_СОБЫТИЯ = название);
INSERT INTO БИТВЫ_ВОЙНЫ(ИД_СОБЫТИЯ,ИД_ВОЙНЫ,ИД_АТАК_СТРАНЫ,ИД_ОБОРОН_СТРАНЫ,ИД_СТРАНЫ_ПОБЕДИТЕЛЯ,МЕСТНОСТЬ) VALUES
( id_event,ид_войны,ид_атак,ид_оборон,ид_страны_побед,местность);
END IF;
END
$$;

alter function добавить_битву(varchar, text, timestamp, timestamp, integer, integer, integer, integer, text) owner to s243853;

