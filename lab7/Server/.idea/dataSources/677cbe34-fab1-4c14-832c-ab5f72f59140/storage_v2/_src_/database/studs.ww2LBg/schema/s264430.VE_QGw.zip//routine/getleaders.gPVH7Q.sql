create function getleaders(name text) returns text
    language sql
as
$$
select Leader_name from Race inner join Fraction on Race.Fraction_name=$1
$$;

alter function getleaders(text) owner to s264430;

