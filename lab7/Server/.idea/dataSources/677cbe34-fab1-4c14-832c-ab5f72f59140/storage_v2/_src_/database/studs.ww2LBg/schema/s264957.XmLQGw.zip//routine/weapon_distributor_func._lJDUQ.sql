create function weapon_distributor_func() returns trigger
    language plpgsql
as
$$
BEGIN
        insert into weapon values(NEW.weapon_id, null, null) ON CONFLICT DO NOTHING;
        insert into distributor values(NEW.distributor_id, (SELECT location_id from participant where id = NEW.distributor_id), (SELECT name from participant where id = NEW.distributor_id)) ON CONFLICT DO NOTHING;
    RETURN NEW;
    end;
$$;

alter function weapon_distributor_func() owner to s264957;

