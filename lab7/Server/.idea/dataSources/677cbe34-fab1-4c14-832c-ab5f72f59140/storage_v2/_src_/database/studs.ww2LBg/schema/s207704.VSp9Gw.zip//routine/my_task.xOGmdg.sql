create function my_task(sch character varying DEFAULT ''::character varying) returns void
    language plpgsql
as
$$
begin
    declare
        table_count   integer;
        columns_count integer;
        index_count   integer;
        row_count     integer;
        column_count  integer;
        count         int := 1;
        tables cursor for (select tablename
                           from pg_catalog.pg_tables
                           where schemaname = sch);
    begin
        if sch = ''
        then
            raise exception 'Неправильно вызвана команда,попробуйте иначе';
        end if;
        table_count := (SELECT COUNT(table_name)
                        FROM information_schema.tables
                        WHERE table_schema NOT IN ('information_schema', 'pg_catalog'));
        columns_count := (SELECT COUNT(*) FROM information_schema."columns" WHERE table_schema = sch);
        index_count := (select count(*) from pg_indexes where schemaname = sch);
        raise notice 'Количество таблиц в схеме % - %',sch,table_count;
        raise notice 'Количество столбцов в схеме % - %',sch,columns_count;
        raise notice 'Количество индексов в схеме % - %',sch,index_count;
        raise notice ' ';
        raise notice '   Таблицы схемы %',sch;
        raise notice ' ';
        raise notice '   Имя                  Столбцов     Строк ';
        raise notice '-----------------------------------------------';

        for row in tables
            loop
                execute format('SELECT COUNT(*) from %I', row.tablename) into row_count;
                execute format('SELECT COUNT(*) from information_schema.columns ' ||
                               'where table_name= ''%I'' and table_schema = ''%I''', row.tablename, sch) into column_count;
    --             if null_counter > 0
                    -- lpad с пробелом ничего не делает, вот со * например норм, а с пробелами ******
                    -- ладно на самом деле он просто выкидывает ведущие пробелы, но всё равно треш
    --             then
                    raise notice '% % %', rpad(row.tablename, 28, ' '), rpad(column_count::text, 9, ' '), row_count;
                    count = count + 1;
    --             end if;
            end loop;

    end;
end;
$$;

alter function my_task(varchar) owner to s207704;

