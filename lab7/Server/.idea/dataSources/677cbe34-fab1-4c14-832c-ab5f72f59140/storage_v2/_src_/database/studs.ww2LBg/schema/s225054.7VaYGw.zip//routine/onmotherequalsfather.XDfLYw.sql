create function onmotherequalsfather() returns trigger
    language plpgsql
as
$$
BEGIN
IF (NEW.ID_МАТЕРИ IS NOT NULL AND (NEW.ID_МАТЕРИ = NEW.ID_ОТЦА)) 
THEN
RAISE NOTICE 'Это же непорочное зачатие';
RETURN OLD;
        END IF;
RETURN NEW;
END;
$$;

alter function onmotherequalsfather() owner to s225054;

