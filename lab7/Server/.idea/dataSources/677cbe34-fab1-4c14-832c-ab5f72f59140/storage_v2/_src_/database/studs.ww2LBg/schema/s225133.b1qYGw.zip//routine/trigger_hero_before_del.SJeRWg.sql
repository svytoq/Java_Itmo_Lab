create function trigger_hero_before_del() returns trigger
    language plpgsql
as
$$
BEGIN

    if (select count(*) from "Войско" a
    where a."id_героя"=OLD."id")>0
        then delete from "Войско" where "Войско"."id_героя"=OLD."id";
    end if;

    if (select count(*) from "Экипировка" b
    where b."id_героя"=OLD."id")>0
        then delete from "Экипировка" where "Экипировка"."id_героя"=OLD."id";
    end if;

    if (select count(*) from "ГЕРОЙ_К_МАГИИ" c
    where c."id_героя"=OLD."id")>0
        then delete from "ГЕРОЙ_К_МАГИИ" where "ГЕРОЙ_К_МАГИИ"."id_героя"=OLD."id";
    end if;

    if (select count(*) from "Магия" d
    where d."id_героя"=OLD."id")>0
        then delete from "Магия" where "Магия"."id_героя"=OLD."id";
    end if;

    if (select count(*) from "Битва" e
    where e."id_победителя"=OLD."id")>0
        then delete from "Битва" where "Битва"."id_победителя"=OLD."id";
    end if;

    if (select count(*) from "Битва" f
    where f."id_проигравшего"=OLD."id")>0
        then delete from "Битва" where "Битва"."id_проигравшего"=OLD."id";
    end if;

    return OLD;
END;
$$;

alter function trigger_hero_before_del() owner to s225133;

