create view aq as
SELECT 1;

alter table aq
    owner to s223619;

