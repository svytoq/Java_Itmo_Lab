create function addind() returns trigger
    language plpgsql
as
$$
begin insert into Контактные_данные (ИД) values(new.ИД_автомастерской); return new;end;
$$;

alter function addind() owner to s243882;

