create function check_work_hours() returns trigger
    language plpgsql
as
$$
BEGIN
        IF (SELECT COUNT(*) FROM НАРАБОТАННОЕ_ВРЕМЯ WHERE НАРАБОТАННОЕ_ВРЕМЯ.ИД_СОТРУДНИК = NEW.ИД_СОТРУДНИК AND НАРАБОТАННОЕ_ВРЕМЯ.ДАТА = NEW.ДАТА) >= '1' THEN
            RAISE EXCEPTION 'Ему хватит одной зарплаты';
        END IF;
        IF NEW.ВРЕМЯ_РАБОТЫ > (INTERVAL '24' HOUR) THEN
            RAISE EXCEPTION 'Интервал работы не должен быть больше суток';
        END IF;
        IF (SELECT СТАТУС FROM ЛОГИ_СОТРУДНИКА WHERE ЛОГИ_СОТРУДНИКА.ИД_СОТРУДНИК = NEW.ИД_СОТРУДНИК ORDER BY ДАТА_ЛОГА LIMIT 1) != 'РАБОТАЕТ' THEN
            RAISE EXCEPTION 'Статус этого сотрудника не подходит для работы';
        END IF;
        RETURN NEW;
    END;
$$;

alter function check_work_hours() owner to s242297;

