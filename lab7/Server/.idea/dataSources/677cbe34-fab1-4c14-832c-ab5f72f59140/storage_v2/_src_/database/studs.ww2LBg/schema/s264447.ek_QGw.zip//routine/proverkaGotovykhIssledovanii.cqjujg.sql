create function "проверкаГотовыхИсследований"() returns trigger
    language plpgsql
as
$$
declare
количествоНеготовых int;
заказ int;
BEGIN
    заказ := (select заказ_id from Исследования where id=NEW.id limit 1);    
    количествоНеготовых := (select count(*) from ЛабораторныеИсследования where заказ_id=заказ AND готов='f');
    if количествоНеготовых=0 then
        update Заказы
        set готов='t'
        where id=заказ;
    end if;
    return new;
end;
$$;

alter function "проверкаГотовыхИсследований"() owner to s264447;

