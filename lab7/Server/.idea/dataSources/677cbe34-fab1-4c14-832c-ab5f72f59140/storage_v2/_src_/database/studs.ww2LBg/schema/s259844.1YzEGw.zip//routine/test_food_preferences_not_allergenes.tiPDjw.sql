create function test_food_preferences_not_allergenes() returns trigger
    language plpgsql
as
$$
BEGIN
    ASSERT NOT EXISTS (SELECT 1 FROM cat_allergen
        INNER JOIN food_allergen USING (allergen_id)
        WHERE cat_allergen.cat_id = NEW.cat_id AND
            food_allergen.food_id = NEW.food_id);

    RETURN NEW;
END;
$$;

alter function test_food_preferences_not_allergenes() owner to s259844;

