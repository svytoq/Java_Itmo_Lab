create function kill(character varying) returns void
    language plpgsql
as
$$
BEGIN
DELETE FROM Peasant WHERE Name = $1;
RAISE NOTICE 'Ubili';
END
$$;

alter function kill(varchar) owner to s265104;

