create function add_headmaster(name character, birthdate integer, st_sword integer, sil_sword integer) returns integer
    language plpgsql
as
$$
DECLARE
person_id INTEGER;
role_id INTEGER;
witcher_id INTEGER;
begin
 person_id = add_person(name, birthdate, true);
 role_id = add_role('headmaster', NULL, st_sword, NULL, sil_sword);
 witcher_id = nextval('witcher_witcher_id_seq'); 
 INSERT INTO witcher VALUES
 (witcher_id, 'headmaster', person_id, role_id, NULL);
 
 UPDATE sword set owner_id = witcher_id WHERE sword_id = st_sword;
 UPDATE sword set owner_id = witcher_id WHERE sword_id = sil_sword;
 
 RETURN witcher_id;
 end
$$;

alter function add_headmaster(char, integer, integer, integer) owner to s268428;

