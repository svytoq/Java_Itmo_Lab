create function "ПРОВЕРИТЬ_ЗАНЯТИЕ"() returns trigger
    language plpgsql
as
$$
DECLARE
	duration interval;
	start_date date;
	finish_date date;
	lesson_ex_row record;
	count_studs smallint;
	aud_count_studs smallint;
	group_level smallint;
BEGIN
	--проверка длительности--
	duration:=age(NEW.ВРЕМЯ_КОНЦА,NEW.ВРЕМЯ_НАЧАЛА);
	IF (duration<'1 hour' or duration>'4 hours') THEN
		RAISE EXCEPTION 'Занятия должно длиться от 1 до 4 часов, %',duration;
		RETURN NULL;
	END IF;
	--Проверка, что занятие проходит именно в этом семестре--
	SELECT INTO start_date,finish_date ДАТА_НАЧАЛА,ДАТА_КОНЦА FROM СЕМЕСТР WHERE СЕМЕСТР_ИД=NEW.СЕМЕСТР_ИД;
	IF (NEW.ВРЕМЯ_НАЧАЛА<start_date or NEW.ВРЕМЯ_КОНЦА>finish_date) THEN
		RAISE EXCEPTION 'Занятие не проходит в рамках семестра';
		RETURN NULL;
	END IF;
	--проверка занятости на занятия--
	FOR lesson_ex_row IN SELECT * FROM ЗАНЯТИЕ WHERE (NOT(NEW.ВРЕМЯ_НАЧАЛА>=ВРЕМЯ_КОНЦА) AND NOT(NEW.ВРЕМЯ_КОНЦА<=ВРЕМЯ_НАЧАЛА)) LOOP
		CONTINUE WHEN (lesson_ex_row.ЗАНЯТИЕ_ИД=NEW.ЗАНЯТИЕ_ИД);
		IF (lesson_ex_row.ГРУППА_ИД=NEW.ГРУППА_ИД) THEN
			RAISE EXCEPTION 'Группа ID=% уже занята в это время',NEW.ГРУППА_ИД;
			RETURN NULL;
		END IF;
		IF (NEW.ПРЕП_ИД IS NOT NULL) THEN
			IF (lesson_ex_row.ПРЕП_ИД IS NOT NULL AND lesson_ex_row.ПРЕП_ИД=NEW.ПРЕП_ИД) THEN
				RAISE EXCEPTION 'Преподаватель ID=% уже занят в это время на занятии',NEW.ПРЕП_ИД;
				RETURN NULL;
			END IF;
		END IF;
		IF (NEW.АУД_ИД IS NOT NULL) THEN
			IF (lesson_ex_row.АУД_ИД IS NOT NULL AND lesson_ex_row.АУД_ИД=NEW.АУД_ИД) THEN
				RAISE EXCEPTION 'Аудитория номер=% уже занята в это время на занятие',NEW.АУД_ИД;
				RETURN NULL;
			END IF;
		END IF;
	END LOOP;
	--проверка занятности на экзаменах--
	FOR lesson_ex_row IN SELECT * FROM ЭКЗАМЕН WHERE (NOT(NEW.ВРЕМЯ_НАЧАЛА>=ВРЕМЯ_КОНЦА) AND NOT(NEW.ВРЕМЯ_КОНЦА<=ВРЕМЯ_НАЧАЛА)) LOOP
		IF (NEW.ПРЕП_ИД IS NOT NULL) THEN
			IF (lesson_ex_row.ПРЕП_ИД IS NOT NULL AND lesson_ex_row.ПРЕП_ИД=NEW.ПРЕП_ИД) THEN
				RAISE EXCEPTION 'Преподаватель ID=% уже занят в это время на экзамене',NEW.ПРЕП_ИД;
				RETURN NULL;
			END IF;
		END IF;
		IF (NEW.АУД_ИД IS NOT NULL) THEN
			IF (lesson_ex_row.АУД_ИД IS NOT NULL AND lesson_ex_row.АУД_ИД=NEW.АУД_ИД) THEN
				RAISE EXCEPTION 'Аудитория номер=% уже занята в это время на экзамен',NEW.АУД_ИД;
				RETURN NULL;
			END IF;
		END IF;
	END LOOP;
	--Все свободны, проверим, что аудитория вмещает всех учеников+препода--
	IF (NEW.АУД_ИД IS NOT NULL) THEN
		SELECT INTO aud_count_studs ВМЕСТИМОСТЬ FROM АУДИТОРИЯ WHERE НОМЕР=NEW.АУД_ИД;
		SELECT INTO count_studs КОЛИЧЕСТВО_УЧЕНИКОВ FROM ГРУППА WHERE ГРУППА_ИД=NEW.ГРУППА_ИД;
		IF (aud_count_studs<(count_studs+1)) THEN
			RAISE EXCEPTION 'Аудитория не вмещает всех студентов и преподавателя';
			RETURN NULL;
		END IF;
	END IF;
	--Проверим, что у препода нет материала--
	IF (NEW.ПРЕП_ИД IS NOT NULL) THEN
		SELECT INTO group_level УРОВЕНЬ FROM ГРУППА WHERE ГРУППА_ИД=NEW.ГРУППА_ИД;
		IF (group_level IS NOT NULL AND NOT EXISTS (SELECT TRUE FROM ДОСТУП_МАТ_ПРЕПОД JOIN МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ USING (МАТ_ПРЕП_ИД) WHERE ПРЕП_ИД=NEW.ПРЕП_ИД AND МАТЕРИАЛ_ПРЕПОДАВАТЕЛЯ.УРОВЕНЬ=group_level)) THEN
			RAISE EXCEPTION 'У преподавателя нет материалов для обучения этой группы. Предоставьте ему доступ к материалам уровня %',group_level;
			RETURN NULL;
		END IF;
	END IF;
	RETURN NEW;
END;
$$;

alter function "ПРОВЕРИТЬ_ЗАНЯТИЕ"() owner to s265057;

