create function create_ticket(passport character, flightid integer, seeat character varying, name character varying, secname character varying, thirdname character varying, dat date, amount integer, book integer) returns boolean
    language plpgsql
as
$$
begin
  if add_passenger(name,secname,thirdname,passport,dat) then
  insert into ticket (passenger_id,  seat_id, amount, book_id, registered)
  values (passport,(select id from seat where number=seeat and seat.flight_id=flightId), amount, book, false);
    end if;
    return true;
end;
$$;

alter function create_ticket(char, integer, varchar, varchar, varchar, varchar, date, integer, integer) owner to s265061;

