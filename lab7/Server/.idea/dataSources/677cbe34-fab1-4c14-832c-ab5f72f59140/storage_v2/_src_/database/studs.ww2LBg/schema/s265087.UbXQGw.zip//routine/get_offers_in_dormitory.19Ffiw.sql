create function get_offers_in_dormitory(dormitory_id integer)
    returns TABLE(id integer, name character varying, description character varying, status s265087."STATUS", creation_date timestamp with time zone, author integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT OFFER.ID,
                        OFFER.NAME,
                        OFFER.DESCRIPTION,
                        OFFER.STATUS,
                        OFFER.CREATION_DATE,
                        OFFER.AUTHOR
                 FROM USERS
                          JOIN DORMITORY ON USERS.DORMITORY = DORMITORY.ID
                          JOIN OFFER ON OFFER.AUTHOR = USERS.ID
                 WHERE DORMITORY.ID = DORMITORY_ID;
END;
$$;

alter function get_offers_in_dormitory(integer) owner to s265087;

