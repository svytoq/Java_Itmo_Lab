create function calc_army_power(army_id_param integer) returns integer
    language plpgsql
as
$$
Declare
    squads_power   int;
    machines_power int;
BEGIN
    if army_id_param in (select id
                         from army)
    then
        squads_power = (select sum(squad.unit_number * squad_type.power_of_guns)
                        from squad
                                 inner join squad_type on squad.squad_type = squad_type.id
                        where squad.army_id = army_id_param);
        machines_power = (select sum(machine.strength * machine_type.power_of_guns)
                          from machine
                                   inner join machine_type on machine.machine_type = machine_type.id
                          where machine.army_id = army_id_param);
        return machines_power + squads_power;
    
    end if;
end;
$$;

alter function calc_army_power(integer) owner to s265106;

