create function insert_planets_and_manufactures_and_ships() returns void
    language plpgsql
as
$$
declare
    ret_id_device integer;
    ret_id_ship integer;
begin
     ret_id_device := id from "Devices" where model_name ='OVEN-AI-MB210-101';
     FOR ret_id_ship IN SELECT * FROM "Spaceships"
         LOOP
             insert into "Spaceships_Devices"(id_spaceship, id_device, ip_address) VALUES (ret_id_ship, ret_id_device, random_ip());
         END LOOP;
     ret_id_device := id from "Devices" where model_name ='OVEN-AI-MB210-100';
     FOR ret_id_ship IN SELECT id FROM "Spaceships"
         LOOP
             insert into "Spaceships_Devices"(id_spaceship, id_device, ip_address) VALUES (ret_id_ship, ret_id_device, random_ip());
         END LOOP;
     ret_id_device := id from "Devices" where model_name ='raspberry pi 4';
     FOR ret_id_ship IN SELECT id FROM "Spaceships" where name='Пегас' or name='Вояджер' or name='Союз'
         LOOP
             insert into "Spaceships_Devices"(id_spaceship, id_device, ip_address) VALUES (ret_id_ship, ret_id_device, random_ip());
         END LOOP;
     ret_id_device := id from "Devices" where model_name ='raspberry pi 3А';
     FOR ret_id_ship IN SELECT id FROM "Spaceships" where name!='Пегас' and name!='Вояджер' and name!='Союз'
         LOOP
             insert into "Spaceships_Devices"(id_spaceship, id_device, ip_address) VALUES (ret_id_ship, ret_id_device, random_ip());
         END LOOP;

     ret_id_device := id from "Devices" where model_name ='Delta VFD-EL-0';
     FOR ret_id_ship IN SELECT id FROM "Spaceships" where name!='Восход' and name!='Шаттл' and name!='Восток'
         LOOP
             insert into "Spaceships_Devices"(id_spaceship, id_device, ip_address) VALUES (ret_id_ship, ret_id_device, random_ip());
         END LOOP;
     ret_id_device := id from "Devices" where model_name ='Prostar PR-6101';
     FOR ret_id_ship IN SELECT id FROM "Spaceships" where name='Восход' or name='Шаттл' or name='Гaй-дo'
         LOOP
             insert into "Spaceships_Devices"(id_spaceship, id_device, ip_address) VALUES (ret_id_ship, ret_id_device, random_ip());
         END LOOP;

end;
$$;

alter function insert_planets_and_manufactures_and_ships() owner to s264434;

