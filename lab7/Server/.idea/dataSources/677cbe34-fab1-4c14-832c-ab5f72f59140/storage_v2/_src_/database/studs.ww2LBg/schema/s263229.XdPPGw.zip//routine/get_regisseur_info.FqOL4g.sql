create function get_regisseur_info(regisseur_id integer)
    returns TABLE(worker_id integer, worker_name character varying, worker_second_name character varying, gender character varying, age integer, place_of_birth text, films_number integer, genres character varying[])
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY 
    SELECT r.WORKER_ID, w.NAME, w.SECOND_NAME, w.GENDER, w.AGE, w.PLACE_OF_BIRTH, r.FILMS_NUMBER, r.GENRES FROM regisseurs AS r 
    JOIN workers AS w USING(MAIN_WORKER_ID) WHERE r.WORKER_ID = regisseur_id;
END
$$;

alter function get_regisseur_info(integer) owner to s263229;

