create function change_economical(_company_id integer)
    returns TABLE(idd integer, n character varying, s character varying, m_c numeric, np numeric)
    language plpgsql
as
$$
DECLARE
    a DECIMAL := (SELECT SUM(random_changing)
                  FROM random_changing());
    b DECIMAL := (SELECT SUM(random_changing)
                  FROM random_changing());
    c DECIMAL := (SELECT SUM(random_changing)
                  FROM random_changing());
    d DECIMAL := (SELECT SUM(random_changing)
                  FROM random_changing());
BEGIN
    UPDATE companies cc
    SET (market_cap, net_profit_margin_pct_annual) = (mc * a, npmpa * c)
    FROM (SELECT id idd, market_cap mc, net_profit_margin_pct_annual npmpa
          FROM companies c
          WHERE (c.id = _company_id)
         ) AS prev_val
    WHERE cc.id = _company_id;

    RETURN QUERY (SELECT comp.id                           idd,
                         comp.name                         n,
                         comp.specialization               s,
                         comp.market_cap                   m_c,
                         comp.net_profit_margin_pct_annual np
                  FROM companies comp
                  WHERE comp.id = _company_id);
END;
$$;

alter function change_economical(integer) owner to s264475;

