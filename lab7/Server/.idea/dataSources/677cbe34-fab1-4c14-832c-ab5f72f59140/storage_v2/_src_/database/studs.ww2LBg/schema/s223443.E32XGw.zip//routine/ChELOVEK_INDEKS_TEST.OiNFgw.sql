create function "ЧЕЛОВЕК_ИНДЕКС_ТЕСТ"(i integer) returns void
    language plpgsql
as
$$
DECLARE
BEGIN
FOR k IN 1..i LOOP
INSERT INTO "ЧЕЛОВЕК" ("ФАМИЛИЯ", "ИМЯ", "ОТЧЕСТВО", "ДАТА_РОЖДЕНИЯ")
VALUES ((ARRAY['вася','петя ','гена'])[floor(random()*3)+1], random_string(random()::integer*10+4),
random_string(random()::integer*10+4), date(NOW() - '1 year'::INTERVAL * ROUND(RANDOM() * 100)));
k = k + 1;
END LOOP;
END;
$$;

alter function "ЧЕЛОВЕК_ИНДЕКС_ТЕСТ"(integer) owner to s223443;

