create function add_role(role_name character, school_id integer, st_sword integer, learnability integer, sil_sword integer) returns integer
    language plpgsql
as
$$
DECLARE
id INTEGER;
begin
 id = nextval('role_role_id_seq'); 
 if role_name = 'witcherJr' THEN
	INSERT INTO role(role_id, name, school_id, learnability) VALUES
	(id, role_name, school_id, learnability);
 RETURN id;
 end if;
	INSERT INTO role VALUES
	(id, role_name, school_id, st_sword, learnability, sil_sword);
	 RETURN id;
 end;
$$;

alter function add_role(char, integer, integer, integer, integer) owner to s268428;

