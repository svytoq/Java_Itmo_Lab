create function validate_user() returns trigger
    language plpgsql
as
$$
BEGIN
IF (length(NEW.Gamer_mail)) <5 
THEN
RAISE EXCEPTION ' Gamer_mail не соответствует формату';
END IF; RETURN NEW; END
$$;

alter function validate_user() owner to s243879;

