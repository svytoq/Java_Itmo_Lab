create function get_profession_by_id(integer) returns character varying
    language plpgsql
as
$$
begin
    return (select profession.name from profession where  profession.id = $1);
end;
$$;

alter function get_profession_by_id(integer) owner to s264484;

