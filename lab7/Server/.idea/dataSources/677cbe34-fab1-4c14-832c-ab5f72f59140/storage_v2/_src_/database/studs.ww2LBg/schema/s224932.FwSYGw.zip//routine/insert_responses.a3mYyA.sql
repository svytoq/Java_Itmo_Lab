create function insert_responses() returns void
    language plpgsql
as
$$
DECLARE
        film record;
        users record;
BEGIN
        FOR users IN (SELECT ид from Пользователи)
        LOOP
                FOR film IN (SELECT ид from Фильмы)
                LOOP
                        insert into Оценки(ид_фильма,ид_пользователя, значение, комментарий) 
        values(film.ид,users.ид, 5, random_string(5));
                END LOOP;
        END LOOP;
END;
$$;

alter function insert_responses() owner to s224932;

