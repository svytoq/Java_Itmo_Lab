create function check_if_device_is_not_damaged() returns trigger
    language plpgsql
as
$$
DECLARE
   device_id astronaut.fixing_device_id%type;
BEGIN
   IF (EXISTS(SELECT damaged FROM device where id=NEW.fixing_device_id AND damaged = False)) THEN
     RAISE EXCEPTION 'no, you can`t fix device because it`s not damaged';
   END IF;
   RETURN NEW;
END;
$$;

alter function check_if_device_is_not_damaged() owner to s270250;

