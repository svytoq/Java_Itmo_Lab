create function add_to_cults() returns trigger
    language plpgsql
as
$$
BEGIN
		IF NEW.ГЛАВА_КУЛЬТА IS NOT NULL THEN
		INSERT INTO КЛЮЧЕВЫЕ_ПЕРСОНАЖИ_КУЛЬТЫ(ИД_КЛЮЧЕВОГО_ПЕРСОНАЖА, ИД_КУЛЬТА)
			VALUES (NEW.ГЛАВА_КУЛЬТА, NEW.ИД);
		END IF;
		RETURN NEW;
	END;
$$;

alter function add_to_cults() owner to s243848;

