create function calculate_rating(serial_name text, season_num integer, seria_num integer) returns real
    language plpgsql
as
$$
declare
  seria_id integer;
  result   real;
begin
  select into seria_id "SeriaId"
  from 
      "Seria" s
         join "Season" C on s."SeasonId" = C."Id"
         join "Serial" C2 on C."SerialId" = C2."Id"
  where C2."Name" = serial_name
    and C."Number" = season_num
    and s."Number" = seria_num;
  with cr_avgs as (SELECT AVG("Value") as "Rate" from  "Seria" s inner join "UserRate" r on s."Id" = r."SeriaId" where s."Id" = seria_id)
  select into result "Rate"
  from cr_avgs;
  return result;
end;
$$;

alter function calculate_rating(text, integer, integer) owner to s264469;

