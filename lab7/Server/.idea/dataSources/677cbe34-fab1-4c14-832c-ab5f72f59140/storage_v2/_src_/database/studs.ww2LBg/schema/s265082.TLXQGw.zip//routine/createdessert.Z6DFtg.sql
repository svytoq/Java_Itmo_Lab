create function createdessert(name text, price double precision, calories double precision, weight double precision) returns text
    strict
    language plpgsql
as
$$
DECLARE
ret int;
BEGIN
	INSERT INTO товар(название, стоимость) VALUES(name, price) RETURNING id INTO ret;
	INSERT INTO десерт(id, id_товара, калории, вес) VALUES(ret, ret, calories, weight);
	RETURN 'Десерт добавлен, id - ' || ret;
END;
$$;

alter function createdessert(text, double precision, double precision, double precision) owner to s265082;

