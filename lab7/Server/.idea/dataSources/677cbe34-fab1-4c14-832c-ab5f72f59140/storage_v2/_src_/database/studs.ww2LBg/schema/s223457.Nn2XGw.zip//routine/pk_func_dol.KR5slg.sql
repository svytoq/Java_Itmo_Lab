create function pk_func_dol() returns trigger
    language plpgsql
as
$$
BEGIN
  new.ИД = nextval('pk_seq_dol');
  RETURN new;
END;
$$;

alter function pk_func_dol() owner to s223457;

