create function "СЕАНС_ТФ"() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW."ИД" IS NULL THEN
   NEW."ИД" = generate_UUID();
END IF;
IF (exists(SELECT FROM "СЕАНС" WHERE "СЕАНС"."ИД" = NEW."ИД")) THEN
RAISE 'Сеанс с указанным ид уже существует';
END IF;
IF NOT (exists(SELECT FROM "ПОСЕТИТЕЛЬ" WHERE "ПОСЕТИТЕЛЬ"."ИД_ПОСЕТИТЕЛЬ" = NEW."ИД_ПОСЕТИТЕЛЬ")) THEN
RAISE 'Посетителя с указаным ИД нет в базе.';
END IF;
IF NOT (exists(SELECT FROM "ВИД_ИГРЫ" WHERE "ВИД_ИГРЫ"."ИД_ВИДА_ИГРЫ" = NEW."ИД_ВИДА_ИГРЫ")) THEN
RAISE 'Персонала с указаным ИД нет в базе.';
END IF;
IF NEW."ВРЕМЯ_НАЧАЛА_СЕАНСА" > current_timestamp THEN
RAISE 'Время начала сеанса не может быть позже чем текущее время';
END IF;
IF NEW."СТОЛ_АВТОМАТ" < 0 THEN
RAISE 'Нет таких автоматов/столов';
END IF;
return NEW;
END;
$$;

alter function "СЕАНС_ТФ"() owner to s223443;

