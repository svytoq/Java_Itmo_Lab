create function check_a_h() returns trigger
    language plpgsql
as
$$
DECLARE
  id INTEGER;
  school INTEGER;
  sorcerer INTEGER;
BEGIN

  SELECT INTO id stream_id
  FROM stream
  WHERE h_h_id = NEW.h_h_id;
 
 SELECT INTO school school_id
 FROM stream
 WHERE stream_id = id;
 
 SELECT INTO sorcerer sorcerer_id
 FROM school_sorcerer
 WHERE school_id = school AND sorcerer_id = NEW. sorcerer_id;
 
  IF (sorcerer is NULL AND NEW.h_h_id IS NOT NULL)
  THEN
    RAISE EXCEPTION 'H_h connected to the school which this sorcerer does not belong to';
  END IF;
  
   RETURN NEW;
END;
$$;

alter function check_a_h() owner to s268428;

