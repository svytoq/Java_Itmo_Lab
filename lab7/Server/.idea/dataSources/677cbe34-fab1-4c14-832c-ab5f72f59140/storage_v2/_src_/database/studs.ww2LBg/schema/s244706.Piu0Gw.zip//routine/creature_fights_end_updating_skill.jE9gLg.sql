create function creature_fights_end_updating_skill(in_student_id bigint, in_mod_delta smallint) returns void
    language plpgsql
as
$$
begin
with fight as (
delete from creature_fights
where student_id = in_student_id
returning creature_id
)
insert into creature_handling_skills as chs (student_id, creature_id, modifier)
select in_student_id, fight.creature_id, in_mod_delta
from fight
on conflict (student_id, creature_id)
do update set modifier = least(100, chs.modifier + in_mod_delta);
end;
$$;

alter function creature_fights_end_updating_skill(bigint, smallint) owner to s244706;

