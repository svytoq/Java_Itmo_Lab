create function insert_developer_team(developer_id integer, team_id integer) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO developer_team (developer_id,
                team_id)

  VALUES (insert_developer_team.developer_id,
      insert_developer_team.team_id);
END;

$$;

alter function insert_developer_team(integer, integer) owner to s264458;

