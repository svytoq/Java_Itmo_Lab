create function add_abonent_and_contract(name character varying, surname character varying, patronymic character varying, birth date, passport character varying, place text, phone character varying, port_name integer, entrance_name integer, tariff_name text, cont_name character varying, beginning date, flat integer, balance integer, password text) returns void
    language plpgsql
as
$$
DECLARE
    PORT_ID     INTEGER;
    ENTRANCE_ID INTEGER;
    TARIFF_ID   INTEGER;
    ABONENT_ID  INTEGER;
BEGIN
    INSERT INTO s265109.abonent(name, surname, patronymic, birth, passport, place, phone)
    VALUES (NAME,
            SURNAME,
            PATRONYMIC,
            BIRTH,
            PASSPORT,
            PLACE,
            PHONE)
    returning id INTO ABONENT_ID;
    SELECT P.ID INTO PORT_ID FROM s265109.port AS P WHERE P.number = PORT_NAME;
    SELECT E.ID INTO ENTRANCE_ID FROM s265109.entrance AS E WHERE E.number = ENTRANCE_NAME;
    SELECT T.ID INTO TARIFF_ID FROM s265109.tariff AS T WHERE T.name = TARIFF_NAME;
    INSERT INTO s265109.contract(port_id, abonent_id, prev_id, entrance_id, tariff_id, number, beginning, flat, balance,
                                 password)
    VALUES (PORT_ID, ABONENT_ID, NULL, ENTRANCE_ID, TARIFF_ID, CONT_NAME, BEGINNING, FLAT, BALANCE, PASSWORD);
end;
$$;

alter function add_abonent_and_contract(varchar, varchar, varchar, date, varchar, text, varchar, integer, integer, text, varchar, date, integer, integer, text) owner to s265109;

