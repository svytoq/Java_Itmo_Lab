create function сгенерировать_группы_к_фильмам() returns void
    language plpgsql
as
$$
DECLARE
        film record;
        groups record;
BEGIN
        FOR groups IN (SELECT ид from Группы)
        LOOP
                FOR film IN (SELECT ид from Фильмы)
                LOOP
                    if (random() > 0.8) THEN
                        insert into Фильмы_Группы 
                                values(film.ид, groups.ид);
                    end if;
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_группы_к_фильмам() owner to s242395;

