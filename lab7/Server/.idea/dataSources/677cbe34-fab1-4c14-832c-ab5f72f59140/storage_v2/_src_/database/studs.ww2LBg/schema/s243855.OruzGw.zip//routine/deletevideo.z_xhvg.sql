create function deletevideo() returns trigger
    language plpgsql
as
$$
begin
 delete from УСТРОЙСТВА where  УСТРОЙСТВА.ИД_ВИДЕОКАРТЫ = ВИДЕОКАРТА.ИД;
 end;
$$;

alter function deletevideo() owner to s243855;

