create function star_stamp() returns trigger
    language plpgsql
as
$$
BEGIN
        IF NEW."Масса" > 10000000 THEN
            RAISE EXCEPTION 'massa cannot be biger than 10000000';
        END IF;
        RETURN NEW;
    END;
$$;

alter function star_stamp() owner to s247409;

