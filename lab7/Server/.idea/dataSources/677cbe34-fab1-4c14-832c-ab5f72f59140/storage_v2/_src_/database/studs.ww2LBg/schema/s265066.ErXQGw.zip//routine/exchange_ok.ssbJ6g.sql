create function exchange_ok(exc_id integer, msg_text text) returns void
    language plpgsql
as
$$
declare
    in_msg_id integer;
begin
    select create_in_message(msg_text) into in_msg_id;

    update Messages set msg_state='sent' where msg_id=(
        select out_msg from Msg_exchanges where msg_exc_id=exc_id);

    update Msg_exchanges set in_msg=in_msg_id, msg_ex_state='ok'
        where msg_exc_id=exc_id;
end;
$$;

alter function exchange_ok(integer, text) owner to s265066;

