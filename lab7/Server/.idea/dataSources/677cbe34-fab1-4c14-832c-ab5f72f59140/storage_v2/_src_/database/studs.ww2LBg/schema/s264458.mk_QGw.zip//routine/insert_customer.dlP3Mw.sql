create function insert_customer(id integer, user_id integer, level character varying, title character varying, wallet character varying) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO customer (id,
              user_id,
              level,
              title,
              wallet)

  VALUES (insert_customer.id,
      insert_customer.user_id,
      insert_customer.level,
      insert_customer.title,
      insert_customer.wallet);
END;

$$;

alter function insert_customer(integer, integer, varchar, varchar, varchar) owner to s264458;

