create function not_null_number_of_safety_system() returns trigger
    language plpgsql
as
$$
DECLARE
  num int;
BEGIN
  num= (select count(safety_system.sub_id) from safety_system where new.sub_id=safety_system.sub_id);
  IF (num=1) and ((new.number=0) or (new.number is null )) then
   raise exception 'Служба безопасности должна иметь телефонный номер, отличный от нуля';
  end if;

  RETURN new;
END;
$$;

alter function not_null_number_of_safety_system() owner to s244702;

