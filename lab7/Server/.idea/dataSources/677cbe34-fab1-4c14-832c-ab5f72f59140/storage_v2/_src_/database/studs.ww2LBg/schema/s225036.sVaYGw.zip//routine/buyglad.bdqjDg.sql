create function buyglad() returns trigger
    language plpgsql
as
$$
BEGIN 
IF(id_master IS NOT NULL) THEN
UPDATE Master SET Money = Money-200 where id_master=NEW.id_master;
RETURN NEW; 
ELSE
RETURN OLD;
END IF;
END;
$$;

alter function buyglad() owner to s225036;

