create function check_product_owner() returns trigger
    language plpgsql
as
$$
BEGIN
  IF NEW.ЕДА_ИД IS NULL
  THEN
    IF (SELECT count(1) FROM ЗАКАЗ WHERE ЗАКАЗ.ОТПРАВИТЕЛЬ_ИД = NEW.ОТПРАВИТЕЛЬ_ИД) = 0::bigint
    THEN
      RAISE EXCEPTION 'You can not write reply on this customer';
    END IF;
  ELSE
    IF (SELECT count(1) FROM ЗАКАЗ NATURAL JOIN КОРЗИНА NATURAL JOIN ЕДА WHERE NEW.ПОЛЬЗОВАТЕЛЬ_ИД = ЗАКАЗЧИК_ИД and NEW.ЕДА_ИД = ЕДА.ЕДА_ИД) = 0::bigint
    THEN
      RAISE EXCEPTION 'You can not write reply on this product';
    END IF;
END IF;
RETURN NEW;
END;
$$;

alter function check_product_owner() owner to s242456;

