create function sponsors_favorite(id_game integer, OUT "Фамилия" character varying, OUT "Имя" character varying, OUT "Дистрикт" smallint) returns SETOF record
    language sql
as
$$
select ФАМИЛИЯ, ИМЯ, ДИСТРИКТ FROM ПОЛЬЗОВАТЕЛИ
JOIN ТРИБУТЫ USING (ИД_ПОЛЬЗОВАТЕЛЯ)
JOIN (SELECT ИД_ТРИБУТА FROM ТРИБУТЫ
JOIN ПОДАРКИ_ТРИБУТА using (ИД_ТРИБУТА)
JOIN ПОДАРКИ USING (ИД_ПОДАРКА)
WHERE ИД_ИГРЫ=id_game
GROUP BY ИД_ТРИБУТА
 having sum(ПОДАРКИ.ЦЕНА)=(SELECT MAX(sum) from (SELECT ИД_ТРИБУТА,sum(ПОДАРКИ.ЦЕНА) FROM ТРИБУТЫ
JOIN ПОДАРКИ_ТРИБУТА using (ИД_ТРИБУТА)
JOIN ПОДАРКИ USING (ИД_ПОДАРКА)
WHERE ИД_ИГРЫ=id_game
GROUP BY ИД_ТРИБУТА) as presents)) as tribut_id USING(ИД_ТРИБУТА);
$$;

alter function sponsors_favorite(integer, out varchar, out varchar, out smallint) owner to s242361;

