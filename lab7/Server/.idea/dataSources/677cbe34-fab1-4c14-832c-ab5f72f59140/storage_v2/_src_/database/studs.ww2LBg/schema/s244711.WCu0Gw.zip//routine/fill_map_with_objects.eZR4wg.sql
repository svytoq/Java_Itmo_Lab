create function fill_map_with_objects(_map integer, amount integer) returns void
    language plpgsql
as
$$
DECLARE
	positions cursor for
		SELECT c.pos
		FROM cells c
		WHERE (c.is_passable = true)
			AND (c.map = _map)
			AND (SELECT (count(*) = 0) 
				FROM objects o
				WHERE (o.pos = c.pos)
					AND (o.map = _map))
		ORDER BY random()
		LIMIT amount;
	cur_pos text;
BEGIN
	FOR cur_pos IN positions LOOP
		INSERT INTO objects
			(map, pos)
		VALUES
			(_map, cur_pos.pos);
	END LOOP;
END;
$$;

alter function fill_map_with_objects(integer, integer) owner to s244711;

