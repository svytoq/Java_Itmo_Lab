create function order_plan() returns trigger
    language plpgsql
as
$$
DECLARE
 id_ingr integer;
 mass float;
 id_akv integer;
 finish boolean;
 end_date date;
 having_mass float;
 end_persent float;
 snum integer;
  BEGIN
FOR id_ingr, mass IN SELECT ИД_ИНГРЕДИЕНТА, МАССА FROM СОСТАВ WHERE ИД_ЛЕКАРСТВА = NEW.ИД_ЛЕКАРСТВА
LOOP
SELECT ИД_  INTO id_akv  FROM ИНГРЕДИЕНТ WHERE ИД_ИНГРЕДИЕНТА = id_ingr;
FOR having_mass IN SELECT МАССА  FROM НАЛИЧИЕ_ИНГРЕДИЕНТОВ WHERE (ИД_ИНГРЕДИЕНТА = id_ingr) AND (ГОДЕН_ДО > NOW())
LOOP
mass := mass - having_mass;
END LOOP; 

-- тут надо придумать что-то поумнее
 
IF (mass > 0) THEN
finish := FALSE;
end_date := NOW() + ROUND(mass/10);
ELSE finish := TRUE; end_date := NOW();
END IF;


INSERT INTO ПЛАН_МАРШРУТ VALUES (NEW.ИД_ЗАКАЗА, id_ingr, id_akv, end_date, finish);
END LOOP;
 
end_persent := (SELECT COUNT(ИД_ЗАКАЗА) FROM ПЛАН_МАРШРУТ WHERE (ИД_ЗАКАЗА = NEW.ИД_ЗАКАЗА) AND (СОБРАНО = TRUE)) / 
(SELECT COUNT(ИД_ЗАКАЗА) FROM ПЛАН_МАРШРУТ WHERE (ИД_ЗАКАЗА = NEW.ИД_ЗАКАЗА));
SELECT MAX(ДАТА_ЗАВЕРШЕНИЯ)  INTO end_date  FROM ПЛАН_МАРШРУТ WHERE ИД_ЗАКАЗА = NEW.ИД_ЗАКАЗА;
SELECT MAX(НОМЕР_В_ОЧЕРЕД) INTO snum FROM СТАТУС_ЗАКАЗА;
IF snum IS NULL THEN snum = 1;
END IF;
INSERT INTO СТАТУС_ЗАКАЗА VALUES (NEW.ИД_ЗАКАЗА, snum, end_persent, end_date);

    RETURN NEW;
  END;
$$;

alter function order_plan() owner to s243875;

