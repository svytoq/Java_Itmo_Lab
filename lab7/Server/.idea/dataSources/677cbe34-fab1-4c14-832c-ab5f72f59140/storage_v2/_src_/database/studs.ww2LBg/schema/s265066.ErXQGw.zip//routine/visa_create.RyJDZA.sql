create function visa_create(app_id integer) returns integer
    language plpgsql
as
$$
declare
    -- app_state visa_app_states;
    -- verd visa_verdicts;
    app Visa_applications;
    res int;
begin
    select * into app from Visa_applications where visa_app_id=app_id;
    if app.visa_app_state = 'ready'
    then
        insert into Visas(
            person_id, 
            start_date, 
            exp_date, 
            max_trans, 
            visa_application,

            visa_state,
            cur_trans)
        values (
            app.person_id, 
            app.start_date, 
            app.exp_date, 
            app.trans, 
            app.visa_app_id,

            'ready',
            0) returning visa_id into res;

        update Visa_applications set visa_app_state='done' where visa_app_id=app_id;
        return res;
    end if;
    raise exception 'application not ready';
end;
$$;

alter function visa_create(integer) owner to s265066;

