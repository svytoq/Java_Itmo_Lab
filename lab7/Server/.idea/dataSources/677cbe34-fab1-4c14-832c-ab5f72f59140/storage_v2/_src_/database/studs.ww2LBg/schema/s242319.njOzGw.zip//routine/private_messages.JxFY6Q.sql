create function private_messages("id_ОТПРАВИТЕЛЬ" integer, "id_ПОЛУЧАТЕЛЯ" integer)
    returns TABLE("СООБЩЕНИЯ" text)
    language sql
as
$$
SELECT СООБЩЕНИЕ FROM ЛИЧНЫЕ_СООБЩЕНИЯ WHERE ((ИД_ОТПРАВИТЕЛЬ = $1 AND ИД_ПОЛУЧАТЕЛЯ =$2) OR (ИД_ОТПРАВИТЕЛЬ = $2 AND ИД_ПОЛУЧАТЕЛЯ =$1));
$$;

alter function private_messages(integer, integer) owner to s242319;

