create function add_eqip() returns trigger
    language plpgsql
as
$$
BEGIN
  INSERT INTO ac_camos SELECT new.player_id,camo_id FROM camos WHERE (necessary_lvl<=new.lvl)  AND (camo_id NOT IN(SELECT camo_id FROM ac_camos WHERE player_id = new.player_id));

  INSERT INTO ac_specializations SELECT new.player_id,specialization_id FROM specializations WHERE necessary_lvl<=new.lvl AND specialization_id NOT IN(SELECT specialization_id FROM ac_specializations WHERE player_id=NEW.player_id);

  INSERT INTO ac_gadgets SELECT new.player_id,gadget_id FROM gadgets WHERE (((necessary_point<=NEW.assault_points)AND(class='Assault'))OR((necessary_point<=NEW.support_points)AND(class='Support'))OR((necessary_point<=NEW.engineer_points)AND(class='Engineer'))OR((necessary_point<=new.recon_points)AND(class='Recon')))and gadget_id NOT IN(SELECT gadget_id FROM ac_gadgets WHERE player_id=NEW.player_id);

  INSERT INTO weapon_kills SELECT new.player_id,weapon_id,0 FROM common_weapons WHERE lvl_for_unlock<=new.lvl and weapon_id NOT IN(SELECT weapon_id FROM weapon_kills WHERE player_id=NEW.player_id);

  INSERT INTO weapon_kills SELECT new.player_id,weapon_id,0 FROM class_weapons WHERE (((points_for_unlock<=NEW.assault_points)AND(class='Assault'))OR((points_for_unlock<=NEW.support_points)AND(class='Support'))OR((points_for_unlock<=NEW.engineer_points)AND(class='Engineer'))OR((points_for_unlock<=new.recon_points)AND(class='Recon'))) and weapon_id NOT IN(SELECT weapon_id FROM weapon_kills WHERE player_id=NEW.player_id);

  RETURN NEW;
END;
$$;

alter function add_eqip() owner to s225100;

