create function foo(a integer)
    returns TABLE(fights integer)
    language plpgsql
as
$$
BEGIN
  RETURN QUERY SELECT "Битва".id FROM "Битва" WHERE "Битва".id_победителя=a;
END;
$$;

alter function foo(integer) owner to s225133;

