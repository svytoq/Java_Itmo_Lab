create function сгенерировать_сеансы("число_сеансов_фильма" integer) returns void
    language plpgsql
as
$$
DECLARE
        film RECORD;
        room RECORD;
        film_time TIMESTAMP;
BEGIN
        FOR room IN (SELECT ид FROM Залы)
        LOOP
                FOR film IN (SELECT * FROM Фильмы)
                LOOP
                    FOR i IN 1 .. число_сеансов_фильма LOOP
                        film_time = (film.премьера + random_film_interval())::TIMESTAMP;
                        INSERT INTO Сеансы(ид_фильма, ид_зала, начало, конец)
                                VALUES(film.ид, room.ид,
                                        film_time, (film_time + ('2 hours')::INTERVAL)::TIMESTAMP);
                    END LOOP;
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_сеансы(integer) owner to s242395;

