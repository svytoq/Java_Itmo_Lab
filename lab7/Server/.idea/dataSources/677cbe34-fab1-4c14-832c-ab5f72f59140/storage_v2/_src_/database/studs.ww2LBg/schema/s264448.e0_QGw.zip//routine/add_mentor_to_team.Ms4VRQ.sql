create function add_mentor_to_team(mentor_id integer, championship_id integer, team_id integer) returns void
    language plpgsql
as
$$
BEGIN
    INSERT INTO mentor_team (person_id, championship_id, team_id)
    VALUES (add_mentor_to_team.mentor_id,
            add_mentor_to_team.championship_id,
            add_mentor_to_team.team_id);
END;
$$;

alter function add_mentor_to_team(integer, integer, integer) owner to s264448;

