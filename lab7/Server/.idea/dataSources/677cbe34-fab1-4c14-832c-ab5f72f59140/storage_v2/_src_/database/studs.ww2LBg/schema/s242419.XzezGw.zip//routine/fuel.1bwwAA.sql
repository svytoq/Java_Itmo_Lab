create function fuel() returns trigger
    language plpgsql
as
$$
BEGIN
IF (NEW.топливо in (select НАЗВАНИЕ from ТОПЛИВО)) = false
then RAISE exception 'Ошибка: такого типа топлива не существует';
else
RETURN NEW;
END IF;
END;
$$;

alter function fuel() owner to s242419;

