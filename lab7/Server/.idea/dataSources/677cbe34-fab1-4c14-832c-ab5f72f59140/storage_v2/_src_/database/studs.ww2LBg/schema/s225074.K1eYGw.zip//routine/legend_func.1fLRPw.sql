create function legend_func() returns trigger
    language plpgsql
as
$$
BEGIN 
new.legend_id:= NEXTVAL('legend_seq');
RETURN new;
END;
$$;

alter function legend_func() owner to s225074;

