create function make_compat() returns trigger
    language plpgsql
as
$$
declare
RFS feature_set%rowtype;
begin
select * into RFS from feature_set where feature_set.id = new.requested_feature_set_id;
create temp table duckFS(
duck_id int,
ID serial,
BIRTHDAY date,
GENDER gender,
COLOUR int[3],
SHADE text,
SHAPE text,
SIZE size,
WEIGHT real,
SWIMMING_SKILL int,
MODEL varchar(30),
PRODUCER varchar(30),
BEAK_ID int,
ACCESSABILITY boolean,
CHARACTER character,
STYLE varchar(20),
ACCESSORIES text);
insert into duckFS
select duck.id as duck_id, feature_set.*
from duck
join feature_set on (duck.feature_set_id = feature_set.id);
insert into compatibility
select duck_id, NEW.id
from duckfs
where ((duckfs.birthday = rfs.birthday)or(rfs.birthday isnull))and
((duckfs.gender = rfs.gender)or(rfs.gender isnull))and
((duckfs.colour = rfs.colour)or(rfs.colour isnull))and
((duckfs.size = rfs.size)or(rfs.size isnull))and
((duckfs.weight = rfs.weight)or(rfs.weight isnull))and
((duckfs.swimming_skill = rfs.swimming_skill)or(rfs.swimming_skill isnull))and
((duckfs.model = rfs.model)or(rfs.model isnull))and
((duckfs.producer = rfs.producer)or(rfs.producer isnull))and
((duckfs.beak_id = rfs.beak_id)or(rfs.beak_id isnull))and
((duckfs.character = rfs.character)or(rfs.character isnull))and
((duckfs.style = rfs.style)or(rfs.style isnull));
drop table duckFS;
return NEW;
end
$$;

alter function make_compat() owner to s243877;

