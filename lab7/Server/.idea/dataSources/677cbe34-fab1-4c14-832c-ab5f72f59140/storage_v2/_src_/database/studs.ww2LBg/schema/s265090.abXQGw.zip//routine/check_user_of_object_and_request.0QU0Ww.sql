create function check_user_of_object_and_request() returns trigger
    language plpgsql
as
$$
DECLARE
    USER_OBJ  INT := (SELECT user_id
                              FROM OBJECT
                              WHERE ID = NEW.OBJECT);
    USER_REQ INT := (SELECT AUTHOR
                        FROM request
                        WHERE ID = NEW.request);
BEGIN
    IF USER_OBJ != USER_REQ THEN
        RETURN NULL;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_user_of_object_and_request() owner to s265090;

