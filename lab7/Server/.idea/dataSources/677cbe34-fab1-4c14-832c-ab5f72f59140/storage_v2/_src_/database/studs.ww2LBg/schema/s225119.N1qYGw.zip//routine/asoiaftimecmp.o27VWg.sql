create function asoiaftimecmp(t1 text, t2 text) returns integer
    language plpgsql
as
$$
DECLARE
  t1_arr int[6]; t2_arr int[6];
  i int = 1;
  NULLFound bool = false;
  asoiafTmstmp1 bigint = 0; asoiafTmstmp2 bigint = 0;
  minCPart int;
BEGIN
  t1_arr = ASOIAFtimeToIntArray(t1);
  t2_arr = ASOIAFtimeToIntArray(t2);

  WHILE (NOT NULLFound) AND i <= 6 LOOP 
    IF t1_arr[i] IS NULL THEN
      NULLFound = true;
    END IF;
    i = i + 1;
  END LOOP;
  
  i = 1;
  WHILE (NOT NULLFound) AND i <= 6 LOOP 
    IF t2_arr[i] IS NULL THEN
      NULLFound = true;
    END IF;
    i = i + 1;
  END LOOP;

  IF NULLFound THEN -- if at least one of the time string is not specified
    IF t1_arr[7] > t2_arr[7] THEN -- means time1 is AC and time2 is BC
      RETURN 1;
    ELSE IF t1_arr[7] < t2_arr[7] THEN -- means time1 is BC and time is AC
      RETURN 2;
    END IF; END IF;

    minCPart = ASOIAFfindMaxComparablePartIndex(t1_arr, t2_arr);
    IF minCPart = 0 THEN
      RETURN -1; -- -1 means ambigues
    END IF;

    FOR i IN 1..minCPart LOOP
      asoiafTmstmp1 = asoiafTmstmp1 * 10^2 + t1_arr[i];
      asoiafTmstmp2 = asoiafTmstmp2 * 10^2 + t2_arr[i];
    END LOOP;

    asoiafTmstmp1 = asoiafTmstmp1 * t1_arr[7];
    asoiafTmstmp2 = asoiafTmstmp2 * t2_arr[7];

    IF asoiafTmstmp1 > asoiafTmstmp2 THEN
      RETURN 1;
    ELSE IF asoiafTmstmp1 = asoiafTmstmp2 THEN
      RETURN -1; -- ambigues
    ELSE
      RETURN 2;
    END IF; END IF;
  END IF;

  asoiafTmstmp1 = (t1_arr[1]*10^10 + t1_arr[2]*10^8 + t1_arr[3]*10^6 + t1_arr[4]*10^4 + t1_arr[5]*10^2 + t1_arr[6])*t1_arr[7];
  asoiafTmstmp2 = (t2_arr[1]*10^10 + t2_arr[2]*10^8 + t2_arr[3]*10^6 + t2_arr[4]*10^4 + t2_arr[5]*10^2 + t2_arr[6])*t2_arr[7];

  IF asoiafTmstmp1 > asoiafTmstmp2 THEN
    RETURN 1;
  ELSE IF asoiafTmstmp1 = asoiafTmstmp2 THEN
    RETURN 0; -- means equal
  ELSE
    RETURN 2;
  END IF;
  END IF;
END
$$;

alter function asoiaftimecmp(text, text) owner to s225119;

