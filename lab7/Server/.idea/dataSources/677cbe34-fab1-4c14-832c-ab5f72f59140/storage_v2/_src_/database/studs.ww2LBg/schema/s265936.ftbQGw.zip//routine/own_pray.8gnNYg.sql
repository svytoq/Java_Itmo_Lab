create function own_pray() returns trigger
    language plpgsql
as
$$
DECLARE
p_soul int;
soul_faith faith_class;
reading_faith faith_class;
BEGIN
    p_soul = (select soul_id from remorse where id = new.id);
    reading_faith = (select faith from holly_book join pray p on holly_book.name = p.holly_book
        join remorse r on p.id = r.pray_id where r.id = new.id);
    soul_faith = (select class from faith join human h on faith.name = h.faith_type join soul s on h.id = s.human_id
        join remorse r2 on s.id = r2.soul_id where r2.id = new.id);
    if reading_faith != soul_faith then
        raise exception 'Можно произносить молитвы только из книг своей веры';
    end if;
END;
$$;

alter function own_pray() owner to s265936;

