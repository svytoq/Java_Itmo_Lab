create function man_inv(table_name text, man_id integer)
    returns TABLE(id integer, name text, col integer)
    language sql
as
$$
SELECT Оружие.ИД, Оружие.Модель_ор, Амуниция.Количество  
FROM Оружие, Амуниция 
WHERE Амуниция.ИД_чел = man_id;
SELECT Патроны.ИД, Патроны.Модель_патрона, БЗ.Количество  
FROM Патроны, БЗ 
WHERE БЗ.ИД_чел = man_id;
SELECT Продукты.ИД, Продукты.Название_прод, Запас_прод.Количество  
FROM Продукты, Запас_прод 
WHERE Запас_прод.ИД_чел = man_id;
SELECT Медикаменты.ИД, Медикаменты.Название, Аптечка.Количество  
FROM Медикаменты, Аптечка 
WHERE Аптечка.ИД_чел = man_id;

$$;

alter function man_inv(text, integer) owner to s225039;

