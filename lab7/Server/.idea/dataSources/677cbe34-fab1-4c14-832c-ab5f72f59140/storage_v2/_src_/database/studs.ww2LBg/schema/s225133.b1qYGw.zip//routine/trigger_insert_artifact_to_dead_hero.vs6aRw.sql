create function trigger_insert_artifact_to_dead_hero() returns trigger
    language plpgsql
as
$$
BEGIN

    if (NEW.id_экипировки  NOT IN (SELECT id FROM "Экипировка" WHERE id_героя IN (SELECT id_проигравшего FROM "Битва"))) then
      return NEW;
      COMMIT;
    ELSE
      RAISE EXCEPTION 'Вы пытаетесь дать новый артефакт мёртвому герою!';
      return NULL;
    end if;
END;
$$;

alter function trigger_insert_artifact_to_dead_hero() owner to s225133;

