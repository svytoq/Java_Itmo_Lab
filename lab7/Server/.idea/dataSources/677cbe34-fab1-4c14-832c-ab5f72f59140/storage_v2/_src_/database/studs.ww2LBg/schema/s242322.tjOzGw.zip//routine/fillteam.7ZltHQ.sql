create function fillteam(mission integer) returns boolean
    language plpgsql
as
$$
DECLARE size integer;
BEGIN
        SELECT  РАЗМЕР_ОТРЯДА FROM ТРЕБОВАНИЯ_МИССИЙ as Т join МИССИИ AS М on М.ИД = mission AND М.ТИП = Т.ТИП_МИССИИ INTO size;
        insert into КОМАНДЫ SELECT mission, Ч.ИД, NULL, NULL from ЧЛЕНЫ_ПОЛИЦИИ as Ч join ОТДЕЛЫ AS О on Ч.ОТДЕЛ = О.ИД and (О.ИД=3 or О.ПОДЧИНЯЕТСЯ = 3) join ПСИХ_ПОРТРЕТ AS П ON Ч.ИД = П.АГЕНТ JOIN ТРЕБОВАНИЯ_МИССИЙ as Т On П.ХАРИЗМА > Т.ХАРИЗМА AND П.АГРЕССИВНОСТЬ > Т.АГРЕССИВНОСТЬ AND П.ПОСЛУШАНИЕ > Т.ПОСЛУШАНИЕ JOIN МИССИИ as М ON М.ТИП = Т.ТИП_МИССИИ AND Ч.УРОВЕНЬ_ДОПУСКА >= М.СЕКРЕТНОСТЬ AND М.ИД = mission ORDER BY RANDOM() LIMIT size;
RETURN TRUE;
END;
$$;

alter function fillteam(integer) owner to s242322;

