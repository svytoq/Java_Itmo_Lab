create function group_pipl(group_name text)
    returns TABLE("НОМЕР" integer, "ДЕЯТЕЛЬНОСТЬ1" s242461."деятель", "ФАМИЛИЯ1" text, "ПСЕВДОНИМ1" text, "ДОЛЖНОСТЬ1" text, "ГРУППИРОВКА1" text, "МОДЕЛЬ_КПК1" character, "СОДЕРЖИМОЕ_ТАЙНИКА1" text)
    language plpgsql
as
$$
BEGIN
    return query
      SELECT distinct( "ЛЮДИ1"."ИД_ЧЕЛ"),"ДЕЯТЕЛЬНОСТЬ" as "1","ФАМИЛИЯ" as "2","ПСЕВДОНИМ" as "3","ДОЛЖНОСТЬ" as ДОЛЖНОСТЬ1,"НАЗВАНИЕ","МОДЕЛЬ", "ТАЙНИКИ"."СОДЕРЖИМОЕ" from "ЛЮДИ1"
        left join  "ИСТОРИЯ_ГРУПП" on("ЛЮДИ1"."ИД_ЧЕЛ"="ИСТОРИЯ_ГРУПП"."ИД_ЧЕЛ")
        left join  "ГРУППИРОВКА"  on "ИСТОРИЯ_ГРУПП"."ИД_ГРУПП" = "ГРУППИРОВКА"."ИД_ГРУПП"
        left outer join "МУТ_ЛЮДИ"  on "ЛЮДИ1"."ИД_ЧЕЛ" = "ЛЮДИ1"."ИД_ЧЕЛ"
        left outer join "МУТАЦИИ"  on "МУТ_ЛЮДИ"."ИД_МУТАЦ" = "МУТАЦИИ"."ИД_МУТАЦ"
        left outer join "КПК"  on "ЛЮДИ1"."ИД_КПК" = "КПК"."ИД_КПК"
        left outer join "ТАЙНИКИ"  on "ЛЮДИ1"."КООРД_ТАЙНИК" = "ТАЙНИКИ"."КООРД_ТАЙНИК"
      where "НАЗВАНИЕ"=group_name order by "ФАМИЛИЯ";
  end;
$$;

alter function group_pipl(text) owner to s242461;

