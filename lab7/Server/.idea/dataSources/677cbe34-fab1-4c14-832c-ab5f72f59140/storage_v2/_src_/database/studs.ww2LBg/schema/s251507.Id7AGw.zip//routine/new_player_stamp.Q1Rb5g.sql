create function new_player_stamp() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.player_price < 400 THEN
    RAISE EXCEPTION 'enough money';
    END IF;

    IF NEW.player_price > 400 THEN
    RAISE EXCEPTION 'not enough money';
    END IF;
    END;
$$;

alter function new_player_stamp() owner to s251507;

