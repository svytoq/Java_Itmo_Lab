create function checkpregnancy() returns trigger
    language plpgsql
as
$$
DECLARE
    has_child bool = false;
BEGIN
    SELECT "Has_child"
    FROM "Family"
    where "Family"."Homeless_ID" = NEW."Homeless_ID"
    INTO has_child;
    IF NEW."child_age" = -9 * 20 and has_child THEN
        RAISE EXCEPTION 'зачем бомжу куча детей??';
    END IF;
    RETURN NEW;
END;
$$;

alter function checkpregnancy() owner to s264425;

