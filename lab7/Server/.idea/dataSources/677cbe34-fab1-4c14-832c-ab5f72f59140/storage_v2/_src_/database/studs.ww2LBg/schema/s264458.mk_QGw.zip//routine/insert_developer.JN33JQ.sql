create function insert_developer(id integer, user_id integer, level text, profession_title text, salary numeric) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO developer (id,
               user_id,
               level,
               profession_title,
               salary)

  VALUES (insert_developer.id,
      insert_developer.user_id,
      insert_developer.level,
      insert_developer.profession_title,
      insert_developer.salary);
END;

$$;

alter function insert_developer(integer, integer, text, text, numeric) owner to s264458;

