create function "АДАПТАЦИИ_ПРОИЗВЕДЕНИЯ"(name character varying)
    returns TABLE("ИД_АДАПТАЦИИ" smallint, "НАЗВАНИЕ" character varying, "ГОД" smallint, "ЖАНР" character varying, "АВТОР" smallint, "ИСХОДНОЕ_ПРОИЗВЕДЕНИЕ" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
"АДАПТАЦИИ"."ИД_АДАПТАЦИИ", "АДАПТАЦИИ"."НАЗВАНИЕ", "АДАПТАЦИИ"."ГОД", "АДАПТАЦИИ"."ЖАНР", "АДАПТАЦИИ"."АВТОР", "АДАПТАЦИИ"."ИСХОДНОЕ_ПРОИЗВЕДЕНИЕ"
FROM "АДАПТАЦИИ" WHERE "АДАПТАЦИИ"."ИСХОДНОЕ_ПРОИЗВЕДЕНИЕ" = name;
END;
$$;

alter function "АДАПТАЦИИ_ПРОИЗВЕДЕНИЯ"(varchar) owner to s225071;

