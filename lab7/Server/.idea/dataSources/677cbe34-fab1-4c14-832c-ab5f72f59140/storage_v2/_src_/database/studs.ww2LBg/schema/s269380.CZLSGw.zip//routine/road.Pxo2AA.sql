create function road() returns trigger
    language plpgsql
as
$$
BEGIN
        if NEW.Категория not between 1 and 10 then
            Raise exception 'Категория not between 1 .. 10';
        end if;
        if NEW.Состояние_покрытия not between 1 and 10 then
            Raise exception 'Состояние_покрытия not between 1 .. 10';
        end if;
        RETURN NEW;
    END;
$$;

alter function road() owner to s269380;

