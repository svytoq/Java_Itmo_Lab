create function "ВЫДАТЬ_МАТЕРИАЛ_УЧЕНИКУ"(id integer, name character varying, level_book smallint, OUT resultat text) returns text
    language plpgsql
as
$$
DECLARE
	material_id RECORD;
	stud_level smallint;
BEGIN
	IF (id is null) THEN
		RAISE NOTICE 'Не определен ученик';
		resultat:=NULL;
	ELSE
		IF (level_book is NULL) THEN
			RAISE NOTICE 'Не определен уровень учебных материалов';
			resultat:=NULL;
		END IF;
		IF (name IS NULL) THEN
			FOR material_id IN SELECT МАТ_УЧЕНИК_ИД FROM МАТЕРИАЛ_УЧЕНИКА WHERE (МАТЕРИАЛ_УЧЕНИКА.УРОВЕНЬ=level_book) LOOP
				INSERT INTO ДОСТУП_МАТ_УЧЕНИК(УЧЕНИК_ИД,МАТ_УЧЕНИК_ИД) VALUES (id,material_id.МАТ_УЧЕНИК_ИД);
			END LOOP;
		ELSE 
			FOR material_id IN SELECT МАТ_УЧЕНИК_ИД FROM МАТЕРИАЛ_УЧЕНИКА WHERE (МАТЕРИАЛ_УЧЕНИКА.УРОВЕНЬ=level_book and МАТЕРИАЛ_УЧЕНИКА.НАЗВАНИЕ=name) LOOP
				INSERT INTO ДОСТУП_МАТ_УЧЕНИК(УЧЕНИК_ИД,МАТ_УЧЕНИК_ИД) VALUES (id,material_id.МАТ_УЧЕНИК_ИД);
			END LOOP;
		END IF;
		resultat:='Материалы ученику выданы';
	END IF;
EXCEPTION
	WHEN unique_violation THEN
		RAISE NOTICE 'Материал % уровня % не был выдан ученику с id %',name,level_book,id;
END;
$$;

alter function "ВЫДАТЬ_МАТЕРИАЛ_УЧЕНИКУ"(integer, varchar, smallint, out text) owner to s265057;

