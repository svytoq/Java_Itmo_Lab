create function getmedicineconsist(id integer)
    returns TABLE("ИД_ИНГРЕДИЕНТА" integer, "НАЗВАНИЕ" text, "СТОИМОСТЬ" integer, "МАССА" double precision)
    language sql
as
$$
select ИНГРЕДИЕНТ.ИД_ИНГРЕДИЕНТА,
        ИНГРЕДИЕНТ.НАЗВАНИЕ,
        ИНГРЕДИЕНТ.СТОИМОСТЬ,
        СОСТАВ.МАССА
    from СОСТАВ
        join ЛЕКАРСТВО using(ИД_ЛЕКАРСТВА)
        join ИНГРЕДИЕНТ using(ИД_ИНГРЕДИЕНТА)
    where ЛЕКАРСТВО.ИД_ЛЕКАРСТВА = id;
$$;

alter function getmedicineconsist(integer) owner to s242425;

