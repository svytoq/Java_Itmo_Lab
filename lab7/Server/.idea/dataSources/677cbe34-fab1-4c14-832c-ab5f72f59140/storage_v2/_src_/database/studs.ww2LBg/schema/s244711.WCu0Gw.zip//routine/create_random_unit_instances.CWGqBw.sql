create function create_random_unit_instances(amount integer) returns void
    language plpgsql
as
$$
DECLARE
	types_amount int;
BEGIN
	types_amount = 
		(SELECT MAX(id)
		FROM creature_types);

	FOR i IN 1 .. amount LOOP
		INSERT INTO unit_instances
			(type, amount)
			VALUES
			((SELECT round(random() * (types_amount - 1)) + 1), 
			(SELECT round(random() * 100) + 1));
	END LOOP;
END;
$$;

alter function create_random_unit_instances(integer) owner to s244711;

