create function create_stream(school integer, h_h integer, beginning date, ending date) returns integer
    language plpgsql
as
$$
DECLARE
headmaster integer;
id INTEGER;
begin
 id = nextval('stream_stream_id_seq'); 
 INSERT INTO stream VALUES
 (id, school, h_h, beginning, ending);
 
 SELECT INTO headmaster headmaster_id FROM school where school_id = school;
 
 UPDATE witcher SET stream_id = id where witcher_id = headmaster;
 RETURN 0;
 end
$$;

alter function create_stream(integer, integer, date, date) owner to s268428;

