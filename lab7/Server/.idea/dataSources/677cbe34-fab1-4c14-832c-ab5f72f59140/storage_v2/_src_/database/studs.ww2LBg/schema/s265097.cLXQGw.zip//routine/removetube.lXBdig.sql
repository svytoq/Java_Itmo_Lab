create function removetube(tubeid integer) returns integer
    language plpgsql
as
$$
declare 
begin
DELETE FROM "Tube" Where "Id" = tubeId;
return 1;
end;
$$;

alter function removetube(integer) owner to s265097;

