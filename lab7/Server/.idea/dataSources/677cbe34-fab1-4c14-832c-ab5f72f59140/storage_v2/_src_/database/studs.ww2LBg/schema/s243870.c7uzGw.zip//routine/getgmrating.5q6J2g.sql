create function getgmrating(integer) returns real
    language plpgsql
as
$$
DECLARE
res real;
BEGIN
select AVG(Оценка_ГМа) from К_Сессии where Партия_ИД IN (select Id from К_Партии where ГМ_ИД = $1) into res;
if(res is null) then
res:= 0;
end IF;
RETURN (res);
END;
$$;

alter function getgmrating(integer) owner to s243870;

