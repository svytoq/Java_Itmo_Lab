create function check_squad_application(army_id integer, squad_type integer) returns boolean
    language sql
as
$$
SELECT (t1.army_type=t2.application_area) FROM army as t1, squad_type as t2 WHERE t1.ID = army_id and t2.ID = squad_type;
$$;

alter function check_squad_application(integer, integer) owner to s265106;

