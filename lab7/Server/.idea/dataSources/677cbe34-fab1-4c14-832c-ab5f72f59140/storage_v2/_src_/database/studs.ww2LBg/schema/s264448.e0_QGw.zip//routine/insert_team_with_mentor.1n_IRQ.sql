create function insert_team_with_mentor(name text, participants integer[], mentors integer[], leader_id integer, championship_id integer) returns integer
    language plpgsql
as
$$
DECLARE
    cur_mentor  integer;
    team_number integer;
BEGIN
    SELECT insert_team(name, participants, leader_id, championship_id) INTO team_number;

    FOREACH cur_mentor IN ARRAY mentors
        LOOP
            PERFORM add_mentor_to_team(cur_mentor, championship_id, team_number);
        END LOOP;

    RETURN team_number;
END;
$$;

alter function insert_team_with_mentor(text, integer[], integer[], integer, integer) owner to s264448;

