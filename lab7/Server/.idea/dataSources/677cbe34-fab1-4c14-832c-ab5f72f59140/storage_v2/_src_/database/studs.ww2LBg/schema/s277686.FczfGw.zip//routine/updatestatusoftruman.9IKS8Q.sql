create function updatestatusoftruman() returns character varying
    language plpgsql
as
$$
BEGIN
IF shouldTrumanStartEscaping() THEN
Update truman_status SET activity = 'Escaping' WHERE id=2;
RETURN 'Status Of Truman Updated';
ELSE UPDATE Truman_status SET activity = 'Escaping stopped'WHERE id=2;
END IF;
RETURN 'Status Of Truman Updated';
END;
$$;

alter function updatestatusoftruman() owner to s277686;

