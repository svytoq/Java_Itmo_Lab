create function create_hike(vtype_id bigint, vcategory bigint, vcom_ncom text, vmonth text, vnumber_people bigint, vnumber_days bigint, vcost_rub bigint) returns bigint
    language plpgsql
as
$$
DECLARE
  ret bigint;
BEGIN
  INSERT INTO hikes(type_id, category,
                    com_ncom, month, number_people,
                    number_days, cost_rub)
  VALUES (vtype_id, vcategory, vcom_ncom, vmonth, vnumber_people, vnumber_days, vcost_rub) returning hike_id into ret;
  return ret;
END;
$$;

alter function create_hike(bigint, bigint, text, text, bigint, bigint, bigint) owner to s265067;

