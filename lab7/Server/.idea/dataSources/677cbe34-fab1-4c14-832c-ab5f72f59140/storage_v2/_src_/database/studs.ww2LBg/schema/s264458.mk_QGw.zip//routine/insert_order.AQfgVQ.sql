create function insert_order(id integer, customer_id integer, company_id integer, project_id integer, description text, time_start timestamp without time zone, deadline timestamp without time zone, cost numeric) returns void
    language plpgsql
as
$$
BEGIN
  INSERT INTO orders (id,
            customer_id,
            company_id,
            project_id,
            description,
              time_start,
            deadline,
            cost)

  VALUES (insert_order.id,
      insert_order.customer_id,
      insert_order.company_id,
      insert_order.project_id,
      insert_order.description,
      insert_order.time_start,
      insert_order.deadline,
      insert_order.cost);
END;

$$;

alter function insert_order(integer, integer, integer, integer, text, timestamp, timestamp, numeric) owner to s264458;

