create function validate_stih() returns trigger
    language plpgsql
as
$$
BEGIN
IF length(NEW.Особенность)< 3 AND length(NEW.Особенность)> 0
OR  length(NEW.ТИП)<3
THEN
RAISE EXCEPTION 'Описание Стихии неверно';
END IF;
RETURN NEW;
END
$$;

alter function validate_stih() owner to s242467;

