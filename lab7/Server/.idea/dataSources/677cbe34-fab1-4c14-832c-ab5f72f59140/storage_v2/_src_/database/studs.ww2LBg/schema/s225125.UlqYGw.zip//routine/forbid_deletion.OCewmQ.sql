create function forbid_deletion() returns trigger
    language plpgsql
as
$$
BEGIN
  RAISE EXCEPTION 'Нельзя удалять строки из таблицу %', TG_TABLE_NAME;
END
$$;

alter function forbid_deletion() owner to s225125;

