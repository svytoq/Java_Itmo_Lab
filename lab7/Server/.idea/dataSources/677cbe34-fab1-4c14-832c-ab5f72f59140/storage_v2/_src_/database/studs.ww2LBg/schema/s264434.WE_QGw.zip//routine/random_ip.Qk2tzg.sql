create function random_ip()
    returns TABLE(ip inet)
    language plpgsql
as
$$
begin
    return query select CONCAT(
            TRUNC(RANDOM() * 250 + 2), '.' ,
            TRUNC(RANDOM() * 250 + 2), '.',
            TRUNC(RANDOM() * 250 + 2), '.',
            TRUNC(RANDOM() * 250 + 2)
        )::INET;
end;
$$;

alter function random_ip() owner to s264434;

