create function unitsid() returns trigger
    language plpgsql
as
$$
BEGIN
IF currval('units_id_seq')!=NEW.ID THEN
NEW.ID=nextval('units_id_seq');
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function unitsid() owner to s225102;

