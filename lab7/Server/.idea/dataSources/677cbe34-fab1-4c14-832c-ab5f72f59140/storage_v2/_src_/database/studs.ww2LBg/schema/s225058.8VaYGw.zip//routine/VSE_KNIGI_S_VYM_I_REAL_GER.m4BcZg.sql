create function "ВСЕ_КНИГИ_С_ВЫМ_И_РЕАЛ_ГЕР"(firstname character varying, secondname character varying)
    returns TABLE("НАЗВАНИЕ" character varying, "СТРАНА" character varying, "ДАТА_ПУБЛИКАЦИИ" date, "ЖАНР" character varying)
    language plpgsql
as
$$
BEGIN 
RETURN QUERY SELECT КНИГИ.НАЗВАНИЕ,КНИГИ.СТРАНА,КНИГИ.ДАТА_ПУБЛИКАЦИИ,КНИГИ.ЖАНР 
FROM ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ JOIN КНИГА_И_ВЫМ_И_РЕАЛЬНЫЕ_Л ON ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ИД=ИД_Р_Ч
JOIN КНИГИ ON КНИГИ.ИД=ИД_КНИГИ WHERE (ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ИМЯ = firstname and ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ФАМИЛИЯ = secondname) or (ВЫМ_И_РЕАЛ_ЛЮДИ_УПОМ_В_КНИГ.ФАМИЛИЯ is NULL and secondname IS NULL); 
END;
$$;

alter function "ВСЕ_КНИГИ_С_ВЫМ_И_РЕАЛ_ГЕР"(varchar, varchar) owner to s225058;

