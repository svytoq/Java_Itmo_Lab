create function система2() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.название IN (select название from система) THEN
UPDATE система SET название = NEW.название, местонахождение = NEW.местонахождение, ID_фракции=NEW.ID_фракции WHERE название = NEW.название;
RETURN null;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function система2() owner to s242552;

