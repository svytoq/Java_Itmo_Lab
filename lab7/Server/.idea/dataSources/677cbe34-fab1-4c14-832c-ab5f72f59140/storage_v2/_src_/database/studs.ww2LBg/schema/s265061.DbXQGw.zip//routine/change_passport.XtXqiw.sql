create function change_passport(old_p character varying, new_p character varying) returns void
    language plpgsql
as
$$
begin
update passenger set passport_no=new_p where passport_no=old_p;
end;
$$;

alter function change_passport(varchar, varchar) owner to s265061;

