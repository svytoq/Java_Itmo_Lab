create function feed_peasant(integer) returns void
    language plpgsql
as
$$
DECLARE
    family_money integer;
    family_id integer;
    peasant_cost integer;    
BEGIN

SELECT Peasant.family INTO family_id FROM Peasant WHERE id = $1;
SELECT FamilyInventoryList.amount INTO family_money FROM FamilyInventoryList WHERE F_ID = family_id  AND I_ID = 1;
SELECT Peasant.cost INTO peasant_cost FROM Peasant WHERE id = $1;

IF family_money >= peasant_cost THEN
family_money := family_money - peasant_cost;
UPDATE FamilyInventoryList SET amount = family_money WHERE F_ID = family_id  AND I_ID = 1;
    RAISE NOTICE 'Pokormili';
ELSE
PERFORM Kill($1);
    RAISE NOTICE 'umer ot goloda';
END IF;
END
$$;

alter function feed_peasant(integer) owner to s265104;

