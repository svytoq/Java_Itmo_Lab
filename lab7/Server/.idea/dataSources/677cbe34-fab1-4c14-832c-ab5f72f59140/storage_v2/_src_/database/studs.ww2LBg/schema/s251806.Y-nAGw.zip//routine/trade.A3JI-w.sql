create function trade(trader integer, _item_id integer) returns void
    language plpgsql
as
$$
BEGIN
    IF _item_id IN (SELECT inventory.item_id FROM inventory WHERE character_id = 0) THEN
        UPDATE inventory
        SET quantity = quantity + 1
        WHERE character_id = 0
          AND inventory.item_id = _item_id;
        RETURN;
    END IF;
    INSERT INTO inventory(character_id, item_id, quantity, equipment_id, gold)
    VALUES (0, _item_id, 1, 0, gold - (SELECT cost FROM item WHERE item_id = _item_id));
    UPDATE inventory SET quantity = quantity - 1 WHERE character_id = trader AND inventory.item_id = _item_id;
END;
$$;

alter function trade(integer, integer) owner to s251806;

