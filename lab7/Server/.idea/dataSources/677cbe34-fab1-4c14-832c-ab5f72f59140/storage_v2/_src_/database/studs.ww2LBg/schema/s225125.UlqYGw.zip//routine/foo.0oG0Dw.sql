create function foo(t text) returns boolean
    language plpgsql
as
$$
DECLARE
  y int; m int; d int; h int; min int; sec int; modifier smallint; tmsmpt bigint;
BEGIN
  IF t !~ '[0-1][0-9]{4}/[0-1][0-9]/[0-3][0-9]\s[0-2][0-9]:[0-5][0-9]:[0-5][0-9]\s(BC|AC)' THEN
    RETURN FALSE;
  END IF;
  modifier = 1;
  IF substring(t from 22 for 2) = 'BC' THEN
    modifier = -1;
  END IF;
  y = modifier*substring(t from 1 for 5)::int;
  m = substring(t from 7 for 2)::int;
  d = substring(t from 10 for 2)::int;
  h = substring(t from 13 for 2)::int;
  min = substring(t from 16 for 2)::int;
  sec = substring(t from 19 for 2)::int;

  IF y NOT BETWEEN -1999 AND 999 OR
     m NOT BETWEEN 1 AND 12 OR
     d NOT BETWEEN 1 AND 30 OR
     h NOT BETWEEN 0 AND 23 OR
     min NOT BETWEEN 0 AND 59 OR
     sec NOT BETWEEN 0 AND 59 THEN
       RETURN FALSE;
  END IF;
  raise info '%, %, %, %, %, %,', y, m, d, h, min, sec;
END
$$;

alter function foo(text) owner to s225125;

