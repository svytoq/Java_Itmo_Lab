create function базы() returns trigger
    language plpgsql
as
$$
BEGIN
IF NEW.название_системы not IN (select название from система) THEN
insert into система values(NEW.название_системы, null, -1);
END IF;
IF NEW.раса NOT IN (SELECT название FROM раса) THEN
INSERT INTO раса VALUES(NEW.раса, null, null);
END IF;
return NEW;
END;
$$;

alter function базы() owner to s242552;

