create function user_team_change(id_team integer, new_name character varying) returns void
    language plpgsql
as
$$
BEGIN

  IF NOT EXISTS(SELECT * FROM team WHERE id = user_team_change.id_team) THEN
    RAISE EXCEPTION 'Cannot find team for update';
  ELSE
    UPDATE team
    SET team.title = user_team_change.new_name
    WHERE team.id = user_team_change.id_team;
  END IF;

END;

$$;

alter function user_team_change(integer, varchar) owner to s264458;

