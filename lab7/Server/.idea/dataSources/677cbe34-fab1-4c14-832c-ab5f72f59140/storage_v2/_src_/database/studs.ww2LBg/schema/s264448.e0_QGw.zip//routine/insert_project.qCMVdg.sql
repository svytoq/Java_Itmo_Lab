create function insert_project(name text, team_id integer, cases integer[], description text) returns integer
    language plpgsql
as
$$
DECLARE
    cur_case       integer;
    project_number integer;

BEGIN
    INSERT INTO project (name, team_id, description) VALUES (insert_project.name,
                                                             insert_project.team_id,
                                                             insert_project.description);
    SELECT CURRVAL('project_project_id_seq') INTO project_number;

    FOREACH cur_case IN ARRAY cases
        LOOP
            PERFORM add_case_to_project(project_number, cur_case);
        END LOOP;

    RETURN project_number;
END;
$$;

alter function insert_project(text, integer, integer[], text) owner to s264448;

