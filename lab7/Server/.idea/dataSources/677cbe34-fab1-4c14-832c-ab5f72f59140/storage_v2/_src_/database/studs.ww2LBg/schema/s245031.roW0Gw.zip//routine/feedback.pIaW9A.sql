create function feedback() returns trigger
    language plpgsql
as
$$
begin
    NEW.заказчик := (select заказчик from "Заказы" where id = NEW.заказ);
    NEW."Время" := (select "Время" from "Заказы" where id = NEW.заказ);
    NEW."Срок" :=(select "Срок" from "Заказы" where id = NEW.заказ);
    return new;
    end;
$$;

alter function feedback() owner to s245031;

