create function get_user_objects(author integer)
    returns TABLE(id integer, name character varying, description character varying, image bytea, object_state s265087."OBJECT_STATE", user_id integer)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT *
                 FROM object
                 WHERE user_id = AUTHOR;
END;
$$;

alter function get_user_objects(integer) owner to s265087;

