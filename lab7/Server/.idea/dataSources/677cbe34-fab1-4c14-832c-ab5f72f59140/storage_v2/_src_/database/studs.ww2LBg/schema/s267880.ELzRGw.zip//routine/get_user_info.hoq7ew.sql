create function get_user_info(user_id integer) returns SETOF s267880.user_profile
    language sql
as
$$
select * from user_profile where user_profile_id = user_id;
$$;

alter function get_user_info(integer) owner to s267880;

