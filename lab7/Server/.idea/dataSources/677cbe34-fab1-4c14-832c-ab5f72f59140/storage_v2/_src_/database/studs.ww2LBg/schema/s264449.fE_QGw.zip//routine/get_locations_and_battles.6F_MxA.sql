create function get_locations_and_battles()
    returns TABLE(location_id integer, location_name character varying, battle_name character varying, battle_id integer)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT l.LOCATION_ID, l.LOCATION_NAME, b.BATTLE_NAME, b.BATTLE_ID FROM locations AS l 
    JOIN battle_location USING(LOCATION_ID) JOIN battle AS b USING(BATTLE_ID);
END
$$;

alter function get_locations_and_battles() owner to s264449;

