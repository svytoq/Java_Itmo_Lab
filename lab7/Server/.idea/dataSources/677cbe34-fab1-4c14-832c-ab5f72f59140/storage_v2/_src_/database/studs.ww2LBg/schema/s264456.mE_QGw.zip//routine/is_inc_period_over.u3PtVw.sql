create function is_inc_period_over() returns trigger
    language plpgsql
as
$$
BEGIN
IF (SELECT incubation_period FROM virus 
WHERE NOW.virus_id = virus.virus_id) <
(NOW.date_of_infection -(SELECT  date_of_infection FROM illness
WHERE NOW.INN_carrier = illness.INN_injured AND
inness.virus_id = NOW.virus_id)) THEN
RAISE EXCEPTION 'infection could not occur, the virus is not yet active';
END IF;
END;
$$;

alter function is_inc_period_over() owner to s264456;

