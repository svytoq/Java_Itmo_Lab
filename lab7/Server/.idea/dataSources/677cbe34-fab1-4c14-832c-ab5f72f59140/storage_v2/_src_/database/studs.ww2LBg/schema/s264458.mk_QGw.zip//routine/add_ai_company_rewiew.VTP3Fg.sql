create function add_ai_company_rewiew(id integer, previous_data integer, review_id integer, company_id integer) returns void
    language plpgsql
as
$$
DECLARE
  accuracy DOUBLE PRECISION;
  precision_value DOUBLE PRECISION;
  recall DOUBLE PRECISION;
  f1 DOUBLE PRECISION;
  prediction text;


BEGIN

  accuracy = random();
  precision_value = random();
  recall = random();
  f1 = random();

  IF accuracy > 0.3 AND precision_value > 0.3 AND recall > 0.3 AND f1 > 0.3 THEN
    prediction = 'Good work';
  ELSE
    prediction = 'Bad work';
  END IF;

  PERFORM insert_ai_company_review(
          id,
          previous_data,
          review_id,
          company_id,
          accuracy,
          precision_value,
          recall,
          f1,
          prediction);

END;

$$;

alter function add_ai_company_rewiew(integer, integer, integer, integer) owner to s264458;

