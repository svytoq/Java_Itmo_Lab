create function con_leg() returns trigger
    language plpgsql
as
$$
BEGIN

INSERT INTO Country_Legend(id, country_id, legend_id)
 VALUES(nextval('con_leg_seq'), new.country_id, new.id);

RETURN new;

END;

$$;

alter function con_leg() owner to s225074;

