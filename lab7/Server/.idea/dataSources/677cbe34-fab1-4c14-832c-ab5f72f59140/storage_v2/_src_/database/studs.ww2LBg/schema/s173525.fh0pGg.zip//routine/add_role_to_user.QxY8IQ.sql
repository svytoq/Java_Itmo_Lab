create function add_role_to_user() returns trigger
    language plpgsql
as
$$
DECLARE
	result real;
BEGIN 
	SELECT user_id,role_id,end_date INTO result FROM user_roles WHERE user_id=NEW.user_id AND role_id=NEW.role_id AND end_date IS NULL;
	IF NOT FOUND THEN 
		RETURN NEW;
	ELSE
		RAISE EXCEPTION 'Пользователю уже присвоенна данная роль.';
	END IF;
END;
$$;

alter function add_role_to_user() owner to s173525;

