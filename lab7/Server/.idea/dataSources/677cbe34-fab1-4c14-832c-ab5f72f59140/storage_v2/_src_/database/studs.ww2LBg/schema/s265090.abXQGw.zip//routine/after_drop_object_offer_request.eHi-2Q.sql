create function after_drop_object_offer_request() returns trigger
    language plpgsql
as
$$
DECLARE
    REQUEST INTEGER := (SELECT REQUEST
                        FROM OFFER
                        WHERE ID = OLD.REQUEST);
BEGIN
    DELETE FROM OFFER WHERE ID = REQUEST;
    RETURN NULL;
END;
$$;

alter function after_drop_object_offer_request() owner to s265090;

