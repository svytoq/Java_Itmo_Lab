create function afterupdate(tubeid integer) returns integer
    language plpgsql
as
$$
declare 
begin
UPDATE "Tube" set "PotionId" = potionId Where "Id" = tubeId;
end;
$$;

alter function afterupdate(integer) owner to s265097;

