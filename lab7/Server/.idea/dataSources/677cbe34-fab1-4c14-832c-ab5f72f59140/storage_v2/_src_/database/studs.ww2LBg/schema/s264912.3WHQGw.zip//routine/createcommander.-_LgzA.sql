create function createcommander(charactername text, csobrequet text, cnum integer, cmind integer) returns text
    language plpgsql
as
$$
declare
    id_ch int;
begin
    insert into character(name) values (characterName) returning id_character into id_ch;
    insert into commander(id_commander, sobriquet, mind_level, number_of_conquests) values (id_ch, cSobrequet, cMind, cNum);
    return 'Командир создан! id - ' || id_ch;
end;
$$;

alter function createcommander(text, text, integer, integer) owner to s264912;

