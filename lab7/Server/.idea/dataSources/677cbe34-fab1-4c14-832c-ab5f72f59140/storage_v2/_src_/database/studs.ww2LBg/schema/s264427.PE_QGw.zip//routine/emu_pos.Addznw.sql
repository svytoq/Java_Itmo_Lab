create function emu_pos()
    returns TABLE(emu_group_id integer, quantity_group integer, square_with_emu integer)
    language plpgsql
as
$$
DECLARE
emu_group_size integer = 0;
size_group integer;
now_square integer;
counter integer = 0;
BEGIN
SELECT count(*) INTO STRICT emu_group_size FROM emu_group;
while counter < emu_group_size
LOOP
counter := counter + 1;
emu_group_id = counter;
SELECT quantity INTO STRICT size_group FROM emu_group where group_id = counter;
quantity_group = size_group;
SELECT square_number INTO STRICT now_square FROM Migration_Data where Migration_Data.emu_group_id = counter ORDER BY migration_data_id DESC LIMIT 1;
square_with_emu = now_square;
RETURN next;
END LOOP;
END;
$$;

alter function emu_pos() owner to s264427;

