create function сгенерировать_места("число_мест" integer) returns void
    language plpgsql
as
$$
DECLARE
        cinema_room RECORD;
        row_c integer;
BEGIN
        FOR cinema_room IN (SELECT ид FROM Залы)
        LOOP
                row_c = 1;
            FOR i IN 1..число_мест LOOP
                INSERT INTO Места (ид_зала, ряд, место, стоимость)
                VALUES (cinema_room.ид, row_c, i % 10 + 1, random() * 100 + 100);
                IF i % 10 = 0 THEN
                        row_c = row_c + 1;
                END IF;
            END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_места(integer) owner to s242395;

