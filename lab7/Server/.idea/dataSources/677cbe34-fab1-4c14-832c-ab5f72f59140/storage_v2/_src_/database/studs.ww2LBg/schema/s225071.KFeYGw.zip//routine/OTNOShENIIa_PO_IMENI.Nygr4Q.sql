create function "ОТНОШЕНИЯ_ПО_ИМЕНИ"(name character varying, surname character varying, patr character varying)
    returns TABLE("ИМЯ" character varying, "ФАМИЛИЯ" character varying, "ОТЧЕСТВО" character varying, "ИД_ЧЕЛОВЕК" smallint, "НАЧАЛО" date, "КОНЕЦ" date, "ХАРАКТЕРИСТИКА" character varying)
    language plpgsql
as
$$
BEGIN
RETURN QUERY SELECT
name ИМЯ, surname ФАМИЛИЯ, patr ОТЧЕСТВО, ОТНОШЕНИЯ.ИД_ЧЕЛОВЕК,ОТНОШЕНИЯ.НАЧАЛО,ОТНОШЕНИЯ.КОНЕЦ,ОТНОШЕНИЯ.ХАРАКТЕРИСТИКА
FROM ОТНОШЕНИЯ WHERE ОТНОШЕНИЯ.ИД_ЧЕЛОВЕК = ИД_ПО_ИМЕНИ(name, surname, patr);
END;
$$;

alter function "ОТНОШЕНИЯ_ПО_ИМЕНИ"(varchar, varchar, varchar) owner to s225071;

