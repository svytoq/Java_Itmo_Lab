create function finishquest() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE character_or_entity
    SET experience = experience + (SELECT experience FROM quest WHERE id = old.quest_id)
    WHERE id = 0;
    UPDATE inventory SET gold = gold + (SELECT reward FROM quest WHERE id = old.quest_id) WHERE character_id = 0;
    RETURN NULL;
END;
$$;

alter function finishquest() owner to s251806;

