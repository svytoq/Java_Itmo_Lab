create function autoinckript() returns trigger
    language plpgsql
as
$$
BEGIN
   NEW.ID := nextval('IdKriptSequence');
   Return NEW;
 END;
$$;

alter function autoinckript() owner to s223608;

