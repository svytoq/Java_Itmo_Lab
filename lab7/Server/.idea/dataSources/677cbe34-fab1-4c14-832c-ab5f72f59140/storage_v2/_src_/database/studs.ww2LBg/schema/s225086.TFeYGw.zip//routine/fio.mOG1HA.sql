create function fio(tekst character varying) returns character varying
    language plpgsql
as
$$
DECLARE 
result  VARCHAR(20);  
  kol     INTEGER; 
BEGIN  
  result := LOWER(RTRIM(LTRIM(tekst)));
  kol := LENGTH(result);
  IF kol > 0 THEN  
    result := REPLACE(result,'  ',' ');  
    result := REPLACE(result,'- ','-'); 
    result := REPLACE(result,' -','-'); 
    kol := LENGTH(result);  
FOR i IN 1..kol LOOP
IF INSTR('- абвгдеѐжзийклмнопрстуфхцчшщъыьэюя',SUBSTR(result,i,1))=0 
    THEN
        result := '0';
        EXIT;
     END IF;  
    END LOOP; 
  ELSE 
    result := '0';
  END IF; 
  IF result <> '0' THEN
    result := INITCAP(result);
  END IF; 
    RETURN result; 
END;
$$;

alter function fio(varchar) owner to s225086;

