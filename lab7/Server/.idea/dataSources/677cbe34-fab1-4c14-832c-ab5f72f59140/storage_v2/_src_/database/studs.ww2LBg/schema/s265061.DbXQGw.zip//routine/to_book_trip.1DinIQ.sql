create function to_book_trip(text, am double precision) returns integer
    language plpgsql
as
$$
declare idd integer;
begin
   insert into booking( total_amount, time_limit, contact_data)
  values (am,current_timestamp+interval '2 hour',$1)returning id into idd;
  return idd;
end ;
$$;

alter function to_book_trip(text, double precision) owner to s265061;

