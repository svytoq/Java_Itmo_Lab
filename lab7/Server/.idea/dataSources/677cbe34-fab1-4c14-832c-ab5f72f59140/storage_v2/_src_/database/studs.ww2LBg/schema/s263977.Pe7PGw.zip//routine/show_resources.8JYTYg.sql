create function show_resources(id_isbs integer) returns void
    language plpgsql
as
$$
BEGIN
    if (not (select is_done from Basis_ISBS where ID = id_isbs)) then
        Raise notice 'Для постройки купола №% необходимо % ресурсов', id_isbs, (select need_resource from Basis_ISBS where ID = id_isbs);
    Else raise notice 'купола не существует, либо он уже достроен';
    end if;
END
$$;

alter function show_resources(integer) owner to s263977;

