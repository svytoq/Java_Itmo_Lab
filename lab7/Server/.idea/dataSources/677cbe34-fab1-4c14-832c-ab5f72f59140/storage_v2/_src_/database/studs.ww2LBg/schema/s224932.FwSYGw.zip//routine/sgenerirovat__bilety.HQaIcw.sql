create function сгенерировать_билеты("число_билетов" integer) returns void
    language plpgsql
as
$$
DECLARE
        session Сеансы%ROWTYPE;
        seat Места%ROWTYPE;
BEGIN
        FOR session IN (SELECT ид FROM Сеансы) LOOP
                FOR seat IN (SELECT ид FROM Места WHERE Места.ид_зала = session.ид_зала) LOOP 
                        IF random() > 0.5 THEN
                        INSERT INTO Билеты (ид_сеанса, ид_места, стоимость, статус) 
                        VALUES (session.ид, seat.ид, random() * 500 + 100, random() * 2);
                END IF; 
                END LOOP;
        END LOOP;
END;
$$;

alter function сгенерировать_билеты(integer) owner to s224932;

