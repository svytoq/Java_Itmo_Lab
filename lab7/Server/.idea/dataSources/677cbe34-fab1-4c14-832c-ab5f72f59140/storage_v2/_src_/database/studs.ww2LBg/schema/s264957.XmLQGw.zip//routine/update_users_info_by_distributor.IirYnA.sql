create function update_users_info_by_distributor() returns trigger
    language plpgsql
as
$$
BEGIN
        update participant set name = NEW.main_person_name,
                               status = status,
                               country_id = country_id,
                               location_id = location_id,
                               age = age,
                               power = power,
                               defence = defence,
                               sex = sex,
                               birthdate = birthdate
        where new.main_person_id = id;
    return new;
    end;
$$;

alter function update_users_info_by_distributor() owner to s264957;

