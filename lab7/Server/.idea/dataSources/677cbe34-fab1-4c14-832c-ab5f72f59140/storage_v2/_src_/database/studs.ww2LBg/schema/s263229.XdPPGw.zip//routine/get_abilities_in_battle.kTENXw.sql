create function get_abilities_in_battle()
    returns TABLE(battle_name character varying, ability_name character varying, ability_description character varying, ability_type s263229.ability_types)
    stable
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT b.BATTLE_NAME, a.ABILITY_NAME, a.DESCRIPTION, a.ABILITY_TYPE FROM battle AS b 
    JOIN battle_abilities USING(BATTLE_ID) JOIN abilities AS a USING(ABILITY_ID);
END
$$;

alter function get_abilities_in_battle() owner to s263229;

