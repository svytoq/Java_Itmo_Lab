create function levelincrease(person_id integer) returns void
    language sql
as
$$
UPDATE character_or_entity SET experience=experience-2000,level=level+1
WHERE id=PERSON_ID;
$$;

alter function levelincrease(integer) owner to s251806;

