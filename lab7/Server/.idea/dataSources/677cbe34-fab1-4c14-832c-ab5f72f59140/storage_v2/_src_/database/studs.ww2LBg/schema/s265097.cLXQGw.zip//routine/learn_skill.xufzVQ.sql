create function learn_skill(w_name text, skill_id integer, roomid integer) returns integer
    language plpgsql
as
$$
declare 
hasPotions integer;
notHasSkill integer;
wId integer;
is_adm integer;
begin
IF EXISTS(select "SkillPotion"."PotionId" FROM "Skill" INNER JOIN "SkillPotion" ON "Skill"."Id" = "SkillPotion"."SkillId" 
LEFT JOIN "Tube" ON "Tube"."PotionId" = "SkillPotion"."PotionId" LEFT JOIN "Storage" ON "Tube"."StorageId" = "Storage"."Id" 
LEFT JOIN "Room" ON "Storage"."RoomId" = "Room"."Id" WHERE "Tube"."Id" is null AND "Room"."Id" = roomid AND "Skill"."Id" = skill_id)
THEN
select 0 INTO hasPotions;
else
select 1 INTO hasPotions;
end if;
select "Id" from "Wizard" into wId Where "Name" = w_name;
IF EXISTS(select * from "Wizard" INNER JOIN "WizardSkill" On "Wizard"."Id" = "WizardSkill"."WizardId" WHERE "WizardSkill"."SkillId" = skill_id AND "Wizard"."Name" = w_name)
THEN select 0 INTO notHasSkill; 
else select 1 INTO notHasSkill; end if;

IF hasPotions = 1 AND notHasSkill = 1 AND wId is not null THEN select "Id" from "Wizard" into wId where "Name" = w_name; insert into "WizardSkill" values(wId, skill_id); end if;
return CAST ((hasPotions = 1 AND notHasSkill = 1 AND wId is not null) AS INT);
end;
$$;

alter function learn_skill(text, integer, integer) owner to s265097;

