create function prevent_update() returns trigger
    language plpgsql
as
$$
BEGIN
    RAISE EXCEPTION 'Data modification not allowed';
   END;
$$;

alter function prevent_update() owner to s270250;

