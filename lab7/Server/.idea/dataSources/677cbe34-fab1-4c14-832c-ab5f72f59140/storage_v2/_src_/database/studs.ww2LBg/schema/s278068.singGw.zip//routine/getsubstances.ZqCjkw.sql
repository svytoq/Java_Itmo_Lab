create function getsubstances(human_id integer)
    returns TABLE(id integer, shortname character varying, description character varying, harmfulness integer)
    language sql
as
$$
select a.id, shortname, description, harmfulness
from human_blood_flow_substance as a
    inner join human_blood_flow_circulatorysystem_substances as b on a.id = b.substance_id
    inner join human_blood_flow_circulatorysystem as c on c.id = b.circulatorysystem_id
    inner join human_blood_flow_organism as d on c.organism_id = d.id
where d.owner_id = $1
$$;

alter function getsubstances(integer) owner to s278068;

