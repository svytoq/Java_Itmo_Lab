create function visaemplcheck() returns trigger
    language plpgsql
as
$$
begin
    if exists(
        select 1 from Positions
        join Employee_positions using(position_id)
        join Employees e on e.employee_id=NEW.employee_id
        where department = 'customs'
    )
    then
        return NEW;
    end if;
    return NULL;
end;
$$;

alter function visaemplcheck() owner to s265066;

