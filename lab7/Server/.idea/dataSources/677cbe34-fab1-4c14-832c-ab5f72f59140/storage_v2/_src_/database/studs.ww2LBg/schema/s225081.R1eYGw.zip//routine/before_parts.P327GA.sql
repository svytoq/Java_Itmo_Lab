create function before_parts() returns trigger
    language plpgsql
as
$$
DECLARE
POS POS;
BEGIN
  IF NEW.ЧИСЛЕННОСТЬ <100 THEN
    NEW.ТИП='ЦЕНТУРИЯ';
    ELSE NEW.ТИП ='ЛЕГИОН';
  END IF;
  IF NEW.КОМАНДИР NOTNULL  THEN
    SELECT ДОЛЖНОСТЬ FROM ВОИНЫ  WHERE ID_ВОИНА =NEW.КОМАНДИР INTO POS;
    IF POS ='РЯДОВОЙ ВОИН' THEN
      NEW.КОМАНДИР = NULL ;
      RAISE NOTICE  'РЯДОВОЙ НЕ МОЖЕТ БЫТЬ КОМАНДИРОМ';
      ELSEIF NEW.ТИП = 'ЦЕНТУРИЯ' AND POS ='ЛЕГИОНЕР' OR NEW.ТИП = 'ЛЕГИОН' AND POS ='ЦЕНТУРИОН' THEN
      NEW.КОМАНДИР = NULL;
      RAISE NOTICE 'НЕСОВМЕСТИМОСТЬ ДОЛЖНОСТЕЙ';
    END IF;
  END IF;
  RETURN  NEW;
END;
$$;

alter function before_parts() owner to s225081;

