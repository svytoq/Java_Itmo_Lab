create function check_number_of_weapons() returns trigger
    language plpgsql
as
$$
BEGIN
IF ((SELECT COUNT(ИД_ОРУЖИЯ) FROM ОРУЖИЕ_В_ИГРЕ WHERE ИД_ТРИБУТА = NEW.ИД_ТРИБУТА GROUP BY ИД_ТРИБУТА) >= 3) THEN
RAISE WARNING 'Один трибут не может иметь больше трёх оружий одновременно';
RETURN NULL;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function check_number_of_weapons() owner to s242361;

