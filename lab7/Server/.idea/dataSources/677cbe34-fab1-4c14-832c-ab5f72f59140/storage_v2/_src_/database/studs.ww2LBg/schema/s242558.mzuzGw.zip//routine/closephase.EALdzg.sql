create function closephase(id integer) returns void
    language plpgsql
as
$$
DECLARE 
    beg date;
    endi date;
    temp integer;
    t1 integer;
    t2 integer;
    t3 integer;
    t4 integer;
    t5 integer;
    t6 integer;
    t7 integer;
    t8 integer;
BEGIN
    beg = (SELECT начало FROM стадии WHERE ид=id);
    endi = (SELECT конец FROM стадии WHERE ид=id);
    IF (SELECT типс_ид FROM стадии WHERE ид=id) = 1 THEN
        FOR i IN 1..6 LOOP
            temp = (SELECT поб_ид FROM (SELECT поб_ид, COUNT(поб_ид) FROM матчи JOIN команды ON (матчи.поб_ид=команды.ид) AND (див_ид=i) WHERE (дата>=beg) AND (дата<=endi) GROUP BY поб_ид ORDER BY COUNT(поб_ид) DESC LIMIT 1) AS sub);
            IF i=1 THEN t1=temp;
            ELSIF i=2 THEN t2=temp;
            ELSIF i=3 THEN t3=temp;
            ELSIF i=4 THEN t4=temp;
            ELSIF i=5 THEN t5=temp;
            ELSIF i=6 THEN t6=temp;
            END IF;
        END LOOP;
    END IF;
    t7 = (SELECT поб_ид FROM (SELECT поб_ид, COUNT(поб_ид) FROM матчи WHERE (дата>=beg) AND (дата<=endi) AND (поб_ид NOT IN (t1,t2,t3,t4,t5,t6)) GROUP BY поб_ид ORDER BY COUNT(поб_ид) DESC LIMIT 1) AS sub);
    t8 = (SELECT поб_ид FROM (SELECT поб_ид, COUNT(поб_ид) FROM матчи WHERE (дата>=beg) AND (дата<=endi) AND (поб_ид NOT IN (t1,t2,t3,t4,t5,t6,t7)) GROUP BY поб_ид ORDER BY COUNT(поб_ид) DESC LIMIT 1) AS sub);
    RAISE NOTICE 'Победитель в Северо-Западно дивизионе: %', (SELECT название FROM команды WHERE ид=t1);
    RAISE NOTICE 'Победитель в Тихоокеанском дивизионе: %', (SELECT название FROM команды WHERE ид=t2);
    RAISE NOTICE 'Победитель в Юго-Западном дивизионе: %', (SELECT название FROM команды WHERE ид=t3);
    RAISE NOTICE 'Победитель в Атлантическом дивизионе: %', (SELECT название FROM команды WHERE ид=t4);
    RAISE NOTICE 'Победитель в Центральном дивизионе: %', (SELECT название FROM команды WHERE ид=t5);
    RAISE NOTICE 'Победитель в Юго-Восточном дивизионе: %', (SELECT название FROM команды WHERE ид=t6);
    RAISE NOTICE 'Победитель #1 по наибольшему количеству побед: %', (SELECT название FROM команды WHERE ид=t7);
    RAISE NOTICE 'Победитель #2 по наибольшему количеству побед: %', (SELECT название FROM команды WHERE ид=t8);
END;
$$;

alter function closephase(integer) owner to s242558;

