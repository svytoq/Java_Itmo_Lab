create function max_kills()
    returns TABLE(nazv text, kills integer, playerid integer)
    language plpgsql
as
$$
BEGIN 
RETURN query 
select tournament.name, max(stats.kills), player.id
from tournament
join tournament_result on tournament.id = tournament_result.tournament_id
join team on first_id = team.id
join player on first_id = player.team_id
join stats on stats.player_id = player.id
join match on stats.match_id = match.id
where 
match.tournament_id = tournament.id
group by tournament.name, player.id;
END;
$$;

alter function max_kills() owner to s243878;

