create function sell(character_id integer, item_id integer) returns character varying
    language plpgsql
as
$$
BEGIN
		UPDATE К_Инвентарь SET Статус = 'продан' where Персонаж_ИД = character_id and Предмет_ИД = item_id;		
		RETURN 'Предмет продан';
	END;

$$;

alter function sell(integer, integer) owner to s242193;

