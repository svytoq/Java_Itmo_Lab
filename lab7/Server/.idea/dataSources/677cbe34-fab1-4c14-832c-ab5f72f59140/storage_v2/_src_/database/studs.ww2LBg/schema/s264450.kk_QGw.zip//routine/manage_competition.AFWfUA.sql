create function manage_competition(user_login text, competition_name text) returns void
    language plpgsql
as
$$
BEGIN
insert into competition_manager(competition_id, base_user_login) values ((select id from competition where name like competition_name limit 1), user_login);
END;
$$;

alter function manage_competition(text, text) owner to s264450;

