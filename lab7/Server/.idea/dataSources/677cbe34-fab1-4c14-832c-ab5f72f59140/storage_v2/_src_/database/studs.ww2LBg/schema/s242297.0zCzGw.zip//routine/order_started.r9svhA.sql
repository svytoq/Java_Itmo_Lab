create function order_started() returns trigger
    language plpgsql
as
$$
BEGIN
        INSERT INTO ЗАКАЗЫ_ЛОГИ(ИД_ЗАКАЗА, КТО_ИЗМ, СТАТУС, ВРЕМЯ_ИЗМ)
        VALUES (NEW.ИД, '537953', 'ПРИНЯТ', current_timestamp);
        RETURN NEW;
    END;
$$;

alter function order_started() owner to s242297;

