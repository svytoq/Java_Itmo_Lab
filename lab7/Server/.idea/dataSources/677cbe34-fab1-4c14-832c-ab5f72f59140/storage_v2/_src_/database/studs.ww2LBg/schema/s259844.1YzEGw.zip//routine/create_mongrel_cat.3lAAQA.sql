create function create_mongrel_cat(cat_name text, cat_birthday timestamp without time zone, cat_sex character, cat_color integer) returns s259844.cat
    language plpgsql
as
$$
DECLARE
BEGIN
    RETURN (SELECT create_cat(cat_name, NULL, cat_birthday, cat_sex, cat_color));
END;
$$;

alter function create_mongrel_cat(text, timestamp, char, integer) owner to s259844;

