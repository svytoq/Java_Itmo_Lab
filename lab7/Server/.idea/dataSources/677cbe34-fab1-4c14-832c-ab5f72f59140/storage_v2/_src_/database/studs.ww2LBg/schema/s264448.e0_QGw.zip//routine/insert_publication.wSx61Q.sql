create function insert_publication(name text, description text) returns integer
    language plpgsql
as
$$
BEGIN
    INSERT INTO publication (name, description) VALUES (insert_publication.name, insert_publication.description);
    RETURN (CURRVAL('publication_publication_id_seq'));
END;
$$;

alter function insert_publication(text, text) owner to s264448;

