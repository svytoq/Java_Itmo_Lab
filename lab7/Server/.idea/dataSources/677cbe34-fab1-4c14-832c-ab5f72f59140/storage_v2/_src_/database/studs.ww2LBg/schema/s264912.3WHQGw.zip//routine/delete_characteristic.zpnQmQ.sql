create function delete_characteristic() returns trigger
    language plpgsql
as
$$
BEGIN
    DELETE FROM princess WHERE princess.id_character = OLD.id_character;
    DELETE FROM bogatyr WHERE bogatyr.id_character = OLD.id_character;
    DELETE FROM animal WHERE animal.id_character = OLD.id_character;
    DELETE FROM commander WHERE commander.id_commander = OLD.id_character;
    DELETE FROM villain WHERE villain.id_character = OLD.id_character;
    DELETE FROM wizard WHERE wizard.id_character = OLD.id_character;
    DELETE FROM king WHERE king.id_character = OLD.id_character;
    DELETE FROM story_character WHERE story_character.id_character = OLD.id_character;
    DELETE FROM resident WHERE resident.id_character = OLD.id_character;
    RETURN NULL;
END;
$$;

alter function delete_characteristic() owner to s264912;

