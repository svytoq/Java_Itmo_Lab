create function generate_data() returns text
    language plpgsql
as
$$
begin
    insert into space_system (id, name) select i, random_string(30) from generate_series(4, 1000) as i;
    insert into space_object 
    (id, system_id, name, weight, radius, x_coordinate, y_coordinate, z_coordinate)
    select i, random_between(1, 1000), random_string(30), random_between(1000, 99999), 
    random_between(1000, 10000), random_between(0, 1000000), random_between(0, 1000000), random_between(0, 1000000)
    from generate_series(21, 100000) as i;
    insert into star (object_id, is_lighting, is_main, difficulty)
    select i, random() > 0.5, random() > 0.5, 5
    from generate_series(21, 50000, 2) as i;
    
    insert into army (race_id, quantity) 
    select random_between(1, 4), random_between(1, 10000000) from generate_series(0, 50000);
    
    insert into planet_population (race_id, quantity) 
    select random_between(1, 4), random_between(1, 10000000) from generate_series(0, 50000);
    
    insert into planet (object_id, army_id, population_id, planet_type, 
    can_be_masked, is_masked, is_cooled_down)
    select i, i/2, i/2, '3', 't', 'f', 'f'
    from generate_series(22, 50000, 2) as i;
    
    insert into resource_space_object (object_id, resource_id, quantity)
    select i, 1, random_between(0, 10000000)
    from generate_series(21, 100000) as i;

    insert into resource_space_object (object_id, resource_id, quantity)
    select i, 2, random_between(0, 10000000)
    from generate_series(21, 100000) as i;
    
    insert into resource_army (army_id, resource_id, quantity)
    select i, 1, random_between(0, 10000000)
    from generate_series(6, 50005) as i;
    
    insert into resource_army (army_id, resource_id, quantity)
    select i, 2, random_between(0, 10000000)
    from generate_series(6, 50005) as i;
    return 'Fake data generated';
  end;
$$;

alter function generate_data() owner to s264482;

