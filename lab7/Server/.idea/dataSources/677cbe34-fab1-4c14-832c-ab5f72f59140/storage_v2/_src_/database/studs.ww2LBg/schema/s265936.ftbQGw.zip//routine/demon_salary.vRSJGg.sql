create function demon_salary() returns integer
    language plpgsql
as
$$
declare
    demon int;
    count_of_missions int;
BEGIN
    RAISE NOTICE 'ОБНОВЛЕНИЕ ЗАРПЛАТ ВСЕХ РАБОТНИКОВ, ИМЕЮЩИХ ЗАРПЛАТНЫЕ КАРТОЧКИ...';
    FOR demon IN
        select worker_id from demon_card join worker w on demon_card.worker_id = w.id
    LOOP
        count_of_missions = (select count(*) from mission where (worker_id = demon) and (result = 'Выполнено'));
        update demon_card set salary = (count_of_missions*30000) where worker_id = demon;
    END LOOP;
    RAISE NOTICE 'ОБНОВЛЕНИЕ ЗАКОНЧЕНО.';
    RETURN 1;
END;
$$;

alter function demon_salary() owner to s265936;

