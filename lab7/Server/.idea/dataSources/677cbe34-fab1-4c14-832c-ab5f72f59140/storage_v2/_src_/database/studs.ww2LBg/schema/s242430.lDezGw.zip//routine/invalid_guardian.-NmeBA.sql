create function invalid_guardian() returns trigger
    language plpgsql
as
$$
BEGIN
IF (select SubCircle.idCircle from subcircle natural join tormented  where tormented.idtormented=NEW.idtormented) <>
(SELECT Guardian.idCircle FROM guardian where guardian.idguardian=NEW.idguardian) then
RAISE EXCEPTION 'Страж не с того района!';
END IF;
RETURN NEW;
END;
$$;

alter function invalid_guardian() owner to s242430;

