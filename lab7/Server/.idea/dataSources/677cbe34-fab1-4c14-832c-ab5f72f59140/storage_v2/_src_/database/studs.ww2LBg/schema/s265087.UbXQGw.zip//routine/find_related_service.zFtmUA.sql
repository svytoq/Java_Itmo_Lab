create function find_related_service(user_id_1 integer, user_id_2 integer, user_id_3 integer)
    returns TABLE(producer_id integer, name_producer character varying, surname_producer character varying, consumer_id integer, name_consumer character varying, surname_consumer character varying, suggestion_name character varying, agreed_time timestamp with time zone, crosses boolean)
    language plpgsql
as
$$
BEGIN
    RETURN QUERY SELECT suggestion.author,
                        (SELECT NAME FROM "USER" WHERE ID = SUGGESTION.AUTHOR),
                        (SELECT surname FROM "USER" WHERE ID = SUGGESTION.AUTHOR),
                        REQUEST.author,
                        (SELECT NAME FROM "USER" WHERE ID = REQUEST.author),
                        (SELECT surname FROM "USER" WHERE ID = REQUEST.author),
                        SUGGESTION.NAME,
                        REQUEST.agreed_time,
                        (SELECT IS_TIME_CROSSES(REQUEST.agreed_time, suggestion.author, REQUEST.author))
                 FROM "USER"
                          JOIN request ON "USER".id = request.author
                          JOIN suggestion_request ON request.id = suggestion_request.request
                          JOIN suggestion ON suggestion_request.suggestion = suggestion.id
                 WHERE ("USER".ID = USER_ID_1 OR "USER".ID = USER_ID_2 OR "USER".ID = USER_ID_3)
                   AND (REQUEST.author = USER_ID_1 OR REQUEST.author = USER_ID_2 OR REQUEST.author = USER_ID_3)
                   AND (SUGGESTION.author = USER_ID_1 OR SUGGESTION.author = USER_ID_2 OR SUGGESTION.author = USER_ID_3);
END;
$$;

alter function find_related_service(integer, integer, integer) owner to s265087;

