create function filli() returns void
    language sql
as
$$
    CREATE INDEX города_название ON города (название);
        CREATE INDEX арены_название ON арены (название);
        CREATE INDEX люди_имя ON люди (имя);
        CREATE INDEX люди_дата_рожд ON люди (дата_рожд);
        CREATE INDEX люди_рост ON люди (рост);
        CREATE INDEX люди_вес ON люди (вес);
        CREATE INDEX участники_начало ON участники (начало);
        CREATE INDEX участники_конец ON участники (конец);
        CREATE INDEX команды_название ON команды (название);
        CREATE INDEX команды_основание ON команды (основание);
        CREATE INDEX команды_вступление_в_нба ON команды (вступление_в_нба);
        CREATE INDEX статистика_побед ON статистика (побед);
        CREATE INDEX статистика_поражений ON статистика (поражений);
        CREATE INDEX матчи_дата ON матчи (дата);
        CREATE INDEX сезоны_начало ON сезоны (начало);
        CREATE INDEX сезоны_конец ON сезоны (конец);
        CREATE INDEX стадии_начало ON стадии (начало);
        CREATE INDEX стадии_конец ON стадии (конец);
    $$;

alter function filli() owner to s242558;

