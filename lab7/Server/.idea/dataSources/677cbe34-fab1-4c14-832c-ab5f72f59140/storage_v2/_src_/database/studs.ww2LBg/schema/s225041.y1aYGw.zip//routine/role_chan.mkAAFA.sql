create function role_chan() returns trigger
    language plpgsql
as
$$
DECLARE
old_role text;
new_role text;
BEGIN
old_role = OLD.Роль;
new_role = NEW.Роль;
IF (old_role = new_role) THEN
RETURN NEW;
ELSE 
IF (old_role = 'ЗАКЛЮЧЁННЫЙ') THEN
DELETE FROM ЗАКЛЮЧЁННЫЙ WHERE ЧЕЛОВЕК_ИД = OLD.ЧЕЛОВЕК_ИД;
RETURN NEW;
END IF;
IF (old_role = 'ПЕРСОНАЛ') THEN
DELETE FROM ПЕРСОНАЛ WHERE ЧЕЛОВЕК_ИД = OLD.ЧЕЛОВЕК_ИД;
RETURN NEW;
END IF;
END IF;
END;
$$;

alter function role_chan() owner to s225041;

