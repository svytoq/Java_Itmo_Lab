create function add_home_work_and_additional_work("группа_ид" integer, "предмет_ид" integer, "дата_выдачи" date, "дата_проверки" date, "описание_домашнего_задания" text, "аранжировка_ид" integer, "описание_дополнительного_задания" text) returns void
    language sql
as
$$
BEGIN TRANSACTION;
	INSERT INTO домашнее_задание
	VALUES (nextval('домашнее_задание_ид_seq'), группа_ид, предмет_ид, дата_выдачи, дата_проверки, описание_домашнего_задания)
	;
	INSERT INTO дополнительное_задание
	VALUES (currval('домашнее_задание_ид_seq'), аранжировка_ид, описание_дополнительного_задания)
	;
COMMIT;
$$;

alter function add_home_work_and_additional_work(integer, integer, date, date, text, integer, text) owner to s223758;

