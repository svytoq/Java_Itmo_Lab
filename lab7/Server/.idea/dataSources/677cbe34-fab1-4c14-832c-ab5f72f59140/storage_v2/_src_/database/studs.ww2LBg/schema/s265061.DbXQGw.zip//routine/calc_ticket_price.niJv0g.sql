create function calc_ticket_price(flight_id integer, seat_number character varying) returns double precision
    language plpgsql
as
$$
declare
        airport_tax float = 1.05;
        month_tax float = 1.002;
        half_month_tax float = 1.05;
        week_tax float = 1.1;
        economy_tax float = 1.01;
        business_tax float = 1.1;
        result float;
    begin
        with result_price as (
        select price::float*airport_tax as r_price, extract(day from f.schedule_departure - now()) as days, class
        from trip_price as t
        join flight f on
            f.id = flight_id and
            t.arrival_airport = f.arrival_airport and
            t.departure_airport = f.departure_airport or
            t.arrival_airport = f.departure_airport and
            t.departure_airport = f.arrival_airport
        join seat s on f.id = s.flight_id and s.number = seat_number
            ), result_price_1 as (
            select result_price.class, result_price.r_price, case
                when result_price.days > 30 then result_price.r_price*month_tax
                when result_price.days <= 30 and result_price.days > 15 then result_price.r_price*half_month_tax
                when result_price.days <= 15 then result_price.r_price*week_tax
            end as r_price_1
                from result_price
            ), result_price_2 as (
            select result_price_1.class, result_price_1.r_price_1,
            case
                when result_price_1.class = 'economy' then result_price_1.r_price_1*economy_tax
                when result_price_1.class = 'business' then result_price_1.r_price_1*business_tax
            end as price
                from result_price_1
            ) select into result result_price_2.price from result_price_2;
        return result;
    end;
$$;

alter function calc_ticket_price(integer, varchar) owner to s265061;

