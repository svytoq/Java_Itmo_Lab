create function add_wear() returns trigger
    language plpgsql
as
$$
declare
rr integer;
begin
rr = sqrt(  power(((select coord_x from planets where id=new.start_planet_id)-(select coord_x from planets where id=new.finish_planet_id)),2)
+ power(((select coord_y from planets where id=new.start_planet_id)-(select coord_y from planets where id=new.finish_planet_id)),2)
+ power(((select coord_z from planets where id=new.start_planet_id)-(select coord_z from planets where id=new.finish_planet_id)),2));
update exemplars set wear = wear+rr where id=(select exemplar_id from changes where ship_id=new.ship_id and end_date is null);
return new;
end;
$$;

alter function add_wear() owner to s225051;

