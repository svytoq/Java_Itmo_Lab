create function add_man(name character varying, surname character varying, work character varying, company character varying) returns void
    language sql
as
$$
INSERT INTO Люди (Имя, Фамилия) VALUES (name, surname);
INSERT INTO Наблюдаемый VALUES ((select "ID_человека" from "Люди" where "Имя" = name and "Фамилия" = surname), work, company);
$$;

alter function add_man(varchar, varchar, varchar, varchar) owner to s265102;

