create function сеансы_до_премьеры_запрещены() returns trigger
    language plpgsql
as
$$
DECLARE 
	дата_премьеры timestamp;
BEGIN
SELECT Фильмы.дата_премьеры INTO дата_премьеры FROM "Фильмы" WHERE ид = NEW.ид_фильма;
IF NEW.дата_начала < дата_премьеры THEN
	RAISE EXCEPTION 'Дата премьеры фильма (%) не может быть позже, чем дата начала показа (%)', дата_премьеры, NEW.дата_начала;
END IF;

RETURN NEW;
END;
$$;

alter function сеансы_до_премьеры_запрещены() owner to s242395;

