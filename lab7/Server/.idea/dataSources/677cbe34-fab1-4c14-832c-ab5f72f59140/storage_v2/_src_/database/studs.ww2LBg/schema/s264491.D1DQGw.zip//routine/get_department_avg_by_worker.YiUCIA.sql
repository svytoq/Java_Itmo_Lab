create function get_department_avg_by_worker(worker_id integer) returns s264491.ranking
    language plpgsql
as
$$
DECLARE
    res RANKING;
BEGIN
    SELECT W.department_id INTO res.depart_id FROM WORKER W WHERE W.id = worker_id;
    SELECT SUM(workers_rank) / COUNT(1), SUM(corporate_rank) / COUNT(1)
    INTO res.worker_rank, res.corporate_rank
    FROM WORKER W
    WHERE W.department_id = res.depart_id;
    RETURN res;
END;
$$;

alter function get_department_avg_by_worker(integer) owner to s264491;

