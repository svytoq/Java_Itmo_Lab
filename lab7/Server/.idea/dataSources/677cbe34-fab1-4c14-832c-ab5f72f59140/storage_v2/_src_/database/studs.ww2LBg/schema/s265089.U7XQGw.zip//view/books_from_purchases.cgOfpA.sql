create view books_from_purchases(isbn, title, amount, purchase_id, delivery_date, supplier) as
SELECT b.isbn,
       b.title,
       b.amount,
       pb.purchase_id,
       p.delivery_date,
       p.supplier
FROM s265089.books b
         JOIN s265089.purchases_books pb USING (isbn, amount)
         JOIN s265089.purchases p USING (purchase_id);

alter table books_from_purchases
    owner to s265089;

