create function client_pay() returns trigger
    language plpgsql
as
$$
DECLARE
    del_place integer;
    provider  integer;
BEGIN
    SELECT id_delivery_place FROM clients WHERE clients.id_client = NEW.id_client INTO del_place;
    SELECT id_provider FROM providers WHERE providers.id_delivery_place = del_place INTO provider;
    NEW.id_provider = provider;
    NEW.paying = TRUE;
    NEW.payment_date = current_date;
    RETURN NEW;
END
$$;

alter function client_pay() owner to s270235;

