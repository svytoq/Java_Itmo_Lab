create function peid() returns trigger
    language plpgsql
as
$$
begin
	new.ИД_СОТРУДНИКА := nextval('people_seq');
	return new;
end
$$;

alter function peid() owner to s225120;

