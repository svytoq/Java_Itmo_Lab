create function hire_employee(person bigint, pos integer, access s265066.access_levels, hire_date date) returns integer
    language plpgsql
as
$$
declare
    employee integer;
begin
    perform employment_check(person, pos);
    select employee_id into employee from Employees where person_id=person;
    if employee is null then
        insert into Employees(person_id, employment_date, acc_lvl)
        values(person, hire_date, access) returning employee_id into employee;
    end if;
    
    insert into Employee_positions values (employee, pos);
    return employee;
end;
$$;

alter function hire_employee(bigint, integer, s265066.access_levels, date) owner to s265066;

