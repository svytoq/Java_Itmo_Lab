create function buy_weapon(buyer_character_id integer, buying_weapon_id integer) returns text
    language plpgsql
as
$$
declare
  begin
    -- если такого персонажа/оружия нет в таблице, то произойдет ошибка
    insert into character_has_weapon (character_id, weapon_id) 
    values (buyer_character_id, buying_weapon_id);
    
    return 'Оружие было успешно приобретено';
  end;
$$;

alter function buy_weapon(integer, integer) owner to s263148;

