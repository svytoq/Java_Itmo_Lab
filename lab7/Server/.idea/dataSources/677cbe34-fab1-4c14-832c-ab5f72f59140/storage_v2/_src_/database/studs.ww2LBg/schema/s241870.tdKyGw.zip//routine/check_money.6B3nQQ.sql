create function check_money() returns trigger
    language plpgsql
as
$$
BEGIN
   IF ((SELECT SUM( Контракты.Зарплата_в_долларах::integer ) FROM Контракты
   INNER JOIN Команды ON NEW.ID_Команды = Команды.ID_Команды) + NEW.Зарплата_в_долларах)>(SELECT Команды.Бюджет FROM Команды WHERE Команды.ID_Команды = NEW.ID_Команды)
   THEN
      RAISE EXCEPTION 'У команды не хватает денег на нового игрока';
END IF;
RETURN NEW;
END
$$;

alter function check_money() owner to s241870;

