create function is_prison_room_matches(id_crt integer) returns boolean
    language plpgsql
as
$$
DECLARE 
protec_lvl int = (SELECT protec_lvl/10 
FROM prison
  JOIN prison_room as p_r on p_r.id = p.id_room 
  WHERE p.id = id);
BEGIN
IF get_danger_q(id_crt) <= protec_lvl THEN 
RETURN true;
ELSE 
RETURN false;
END IF;
END;
$$;

alter function is_prison_room_matches(integer) owner to s243856;

