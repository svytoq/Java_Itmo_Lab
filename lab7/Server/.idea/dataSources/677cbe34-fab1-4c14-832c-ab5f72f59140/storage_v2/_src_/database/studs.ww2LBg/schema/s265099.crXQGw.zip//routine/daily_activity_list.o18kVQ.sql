create function daily_activity_list(user_id integer, day date)
    returns TABLE("допустимое_время_начала" timestamp without time zone, "допустимое_время_конца" timestamp without time zone, "продолжительность" interval, "периодичность" interval, "формат" s265099.format_enum, "влияние_на_уровень_стресса" integer, "локация" text)
    language plpgsql
as
$$
BEGIN
		RETURN QUERY SELECT активность.допустимое_время_начала, активность.допустимое_время_конца, активность.продолжительность, активность.периодичность, активность.формат, активность.влияние_на_уровень_стресса, локация.название 
		FROM активность JOIN локация USING (id_локации) 
		WHERE активность.id_пользователя = user_id AND DATE(активность.допустимое_время_начала) <= day AND DATE(активность.допустимое_время_конца) >= day ORDER BY активность.допустимое_время_конца;
	END
$$;

alter function daily_activity_list(integer, date) owner to s265099;

