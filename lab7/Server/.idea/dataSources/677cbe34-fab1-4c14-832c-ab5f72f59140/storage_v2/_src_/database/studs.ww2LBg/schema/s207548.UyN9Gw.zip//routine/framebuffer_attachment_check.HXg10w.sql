create function framebuffer_attachment_check() returns trigger
    language plpgsql
as
$$
BEGIN
	IF (SELECT COUNT(*) FROM FramebufferTexture WHERE FramebufferTexture.FramebufferID = NEW.FramebufferID AND FramebufferTexture."type" = NEW."type") != 0 THEN
		RAISE EXCEPTION 'It is illegal to have two equal framebuffer texture attachments';
	END IF;

	RETURN NEW;
END;
$$;

alter function framebuffer_attachment_check() owner to s207548;

