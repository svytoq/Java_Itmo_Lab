create function all_magicians_exist(magicians integer[]) returns boolean
    language plpgsql
as
$$
DECLARE
          magician int;
          mag_exists boolean;
        BEGIN
          FOREACH magician IN ARRAY magicians 
          LOOP
           SELECT 1 INTO mag_exists FROM Magicians m WHERE m.person_id = magician;
           IF NOT FOUND THEN
             RAISE EXCEPTION 'Такого мага нет';
           END IF;
          END LOOP;
        RETURN 'TRUE';
        END;
$$;

alter function all_magicians_exist(integer[]) owner to s265108;

