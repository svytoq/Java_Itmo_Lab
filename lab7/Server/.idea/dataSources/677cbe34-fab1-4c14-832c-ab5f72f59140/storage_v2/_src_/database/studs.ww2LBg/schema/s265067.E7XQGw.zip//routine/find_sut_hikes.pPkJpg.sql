create function find_sut_hikes() returns trigger
    language plpgsql
as
$$
BEGIN
INSERT INTO suitable_hikes (wish_id, hike_id) (SELECT new.wish_id, sugg_hikes.num
                                              FROM sugg_hikes
                                              WHERE sugg_hikes.type_hike in(select type_hike from type_hike where type_hike.type_id = new.type_id)
                                                AND sugg_hikes.com_ncom = new.com_ncom
                                                AND sugg_hikes.month = new.month
                                                AND sugg_hikes.category <= new.category + 1);
  return new;

end;
$$;

alter function find_sut_hikes() owner to s265067;

