create function "МЕСТО_PK_seq_func"() returns trigger
    language plpgsql
as
$$
DECLARE
                ids            int[];
                max_id    int;
        BEGIN
                ids = array(SELECT "МЕСТО_ИД" FROM "МЕСТО");
                max_id = (SELECT max(unnest) FROM unnest(ids));
                IF NEW."МЕСТО_ИД" = ANY(ids) THEN
                        EXECUTE 
                                'SELECT setval(''МЕСТО_МЕСТО_ИД_seq'', max("МЕСТО_ИД") + 1) FROM "МЕСТО"';
                        NEW."МЕСТО_ИД" := max_id + 1;
                END IF;
                RETURN NEW;
        END;
$$;

alter function "МЕСТО_PK_seq_func"() owner to s245094;

