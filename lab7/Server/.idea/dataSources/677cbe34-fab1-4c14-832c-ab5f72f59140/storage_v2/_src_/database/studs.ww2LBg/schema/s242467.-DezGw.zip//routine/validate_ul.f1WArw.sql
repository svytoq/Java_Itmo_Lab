create function validate_ul() returns trigger
    language plpgsql
as
$$
BEGIN
 IF length(NEW.Эффект)< 3
 THEN
 RAISE EXCEPTION 'Описание эффекта не может быть таким коротким!';
 END IF;
 RETURN NEW;
 END
$$;

alter function validate_ul() owner to s242467;

