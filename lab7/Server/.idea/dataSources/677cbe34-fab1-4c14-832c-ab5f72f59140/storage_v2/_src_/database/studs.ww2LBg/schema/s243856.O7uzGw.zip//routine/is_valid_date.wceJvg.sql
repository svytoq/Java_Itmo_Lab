create function is_valid_date(id_creature integer, check_date date) returns boolean
    language plpgsql
as
$$
DECLARE
birth_date date = (SELECT birthday FROM creature 
WHERE id = id_creature);
BEGIN
IF check_date > birth_date THEN
RETURN true;
END IF;
RETURN false;
END;
$$;

alter function is_valid_date(integer, date) owner to s243856;

