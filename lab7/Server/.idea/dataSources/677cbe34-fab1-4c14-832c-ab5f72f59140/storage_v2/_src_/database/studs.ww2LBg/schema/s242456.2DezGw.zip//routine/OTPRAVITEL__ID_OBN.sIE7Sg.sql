create function "ОТПРАВИТЕЛЬ_ИД_ОБН"() returns trigger
    language plpgsql
as
$$
BEGIN
IF OLD.ОТПРАВИТЕЛЬ_ИД!=NEW.ОТПРАВИТЕЛЬ_ИД THEN
NEW.ОТПРАВИТЕЛЬ_ИД=OLD.ОТПРАВИТЕЛЬ_ИД;
RETURN NEW;
ELSE
RETURN NEW;
END IF;
END;
$$;

alter function "ОТПРАВИТЕЛЬ_ИД_ОБН"() owner to s242456;

