create function dismiss_employee(_employee_id integer) returns integer
    language plpgsql
as
$$
begin
    delete from factory_employee where id = _employee_id;
end;
$$;

alter function dismiss_employee(integer) owner to s264429;

