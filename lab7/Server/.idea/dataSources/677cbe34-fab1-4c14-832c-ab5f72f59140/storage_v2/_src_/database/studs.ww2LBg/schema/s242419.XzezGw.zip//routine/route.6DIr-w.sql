create function route(stop_1 integer, stop_2 integer)
    returns TABLE("ост_1" integer, "ост_2" integer, "транспорт" text)
    language plpgsql
as
$$
<<the_greatest_label>>
declare i record;
j record;
h record;
        k integer;
        p integer;
        q integer;
xP integer;
yP integer;
stopMidd1 integer;
stopMidd2 integer;
tmp_x integer;
tmp_y integer;
init_stop1 integer;
init_stop2 integer;
end_stop1 integer;
end_stop2 integer;
countMarsh integer;
xi integer;
xj integer;
yi integer;
yj integer;
si text;
sj text;
finallyR integer;
stopMid1 integer;
stopMid2 integer;
a integer;
smezh1 integer;
smezh2 integer;
peresad1 integer;
peresad2 integer;
countStops integer;
BEGIN

select count(*) into countStops from ОСТАНОВКА;
if (stop_1 < 1) or (stop_1 > countStops) or (stop_2 < 1) or (stop_2 > countStops) 
then 
raise notice 'Вы ввели неверные номера остановок';

exit the_greatest_label;
end if;

if (select ид_маршрута from ОСТАНОВКА where ид = stop_1)=(select ид_маршрута from ОСТАНОВКА where ид = stop_2)
then
p := stop_2 - stop_1;
q := 0 - p;

if (p) > 0
then 
k := 0;
while p>0 loop
ост_1 := stop_1 + k;
ост_2 := stop_1 + k + 1;
select ТРАНСПОРТ.название into транспорт from (ОСТАНОВКА inner join МАРШРУТ on (ОСТАНОВКА.ид_маршрута=МАРШРУТ.ид)) inner join ТРАНСПОРТ on (МАРШРУТ.ид_транспорта=ТРАНСПОРТ.ид) where ОСТАНОВКА.ид=stop_1;
k := k + 1;
p := p - 1;
return next;
end loop;
else
end if;

if (p) < 0
then 
k := 0;
while q>0 loop
ост_1 := stop_1 - k;
ост_2 := stop_1 - k - 1;
select ТРАНСПОРТ.название into транспорт from (ОСТАНОВКА inner join МАРШРУТ on (ОСТАНОВКА.ид_маршрута=МАРШРУТ.ид)) inner join ТРАНСПОРТ on (МАРШРУТ.ид_транспорта=ТРАНСПОРТ.ид) where ОСТАНОВКА.ид=stop_1;
k := k + 1;
q := q - 1;
return next;
end loop;
else
end if;
else
select x into tmp_x from findP(stop_1, stop_2);
select y into tmp_y from findP(stop_1, stop_2);
if (tmp_x is not null) and (tmp_y is not null) 
then
select x into xP from findP(stop_1, stop_2);
select y into yP from findP(stop_1, stop_2);
select ид into stopMidd1 from ОСТАНОВКА where х_коор=xP and у_коор=yP and ид_маршрута in (select ид_маршрута from ОСТАНОВКА where ид = stop_1);
return query select * from route(stop_1, stopMidd1);
select ид into stopMidd2 from ОСТАНОВКА where х_коор=xP and у_коор=yP and ид_маршрута in (select ид_маршрута from ОСТАНОВКА where ид = stop_2);
ост_1 := stopMidd1;
ост_2 := stopMidd2;
транспорт := 'Пересаживаемся на другой маршрут';
return next;
return query select * from route(stopMidd2, stop_2);
else
select нач_остановка into init_stop1 from ОСТАНОВКА inner join ХАРАКТЕРИСТИКА_МАРШРУТА on (ОСТАНОВКА.ид_маршрута=ХАРАКТЕРИСТИКА_МАРШРУТА.ид) where ОСТАНОВКА.ид=stop_1;
select конеч_остановка into end_stop1 from ОСТАНОВКА inner join ХАРАКТЕРИСТИКА_МАРШРУТА on (ОСТАНОВКА.ид_маршрута=ХАРАКТЕРИСТИКА_МАРШРУТА.ид) where ОСТАНОВКА.ид=stop_1;
select нач_остановка into init_stop2 from ОСТАНОВКА inner join ХАРАКТЕРИСТИКА_МАРШРУТА on (ОСТАНОВКА.ид_маршрута=ХАРАКТЕРИСТИКА_МАРШРУТА.ид) where ОСТАНОВКА.ид=stop_2;
select конеч_остановка into end_stop2 from ОСТАНОВКА inner join ХАРАКТЕРИСТИКА_МАРШРУТА on (ОСТАНОВКА.ид_маршрута=ХАРАКТЕРИСТИКА_МАРШРУТА.ид) where ОСТАНОВКА.ид=stop_2;

select count(distinct номер) into countMarsh from МАРШРУТ;
<<finally>>
for i in init_stop1..end_stop1 loop
smezh1 = is_smezh(i);
if (smezh1 = 1) then
for j in init_stop2..end_stop2 loop
smezh2 = is_smezh(j);
if (smezh2 = 1) then
select х_коор into xi from ОСТАНОВКА where ОСТАНОВКА.ид=i;
select у_коор into yi from ОСТАНОВКА where ОСТАНОВКА.ид=i;
select х_коор into xj from ОСТАНОВКА where ОСТАНОВКА.ид=j;
select у_коор into yj from ОСТАНОВКА where ОСТАНОВКА.ид=j;
si := cast(xi as text) || '_' || cast(yi as text);
sj := cast(xj as text) || '_' || cast(yj as text);
for h in 0..(countMarsh-1) loop
select count(*) into a from (select х_коор, у_коор  from ОСТАНОВКА inner join МАРШРУТ on (ОСТАНОВКА.ид_маршрута=МАРШРУТ.ид)
where ((concat(cast(х_коор as text),'_',cast(у_коор as text)) = si) or (concat(cast(х_коор as text),'_',cast(у_коор as text)) = sj))
and (МАРШРУТ.номер = h) group by х_коор, у_коор) as blabla;
if a=2 
then finallyR:=h;
exit finally;
end if;
end loop;
end if;
end loop;
end if;
end loop;

if (finallyR is null)
then
raise notice 'Увы, невозможно построить маршрут, так как начальный и конечный маршруты не имеют пересечения';

exit the_greatest_label;
end if;

select ОСТАНОВКА.ид into stopMid1 
from ОСТАНОВКА join МАРШРУТ on (ОСТАНОВКА.ид_маршрута = МАРШРУТ.ид) 
where (х_коор = xi) and (у_коор = yi) and (МАРШРУТ.ид = (select ид_маршрута from ОСТАНОВКА where ид = stop_1)) 
limit 1; 
return query select * from route(stop_1, stopMid1);

select ОСТАНОВКА.ид into peresad1 
from ОСТАНОВКА join МАРШРУТ on (ОСТАНОВКА.ид_маршрута = МАРШРУТ.ид) 
where (х_коор = xi) and (у_коор = yi) and (МАРШРУТ.номер = finallyR)
limit 1;
ост_1 := stopMid1;
ост_2 := peresad1;
транспорт := 'Пересаживаемся на другой номер маршрута';
return next;

select ОСТАНОВКА.ид into peresad2 
from ОСТАНОВКА join МАРШРУТ on (ОСТАНОВКА.ид_маршрута = МАРШРУТ.ид) 
where (х_коор = xj) and (у_коор = yj) and (МАРШРУТ.номер = finallyR)
limit 1;
return query select * from route(peresad1, peresad2);

select ОСТАНОВКА.ид into stopMid2
from ОСТАНОВКА join МАРШРУТ on (ОСТАНОВКА.ид_маршрута = МАРШРУТ.ид) 
where (х_коор = xj) and (у_коор = yj) and (МАРШРУТ.ид = (select ид_маршрута from ОСТАНОВКА where ид = stop_2)) 
limit 1;
ост_1 := peresad2;
ост_2 := stopMid2;
транспорт := 'Пересаживаемся на другой номер маршрута';
return next;
return query select * from route(stopMid2, stop_2);
end if;
end if;
END;
$$;

alter function route(integer, integer) owner to s242419;

