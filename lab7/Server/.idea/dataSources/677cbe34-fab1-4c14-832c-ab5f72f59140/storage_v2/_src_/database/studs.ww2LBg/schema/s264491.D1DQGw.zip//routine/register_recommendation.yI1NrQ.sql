create function register_recommendation(work_id integer, pos_id integer, dep_id integer, optn numeric, bns numeric) returns void
    language plpgsql
as
$$
DECLARE
    worker_instance WORKER;
BEGIN
    SELECT * INTO worker_instance FROM WORKER WHERE work_id = id;
    IF pos_id IS NOT NULL THEN worker_instance.position_id := pos_id; END IF;
    IF dep_id IS NOT NULL THEN worker_instance.department_id := dep_id; END IF;
    IF optn IS NOT NULL THEN worker_instance.option := optn; END IF;
    IF bns IS NOT NULL THEN worker_instance.bonus := bns; END IF;
    INSERT INTO RECOMMENDATION (worker_id, position_id, department_id, option, bonus)
    VALUES (work_id, worker_instance.position_id, worker_instance.department_id, worker_instance.option,
            worker_instance.bonus);
END;
$$;

alter function register_recommendation(integer, integer, integer, numeric, numeric) owner to s264491;

