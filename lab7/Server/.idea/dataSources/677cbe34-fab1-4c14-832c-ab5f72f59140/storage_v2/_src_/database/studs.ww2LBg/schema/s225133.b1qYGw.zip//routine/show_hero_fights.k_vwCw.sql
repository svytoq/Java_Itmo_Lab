create function show_hero_fights(integer) returns integer
    language plpgsql
as
$$
DECLARE
  N alias for $1;
  count INTEGER;
BEGIN
RETURN (SELECT id FROM "Битва" WHERE id_победителя=hero);
END;
$$;

alter function show_hero_fights(integer) owner to s225133;

