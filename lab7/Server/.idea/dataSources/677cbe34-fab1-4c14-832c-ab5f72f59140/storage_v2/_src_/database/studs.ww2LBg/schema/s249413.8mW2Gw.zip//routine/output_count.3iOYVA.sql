create function output_count(id integer) returns integer
    language plpgsql
as
$$
DECLARE
    i INTEGER;
BEGIN
    SELECT DISTINCT count(output_name) into i FROM output o WHERE o.output_id IN (SELECT output_id FROM activity WHERE task_id = id);
RETURN i;
end;
$$;

alter function output_count(integer) owner to s249413;

