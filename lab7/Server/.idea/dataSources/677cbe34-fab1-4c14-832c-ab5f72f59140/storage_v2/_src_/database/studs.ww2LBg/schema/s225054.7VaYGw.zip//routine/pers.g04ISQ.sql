create function pers(count integer) returns text
    language plpgsql
as
$$
BEGIN
FOR i IN 1..count LOOP
INSERT INTO ПЕРСОНАЖИ VALUES(1, 'Гарри', 'Поттер', NULL, NULL, 'Карий', 'Черный', NULL, 'Квиддич', NULL, NULL);
END LOOP;
RETURN 'true';
END;
$$;

alter function pers(integer) owner to s225054;

